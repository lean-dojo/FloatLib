import Lake

open Lake DSL

/-!
# Native executable for the standalone transcendental comparison

This deliberately separate Lake file lets `transcendental_compare.sh` compile the vector emitter
without adding a development-only executable to the main tests workspace.
-/

package FloatLeanTranscendentalHarness where
  srcDir := "LeanFloatTests/Oracle"
  packagesDir := "../.lake/packages"
  buildDir :=
    (get_config? buildDir).map System.FilePath.mk |>.getD defaultBuildDir
  leanOptions := #[⟨`autoImplicit, false⟩, ⟨`relaxedAutoImplicit, false⟩]

require LeanFloat from ".."

lean_exe transcendentalEmitter where
  root := `Transcendentals
