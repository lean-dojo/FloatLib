import Lake

open Lake DSL

def floatLeanRoot : System.FilePath :=
  run_io do
    let some root ← IO.getEnv "FLOATLEAN_ROOT"
      | throw <| IO.userError "FLOATLEAN_ROOT is not set"
    pure root

/-!
# Native runner for the SMT-LIB oracle

This small workspace exists because Lean's interpreter cannot execute every native-only
declaration imported by the conversion runtime. It reuses the repository dependency checkout and
local build directory while exposing only the standalone SMT stream runner as an executable.
-/

package FloatLeanSMTFP where
  packagesDir := floatLeanRoot / ".lake" / "packages"
  buildDir :=
    (get_config? buildDir).map System.FilePath.mk |>.getD <|
      run_io do
        return (← IO.getEnv "LEANFLOAT_BUILD_DIR")
          |>.map System.FilePath.mk
          |>.getD defaultBuildDir
  leanOptions := #[⟨`autoImplicit, false⟩, ⟨`relaxedAutoImplicit, false⟩]

require LeanFloat from floatLeanRoot

lean_exe smtFpRunner where
  root := `LeanFloatTests.Oracle.SMT
  srcDir := floatLeanRoot / "tests"
