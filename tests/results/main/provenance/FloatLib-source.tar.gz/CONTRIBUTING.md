# Contributing to LeanFloat

LeanFloat treats executable arithmetic, its reference semantics, and the proof connecting them as
one feature. A change is complete only when those pieces remain consistent and the affected code
has been checked at the appropriate level.

## Source changes

Use the [source map](README.md#source-map) to choose where a definition or theorem belongs.
Update that map when moving a concept. Keep each Lean module within 1,500 lines and group related
results in dependency order. A separate file is useful when it gives callers a smaller import or
makes a substantial argument easier to follow; individual operations and lemmas rarely need one.

Runtime modules do not import proof facets; a module that must construct validity-carrying
kernels from proved bounds declares `-- architecture: allow-proof-imports` above `module` with a
comment explaining why, and the architecture check counts those exemptions.

Use `UpperCamelCase` module names. Move declarations and update callers when reorganizing; remove
obsolete forwarding files. Preserve the separation between executable definitions and proof-heavy
imports where applications use it.

## Development workflow

Install the pinned Lean toolchain and mathlib cache, then build the module being changed:

```bash
lake update
lake exe cache get
lake build LeanFloat.Floats.Formats.BinaryInterchange
```

Repository scripts keep compiler output outside an EFS checkout. For repeated manual Lake
commands on EFS, use the same helper:

```bash
source tests/lib/lake.sh
leanfloat_lake build LeanFloat.Floats.Formats.BinaryInterchange
```

Work from the smallest useful check to the broadest:

1. Compile the edited module directly.
2. Compile its public entry point and focused regression module.
3. Run `tests/checks/architecture.sh` and `tests/checks/trust-surface.sh`.
4. Run `tests/verify.sh` before a release or a substantial merge.

The full verifier builds and tests the library, runs the linter, checks architecture and public
documentation, and executes maintained regressions. The blueprint is checked separately, after the
library API and documentation are stable, with `blueprint/build.sh`. That command
checks its dependency pins and accepts an output directory, defaulting outside the checkout.
Benchmarking and generated code inspection live under `benchmarks/`; independent oracle
comparisons live under `tests/`. CI runs `tests/verify.sh`, then MPFR primitives/reductions and
two binary16 shards. That is not TestFloat level 1, the P3109 tables, Arb, or
`tests/oracles/check.sh --profile release`. Set
`LEANFLOAT_RUN_INDEPENDENT_CHECKER=1` only for the much larger release kernel-checker pass.

Conformance modules and native correctness runners belong in `tests/`; use
`lake -d tests test` or `leanfloat_test_lake`. The root Lake configuration contains
only the reusable library. Keep both tooling manifests aligned with the root dependency pins.

Benchmark executables belong in `benchmarks/lakefile.lean`; invoke them with
`lake -d benchmarks` or `leanfloat_benchmark_lake`. Keep its manifest aligned with the root pins.
Run `benchmarks/scripts/checks/harness.sh` when changing the benchmark driver or workspace.

## Build configuration

The Lake and Lean options below were each measured on this repository at Lean 4.33.1 on revision
`fb21af8` (776 library modules then, 5003 modules in the import closure of which 2321 are Mathlib)
before deciding whether to set them. The current tree has 796 library modules; those import-closure
figures have not been remeasured. The original measurements were taken on a loaded shared machine;
the relevant comparison in each case is between interleaved runs under the same load, not the
absolute numbers.

Where the time goes. Profiling `lake env lean` on hot modules with `-Dprofiler=true` gives, for
`BinaryInterchange/Rounding/Policy/Agreement.lean`, 15.4 s of import against 24.4 s wall, 1.9 s of
`simp`, 1.0 s of typeclass inference, and 64 ms of linting; for
`Posit/Arithmetic/Limb/Decode/Proof.lean`, 6.1 s of import against 10.4 s wall and 64 ms of
linting; for `P3109/Projection/Direction.lean`, 6.9 s of import, 10.7 s of interpretation (Mathlib
tactic code running in the IR interpreter) and 114 ms of linting against 16.9 s wall. Loading
imports dominates, elaboration comes second, and linting is below one percent everywhere.

Dependency artifacts on local disk. The import cost is almost entirely the cost of opening
Mathlib's compiled modules from `.lake/packages` on EFS. Running the same `lean` process against
a copy of the dependency `lib` directories on local disk (interleaved runs, load 83 to 90) took
import for `Agreement.lean` from 8.5 to 11.3 s down to 1.3 to 1.6 s (wall 13.2 to 14.6 s down to
2.9 to 3.9 s) and for `Posit/.../GuardSticky/Semantics/Candidates.lean` from 4.3 s down to 0.85 s
(wall 6.4 to 7.2 s down to 1.8 to 1.9 s). This is the largest available build-time lever. Lake's
`packagesDir` cannot express it per machine: pointing it elsewhere with `-K` or an environment
variable makes Lake warn that the packages directory changed and keep using the manifest's
`.lake/packages` until `lake update` writes the new, machine-specific path into the tracked
manifest. Instead, on an EFS checkout, move `.lake/packages` to local disk once and leave a
symlink in its place; `.lake` is untracked and Lake follows the link. `LEANFLOAT_BUILD_DIR` (see
`tests/lib/lake.sh`) already keeps the library's own artifacts off EFS.

Reconfiguration. `lake -R ... env true` took 5.3 s against 1.4 s without `-R` on the shared
build directory, so `tests/lib/lake.sh` reconfigures once per root and build directory pair and
reuses that configuration. Every Lake invocation still stats each dependency's manifest and
lakefile (882 EFS paths for nine dependencies, traced with `strace`) but does not re-elaborate
anything. `--no-cache`, `--try-cache`, and the `LAKE_*` cache variables only govern artifact
downloads during `lake build` and are not set.

`precompileModules`. Not set on any package. A throwaway package confirmed that Lake builds a
shared library for every transitive import of a precompiled library, so enabling it on
`LeanFloat` or on `tests/` would compile and link all 5003 modules of the closure, Mathlib
included (its generated C totals 400 MB over 8322 modules; sampled `clang -O3` times ran from
0.09 s for a 10 KB file to 3.1 s for the 1 MB `Mathlib/Tactic/NormNum/Basic.c`). The benefit
would be native execution of `#eval`, `native_decide`, and `#float_info` during elaboration, and
the heaviest conformance modules spend little there: `Conformance/Posit.lean` 0.46 s of
interpretation against 16.7 s of import and 7.6 s of kernel type checking in 40.9 s wall,
`Conformance/Posit/ExecutionBoundaries.lean` 2.3 s of interpretation against 16.7 s of import in
42.8 s wall. Test and benchmark executables are compiled C and do not use the interpreter at all.

`buildType`, `moreLeancArgs`, `moreLinkArgs`. Lake's default `buildType` is `.release`, which
passes `-O3 -DNDEBUG` to `clang` (verified with `lake build -v` on a throwaway package; `.debug`
gives `-O0 -g`). Every test and benchmark executable is therefore already optimized, and the
option is left at its default. The dispatch benchmark alone sets alignment flags, for the reason
recorded next to it in `benchmarks/lakefile.lean`. `-march=native` is deliberately not set:
published benchmark results must be reproducible across hosts.

`leanOptions`. The root package sets `autoImplicit false` and `relaxedAutoImplicit false` (never
weaken these) and `pp.unicode.fun`. Linters stay enabled: they cost 64 to 114 ms per hot module,
below one percent of wall time, and Mathlib-style lint feedback is worth more than that.
`maxHeartbeats` and `maxRecDepth` are limits, not speed settings; no module in the library
overrides them. `debug.skipKernelTC` is never acceptable because it disables kernel checking.
`platformIndependent` and `weakLeanArgs` are not set: the library is built on one platform, and
there are no compiler arguments that should be excluded from build traces.

## Proof and API quality

- Search for an existing definition or theorem before adding one.
- State public theorems at the semantic level a caller needs. Keep backend implementation lemmas
  close to the backend.
- Every optimized executable path must refine the same reference operation used by the public
  `ExecFloat.Proof.*_eq_spec` theorem.
- Preserve exceptional values, signed zero, rounding mode, status flags, and single-rounding
  behavior.
- Do not commit `sorry`, `admit`, project-local axioms, unchecked result substitution, or temporary
  resource overrides.
- Use executable checks and external tools as validation evidence, not as replacements for Lean
  proofs.
- Document stable declarations and write comments for numerical users as well as Lean users:
  explain the mathematical statement, important hypotheses, and why the result matters.
- Keep ordinary application syntax simple. Expert constructors for stored words, descriptors, and
  certificates should remain at explicit interoperability or implementation boundaries.

`#float_info` is the public discovery tool for configured numerical types. Its reports must be
derived from checked declarations and actual selected capabilities. If a range or error theorem is
not registered, `#float_info [errors]` must say so; it must never invent a heuristic estimate.

### Opt-in elementary functions

`Configured/Transcendentals.lean` is an import fence, not a trust-surface item.
`import LeanFloat` does not install `ExecFloat.Binary.exp`, `Model.exp`, `Model.pow`, or
`MathFunctions`. `tests/checks/architecture.sh` forbids production modules from importing the
configured barrel, and allows the model barrel only from that configured module. Kernel files
(`ExpLog.lean`, `Trig.lean`, `Operations/Power.lean`, and their siblings) remain importable by
name. `Info/Profile.lean` still imports `Transcendentals/Contract.lean` so `#float_info` can list
enclosure contracts; that does not expose the kernels. The Arb adapter stays in `tests/`.

### Trust surface

Three boundaries need explicit treatment:

- `Configured/NativeFPU/Unchecked.lean` exposes guarded host arithmetic as an explicit opt-in
  API. Certified `ExecFloat` arithmetic does not import or call it.
  `lake -d tests exe check native` compares that opt-in API with the proved software kernels.
  Numerical agreement is validation evidence, not a refinement theorem.
- The posit `toDyadic?` `@[implemented_by]` in `Posit/Model/Decode.lean`, covered by the equality
  theorem `toDyadicImpl?_eq_toDyadic?` that follows it.
- `native_decide` in finite conformance proofs under `tests/`, counted per file.

`tests/checks/trust-surface.sh` holds the exact allowlists for `native_decide` and for every
`@[implemented_by]` and `@[extern]` attribute. The axiom audit in
`tests/LeanFloatTests/Conformance/Trust/Axioms.lean` cannot see replacement code, so a new
replacement needs either a kernel-checked equality theorem or a targeted compiled test that
executes the replacement body and compares it with the logical definition, plus an allowlist
update. Explicit host APIs that lack a refinement theorem must remain outside
`Backend.Certified`, be named as unchecked, and have targeted differential tests.

### Adding an execution backend

The [backend guide](LeanFloat/Floats/ExecFloat/Backends/README.md) explains the layers and walks
through each step; this is the checklist.

1. State eligibility as a decidable `Prop` over descriptor data (width, field widths, encoding),
   never over a format's name.
2. Put the kernel in a `Runtime.lean` that imports only runtime modules; decline with `none` on
   inputs it does not handle so the dispatcher can fall back to the exact baseline.
3. Prove in the sibling `Proof.lean` that an accepted result equals the `Model.Spec` operation,
   using the theorems in `LeanFloat/Kernels`.
4. Add the guarded branch to the operation's dispatcher under `ExecFloat/Backends/Dispatch/` and
   extend its `word_eq_spec`.
5. Give the route a `Backend.Candidate` estimate and either a `Descriptor.Plan.structuralRoute?`
   entry or a direct `Backend.Certified` candidate in the configured plan. The exact generic
   kernel remains the baseline.
6. Record the expected selections in
   `tests/LeanFloatTests/Conformance/Execution/AutomaticDispatch.lean`, run the code-generation
   checks under `benchmarks/scripts/checks/`, calibrate with `execFloatBackendCalibration`, and
   run `benchmarks/scripts/performance-regression.sh check`.
7. Do not add `@[implemented_by]`; see the trust surface above.

## Comments and documentation

Follow mathlib's [style](https://leanprover-community.github.io/contribute/style.html),
[naming](https://leanprover-community.github.io/contribute/naming.html), and
[documentation guidance](https://leanprover-community.github.io/contribute/doc.html).

A module docstring should explain the mathematical topic and where to start reading. Name useful
definitions or results, and mention assumptions a caller could otherwise miss. Skip descriptions
such as “this module owns the proof surface”; say which property is proved.

Declaration docs should explain meaning, hypotheses, and conventions. Local comments are useful
for an invariant, a non-obvious branch, a representation choice, or a measured performance
tradeoff. Delete comments that narrate a tactic or repeat the next line of code. Keep details such
as signed-zero rules and overflow behavior even when they take a few sentences to explain.

Lead an explanation with a result the reader can observe, then show the code or theorem that
explains it. Test Double's [explanation rule](https://github.com/testdouble/han/blob/main/han-communication/references/explanation-rule.md)
describes this approach. Use “we” when walking through a calculation or explaining a design choice;
describe mathematical claims directly. Credit published work where its result is used, and link
claims about this implementation to its declarations. Attribute personal communications only
when they actually took place.

Keep declaration names focused on the operation and conclusion. Use established mathematical
names such as `sqrt`; put exact hypotheses in the statement and docstring. When shortening a
name, update callers and documentation together and check that no distinct result becomes ambiguous.

## General performance changes

Optimize shared abstractions rather than a list of favored formats. Useful specialization
boundaries are descriptor properties and storage classes such as tiny exhaustive tables, one word,
fixed limb tuples, and general limb sequences.

Before accepting a performance change:

1. Preserve the reference definition and its refinement proof.
2. Measure every affected primitive operation, not only the fastest or easiest row.
3. Compare the public call with the selected kernel when dispatch overhead is relevant.
4. Inspect generated code for planner work, thunk forcing, descriptor reconstruction, boxing, or
   closure allocation in the hot path.
5. Measure compile time and generated size when changing imports, specialization, or inlining.
6. Run the relevant code-generation checks and
   `benchmarks/scripts/performance-regression.sh check`.
7. Run the applicable independent oracle campaign before publishing a new main result.

Use identical already-quantized inputs, result sinks, rounding points, and accepted conformance
checks when comparing implementations. Separate setup and process startup from steady-state
arithmetic. MPFR, Arb, SoftFloat, Stillwater Universal, and Flocq are validators or comparison
implementations; routing a result through them does not make it a LeanFloat proof.

See [the benchmark guide](benchmarks/README.md) for performance methodology and
[the external-validation ledger](tests/EXTERNAL.md) for conformance scope.

## Repository hygiene

- Keep generated build products, external source checkouts, profiler output, and temporary vectors
  outside the repository.
- Keep only the reviewed result bundle under `benchmarks/results/main`.
- Do not weaken or delete a regression merely because a larger external campaign overlaps it.
- Remove a theorem or helper only after repository-wide search shows that a canonical replacement
  preserves its public contract.
- Update documentation and examples in the same change as a public API change.

Before committing, inspect the diff for unrelated edits, stale paths, temporary diagnostics,
machine-specific data, and accidental generated artifacts.
