/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module -- shake: keep-all

public import LeanFloat.Numerics
public import LeanFloat.Kernels
public import LeanFloat.Floats.ExecFloat
public import LeanFloat.Floats.Formats
public import LeanFloat.Floats.Interval

/-!
# Executable numerical formats

Binary, posit, P3109, fixed-point, logarithmic, codebook, block, complex, and interval APIs.
`ExecFloat` provides the common carrier and operation contracts. Each family under `Formats`
defines its encoding, mathematical interpretation, and arithmetic implementations.

Import `LeanFloat.Floats.Formats.<Family>` for one family. New format-independent algorithms belong
under `LeanFloat.Kernels`; definitions and theorems about numerical systems belong under
`LeanFloat.Numerics`. Optional Arb comparisons are in `LeanFloatTests.Arb.Oracle`.
-/

@[expose] public section
