/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Examples.BasicOperations
public import LeanFloat.Examples.CustomFormats
public import LeanFloat.Examples.FormatComparison
public import LeanFloat.Examples.PositQuire
public import LeanFloat.Examples.SpecializedFormats
public import LeanFloat.Examples.Transcendentals

/-!
# LeanFloat examples

Each example starts from a concrete question, shows the code, and records what `#eval` prints in
a comment after each definition. Start with `BasicOperations`, which asks what `0.1 + 0.2` gives
in binary32 and how to prove something about it. The other modules can be read independently:

* `CustomFormats` builds a custom 16-bit binary layout, a 12-bit posit, a decimal fixed-point
  grid, and a P3109 type, and checks which calculations are exact in each.
* `FormatComparison` evaluates one expression as native `Float`, `Float32`, LeanFloat binary64
  and binary32, and Posit32, then rounds one third in all four IEEE directions.
* `PositQuire` computes a dot product in a quire, with no rounding until the end, and proves when
  that accumulation is exact.
* `SpecializedFormats` multiplies logarithmic numbers, looks up a codebook product, and quantizes
  shared-scale and OCP MX blocks.
* `Transcendentals` computes `sin`, `cos`, and a composition of `exp`, `log`, and `tanh`.
  The example file imports `Configured.Transcendentals`; those functions are not installed by
  `import LeanFloat`. It states what is and is not promised about accuracy.

To try a sample in the editor, start a scratch file with `import LeanFloat`. For the
`Transcendentals` example, also import
`LeanFloat.Floats.Formats.BinaryInterchange.Configured.Transcendentals`. Copy the namespace
openings, type aliases, and definitions you need, then add `#eval` followed by the value's name.
Binary values and posits print their exact stored value;
`toString`, string interpolation, and `IO.println` use the same display API.

From the repository root, build all examples with `lake build LeanFloat.Examples`, or run the
comparison with `lake -d tests exe check example`. Copy the examples into an application and
change the inputs or format parameters to explore their behavior. Sample values are private;
the reusable functions, including `PositQuire.dotProduct`, are public.
-/
