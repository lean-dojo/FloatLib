/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange
public import LeanFloat.Floats.Formats.Block
public import LeanFloat.Floats.Formats.Codebook
public import LeanFloat.Floats.Formats.FiniteOnly
public import LeanFloat.Floats.Formats.FixedPoint
public import LeanFloat.Floats.Formats.Flocq
public import LeanFloat.Floats.Formats.IEEE754
public import LeanFloat.Floats.Formats.Logarithmic
public import LeanFloat.Floats.Formats.OCP
public import LeanFloat.Floats.Formats.P3109
public import LeanFloat.Floats.Formats.Posit

/-!
# Executable numerical format families

This hierarchy owns format-specific representation, semantics, capabilities, backends, and
conformance packages. The universal carrier and operation interfaces remain above every family.
-/

@[expose] public section
