/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Backends.WideLimb.Addition.Runtime

/-!
# Wide-limb fused multiply-add runtime

The exact product of two normal significands, formed by the schoolbook limb product, is combined
with the third operand's significand by the same alignment core as addition, `alignAndRound?`,
with the product at twice the significand offset. There is a single rounding. Zero, subnormal,
and exceptional operands and out-of-range results are declined and computed by the reference
operation `Model.Spec.fma`. `Fma.Proof` proves that `fma` equals `Model.Spec.fma`.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model.WideLimb

open LeanFloat.Numerics

/-- Fused multiply-add of three normal stored values, declining every other case. -/
def fmaNormal? (fmt : FloatFormat) (x y z : Value fmt) : Option (Value fmt) :=
  let xExponent := expWord x
  let yExponent := expWord y
  let zExponent := expWord z
  if xExponent == 0 || xExponent == expAllOnes fmt ||
      yExponent == 0 || yExponent == expAllOnes fmt ||
      zExponent == 0 || zExponent == expAllOnes fmt then
    none
  else
    alignAndRound? fmt 0
      (Bool.xor (signBit x) (signBit y)) ((normalMantissa x).mul (normalMantissa y))
      ((xExponent.toNat - 1) + (yExponent.toNat - 1))
      (signBit z) (normalMantissa z)
      ((zExponent.toNat - 1) + FiniteKernel.finiteScaleOffset fmt)

/-- Wide-limb fused multiply-add with the reference operation for declined cases. -/
def fma (fmt : FloatFormat) (x y z : Value fmt) : Value fmt :=
  match fmaNormal? fmt x y z with
  | some result => result
  | none => ofModel (Spec.fma (toModel x) (toModel y) (toModel z))

end LeanFloat.Floats.Formats.BinaryInterchange.Model.WideLimb
