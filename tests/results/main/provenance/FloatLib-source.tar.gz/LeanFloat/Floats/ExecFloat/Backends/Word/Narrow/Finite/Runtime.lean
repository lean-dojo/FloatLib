/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Kernels.FixedWord.Core.Runtime
public import Mathlib.Data.Rat.Cast.Order

/-!
# Finite binary32 runtime coordinates

This module converts finite binary32 fields into the mantissa-and-scale coordinates shared by
native arithmetic kernels. For every nonzero finite value, the coordinates denote
`mantissa * 2^(scale - 149)`. Bounds and decoder agreement live in `Finite.Proof`.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model.NativeBinary32

/-- Decode a finite binary32 significand into one native word. -/
@[inline] def finiteMantissa (exponent fraction : UInt32) : UInt64 :=
  if exponent == 0 then
    fraction.toUInt64
  else
    fraction.toUInt64 ||| 0x800000

/--
Encode the exact finite exponent as a nonnegative scale, with value `mantissa * 2^(scale - 149)`.

The binary32 entry point only widens its native field; the scale rule itself is shared with every
word kernel.
-/
@[always_inline, inline] def finiteScale (exponent : UInt32) : UInt64 :=
  LeanFloat.Numerics.FixedWord.finiteScale exponent.toUInt64

end LeanFloat.Floats.Formats.BinaryInterchange.Model.NativeBinary32
