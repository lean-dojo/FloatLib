/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Backends.Generic.AddDyadic.Proof
import LeanFloat.Numerics.Exact.Dyadic.Arithmetic.Proof

/-!
# Exact dyadic alignment lemmas

These lemmas normalize exact dyadic addition to a shared exponent. They are independent of any
particular arithmetic operation and support both native addition and fused multiply-add proofs.

The executable kernels align bounded significands with shifts, whereas their specifications add
mathematical dyadics. The bridge here covers sign and zero-shift cases, letting each operation
proof focus on its own rounding and packing behavior.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model.NativeBinary32

/-- Align the right dyadic magnitude to the left exponent without changing the exact sum. -/
theorem addDyadic_alignRightOffset
    (offset : Nat) (xSign ySign : Bool)
    (xMagnitude yMagnitude xScale yScale : Nat)
    (hx : xMagnitude ≠ 0) (hy : yMagnitude ≠ 0)
    (hscale : xScale ≤ yScale) :
    Model.addDyadic
        { negative := xSign
          significand := xMagnitude
          exponent := Int.ofNat xScale - Int.ofNat offset }
        { negative := ySign
          significand := yMagnitude
          exponent := Int.ofNat yScale - Int.ofNat offset } =
      Model.addDyadic
        { negative := xSign
          significand := xMagnitude
          exponent := Int.ofNat xScale - Int.ofNat offset }
        { negative := ySign
          significand := yMagnitude <<< (yScale - xScale)
          exponent := Int.ofNat xScale - Int.ofNat offset } := by
  have hscaleInt :
      Int.ofNat xScale - Int.ofNat offset ≤
        Int.ofNat yScale - Int.ofNat offset := by
    simp only [Int.ofNat_eq_natCast]
    omega
  have hshift :
      Int.toNat
          ((Int.ofNat yScale - Int.ofNat offset) -
            (Int.ofNat xScale - Int.ofNat offset)) =
        yScale - xScale := by
    simp only [Int.ofNat_eq_natCast]
    omega
  simpa [Model.addDyadic, hshift] using
    Numerics.Dyadic.add_align_right_to_left_exponent
      xSign ySign xMagnitude yMagnitude
      (Int.ofNat xScale - Int.ofNat offset)
      (Int.ofNat yScale - Int.ofNat offset)
      hx hy hscaleInt

/-- Align the left dyadic magnitude to the right exponent without changing the exact sum. -/
theorem addDyadic_alignLeftOffset
    (offset : Nat) (xSign ySign : Bool)
    (xMagnitude yMagnitude xScale yScale : Nat)
    (hx : xMagnitude ≠ 0) (hy : yMagnitude ≠ 0)
    (hscale : yScale < xScale) :
    Model.addDyadic
        { negative := xSign
          significand := xMagnitude
          exponent := Int.ofNat xScale - Int.ofNat offset }
        { negative := ySign
          significand := yMagnitude
          exponent := Int.ofNat yScale - Int.ofNat offset } =
      Model.addDyadic
        { negative := xSign
          significand := xMagnitude <<< (xScale - yScale)
          exponent := Int.ofNat yScale - Int.ofNat offset }
        { negative := ySign
          significand := yMagnitude
          exponent := Int.ofNat yScale - Int.ofNat offset } := by
  have hscaleInt :
      Int.ofNat yScale - Int.ofNat offset <
        Int.ofNat xScale - Int.ofNat offset := by
    simp only [Int.ofNat_eq_natCast]
    omega
  have hshift :
      Int.toNat
          ((Int.ofNat xScale - Int.ofNat offset) -
            (Int.ofNat yScale - Int.ofNat offset)) =
        xScale - yScale := by
    simp only [Int.ofNat_eq_natCast]
    omega
  simpa [Model.addDyadic, hshift] using
    Numerics.Dyadic.add_align_left_to_right_exponent
      xSign ySign xMagnitude yMagnitude
      (Int.ofNat xScale - Int.ofNat offset)
      (Int.ofNat yScale - Int.ofNat offset)
      hx hy hscaleInt

/-- Exact addition of two nonzero dyadics with the same sign and exponent. -/
theorem addDyadic_sameSign_sameExp
    (sign : Bool) (a b : Nat) (exponent : Int)
    (ha : a ≠ 0) (hb : b ≠ 0) :
    Model.addDyadic
        { negative := sign, significand := a, exponent := exponent }
        { negative := sign, significand := b, exponent := exponent } =
      { negative := sign, significand := b + a, exponent := exponent } := by
  simpa [Nat.add_comm] using
    Model.addDyadic_sameSign_sameExponent sign a b exponent ha hb

end LeanFloat.Floats.Formats.BinaryInterchange.Model.NativeBinary32
