/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Kernels.FixedWord.Quotient.Proof
public import LeanFloat.Floats.Formats.BinaryInterchange.DirectedSemantics.Rational.NearestEven

/-!
# Shared bounds for native-word quotient kernels

The one-word and binary64 division backends use different packing code, but they normalize the
same exact rational quotient. This module proves the representation-independent facts once:

* the normalization shift is nonnegative,
* nearest-even rounding produces one or two leading significand bits, and
* the restoring quotient and its carry bit fit in the `UInt64` kernel.

The final width hypothesis is about the native representation, not a floating-point format
restriction. Wider formats use a multiword quotient kernel while keeping the same rational
specification.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model.NativeWordQuotient

open LeanFloat.Numerics.FixedWord.RestoringQuotient

/-- The normalizing shift computed by the native kernel is the corresponding integer difference. -/
theorem normalShift_eq
    (fmt : FloatFormat) (num den : UInt64)
    (hnum : num ≠ 0)
    (hnumFit : num.toNat < 2 ^ (fmt.fracWidth + 1)) :
    let rationalExponent := floorLog2RatWord num den
    let shift := Int.toNat (Int.ofNat fmt.fracWidth - rationalExponent)
    Int.ofNat shift =
      Int.ofNat fmt.fracWidth - rationalExponent := by
  have hnumLog :
      num.log2.toNat < fmt.fracWidth + 1 :=
    LeanFloat.Numerics.FixedWord.log2_toNat_lt_of_toNat_lt_two_pow
      num (fmt.fracWidth + 1) hnum hnumFit
  have hrange := floorLog2RatWord_log_bounds num den
  simp only [Int.ofNat_eq_natCast] at hrange
  have hnumLogLe :
      (num.log2.toNat : Int) ≤ Int.ofNat fmt.fracWidth := by
    simp only [Int.ofNat_eq_natCast]
    omega
  have hnonnegative :
      0 ≤ Int.ofNat fmt.fracWidth -
        floorLog2RatWord num den := by
    have hfloorLe := hrange.2
    omega
  exact Int.toNat_of_nonneg hnonnegative

/--
The normalized numerator and its shift fit the signed-width budget used by the `UInt64` quotient
kernel.

The condition `2 * (fracWidth + 1) ≤ 63` is the representation boundary for this direct shifted
numerator path. It is satisfied by binary32 and other narrow formats; wider one-word formats use
the restoring loop without first materializing the whole shifted numerator.
-/
theorem normalShift_bounds
    (fmt : FloatFormat) (num den : UInt64)
    (hnum : num ≠ 0) (hden : den ≠ 0)
    (hnumFit : num.toNat < 2 ^ (fmt.fracWidth + 1))
    (hdenFit : den.toNat < 2 ^ (fmt.fracWidth + 1))
    (hbudget : 2 * (fmt.fracWidth + 1) ≤ 63) :
    let rationalExponent := floorLog2RatWord num den
    let shift := Int.toNat (Int.ofNat fmt.fracWidth - rationalExponent)
    shift < 64 ∧ num.toNat <<< shift < 2 ^ 63 := by
  let rationalExponent := floorLog2RatWord num den
  let shift := Int.toNat (Int.ofNat fmt.fracWidth - rationalExponent)
  have hnumLog :
      num.log2.toNat < fmt.fracWidth + 1 :=
    LeanFloat.Numerics.FixedWord.log2_toNat_lt_of_toNat_lt_two_pow
      num (fmt.fracWidth + 1) hnum hnumFit
  have hdenLog :
      den.log2.toNat < fmt.fracWidth + 1 :=
    LeanFloat.Numerics.FixedWord.log2_toNat_lt_of_toNat_lt_two_pow
      den (fmt.fracWidth + 1) hden hdenFit
  have hrange := floorLog2RatWord_log_bounds num den
  simp only [Int.ofNat_eq_natCast] at hrange
  have hshiftInt :
      Int.ofNat shift =
        Int.ofNat fmt.fracWidth - rationalExponent :=
    normalShift_eq fmt num den hnum hnumFit
  simp only [Int.ofNat_eq_natCast] at hshiftInt
  have hshiftLt : shift < 64 := by
    dsimp only [rationalExponent] at hshiftInt
    omega
  have hexponent :
      num.log2.toNat + 1 + shift ≤ 63 := by
    dsimp only [rationalExponent] at hshiftInt
    omega
  have hbound :
      num.toNat <<< shift <
        2 ^ (num.toNat.log2 + 1 + shift) :=
    Nat.shiftLeft_lt Nat.lt_log2_self
  rw [← LeanFloat.Numerics.FixedWord.log2_toNat] at hbound
  exact ⟨hshiftLt, lt_of_lt_of_le hbound <|
    Nat.pow_le_pow_right (by decide) hexponent⟩

/-- Normalized nearest-even quotient rounding stays within the expected significand interval. -/
theorem roundedMantissa_bounds
    (fmt : FloatFormat) (num den : UInt64)
    (hnum : num ≠ 0) (hden : den ≠ 0)
    (hnumFit : num.toNat < 2 ^ (fmt.fracWidth + 1)) :
    let rationalExponent := floorLog2RatWord num den
    let shift := Int.toNat (Int.ofNat fmt.fracWidth - rationalExponent)
    2 ^ fmt.fracWidth ≤
        Numerics.roundQuotientEven
          (num.toNat <<< shift) den.toNat ∧
      Numerics.roundQuotientEven
          (num.toNat <<< shift) den.toNat ≤
        2 ^ (fmt.fracWidth + 1) := by
  let rationalExponent := floorLog2RatWord num den
  let shift := Int.toNat (Int.ofNat fmt.fracWidth - rationalExponent)
  have hnumNat : num.toNat ≠ 0 := by
    simpa [← UInt64.toNat_inj] using hnum
  have hdenNat : den.toNat ≠ 0 := by
    simpa [← UInt64.toNat_inj] using hden
  have hfloor := floorLog2RatWord_eq num den hnum hden
  have hshift := normalShift_eq fmt num den hnum hnumFit
  have hscaled :
      Numerics.RationalBinary.scaleByPowerOfTwo num.toNat den.toNat
          (Int.ofNat fmt.fracWidth -
            Numerics.RationalBinary.floorLog2 num.toNat den.toNat) =
        (num.toNat <<< shift, den.toNat) := by
    rw [← hfloor, ← hshift]
    rfl
  have hrounded :=
    Model.roundQuotientEven_normal_bounds
      fmt num.toNat den.toNat hnumNat hdenNat
  dsimp only at hrounded
  rw [hscaled] at hrounded
  simpa only [Model.pow2_eq_two_pow] using hrounded

/--
The restoring quotient and a possible rounding increment fit below bit 63.

Bit 63 remains free because the implementation uses a signed-width comparison while producing
the final quotient bits. All currently selected one-word formats satisfy the stronger bound
`fracWidth ≤ 61`.
-/
theorem quotient_lt_two_pow_63
    (fmt : FloatFormat) (num den : UInt64)
    (hnum : num ≠ 0) (hden : den ≠ 0)
    (hnumFit : num.toNat < 2 ^ (fmt.fracWidth + 1))
    (hfracWidth : fmt.fracWidth ≤ 61) :
    let rationalExponent := floorLog2RatWord num den
    let shift := Int.toNat (Int.ofNat fmt.fracWidth - rationalExponent)
    (num.toNat <<< shift) / den.toNat + 1 < 2 ^ 63 := by
  let rationalExponent := floorLog2RatWord num den
  let shift := Int.toNat (Int.ofNat fmt.fracWidth - rationalExponent)
  have hdenNat : den.toNat ≠ 0 := by
    simpa [← UInt64.toNat_inj] using hden
  have hroundedUpper :
      Numerics.roundQuotientEven
          (num.toNat <<< shift) den.toNat ≤
        2 ^ (fmt.fracWidth + 1) :=
    (roundedMantissa_bounds fmt num den hnum hden hnumFit).2
  have hfloorLe :
      (num.toNat <<< shift) / den.toNat ≤
        Numerics.roundQuotientEven
          (num.toNat <<< shift) den.toNat := by
    have hsandwich :=
      Model.roundQuotDirected_false_le_roundQuotientEven_le_true
        (num.toNat <<< shift) den.toNat hdenNat
    simpa [Model.roundQuotDirected] using hsandwich.1
  change
    (num.toNat <<< shift) / den.toNat + 1 < 2 ^ 63
  have hpow : 2 ^ (fmt.fracWidth + 1) < 2 ^ 63 :=
    Nat.pow_lt_pow_right (by decide) (by omega)
  omega

end LeanFloat.Floats.Formats.BinaryInterchange.Model.NativeWordQuotient
