/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Backends.Word.Narrow.Rounding.Proof
public import LeanFloat.Kernels.FixedWord.SignedMagnitude.Proof
public import LeanFloat.Floats.Formats.BinaryInterchange.Dyadic.Rounding

/-!
# Refinement of native signed-magnitude addition

This module proves that the shared `UInt64` signed-magnitude primitive denotes exact dyadic
addition before binary32 rounding. Keeping the proof separate preserves the small runtime import
surface of `Word.SignedMagnitude.Runtime`.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model.NativeBinary32

/--
Round one exact signed-magnitude sum at a shared native scale.

The hypotheses state the nonzero and no-overflow invariants required by the `UInt64` kernel.
-/
theorem roundAddMagnitudesAtScale_eq_roundDyadic
    (xSign ySign : Bool) (xMagnitude yMagnitude scale : UInt64)
    (hx : xMagnitude ≠ 0) (hy : yMagnitude ≠ 0)
    (hsum : xMagnitude.toNat + yMagnitude.toNat < 2 ^ 64)
    (hscale : scale.toNat ≤ 506) :
    roundProduct
        (LeanFloat.Numerics.FixedWord.addSignedMagnitudes
          xSign ySign xMagnitude yMagnitude).1
        (LeanFloat.Numerics.FixedWord.addSignedMagnitudes
          xSign ySign xMagnitude yMagnitude).2
        scale =
      roundDyadic
        (Model.addDyadic
          { negative := xSign
            significand := xMagnitude.toNat
            exponent := Int.ofNat scale.toNat - 298 }
          { negative := ySign
            significand := yMagnitude.toNat
            exponent := Int.ofNat scale.toNat - 298 }) := by
  have hround := roundProduct_eq_roundDyadic
    (LeanFloat.Numerics.FixedWord.addSignedMagnitudes
      xSign ySign xMagnitude yMagnitude).1
    (LeanFloat.Numerics.FixedWord.addSignedMagnitudes
      xSign ySign xMagnitude yMagnitude).2
    scale hscale
  rw [hround]
  have hexact :
      LeanFloat.Numerics.FixedWord.signedMagnitudeDyadic
          (LeanFloat.Numerics.FixedWord.addSignedMagnitudes
            xSign ySign xMagnitude yMagnitude).1
          (LeanFloat.Numerics.FixedWord.addSignedMagnitudes
            xSign ySign xMagnitude yMagnitude).2
          (Int.ofNat scale.toNat - 298) =
        Model.addDyadic
          { negative := xSign
            significand := xMagnitude.toNat
            exponent := Int.ofNat scale.toNat - 298 }
          { negative := ySign
            significand := yMagnitude.toNat
            exponent := Int.ofNat scale.toNat - 298 } := by
    simpa [Model.addDyadic, LeanFloat.Numerics.Dyadic.add] using
      (LeanFloat.Numerics.FixedWord.signedMagnitudeDyadic_addSignedMagnitudes_eq_addFields
          xSign ySign xMagnitude yMagnitude
          (Int.ofNat scale.toNat - 298)
          hx hy (fun _ => hsum))
  rw [← hexact]
  by_cases hzero :
      (LeanFloat.Numerics.FixedWord.addSignedMagnitudes
        xSign ySign xMagnitude yMagnitude).2 = 0
  · have hsign :=
      LeanFloat.Numerics.FixedWord.addSignedMagnitudes_sign_eq_false_of_magnitude_eq_zero
          xSign ySign xMagnitude yMagnitude hx hy (fun _ => hsum) hzero
    simp [LeanFloat.Numerics.FixedWord.signedMagnitudeDyadic,
      hzero, hsign, roundDyadic]
  · simp [LeanFloat.Numerics.FixedWord.signedMagnitudeDyadic, hzero]

end LeanFloat.Floats.Formats.BinaryInterchange.Model.NativeBinary32
