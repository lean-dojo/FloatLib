# Execution backends

`Kernels/` is the shared toolbox. The code that runs `x + y` is chosen here. Every candidate is
certified (`run = spec`) before the planner looks at cost.

Layers: Numerics (exact values, contracts) → Kernels (integer algorithms) → this directory
(format-level backends) → `Backends/Dispatch` (try specialized kernel, else exact baseline) →
a `Capability` whose planner picks one certified candidate. Only that last step uses a cost model.

## Backends

Eligibility is a decidable proposition on descriptor data, never a format name. A custom
`ExecFloat.Binary` with the same layout gets the same backend. Shared word pieces
(`Word/NormalPair`, `ProductRound`, `Quotient`, `ModelSqrt`) are not separately selectable.

| Directory | Class | Eligible | Ops | Status |
| --- | --- | --- | --- | --- |
| `TinyTable/` (tables built in `Configured/ByteTable/`) | exhaustive table | ≤ 8 encoded bits | six | proved |
| `Word/Small/` | native-word | IEEE ≤ 64 bits; tighter caps on add/div/mul | six | proved |
| `Word/TwoWordMul/` | via fixed-limb route | IEEE ≤ 64 bits, 32–62 fraction bits | mul | proved |
| `Word/Narrow/` | fixed-format | exactly binary32 | six | proved |
| `Word/Full/` | fixed-format | exactly binary64 | six | proved |
| `FixedLimb/Pair/` | two `UInt64` limbs | IEEE, `64 < fracWidth`, `bitWidth ≤ 128` | six; sqrt declines some layouts | proved |
| `WideLimb/` | 32-bit limbs | IEEE > 128 bits, exponent ≤ 32; `ExecFloat.BinaryLimbs` | add, sub, mul, fma (else exact) | proved |
| `Generic/` | exact baseline | every binary descriptor | six | proved |
| `Configured/NativeFPU/Unchecked.lean` | not a planner class | binary32/64, explicit call site | add, sub, mul, div, sqrt (not fma) | unchecked |

| Type | Selected (balanced policy) |
| --- | --- |
| `ExecFloat.Binary 8 23` | all six = fixed-format |
| `ExecFloat.Binary 5 10` | all six = native-word (`UInt16`) |
| `ExecFloat.Binary 4 3` | add/sub/mul/div = native-word; sqrt = table; fma = exact |
| `ExecFloat.Binary 15 112` | all six = fixed-limb |
| `ExecFloat.Binary 19 236` | all six = exact (proof-model carrier has no specialized kernel > 128) |
| `ExecFloat.BinaryLimbs 19 236` | add/sub/mul/fma = wide-limb; div/sqrt = exact |

Posits use `Formats/Posit/Configured/Backend/` with the same `Certified` / `PolicyFor` machinery.

`#float_info T` prints the selection; `#float_info! T` prints scores. Programmatic:
`ExecFloat.Add.selectedCandidate (F := F)`, `Backend.selectionReport`.

## Policy

Default: `Backend.Policy.default` (100k expected calls, 1 MiB resident). Scoped switches:

```lean
open scoped LeanFloat.Floats.ExecFloat.Backend.PlanningLatency     -- one call; skip table setup
open scoped LeanFloat.Floats.ExecFloat.Backend.PlanningThroughput   -- 5M calls, 16 MiB ceiling
```

A local `PolicyFor` instance can retune one family. Values, literals, and theorems do not change:
every candidate was already `run = spec`. Binary32/64 stay on proved software under every policy.
Host speed is an explicit call:

```lean
NativeFPU.Unchecked.add32 x y
```

No scoped `ExecFloat.Add` instance for host ops: a capability must contain `Backend.Certified`.

## Adding a backend

Model: the one-word kernels. No `@[implemented_by]`. Runtime and proof modules stay separate.
Keep modules under 1,500 lines.

1. **Eligibility.** Decidable `Prop` on descriptor data (`if h : … then isTrue h else isFalse h`,
   not `inferInstanceAs`). Do not test a format name.
2. **Kernel.** `Runtime.lean`, runtime imports only. Decline with `none`; dispatcher falls back.
   Use `LeanFloat/Kernels`.
3. **Proof.** Sibling `Proof.lean`: `kernel? x y = some r → r = Model.Spec.add x y`.
4. **Dispatcher.** Branch in `Dispatch/<Op>/Runtime.lean`; extend `word_eq_spec`.
5. **Certificate.** `Backend.Candidate` estimate; `Certified.binary` for representation-specific
   kernels. Mandatory baseline remains the exact generic kernel.
6. **Registration.** Eligible `ExecFloat.Binary` types offer the candidate automatically.
   Dominant under every policy: `Backend.selectCertified_cons_of_dominant`.
7. **Tests.** Expected selections in `tests/.../AutomaticDispatch.lean`; codegen scripts under
   `benchmarks/scripts/checks/`; measure with `execFloatBackendCalibration`; then
   `performance-regression.sh check`. Change a cost prior only after three isolated trials beat
   the selected candidate.
