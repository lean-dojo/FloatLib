/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Backends.TinyTable.Generic.Core

/-!
# Exhaustive byte-table construction

This module generates dense unary, binary, and ternary tables from exact model operations. Tables
are stored in Lean runtime `Thunk` cells, so construction is lazy and memoized while the warm path
performs no model evaluation.
-/

@[expose] public section

namespace LeanFloat.Floats.ExecFloat.Backend.TinyTable

universe u

variable {Model : Type u}

/-- Build the row-major byte table of a total binary model operation. -/
def binaryTotal (encoding : Encoding Model) (op : Model → Model → Model) : ByteArray :=
  ByteArray.ofFn fun index : Fin (encoding.radix * encoding.radix) =>
    let left : Fin encoding.radix :=
      ⟨index.val / encoding.radix, by
        exact Nat.div_lt_iff_lt_mul encoding.radix_pos |>.2 (by
          simpa only [Nat.mul_comm] using index.isLt)⟩
    let right : Fin encoding.radix :=
      ⟨index.val % encoding.radix, Nat.mod_lt _ encoding.radix_pos⟩
    UInt8.ofNat (encoding.encode (op (encoding.decode left) (encoding.decode right))).val

/-- Build the dense byte table of a total unary model operation. -/
def unaryTotal (encoding : Encoding Model) (op : Model → Model) : ByteArray :=
  ByteArray.ofFn fun index : Fin encoding.radix =>
    UInt8.ofNat (encoding.encode (op (encoding.decode index))).val

/-- Build the row-major byte table of a total ternary model operation. -/
def ternaryTotal
    (encoding : Encoding Model) (op : Model → Model → Model → Model) : ByteArray :=
  ByteArray.ofFn fun index :
      Fin (encoding.radix * encoding.radix * encoding.radix) =>
    let pair := index.val / encoding.radix
    let left : Fin encoding.radix :=
      ⟨pair / encoding.radix, by
        have hpair : pair < encoding.radix * encoding.radix := by
          exact Nat.div_lt_iff_lt_mul encoding.radix_pos |>.2 (by
            simpa [Nat.mul_assoc] using index.isLt)
        exact Nat.div_lt_iff_lt_mul encoding.radix_pos |>.2 (by
          simpa [Nat.mul_comm] using hpair)⟩
    let right : Fin encoding.radix :=
      ⟨pair % encoding.radix, Nat.mod_lt _ encoding.radix_pos⟩
    let addend : Fin encoding.radix :=
      ⟨index.val % encoding.radix, Nat.mod_lt _ encoding.radix_pos⟩
    UInt8.ofNat <|
      (encoding.encode <|
        op (encoding.decode left) (encoding.decode right) (encoding.decode addend)).val

/-- Delay and memoize a total binary table. -/
def lazyBinaryTotal
    (encoding : Encoding Model) (op : Model → Model → Model) : Thunk ByteArray :=
  Thunk.mk fun _ => binaryTotal encoding op

/-- Delay and memoize a total unary table. -/
def lazyUnaryTotal
    (encoding : Encoding Model) (op : Model → Model) : Thunk ByteArray :=
  Thunk.mk fun _ => unaryTotal encoding op

/-- Delay and memoize a total ternary table. -/
def lazyTernaryTotal
    (encoding : Encoding Model) (op : Model → Model → Model → Model) : Thunk ByteArray :=
  Thunk.mk fun _ => ternaryTotal encoding op

/-- Forcing a lazy binary table yields the corresponding exhaustive table. -/
@[simp] theorem lazyBinaryTotal_get
    (encoding : Encoding Model) (op : Model → Model → Model) :
    (lazyBinaryTotal encoding op).get = binaryTotal encoding op := by
  rfl

/-- Forcing a lazy unary table yields the corresponding exhaustive table. -/
@[simp] theorem lazyUnaryTotal_get
    (encoding : Encoding Model) (op : Model → Model) :
    (lazyUnaryTotal encoding op).get = unaryTotal encoding op := by
  rfl

/-- Forcing a lazy ternary table yields the corresponding exhaustive table. -/
@[simp] theorem lazyTernaryTotal_get
    (encoding : Encoding Model) (op : Model → Model → Model → Model) :
    (lazyTernaryTotal encoding op).get = ternaryTotal encoding op := by
  rfl

end LeanFloat.Floats.ExecFloat.Backend.TinyTable
