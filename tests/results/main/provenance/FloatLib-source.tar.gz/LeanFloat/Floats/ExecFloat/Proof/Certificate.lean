/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Proof.Arithmetic

/-!
# Discoverable certificate for the complete core arithmetic surface

The operation typeclasses already require every executable kernel to carry its refinement proof.
`FullArithmeticCertificate` quantifies those six existing proofs over the shared operation enum;
it introduces no second arithmetic API, backend, or trusted axiom.

Users can request this bundle when they want one machine-checked answer to “which core operations
are certified for this format?” Formats supporting only a subset of operations continue to expose
their individual `ExecFloat.Proof.*_eq_spec` theorems.

The certificate covers the universal execution boundary: each public operation equals the
specification stored by its format capability. Standards conformance and denotational properties
of that specification remain separate format-family theorems; this bundle does not manufacture
those properties for an arbitrary instance.
-/

@[expose] public section

namespace LeanFloat.Floats.ExecFloat.Proof

open LeanFloat.Numerics

universe u

/-- Pointwise specification-refinement proposition for one universal operation. -/
def OperationRefines
    (F : Type u)
    [LeanFloat.Floats.ExecFloat.Backend.PolicyFor F]
    [EncodedFormat F]
    [LeanFloat.Floats.ExecFloat.Add F]
    [LeanFloat.Floats.ExecFloat.Sub F]
    [LeanFloat.Floats.ExecFloat.Mul F]
    [LeanFloat.Floats.ExecFloat.Div F]
    [LeanFloat.Floats.ExecFloat.Sqrt F]
    [LeanFloat.Floats.ExecFloat.Fma F] :
    LeanFloat.Floats.ExecFloat.Backend.Operation → Prop
  | .add =>
    ∀ left right : LeanFloat.Floats.ExecFloat F,
      LeanFloat.Floats.ExecFloat.add left right =
        LeanFloat.Floats.ExecFloat.Spec.add left right
  | .sub =>
    ∀ left right : LeanFloat.Floats.ExecFloat F,
      LeanFloat.Floats.ExecFloat.sub left right =
        LeanFloat.Floats.ExecFloat.Spec.sub left right
  | .mul =>
    ∀ left right : LeanFloat.Floats.ExecFloat F,
      LeanFloat.Floats.ExecFloat.mul left right =
        LeanFloat.Floats.ExecFloat.Spec.mul left right
  | .div =>
    ∀ left right : LeanFloat.Floats.ExecFloat F,
      LeanFloat.Floats.ExecFloat.div left right =
        LeanFloat.Floats.ExecFloat.Spec.div left right
  | .sqrt =>
    ∀ value : LeanFloat.Floats.ExecFloat F,
      LeanFloat.Floats.ExecFloat.sqrt value =
        LeanFloat.Floats.ExecFloat.Spec.sqrt value
  | .fma =>
    ∀ left right addend : LeanFloat.Floats.ExecFloat F,
      LeanFloat.Floats.ExecFloat.fma left right addend =
        LeanFloat.Floats.ExecFloat.Spec.fma left right addend

/--
Kernel-checked refinement evidence for every universal arithmetic operation on one format.

Indexing by `Backend.Operation` avoids a second six-field record parallel to the executable
capability hierarchy. This proposition certifies execution against the installed specifications;
it does not replace format-specific theorems about what those specifications mean.
-/
abbrev FullArithmeticCertificate
    (F : Type u)
    [LeanFloat.Floats.ExecFloat.Backend.PolicyFor F]
    [EncodedFormat F]
    [LeanFloat.Floats.ExecFloat.Add F]
    [LeanFloat.Floats.ExecFloat.Sub F]
    [LeanFloat.Floats.ExecFloat.Mul F]
    [LeanFloat.Floats.ExecFloat.Div F]
    [LeanFloat.Floats.ExecFloat.Sqrt F]
    [LeanFloat.Floats.ExecFloat.Fma F] : Prop :=
  ∀ operation, OperationRefines F operation

/--
Collect the proofs already required by the six operation capabilities.

No proof is recovered from testing: each component is the corresponding typeclass certificate
checked by Lean's kernel.
-/
theorem fullArithmeticCertificate
    (F : Type u)
    [LeanFloat.Floats.ExecFloat.Backend.PolicyFor F]
    [EncodedFormat F]
    [LeanFloat.Floats.ExecFloat.Add F]
    [LeanFloat.Floats.ExecFloat.Sub F]
    [LeanFloat.Floats.ExecFloat.Mul F]
    [LeanFloat.Floats.ExecFloat.Div F]
    [LeanFloat.Floats.ExecFloat.Sqrt F]
    [LeanFloat.Floats.ExecFloat.Fma F] :
    FullArithmeticCertificate F := by
  intro operation
  cases operation with
  | add => exact add_eq_spec
  | sub => exact sub_eq_spec
  | mul => exact mul_eq_spec
  | div => exact div_eq_spec
  | sqrt => exact sqrt_eq_spec
  | fma => exact fma_eq_spec

end LeanFloat.Floats.ExecFloat.Proof
