/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Core.Operations

/-!
# Reference arithmetic for `ExecFloat`

Names for the six reference operations supplied by arithmetic capabilities. Use them with the
refinement equations in `ExecFloat.Proof` to reason about an executable arithmetic expression.

Each reference operation is the `spec` field of the format's `Capability`, and `Capability` is
indexed by the planning policy `[Backend.PolicyFor F]` because the same class also stores the
selected implementation. The specification itself does not depend on the policy: every capability
instance for a format supplies the same `spec`, and only the executed kernel changes with the
policy. Separating the specification into its own class would let these definitions drop the
policy argument, but it would also split every family's capability instances in two, so we keep
the extra argument and note it here. In practice the default `PolicyFor` instance is found
automatically and the argument is invisible at use sites.
-/

@[expose] public section

namespace LeanFloat.Floats.ExecFloat.Spec

open LeanFloat.Numerics

universe u

variable {F : Type u} [LeanFloat.Floats.ExecFloat.Backend.PolicyFor F]
    [EncodedFormat F]

/--
Clear reference definition of addition for this format.

Proofs use this definition to state the required result. Numerical code should normally call
`ExecFloat.add` or use `+`.
-/
def add [LeanFloat.Floats.ExecFloat.Add F]
    (left right : LeanFloat.Floats.ExecFloat F) : LeanFloat.Floats.ExecFloat F :=
  LeanFloat.Floats.ExecFloat.Add.spec left right

/--
Clear reference definition of subtraction for this format.

Proofs use this definition to state the required result. Numerical code should normally call
`ExecFloat.sub` or use `-`.
-/
def sub [LeanFloat.Floats.ExecFloat.Sub F]
    (left right : LeanFloat.Floats.ExecFloat F) : LeanFloat.Floats.ExecFloat F :=
  LeanFloat.Floats.ExecFloat.Sub.spec left right

/--
Clear reference definition of multiplication for this format.

Proofs use this definition to state the required result. Numerical code should normally call
`ExecFloat.mul` or use `*`.
-/
def mul [LeanFloat.Floats.ExecFloat.Mul F]
    (left right : LeanFloat.Floats.ExecFloat F) : LeanFloat.Floats.ExecFloat F :=
  LeanFloat.Floats.ExecFloat.Mul.spec left right

/--
Clear reference definition of division for this format.

Proofs use this definition to state the required result. Numerical code should normally call
`ExecFloat.div` or use `/`.
-/
def div [LeanFloat.Floats.ExecFloat.Div F]
    (left right : LeanFloat.Floats.ExecFloat F) : LeanFloat.Floats.ExecFloat F :=
  LeanFloat.Floats.ExecFloat.Div.spec left right

/--
Clear reference definition of square root for this format.

Proofs use this definition to state the required result. Numerical code should normally call
`ExecFloat.sqrt` or use `.sqrt`.
-/
def sqrt [LeanFloat.Floats.ExecFloat.Sqrt F]
    (value : LeanFloat.Floats.ExecFloat F) : LeanFloat.Floats.ExecFloat F :=
  LeanFloat.Floats.ExecFloat.Sqrt.spec value

/--
Clear reference definition of fused multiply-add for this format.

Proofs use this definition to state the required one-rounding result. Numerical code should
normally call `ExecFloat.fma`.
-/
def fma [LeanFloat.Floats.ExecFloat.Fma F]
    (left right addend : LeanFloat.Floats.ExecFloat F) : LeanFloat.Floats.ExecFloat F :=
  LeanFloat.Floats.ExecFloat.Fma.spec left right addend

end LeanFloat.Floats.ExecFloat.Spec
