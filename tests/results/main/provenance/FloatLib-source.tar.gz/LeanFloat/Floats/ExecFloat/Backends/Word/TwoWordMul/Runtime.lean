/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Kernels.FixedWord.LimbRound.Runtime
public import LeanFloat.Floats.ExecFloat.Backends.Word.ProductRound.Runtime

/-!
# Native two-word finite multiplication

This is the executable `64 x 64 -> 128` normal-product tier for one-word IEEE formats whose
significand product needs two words. Refinement proofs live in `TwoWordMul.Proof`.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model.NativeTwoWordMul

open NativeSmallWord

/-- Capacity contract for a one-storage-word format whose product needs two native words. -/
def Eligible (fmt : FloatFormat) : Prop :=
  fmt.isIEEE = true ∧
    fmt.bitWidth ≤ 64 ∧
    32 ≤ fmt.fracWidth ∧
    fmt.fracWidth ≤ 62

/--
Two-word eligibility is decided from the descriptor fields; the conditional form is inlined and
folds at compile time for a closed format (see `NativeSmallWord.StorageEligible`).
-/
@[inline] instance (fmt : FloatFormat) : Decidable (Eligible fmt) :=
  if h : fmt.isIEEE = true ∧ fmt.bitWidth ≤ 64 ∧ 32 ≤ fmt.fracWidth ∧ fmt.fracWidth ≤ 62 then
    isTrue h
  else
    isFalse h

/-- Leading-bit position of a product of two normalized significands in the two-word tier. -/
@[inline] def productLeading (fmt : FloatFormat)
    (product : LeanFloat.Numerics.FixedWord.UInt128) : UInt64 :=
  let lower := UInt64.ofNat (2 * fmt.fracWidth)
  let threshold :=
    (1 : UInt64) <<<
      UInt64.ofNat (2 * fmt.fracWidth + 1 - 64)
  if product.hi < threshold then lower else lower + 1

/-- Round an exact two-word product of two normal finite significands. -/
@[inline] def roundNormalProduct? (fmt : FloatFormat) (sign : Bool)
    (xExponent yExponent xMantissa yMantissa : UInt64) :
    Option (Model fmt) :=
  let product := LeanFloat.Numerics.FixedWord.mul64 xMantissa yMantissa
  let leading := productLeading fmt product
  let scale := (xExponent - 1) + (yExponent - 1)
  let position := leading + scale
  let normalThreshold :=
    UInt64.ofNat (fmt.bias + 2 * fmt.fracWidth - 1)
  if position < normalThreshold then
    none
  else
    let rounded :=
      product.roundShiftRightEven
        (leading - UInt64.ofNat fmt.fracWidth).toNat
    NativeWordProduct.finish? fmt sign position rounded

/-- Decode two normal finite values and try the reusable two-word product path. -/
@[inline] def mulNormal? {fmt : FloatFormat}
    (x y : Model fmt) : Option (Model fmt) :=
  NativeSmallWord.withNormalPair? x y (roundNormalProduct? fmt)

end Model.NativeTwoWordMul
end LeanFloat.Floats.Formats.BinaryInterchange
