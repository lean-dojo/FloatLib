/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Backends.Word.Narrow.Base.Runtime

/-!
# Correctness of native binary32 storage operations

This module proves that the unboxed `UInt32` storage operations in `Base.Runtime` agree with the
generic binary32 model. Executable clients should import `Base.Runtime`; theorem-facing clients can
import this module or the `Base` module.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model.NativeBinary32

/-- Word negation is the model sign flip. -/
@[simp] theorem negate_eq (x : Value) :
    negate x = Model.neg x := by
  cases x
  rfl

/-- Repacking the stored word returns the value. -/
@[simp] theorem ofUInt32_toUInt32 (x : Value) :
    ofUInt32 (toUInt32 x) = x := by
  cases x
  rfl

/-- Unpacking a freshly packed word returns the word. -/
@[simp] theorem toUInt32_ofUInt32 (bits : UInt32) :
    toUInt32 (ofUInt32 bits) = bits :=
  rfl

end LeanFloat.Floats.Formats.BinaryInterchange.Model.NativeBinary32
