/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Backends.Word.Narrow.Base.Runtime
public import LeanFloat.Kernels.FixedWord.Core.Runtime

/-!
# Native binary32 product rounding

This module contains the machine-word rounder shared by multiplication, aligned addition, and
fused multiply-add. Its correctness theorem lives in `Rounding.Proof`, keeping execution-only
imports independent of the proof development.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model.NativeBinary32

/--
Round the exact product `product * 2^(scale - 298)` to binary32.

All call sites establish the branch-specific bounds needed for exact native shifts. In particular,
finite multiplication supplies a product below `2^48` and a scale at most `506`.
-/
@[inline] def roundProduct (sign : Bool) (product scale : UInt64) : UInt32 :=
  if product == 0 then
    if sign then 0x80000000 else 0
  else
    let leading := product.log2
    let position := leading + scale
    if position < 172 then
      let fraction :=
        if scale < 149 then
          LeanFloat.Numerics.FixedWord.roundShiftRightEven product (149 - scale).toNat
        else
          product <<< (scale - 149)
      if fraction == 0 then
        if sign then 0x80000000 else 0
      else if fraction == 0x800000 then
        mkBits sign 1 0
      else
        mkBits sign 0 fraction.toNat
    else
      let roundedMantissa :=
        if leading < 23 then
          product <<< (23 - leading)
        else
          LeanFloat.Numerics.FixedWord.roundShiftRightEven product (leading - 23).toNat
      let carry := roundedMantissa == 0x1000000
      let normalizedPosition := if carry then position + 1 else position
      if normalizedPosition > 425 then
        if sign then 0xff800000 else 0x7f800000
      else
        let normalizedMantissa := if carry then 0x800000 else roundedMantissa
        let encodedExponent := normalizedPosition - 171
        let fraction := normalizedMantissa.toNat - 0x800000
        mkBits sign encodedExponent.toNat fraction

end LeanFloat.Floats.Formats.BinaryInterchange.Model.NativeBinary32
