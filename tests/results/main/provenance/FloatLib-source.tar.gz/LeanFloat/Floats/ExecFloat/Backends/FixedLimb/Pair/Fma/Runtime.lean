/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Backends.FixedLimb.Pair.Multiplication.Runtime
public import LeanFloat.Floats.ExecFloat.Backends.Generic.Kernel.Runtime

/-!
# Two-word fused multiply-add runtime

Normal same-sign inputs with the supported alignment use a four-word exact sum and one
nearest-even rounding step. The complete finite candidate chain then uses the width-generic exact
kernel for other finite inputs. Correctness proofs live in `Fma.Proof`.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model.NativePair

/-- Shift a normal significand by `fracWidth` bits into the product's four-word coordinate. -/
@[inline] def alignFmaAddend (fmt : FloatFormat)
    (mantissa : LeanFloat.Numerics.FixedWord.UInt128) :
    LeanFloat.Numerics.FixedWord.UInt256 :=
  LeanFloat.Numerics.FixedWord.UInt256.ofUInt128ShiftedLeft mantissa fmt.fracWidth

/--
Try the all-native same-sign, exactly aligned normal FMA path.

The sign test uses the public carrier's most-significant bit before native-word decoding, keeping
declined opposite-sign cases cheap. The addend is accepted when its scale equals the product scale
plus `fracWidth`, so both operands share the four-word coordinate of the product rounder.
-/
@[inline] def fmaNormalSameSignAligned? {fmt : FloatFormat} (x y z : Model fmt) :
    Option (Model fmt) :=
  let productSign := Bool.xor x.bits.msb y.bits.msb
  let zSign := z.bits.msb
  if productSign != zSign then
    none
  else
    let xWords := toWords x
    let yWords := toWords y
    let zWords := toWords z
    let xExponent := expField fmt xWords.hi
    let yExponent := expField fmt yWords.hi
    let zExponent := expField fmt zWords.hi
    if xExponent == 0 || xExponent == expAllOnes fmt ||
        yExponent == 0 || yExponent == expAllOnes fmt ||
        zExponent == 0 || zExponent == expAllOnes fmt then
      none
    else
      let productScale := (xExponent - 1) + (yExponent - 1)
      let zProductScale := (zExponent - 1) + UInt64.ofNat (fmt.bias + fmt.fracWidth - 1)
      if productScale + UInt64.ofNat fmt.fracWidth != zProductScale then
        none
      else
        let xMantissa := normalMantissa fmt (fracHigh fmt xWords.hi) xWords.lo
        let yMantissa := normalMantissa fmt (fracHigh fmt yWords.hi) yWords.lo
        let zMantissa := normalMantissa fmt (fracHigh fmt zWords.hi) zWords.lo
        let product := LeanFloat.Numerics.FixedWord.mul128 xMantissa yMantissa
        let sum :=
          LeanFloat.Numerics.FixedWord.add256 product (alignFmaAddend fmt zMantissa)
        if sum.carry != 0 then
          none
        else
          roundNormalProduct? productSign xExponent yExponent sum.value
            (UInt64.ofNat sum.value.log2)

/--
Evaluate finite two-word fused multiply-add.

The aligned fixed-limb kernel is attempted first. Every remaining finite case uses the generic
one-rounding exact kernel; exceptional inputs are reported as `none` to the dispatcher. The entry
point is specialized on the descriptor rather than inlined: a call site with a closed format
receives a copy in which every descriptor constant is folded, while the operation dispatchers,
which are inlined at every storage plan, keep one shared copy for an open format.
-/
@[specialize fmt] def fmaFinite? {fmt : FloatFormat} (x y z : Model fmt) : Option (Model fmt) :=
  match fmaNormalSameSignAligned? x y z with
  | some result => some result
  | none => FiniteKernel.fmaRuntimeFlat? x y z

end LeanFloat.Floats.Formats.BinaryInterchange.Model.NativePair
