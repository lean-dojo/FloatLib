/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Backends.FixedLimb.Pair.Core.Runtime
public import LeanFloat.Kernels.FixedWord.RestoringSqrt.Runtime

/-!
# Two-word square-root runtime

The proved restoring loop computes the exact floor square root and remainder for a positive normal
input of any eligible two-word layout whose fraction has at most 124 bits and whose bias exceeds
the fraction width. Correctness proofs live in `Sqrt.Proof`.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model.NativePair

open LeanFloat.Numerics.FixedWord.RestoringSquareRoot

/-- Shift a normal significand by `shift` bits into four words. -/
@[inline] def alignSqrtRadicand
    (mantissa : LeanFloat.Numerics.FixedWord.UInt128)
    (shift : Nat) : LeanFloat.Numerics.FixedWord.UInt256 :=
  LeanFloat.Numerics.FixedWord.UInt256.ofUInt128ShiftedLeft mantissa shift

/--
Try the fixed-word square root for one positive normal value.

The radicand is the significand shifted by `fracWidth` or `fracWidth + 1` bits, chosen so that the
result exponent is integral, and the root is extracted with `fracWidth + 1` base-four digits. The
kernel declines formats whose fraction exceeds 124 bits, where the doubled remainder would leave
the two-word state, and formats whose bias is at most the fraction width, where the exponent
arithmetic of `SqrtArithmetic` does not apply; those formats keep the exact baseline. The entry
point is specialized on the descriptor rather than inlined: a call site with a closed format
receives a copy in which every descriptor constant is folded, while the operation dispatchers,
which are inlined at every storage plan, keep one shared copy for an open format.
-/
@[specialize fmt] def sqrtNormal? {fmt : FloatFormat} (x : Model fmt) : Option (Model fmt) :=
  if x.bits.msb then
    none
  else if fmt.bias < fmt.fracWidth + 1 || 124 < fmt.fracWidth then
    none
  else
    let words := toWords x
    let exponent := expField fmt words.hi
    if exponent == 0 || exponent == expAllOnes fmt then
      none
    else
      let mantissa := normalMantissa fmt (fracHigh fmt words.hi) words.lo
      let shift := if (exponent &&& 1) == 1 then fmt.fracWidth else fmt.fracWidth + 1
      let radicand := alignSqrtRadicand mantissa shift
      let state := rootAndRemainder radicand (fmt.fracWidth + 1)
      let rounded := roundRoot state
      let carry := isCarry fmt rounded
      let resultExponent :=
        (exponent + UInt64.ofNat fmt.bias) / 2 + if carry then 1 else 0
      some <| packNormal fmt false resultExponent (normalizeCarry fmt carry rounded)

end LeanFloat.Floats.Formats.BinaryInterchange.Model.NativePair
