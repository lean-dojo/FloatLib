/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Backends.WideLimb.Core.Runtime

/-!
# Wide-limb normal rounding runtime

Every wide-limb arithmetic kernel ends by rounding an exact or sticky-jammed significand at an
unsigned scale into a normal stored value. `roundNormal?` performs that step on limbs: it locates
the leading bit, rounds to `fracWidth + 1` bits with ties to even, detects a carry into the next
binade, checks the exponent range, and packs. It declines, returning `none`, when the result would
be subnormal or would overflow; the dispatcher then computes those rare cases with the exact
baseline. `Round.Proof` shows that an accepted result is the arbitrary-precision product rounder
`FiniteProductRound.round` applied to the exact value.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model.WideLimb

open LeanFloat.Numerics

/--
Round `significand * 2^jam * 2^(scale - 2 * subnormalAlignExp fmt)` to a normal stored value.

`significand` is nonzero and either exact (`jam = 0`) or the sticky-jammed value of an exact
significand whose `jam` low bits were discarded; the leading bit of the exact value is then at
position `significand.log2 + jam`. The thresholds are those of `FiniteProductRound.round` in the
same unsigned coordinate. Subnormal and overflowing results are declined.
-/
def roundNormal? (fmt : FloatFormat) (sign : Bool) (significand : LimbArray) (jam scale : Nat) :
    Option (Value fmt) :=
  let leading := significand.log2
  let position := leading + jam + scale
  if position < fmt.bias + 2 * fmt.fracWidth - 1 then
    none
  else
    let rounded :=
      if fmt.fracWidth ≤ leading then
        significand.roundShiftRightEven (leading - fmt.fracWidth)
      else
        significand.shiftLeft (fmt.fracWidth - leading)
    let carry := rounded.log2 == fmt.fracWidth + 1
    let normalizedPosition := if carry then position + 1 else position
    if 3 * fmt.bias + 2 * fmt.fracWidth - 2 < normalizedPosition then
      none
    else
      some <| pack fmt sign
        (UInt32.ofNat (normalizedPosition - (fmt.bias + 2 * fmt.fracWidth - 2)))
        (rounded.lowBits fmt.fracWidth)

end LeanFloat.Floats.Formats.BinaryInterchange.Model.WideLimb
