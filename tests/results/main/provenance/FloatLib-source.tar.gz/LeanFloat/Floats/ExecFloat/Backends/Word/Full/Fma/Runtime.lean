/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Backends.Word.Full.Core.Runtime
public import LeanFloat.Kernels.FixedWord.Difference.Runtime

/-!
# Native binary64 fused multiply-add runtime

The accepted paths align finite normal operands in two native limbs and round the exact sum or
difference once. Declined cases retain the generic exact finite kernel. Correctness proofs are
isolated in `Fma.Proof`.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model.NativeBinary64

open LeanFloat.Numerics.FixedWord

/-- Shift a normal binary64 significand into the product's two-word coordinate. -/
@[inline] def alignFmaAddend (mantissa : UInt64) : LeanFloat.Numerics.FixedWord.UInt128 :=
  LeanFloat.Numerics.FixedWord.UInt128.shiftLeft { hi := 0, lo := mantissa } 52

/-- Leading-bit position of an accepted 107-bit binary64 FMA magnitude. -/
@[inline] def fmaLeading (magnitude : LeanFloat.Numerics.FixedWord.UInt128) : UInt64 :=
  UInt64.ofNat (LeanFloat.Numerics.FixedWord.UInt128.log2 magnitude)

/--
Try the all-native same-sign, exactly aligned normal binary64 FMA path.

The accepted exact magnitude is
`xMantissa * yMantissa + zMantissa * 2^52`. The final result is still rounded only once.
-/
@[inline] def fmaNormalSameSignAligned? (x y z : Value) : Option Value :=
  let xBits := toUInt64 x
  let yBits := toUInt64 y
  let zBits := toUInt64 z
  let xExponent := expField xBits
  let yExponent := expField yBits
  let zExponent := expField zBits
  if xExponent == 0 || xExponent == 0x7ff ||
      yExponent == 0 || yExponent == 0x7ff ||
      zExponent == 0 || zExponent == 0x7ff then
    none
  else
    let xMantissa := finiteMantissa xExponent (fracField xBits)
    let yMantissa := finiteMantissa yExponent (fracField yBits)
    let zMantissa := finiteMantissa zExponent (fracField zBits)
    let productScale := finiteScale xExponent + finiteScale yExponent
    let zProductScale := finiteScale zExponent + 1074
    let productSign := Bool.xor (signBit xBits) (signBit yBits)
    let zSign := signBit zBits
    if productSign != zSign || productScale + 52 != zProductScale then
      none
    else
      let product := LeanFloat.Numerics.FixedWord.mul64 xMantissa yMantissa
      let sum := LeanFloat.Numerics.FixedWord.add128 product (alignFmaAddend zMantissa)
      if sum.carry != 0 then
        none
      else
        roundNormalProduct? productSign xExponent yExponent sum.value
          (fmaLeading sum.value)

/--
Try the all-native opposite-sign, exactly aligned normal binary64 FMA path.

Exact cancellation and magnitudes below the normal 53-bit rounding range are declined so the
generic kernel retains signed-zero and subnormal behavior.
-/
@[inline] def fmaNormalOppositeSignAligned? (x y z : Value) : Option Value :=
  let xBits := toUInt64 x
  let yBits := toUInt64 y
  let zBits := toUInt64 z
  let xExponent := expField xBits
  let yExponent := expField yBits
  let zExponent := expField zBits
  if xExponent == 0 || xExponent == 0x7ff ||
      yExponent == 0 || yExponent == 0x7ff ||
      zExponent == 0 || zExponent == 0x7ff then
    none
  else
    let xMantissa := finiteMantissa xExponent (fracField xBits)
    let yMantissa := finiteMantissa yExponent (fracField yBits)
    let zMantissa := finiteMantissa zExponent (fracField zBits)
    let productScale := finiteScale xExponent + finiteScale yExponent
    let zProductScale := finiteScale zExponent + 1074
    let productSign := Bool.xor (signBit xBits) (signBit yBits)
    let zSign := signBit zBits
    if productSign == zSign || productScale + 52 != zProductScale then
      none
    else
      let product := LeanFloat.Numerics.FixedWord.mul64 xMantissa yMantissa
      let aligned := alignFmaAddend zMantissa
      if product == aligned then
        none
      else
        let productLess := LeanFloat.Numerics.FixedWord.UInt128.less product aligned
        let magnitude :=
          if productLess then
            LeanFloat.Numerics.FixedWord.UInt128.sub aligned product
          else
            LeanFloat.Numerics.FixedWord.UInt128.sub product aligned
        let leading := fmaLeading magnitude
        if leading < 53 then
          none
        else
          roundNormalProduct? (if productLess then zSign else productSign)
            xExponent yExponent magnitude leading

/-- Use both native aligned paths before the existing exact finite FMA kernel. -/
@[inline] def fmaFiniteFastImpl? (x y z : Value) : Option Value :=
  match fmaNormalSameSignAligned? x y z with
  | some result => some result
  | none =>
      match fmaNormalOppositeSignAligned? x y z with
      | some result => some result
      | none => fmaFiniteImpl? x y z

end LeanFloat.Floats.Formats.BinaryInterchange.Model.NativeBinary64
