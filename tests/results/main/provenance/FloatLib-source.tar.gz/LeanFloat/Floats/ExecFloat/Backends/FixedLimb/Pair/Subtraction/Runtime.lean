/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Kernels.FixedWord.Difference.Runtime
public import LeanFloat.Floats.ExecFloat.Backends.FixedLimb.Pair.Core.Runtime
public import LeanFloat.Floats.ExecFloat.Backends.Generic.Kernel.Runtime

/-!
# Two-word subtraction runtime

This module contains the equal-exponent subtraction kernel and the complete finite candidate chain
for every eligible two-word layout. It reuses the pair-kernel storage layer; correctness proofs are
isolated in `Subtraction.Proof`.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model.NativePair

/--
Try exact native subtraction of same-sign normal operands with the same exponent.

The accepted result remains normal. Exact zero is returned directly; cancellation into the
subnormal range is declined so the generic implementation preserves every boundary policy.
-/
@[inline] def subNormalSameExponent? {fmt : FloatFormat} (x y : Model fmt) : Option (Model fmt) :=
  let xWords := toWords x
  let yWords := toWords y
  let xExponent := expField fmt xWords.hi
  let yExponent := expField fmt yWords.hi
  let xSign := signBit fmt xWords.hi
  let ySign := signBit fmt yWords.hi
  if xSign != ySign || xExponent == 0 || xExponent == expAllOnes fmt ||
      yExponent != xExponent then
    none
  else
    let xMantissa := normalMantissa fmt (fracHigh fmt xWords.hi) xWords.lo
    let yMantissa := normalMantissa fmt (fracHigh fmt yWords.hi) yWords.lo
    if xMantissa == yMantissa then
      some (Model.posZero fmt)
    else
      let xLess := LeanFloat.Numerics.FixedWord.UInt128.less xMantissa yMantissa
      let difference :=
        if xLess then
          LeanFloat.Numerics.FixedWord.UInt128.sub yMantissa xMantissa
        else
          LeanFloat.Numerics.FixedWord.UInt128.sub xMantissa yMantissa
      let leading := LeanFloat.Numerics.FixedWord.UInt128.log2 difference
      if xExponent.toNat + leading ≤ fmt.fracWidth then
        none
      else
        let normalized :=
          LeanFloat.Numerics.FixedWord.UInt128.shiftLeft difference (fmt.fracWidth - leading)
        let resultExponent :=
          UInt64.ofNat (xExponent.toNat + leading - fmt.fracWidth)
        some <| packNormal fmt (if xLess then !xSign else xSign)
          resultExponent normalized

/--
Evaluate finite two-word subtraction.

The fixed-limb equal-exponent kernel is attempted first. Every remaining finite case uses generic
exact addition with a negated right operand; exceptional inputs remain visible to the dispatcher.
The entry point is specialized on the descriptor rather than inlined: a call site with a closed
format receives a copy in which every descriptor constant is folded, while the operation
dispatchers, which are inlined at every storage plan, keep one shared copy for an open format.
-/
@[specialize fmt] def subFinite? {fmt : FloatFormat} (x y : Model fmt) : Option (Model fmt) :=
  match subNormalSameExponent? x y with
  | some difference => some difference
  | none => FiniteKernel.addRuntime? x (neg y)

end LeanFloat.Floats.Formats.BinaryInterchange.Model.NativePair
