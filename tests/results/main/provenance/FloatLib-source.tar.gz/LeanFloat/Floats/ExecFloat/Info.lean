/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Info.Command
public import LeanFloat.Floats.ExecFloat.Info.Profile
public import LeanFloat.Floats.ExecFloat.Info.Inspection
public import LeanFloat.Floats.ExecFloat.Info.Render

/-!
# Format inspection

`#float_info` reports a numerical type's format, backends, and available theorems.
`#float_info!` includes theorem names and hypotheses; `#float_help` lists the command options.

`Info.Profile` defines report data and checks theorem references. `Info.Inspection` discovers
capabilities and backend metadata, `Info.Render` formats the report, and `Info.Command` defines
the syntax. Format families register renderers in their own `Info` modules.
-/

@[expose] public section

namespace LeanFloat.Floats.ExecFloat.Inspection

/--
Attach the capabilities discovered for a value type, check every referenced theorem, and render
the resulting report. Format modules only need to describe their own representation and semantics.
-/
meta def renderProfile
    (profile : FormatProfile) (valueType : Lean.Expr)
    (operations : CoreOperationCoverage) : Lean.Meta.MetaM String := do
  let profile ← withConversions profile valueType
  profile.validateDeclarations
  LeanFloat.Floats.ExecFloat.renderFormatInfo profile operations

/-- Render a profile using the universal operations actually installed for an `ExecFloat` family. -/
meta def renderExecProfile
    (profile : FormatProfile) (valueType family : Lean.Expr) :
    Lean.Meta.MetaM String := do
  renderProfile profile valueType (← coreOperations family)

end LeanFloat.Floats.ExecFloat.Inspection
