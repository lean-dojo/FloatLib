/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Backends.WideLimb.Round.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Spec.Dyadic

/-!
# Wide-limb multiplication runtime

Normal operands are multiplied exactly by the schoolbook limb product and rounded once by
`roundNormal?`. Zero, subnormal, and exceptional operands, and products that leave the normal
range, are declined and computed by the reference operation `Model.Spec.mul` through the model
codec. `Multiplication.Proof` proves that the total operation `mul` equals `Model.Spec.mul` on the
model of its operands.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model.WideLimb

open LeanFloat.Numerics

/-- Multiply two normal stored values, declining every other case. -/
def mulNormal? (fmt : FloatFormat) (x y : Value fmt) : Option (Value fmt) :=
  let xExponent := expWord x
  let yExponent := expWord y
  if xExponent == 0 || xExponent == expAllOnes fmt ||
      yExponent == 0 || yExponent == expAllOnes fmt then
    none
  else
    roundNormal? fmt (Bool.xor (signBit x) (signBit y))
      ((normalMantissa x).mul (normalMantissa y)) 0
      ((xExponent.toNat - 1) + (yExponent.toNat - 1))

/-- Wide-limb multiplication with the reference operation for declined cases. -/
def mul (fmt : FloatFormat) (x y : Value fmt) : Value fmt :=
  match mulNormal? fmt x y with
  | some product => product
  | none => ofModel (Spec.mul (toModel x) (toModel y))

end LeanFloat.Floats.Formats.BinaryInterchange.Model.WideLimb
