/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Backends.Word.ProductRound.Runtime
public import LeanFloat.Kernels.FixedWord.Core.Runtime
public import Mathlib.Data.Rat.Cast.Order

/-!
# Native one-word finite multiplication

The executable normal multiplication path here serves conventional IEEE formats whose storage,
exponent, and significand intermediates fit in `UInt64`. Refinement proofs live in `Mul.Proof`.

The kernel returns a decline marker when a boundary case would exceed the clean one-word envelope;
the dispatcher then uses the separately specified general path. This is capability composition,
not a hidden correctness check: accepted normal results are proved exact, and no reference
calculation is run beside them.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model.NativeSmallWordMul

open NativeSmallWord

/--
Capacity contract for exact `UInt64` normal multiplication.

A 32-bit normalized significand still has an exact 64-bit product. This is one fraction bit wider
than the conservative contract shared with native division.
-/
def Eligible (fmt : FloatFormat) : Prop :=
  fmt.isIEEE = true ∧
    fmt.bitWidth ≤ 64 ∧
    fmt.expWidth ≤ 30 ∧
    fmt.fracWidth ≤ 31

/--
Product eligibility is decided from the descriptor fields; the conditional form is inlined and
folds at compile time for a closed format (see `NativeSmallWord.StorageEligible`).
-/
@[inline] instance (fmt : FloatFormat) : Decidable (Eligible fmt) :=
  if h : fmt.isIEEE = true ∧ fmt.bitWidth ≤ 64 ∧ fmt.expWidth ≤ 30 ∧ fmt.fracWidth ≤ 31 then
    isTrue h
  else
    isFalse h

/-- Flat decline sentinel for the allocation-free one-word execution boundary. -/
@[inline] def declineWord : UInt64 :=
  (1 : UInt64) <<< 63

/--
Round an exact product of two normal finite significands in native words.

`none` means the exact result is subnormal or overflows. Those boundary cases retain the generic
exact rounder.
-/
@[inline] def roundNormalProduct? (fmt : FloatFormat) (sign : Bool)
    (xExponent yExponent xMantissa yMantissa : UInt64) :
    Option (Model fmt) :=
  let product := xMantissa * yMantissa
  let leading := product.log2
  let scale := (xExponent - 1) + (yExponent - 1)
  let position := leading + scale
  let normalThreshold :=
    biasWord fmt + 2 * UInt64.ofNat fmt.fracWidth - 1
  if position < normalThreshold then
    none
  else
    let rounded :=
      LeanFloat.Numerics.FixedWord.roundShiftRightEven product
        (leading - UInt64.ofNat fmt.fracWidth).toNat
    NativeWordProduct.finish? fmt sign position rounded

/--
Allocation-free execution view of `roundNormalProduct?`.

The high decline bit is reserved as a sentinel. Every successful result is normal and cannot use
that word for an eligible format.
-/
@[inline] def roundNormalProductWord (fmt : FloatFormat) (sign : Bool)
    (xExponent yExponent xMantissa yMantissa : UInt64) : UInt64 :=
  let product := xMantissa * yMantissa
  let leading := product.log2
  let scale := (xExponent - 1) + (yExponent - 1)
  let position := leading + scale
  let normalThreshold :=
    biasWord fmt + 2 * UInt64.ofNat fmt.fracWidth - 1
  if position < normalThreshold then
    declineWord
  else
    let rounded :=
      LeanFloat.Numerics.FixedWord.roundShiftRightEven product
        (leading - UInt64.ofNat fmt.fracWidth).toNat
    NativeWordProduct.finishWord fmt declineWord sign position rounded

/--
Decode two normal finite values and try the reusable one-word product path.

Exceptional and subnormal operands return `none` before any significand arithmetic.
-/
@[inline] def mulNormal? {fmt : FloatFormat}
    (x y : Model fmt) : Option (Model fmt) :=
  NativeSmallWord.withNormalPair? x y (roundNormalProduct? fmt)

/--
Allocation-free execution view of `mulNormal?`.

Successful results stay in native fields until the final packed word. `declineWord` means the
caller must use the general exact path.
-/
@[inline] def mulNormalWord {fmt : FloatFormat}
    (x y : Model fmt) : UInt64 :=
  let xBits := NativeSmallWord.toWord x
  let yBits := NativeSmallWord.toWord y
  let xExponent := NativeSmallWord.exponentField fmt xBits
  let yExponent := NativeSmallWord.exponentField fmt yBits
  let allOnes := NativeSmallWord.exponentMask fmt
  if xExponent == 0 || xExponent == allOnes ||
      yExponent == 0 || yExponent == allOnes then
    declineWord
  else
    let xMantissa :=
      NativeSmallWord.fractionField fmt xBits ||| hiddenBit fmt
    let yMantissa :=
      NativeSmallWord.fractionField fmt yBits ||| hiddenBit fmt
    roundNormalProductWord fmt
      (Bool.xor
        (NativeSmallWord.signField fmt xBits)
        (NativeSmallWord.signField fmt yBits))
      xExponent yExponent xMantissa yMantissa

end Model.NativeSmallWordMul
end LeanFloat.Floats.Formats.BinaryInterchange
