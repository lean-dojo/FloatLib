/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Backends.TinyTable.Generic.Indexing

/-!
# Byte-table lookup certificates

These theorems connect native array reads to the exhaustive tables that generated them. Runtime
definitions use the certificates only to discharge erased bounds; semantic refinement remains in
the separate proof layer.
-/

@[expose] public section

namespace LeanFloat.Floats.ExecFloat.Backend.TinyTable

universe u

variable {Model : Type u}

/-- A native binary table read returns the encoded model-operation result. -/
theorem lookupBinary
    (encoding : Encoding Model)
    (op : Model → Model → Model) (left right : Code encoding)
    (hindex :
      (binaryByteIndex (radixWord encoding) left.1 right.1).toNat <
        (binaryTotal encoding op).size) :
    (binaryTotal encoding op).uget
        (binaryByteIndex (radixWord encoding) left.1 right.1)
        hindex =
      UInt8.ofNat
        (encoding.encode
          (op (encoding.decodeCode left) (encoding.decodeCode right))).val := by
  rw [uget_eq_get]
  unfold binaryTotal at hindex ⊢
  rw [ByteArray.getElem_ofFn]
  have hidx :
      (binaryByteIndex (radixWord encoding) left.1 right.1).toNat =
        left.1.toNat * encoding.radix + right.1.toNat := by
    simpa only [radixWord_toNat] using
      binaryByteIndex_toNat (radixWord encoding) left.1 right.1
        (binaryIndex_noOverflow encoding (radixWord encoding)
          (radixWord_toNat encoding) left right)
  have hdiv :
      (left.1.toNat * encoding.radix + right.1.toNat) / encoding.radix =
        left.1.toNat := by
    rw [Nat.mul_comm left.1.toNat encoding.radix,
      Nat.mul_add_div encoding.radix_pos, Nat.div_eq_of_lt right.2, Nat.add_zero]
  have hmod :
      (left.1.toNat * encoding.radix + right.1.toNat) % encoding.radix =
        right.1.toNat := by
    rw [Nat.mul_comm left.1.toNat encoding.radix,
      Nat.mul_add_mod_self_left, Nat.mod_eq_of_lt right.2]
  simp only [hidx, hdiv, hmod, Encoding.decodeCode]

/-- A native unary table read returns the encoded model-operation result. -/
theorem lookupUnary
    (encoding : Encoding Model) (op : Model → Model) (value : Code encoding)
    (hindex :
      (unaryByteIndex value.1).toNat <
        (unaryTotal encoding op).size) :
    (unaryTotal encoding op).uget
        (unaryByteIndex value.1) hindex =
      UInt8.ofNat
        (encoding.encode (op (encoding.decodeCode value))).val := by
  rw [uget_eq_get]
  unfold unaryTotal at hindex ⊢
  rw [ByteArray.getElem_ofFn]
  simp only [unaryByteIndex_toNat, Encoding.decodeCode]

/-- A native ternary table read returns the encoded model-operation result. -/
theorem lookupTernary
    (encoding : Encoding Model)
    (op : Model → Model → Model → Model)
    (left right addend : Code encoding)
    (hindex :
      (ternaryByteIndex (radixWord encoding) left.1 right.1 addend.1).toNat <
        (ternaryTotal encoding op).size) :
    (ternaryTotal encoding op).uget
        (ternaryByteIndex (radixWord encoding) left.1 right.1 addend.1)
        hindex =
      UInt8.ofNat
        (encoding.encode <|
          op (encoding.decodeCode left) (encoding.decodeCode right)
            (encoding.decodeCode addend)).val := by
  rw [uget_eq_get]
  unfold ternaryTotal at hindex ⊢
  rw [ByteArray.getElem_ofFn]
  obtain ⟨hleftMul, hpair, hpairMul, hindex⟩ :=
    ternaryIndex_noOverflow encoding (radixWord encoding)
      (radixWord_toNat encoding) left right addend
  have hidx :
      (ternaryByteIndex (radixWord encoding) left.1 right.1 addend.1).toNat =
        (left.1.toNat * encoding.radix + right.1.toNat) * encoding.radix +
          addend.1.toNat := by
    simpa only [radixWord_toNat] using
      ternaryByteIndex_toNat (radixWord encoding) left.1 right.1 addend.1
        hleftMul hpair hpairMul hindex
  have houterDiv :
      ((left.1.toNat * encoding.radix + right.1.toNat) * encoding.radix +
          addend.1.toNat) / encoding.radix =
        left.1.toNat * encoding.radix + right.1.toNat := by
    rw [Nat.mul_comm (left.1.toNat * encoding.radix + right.1.toNat)
      encoding.radix, Nat.mul_add_div encoding.radix_pos,
      Nat.div_eq_of_lt addend.2, Nat.add_zero]
  have houterMod :
      ((left.1.toNat * encoding.radix + right.1.toNat) * encoding.radix +
          addend.1.toNat) % encoding.radix = addend.1.toNat := by
    rw [Nat.mul_comm (left.1.toNat * encoding.radix + right.1.toNat)
      encoding.radix, Nat.mul_add_mod_self_left, Nat.mod_eq_of_lt addend.2]
  have hleftDiv :
      (left.1.toNat * encoding.radix + right.1.toNat) / encoding.radix =
        left.1.toNat := by
    rw [Nat.mul_comm left.1.toNat encoding.radix,
      Nat.mul_add_div encoding.radix_pos, Nat.div_eq_of_lt right.2, Nat.add_zero]
  have hrightMod :
      (left.1.toNat * encoding.radix + right.1.toNat) % encoding.radix =
        right.1.toNat := by
    rw [Nat.mul_comm left.1.toNat encoding.radix,
      Nat.mul_add_mod_self_left, Nat.mod_eq_of_lt right.2]
  simp only [hidx, houterDiv, houterMod, hleftDiv, hrightMod,
    Encoding.decodeCode]

end LeanFloat.Floats.ExecFloat.Backend.TinyTable
