/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Backends.Word.ProductRound.Runtime
public import LeanFloat.Floats.ExecFloat.Backends.Word.Small.Finite.Runtime
public import LeanFloat.Kernels.FixedWord.Core.Runtime

/-!
# Native one-word finite addition

This module contains the executable addition path for conventional IEEE formats whose storage
word, exponent range, and aligned significand sum all fit in `UInt64` (`Eligible`). It is the word-tier
counterpart of the arbitrary-precision kernel `FiniteScaleAdd.roundSum`: both operands are decoded
from the storage word into a sign, a nonnegative scale, and an integer significand; the
significands are aligned by a left shift; the signed magnitudes are combined; and the result is
rounded to nearest even and packed, all without leaving machine words. Refinement proofs live in
`Add.Proof`.

The kernel is partial by design and returns `none` whenever a case would leave the clean one-word
envelope: an exceptional operand, a zero operand, an alignment shift wider than the spare bits of
the word, a subnormal result, or overflow. The dispatcher then uses the exact generic
implementation, so a decline is a performance decision and never a second arithmetic semantics.
Accepted results are proved bit-identical to the exact kernel in `Add.Proof`.

The functions mirror the branch structure of `FiniteScaleAdd.roundMagnitudes` and
`FiniteScaleAdd.roundSum` step for step. Keeping the two shapes aligned is what makes the
refinement proof a transfer of natural-number values through `UInt64.toNat`.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model.NativeSmallWordAdd

open NativeSmallWord

/--
Capacity contract of the one-word addition kernel.

The IEEE condition selects the exact binary semantics. The width bounds keep every storage word,
scale, and aligned significand in `UInt64`: a significand has at most `fracWidth + 1 ≤ 62` bits,
so the same-sign sum of two aligned significands fits after any alignment shift accepted by
`shiftLimit`. The kernel therefore serves every one-word IEEE format, including binary64.
-/
def Eligible (fmt : FloatFormat) : Prop :=
  fmt.isIEEE = true ∧
    fmt.bitWidth ≤ 64 ∧
    fmt.expWidth ≤ 30 ∧
    fmt.fracWidth ≤ 61

/--
Addition eligibility is decided from the descriptor fields; the conditional form is inlined and
folds at compile time for a closed format (see `NativeSmallWord.StorageEligible`).
-/
@[inline] instance (fmt : FloatFormat) : Decidable (Eligible fmt) :=
  if h : fmt.isIEEE = true ∧ fmt.bitWidth ≤ 64 ∧ fmt.expWidth ≤ 30 ∧ fmt.fracWidth ≤ 61 then
    isTrue h
  else
    isFalse h

/--
Nonnegative scale offset separating the compact finite scale from the product rounder's
coordinate: `fmt.exponentBias + fmt.fracWidth - 1`, the value of
`FiniteKernel.finiteScaleOffset fmt` as one machine word.

For every format that fits one machine word this constant is exact because the bias is below
`2 ^ expWidth`.
-/
@[inline] def alignOffset (fmt : FloatFormat) : UInt64 :=
  UInt64.ofNat (fmt.exponentBias + fmt.fracWidth - 1)

/--
Largest exponent-alignment shift the one-word kernel accepts.

A significand has at most `fracWidth + 1` bits. Shifting the larger-scale operand left by at most
`62 - fracWidth` bits keeps it below `2 ^ 63`, so the same-sign sum of both significands is still
below `2 ^ 64` and no machine-word addition can wrap. Larger shifts decline to the exact kernel.
-/
@[inline] def shiftLimit (fmt : FloatFormat) : UInt64 :=
  62 - UInt64.ofNat fmt.fracWidth

/--
Round a nonzero magnitude at an unsigned scale to a normal result, or decline.

`magnitude * 2 ^ (scale - offset)` is the exact value, in the coordinate of
`FiniteScaleAdd.roundMagnitude`. The function reproduces the normal branch of
`FiniteProductRound.round` in machine words: it finds the leading bit, rounds the significand to
`fracWidth + 1` bits with ties to even, and hands carry, overflow, and packing to the shared
`NativeWordProduct.finish?`. A result that would be subnormal or overflow returns `none`.
-/
@[inline] def roundMagnitude? (fmt : FloatFormat) (sign : Bool)
    (magnitude scale : UInt64) : Option (Model fmt) :=
  let leading := magnitude.log2
  let position := leading + scale + alignOffset fmt
  let normalThreshold := biasWord fmt + 2 * UInt64.ofNat fmt.fracWidth - 1
  if position < normalThreshold then
    none
  else
    let fracWidth := UInt64.ofNat fmt.fracWidth
    let rounded :=
      if fracWidth ≤ leading then
        LeanFloat.Numerics.FixedWord.roundShiftRightEven magnitude
          (leading - fracWidth).toNat
      else
        magnitude <<< (fracWidth - leading)
    NativeWordProduct.finish? fmt sign position rounded

/--
Combine two nonzero signed magnitudes already aligned at one unsigned scale and round once.

The four branches are those of `FiniteScaleAdd.roundMagnitudes`: same signs add the magnitudes,
equal opposite magnitudes cancel to positive zero, and otherwise the larger magnitude determines the
sign of the difference. Same-sign callers must keep `left + right` below `2 ^ 64`; opposite-sign
subtraction cannot wrap.
-/
@[inline] def roundAligned? (fmt : FloatFormat) (leftSign rightSign : Bool)
    (left right scale : UInt64) : Option (Model fmt) :=
  if leftSign == rightSign then
    roundMagnitude? fmt leftSign (left + right) scale
  else if left == right then
    some (zero fmt (leftSign && rightSign))
  else if left < right then
    roundMagnitude? fmt rightSign (right - left) scale
  else
    roundMagnitude? fmt leftSign (left - right) scale

/--
Add two decoded finite operands in machine words, or decline.

Each operand is a sign, its stored biased exponent, and its integer significand including the
implicit bit of a normal value. The scales are the compact finite scales of `FiniteKernel.scale`,
so the operand with the larger scale is shifted left before the signed magnitudes are combined.
Zero operands and alignment shifts above `shiftLimit fmt` return `none`; the exact kernel handles
them.
-/
@[inline] def addFields? (fmt : FloatFormat)
    (xSign : Bool) (xExponent xMantissa : UInt64)
    (ySign : Bool) (yExponent yMantissa : UInt64) : Option (Model fmt) :=
  if xMantissa == 0 || yMantissa == 0 then
    none
  else
    let xScale := LeanFloat.Numerics.FixedWord.finiteScale xExponent
    let yScale := LeanFloat.Numerics.FixedWord.finiteScale yExponent
    if xScale ≤ yScale then
      let shift := yScale - xScale
      if shift ≤ shiftLimit fmt then
        roundAligned? fmt xSign ySign xMantissa (yMantissa <<< shift) xScale
      else
        none
    else
      let shift := xScale - yScale
      if shift ≤ shiftLimit fmt then
        roundAligned? fmt xSign ySign (xMantissa <<< shift) yMantissa yScale
      else
        none

/--
One-word finite addition, or subtraction when `negateRight` is set, directly on storage words.

Both operands are decoded with the shared one-word field extractors. An exceptional operand (an
all-ones exponent field) returns `none`. The right operand's sign is toggled by `negateRight`, so
subtraction never materializes a negated model value. Every accepted result is proved equal to
`FiniteKernel.add? x y`, respectively `FiniteKernel.add? x (neg y)`, in `Add.Proof`.
-/
@[inline] def addFinite? {fmt : FloatFormat} (x y : Model fmt) (negateRight : Bool) :
    Option (Model fmt) :=
  let xBits := toWord x
  let yBits := toWord y
  let xExponent := exponentField fmt xBits
  let yExponent := exponentField fmt yBits
  let allOnes := exponentMask fmt
  if xExponent == allOnes || yExponent == allOnes then
    none
  else
    addFields? fmt
      (signField fmt xBits) xExponent
      (NativeSmallWordFinite.finiteMantissa fmt xExponent (fractionField fmt xBits))
      (Bool.xor (signField fmt yBits) negateRight) yExponent
      (NativeSmallWordFinite.finiteMantissa fmt yExponent (fractionField fmt yBits))

end Model.NativeSmallWordAdd
end LeanFloat.Floats.Formats.BinaryInterchange
