/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Backends.Dispatch.SqrtWord.Runtime
public import LeanFloat.Floats.ExecFloat.Backends.FixedLimb.Pair.Sqrt.Runtime

/-!
# Final executable square-root dispatch

The dispatcher adds the certified pair-layout route to the smaller word-specialized kernels
without importing their refinement proofs. It alone selects the exact word baseline when the
partial pair kernel declines.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model
namespace SqrtBackend

/--
Select the best certified square-root backend for the concrete format.

The fast path is computed first as an `Option` and the word dispatcher appears exactly once, in
the fallback: the word dispatcher is large once inlined, and mentioning it in several branches
multiplies the generated code at every configured type. For a closed binary32 or binary64
descriptor the compiler folds the fixed-format test to `true`, so the two-word probe disappears
entirely; neither fixed format is pair-eligible, so the fold changes nothing observable.
-/
@[inline] def dispatch {fmt : FloatFormat} (x : Model fmt) : Model fmt :=
  let fast : Option (Model fmt) :=
    if FloatFormat.IsBinary32 fmt ∨ FloatFormat.IsBinary64 fmt then none
    else if _hpair : NativePair.Eligible fmt then NativePair.sqrtNormal? x
    else none
  match fast with
  | some result => result
  | none => word x

end SqrtBackend
end Model
end LeanFloat.Floats.Formats.BinaryInterchange
