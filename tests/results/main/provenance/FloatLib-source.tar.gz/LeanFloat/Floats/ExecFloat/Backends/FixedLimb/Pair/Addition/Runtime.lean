/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Backends.FixedLimb.Pair.Core.Runtime
public import LeanFloat.Floats.ExecFloat.Backends.Generic.Kernel.Runtime
public import LeanFloat.Kernels.FixedWord.LimbRound.Runtime

/-!
# Two-word addition runtime

This module contains the same-exponent addition kernel and the complete finite candidate chain for
every eligible two-word layout. Correctness theorems are isolated in `Addition.Proof`.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model.NativePair

/--
Try native same-sign addition of normal operands with the same exponent.

The two largest exponent fields are rejected so incrementing the accepted exponent always remains
finite. The sum of two `fracWidth + 1`-bit significands fits in the two-word accumulator.
-/
@[inline] def addNormalSameExponent? {fmt : FloatFormat} (x y : Model fmt) : Option (Model fmt) :=
  let xWords := toWords x
  let yWords := toWords y
  let xExponent := expField fmt xWords.hi
  let yExponent := expField fmt yWords.hi
  let xSign := signBit fmt xWords.hi
  let ySign := signBit fmt yWords.hi
  if xSign != ySign || xExponent == 0 || expAllOnes fmt - 1 ≤ xExponent ||
      yExponent != xExponent then
    none
  else
    let xMantissa := normalMantissa fmt (fracHigh fmt xWords.hi) xWords.lo
    let yMantissa := normalMantissa fmt (fracHigh fmt yWords.hi) yWords.lo
    let exact := LeanFloat.Numerics.FixedWord.add128 xMantissa yMantissa
    let rounded := exact.value.roundShiftRightOneEven
    some <| packNormal fmt xSign (xExponent + 1) rounded

/--
Evaluate finite two-word addition.

The fixed-limb same-exponent kernel is attempted first. Every remaining finite case uses the
width-generic exact kernel; exceptional inputs are reported as `none` to the operation dispatcher.
The entry point is specialized on the descriptor rather than inlined: a call site with a closed
format receives a copy in which every descriptor constant is folded, while the operation
dispatchers, which are inlined at every storage plan, keep one shared copy for an open format.
-/
@[specialize fmt] def addFinite? {fmt : FloatFormat} (x y : Model fmt) : Option (Model fmt) :=
  match addNormalSameExponent? x y with
  | some sum => some sum
  | none => FiniteKernel.addRuntime? x y

end LeanFloat.Floats.Formats.BinaryInterchange.Model.NativePair
