/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module -- shake: keep-all

public import LeanFloat.Floats.ExecFloat.Carrier
public import LeanFloat.Floats.ExecFloat.Comparison
public import LeanFloat.Floats.ExecFloat.Conversion.Runtime
public import LeanFloat.Floats.ExecFloat.Dispatch
public import LeanFloat.Floats.ExecFloat.Instances

/-!
# Execution-only `ExecFloat` interface

Import this module when a program needs the universal carrier, comparison, explicit conversion,
destination-driven mixed arithmetic, same-format arithmetic capabilities, public dispatch
functions, and ordinary operator instances without importing proof automation or the
`#float_info` elaborator.

This execution-only import does not weaken the architecture: every installed arithmetic
capability still stores a certified implementation. It only avoids re-exporting reference
definitions, user-facing correctness theorems, automation attributes, and inspection commands
when a downstream runtime module does not use them.

Conversion remains proof-linked through this execution-only API: every destination
`Quantizer` stores a mathematical contract and an implementation theorem. The theorem names are
not re-exported through this runtime-focused import.

Use `LeanFloat.Floats.ExecFloat` for the complete user interface.
-/

@[expose] public section
