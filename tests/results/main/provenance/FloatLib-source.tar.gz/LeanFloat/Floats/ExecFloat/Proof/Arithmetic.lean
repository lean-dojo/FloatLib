/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Dispatch
public import LeanFloat.Floats.ExecFloat.Spec.Arithmetic

/-!
# Arithmetic refinement equations

The six `*_eq_spec` theorems rewrite `+`, `-`, `*`, `/`, `ExecFloat.sqrt`, and `ExecFloat.fma` to
the format's reference operations. They apply directly to notation and follow from the selected
capability's refinement proof. The equations hold for built-in and user-defined formats under
any supported planning policy.
-/

@[expose] public section

namespace LeanFloat.Floats.ExecFloat.Proof

open LeanFloat.Numerics

universe u

variable {F : Type u} [LeanFloat.Floats.ExecFloat.Backend.PolicyFor F]
    [EncodedFormat F]

/--
Executable addition agrees with reference addition; the theorem also applies to `left + right`.
-/
@[grind =] theorem add_eq_spec [LeanFloat.Floats.ExecFloat.Add F]
    (left right : LeanFloat.Floats.ExecFloat F) :
    LeanFloat.Floats.ExecFloat.add left right =
      LeanFloat.Floats.ExecFloat.Spec.add left right :=
  LeanFloat.Floats.ExecFloat.Add.run_eq_spec left right

/--
Executable subtraction agrees with reference subtraction; the theorem also applies to
`left - right`.
-/
@[grind =] theorem sub_eq_spec [LeanFloat.Floats.ExecFloat.Sub F]
    (left right : LeanFloat.Floats.ExecFloat F) :
    LeanFloat.Floats.ExecFloat.sub left right =
      LeanFloat.Floats.ExecFloat.Spec.sub left right :=
  LeanFloat.Floats.ExecFloat.Sub.run_eq_spec left right

/--
Executable multiplication agrees with reference multiplication; the theorem also applies to
`left * right`.
-/
@[grind =] theorem mul_eq_spec [LeanFloat.Floats.ExecFloat.Mul F]
    (left right : LeanFloat.Floats.ExecFloat F) :
    LeanFloat.Floats.ExecFloat.mul left right =
      LeanFloat.Floats.ExecFloat.Spec.mul left right :=
  LeanFloat.Floats.ExecFloat.Mul.run_eq_spec left right

/--
Executable division agrees with reference division; the theorem also applies to `left / right`.
-/
@[grind =] theorem div_eq_spec [LeanFloat.Floats.ExecFloat.Div F]
    (left right : LeanFloat.Floats.ExecFloat F) :
    LeanFloat.Floats.ExecFloat.div left right =
      LeanFloat.Floats.ExecFloat.Spec.div left right :=
  LeanFloat.Floats.ExecFloat.Div.run_eq_spec left right

/-- Executable square root agrees with the format's reference square root. -/
@[grind =] theorem sqrt_eq_spec [LeanFloat.Floats.ExecFloat.Sqrt F]
    (value : LeanFloat.Floats.ExecFloat F) :
    LeanFloat.Floats.ExecFloat.sqrt value =
      LeanFloat.Floats.ExecFloat.Spec.sqrt value :=
  LeanFloat.Floats.ExecFloat.Sqrt.run_eq_spec value

/-- Executable fused multiply-add agrees with the format's one-rounding reference operation. -/
@[grind =] theorem fma_eq_spec [LeanFloat.Floats.ExecFloat.Fma F]
    (left right addend : LeanFloat.Floats.ExecFloat F) :
    LeanFloat.Floats.ExecFloat.fma left right addend =
      LeanFloat.Floats.ExecFloat.Spec.fma left right addend :=
  LeanFloat.Floats.ExecFloat.Fma.run_eq_spec left right addend

end LeanFloat.Floats.ExecFloat.Proof
