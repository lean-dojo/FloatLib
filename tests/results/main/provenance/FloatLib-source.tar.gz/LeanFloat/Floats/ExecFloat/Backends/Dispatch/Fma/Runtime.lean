/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Backends.Dispatch.FmaWord.Runtime
public import LeanFloat.Floats.ExecFloat.Backends.FixedLimb.Pair.Fma.Runtime

/-!
# Final executable fused multiply-add dispatch

The dispatcher adds the fixed-limb pair-layout route to the smaller word-specialized kernels
without importing their refinement proofs. The pair route contains a complete finite candidate
chain; the dispatcher handles only exceptional inputs after that chain returns `none`.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model
namespace FmaBackend

/-- Select the best certified fused multiply-add backend for the concrete format. -/
@[inline] def dispatch {fmt : FloatFormat}
    (x y z : Model fmt) : Model fmt :=
  -- The fast path is an `Option` and the word dispatcher appears once, in the fallback, so the
  -- inlined code stays small; the fixed-format test folds for binary32 and binary64 and removes
  -- the two-word probe there. Neither fixed format is pair-eligible.
  let fast : Option (Model fmt) :=
    if FloatFormat.IsBinary32 fmt ∨ FloatFormat.IsBinary64 fmt then none
    else if _hpair : NativePair.Eligible fmt then NativePair.fmaFinite? x y z
    else none
  match fast with
  | some result => result
  | none => word x y z

end FmaBackend
end Model
end LeanFloat.Floats.Formats.BinaryInterchange
