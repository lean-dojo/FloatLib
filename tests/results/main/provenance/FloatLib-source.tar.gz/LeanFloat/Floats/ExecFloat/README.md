# ExecFloat

One value type for execution and proof:

```lean
import LeanFloat

open LeanFloat.Floats

abbrev Binary32 := ExecFloat.Binary (exponentBits := 8) (fractionBits := 23)

def add (left right : Binary32) : Binary32 := left + right

example (left right : Binary32) : add left right = ExecFloat.Spec.add left right :=
  ExecFloat.Proof.add_eq_spec left right
```

`ExecFloat F` stores the code chosen by format `F`. Each implementation carries `run = spec`.
Format-specific theorems then relate that spec to real arithmetic; see [THEOREMS.md](../THEOREMS.md).

Import `LeanFloat.Floats.ExecFloat`. Runtime-only clients can import
`LeanFloat.Floats.ExecFloat.Runtime`. Concrete formats live under `LeanFloat/Floats/Formats/`.

## Casts and mixed arithmetic

A cast names its destination. A mixed operation names its result type:

```lean
abbrev Binary64 := ExecFloat.Binary (exponentBits := 11) (fractionBits := 52)

def widen (source : Binary32) : ExecFloat.ConversionOutcome Binary64 :=
  source.cast (target := Binary64)

def addWide (left : Binary32) (right : Binary64) : ExecFloat.ConversionOutcome Binary64 :=
  ExecFloat.addAs (result := Binary64) left right
```

Finite mixed ops compute in the destination's exact system and round once. Binary destinations use
`Numerics.SignedRat` (rational + IEEE sign bit), so `(-0).cast` stays `-0`. Destinations without
negative zero (posits, fixed point) use `Rat`. `ExactMap` embeddings: [ExactMap.lean](ExactMap.lean).

`fma` is its own operation: rounding `x * y + z` once can differ from rounding product then sum.
Longer finite calculations: `ExactExpression.operand` plus `roundOnce` / `roundOnceWith`.

## Backends

Several certified backends can run the same op (byte tables, word/two-word kernels, binary32/64
specializations, two-limb binary128, wide-limb, exact baseline). The planner picks by estimated
cost. `NativeFPU.Unchecked` is not a planner candidate.

`#float_info YourType` shows the certified selection; `#float_info!` adds costs and theorems;
`#float_info [errors] YourType` lists registered bounds. Eligibility, policies, and how to add a
backend: [Backends/README.md](Backends/README.md).

## Elementary functions

`import LeanFloat` does not install `ExecFloat.Binary.exp`, `Model.exp`, `Model.pow`, or
`MathFunctions`. Import
`LeanFloat.Floats.Formats.BinaryInterchange.Configured.Transcendentals` (or the model barrel
`BinaryInterchange.Transcendentals`) by name. These are deterministic software kernels with
representation-bridge theorems, not a host-FPU path. Certified `sqrt` and `abs` stay on the
default import.

## Intervals

- Proof-side outward-rounded reals: `LeanFloat/Floats/Interval/Quantized.lean` (Flocq-style grid).
- Executable binary endpoints: `Model.Interval fmt`. Unordered or NaN endpoints become `whole fmt`.
- Optional Arb-backed transcendentals: `LeanFloatTests.Arb.ModelTranscendentals` (not kernel-checked).
