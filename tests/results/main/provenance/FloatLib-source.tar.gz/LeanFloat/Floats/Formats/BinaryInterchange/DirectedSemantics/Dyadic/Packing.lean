/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.DirectedSemantics.Basic

/-!
# Field packing for directed dyadic rounding

Directed rounding first chooses a point on the representable dyadic grid and then packs that point
into exponent and fraction fields. This module proves that the normal and subnormal packing
formulas preserve the chosen exact value.

The bounds are kept explicit because they also rule out accidental encodings of zero, infinity, or
NaN. Later directed-rounding proofs can reason about grid neighbors in mathematics and use these
lemmas only at the final bit-layout boundary.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model

open LeanFloat.Floats

noncomputable section

/-! ## Normal field bounds -/

/-- A normal unbiased exponent produces a positive biased exponent field. -/
theorem biasedExponent_pos (fmt : FloatFormat) (exponent : Int)
    (hmin : fmt.minNormalExponent ≤ exponent) :
    0 < exponent + Int.ofNat fmt.exponentBias := by
  unfold FloatFormat.minNormalExponent at hmin
  omega

/-- Conversion of a normal biased exponent through `Int.toNat` is exact. -/
theorem ofNat_toNat_biasedExponent (fmt : FloatFormat) (exponent : Int)
    (hmin : fmt.minNormalExponent ≤ exponent) :
    Int.ofNat (Int.toNat (exponent + Int.ofNat fmt.exponentBias)) =
      exponent + Int.ofNat fmt.exponentBias :=
  Int.toNat_of_nonneg (biasedExponent_pos fmt exponent hmin).le

/-- A representable normal exponent remains within the descriptor's finite exponent range. -/
theorem encodedExponent_le_maxFiniteExpField
    (fmt : FloatFormat) (exponent : Int)
    (hmin : fmt.minNormalExponent ≤ exponent)
    (hmax : exponent ≤ fmt.maxNormalExponent) :
    Int.toNat (exponent + Int.ofNat fmt.exponentBias) ≤
      fmt.maxFiniteExpField := by
  have hencoded :
      Int.ofNat (Int.toNat (exponent + Int.ofNat fmt.exponentBias)) =
        exponent + Int.ofNat fmt.exponentBias :=
    ofNat_toNat_biasedExponent fmt exponent hmin
  have hupper :
      Int.ofNat (Int.toNat (exponent + Int.ofNat fmt.exponentBias)) ≤
        Int.ofNat fmt.maxFiniteExpField := by
    rw [hencoded]
    unfold FloatFormat.maxNormalExponent at hmax
    omega
  exact Int.ofNat_le.mp hupper

/-- A normal unbiased exponent never encodes as the zero exponent field. -/
theorem encodedExponent_ne_zero
    (fmt : FloatFormat) (exponent : Int)
    (hmin : fmt.minNormalExponent ≤ exponent) :
    Int.toNat (exponent + Int.ofNat fmt.exponentBias) ≠ 0 := by
  have hpositiveInt :
      (0 : Int) < Int.ofNat (Int.toNat (exponent + Int.ofNat fmt.exponentBias)) := by
    rw [ofNat_toNat_biasedExponent fmt exponent hmin]
    exact biasedExponent_pos fmt exponent hmin
  exact Nat.ne_of_gt (Int.natCast_pos.mp hpositiveInt)

/-- Decoding a normal biased exponent recovers the intended normalized dyadic scale. -/
theorem decode_encodedExponent
    (fmt : FloatFormat) (exponent : Int)
    (hmin : fmt.minNormalExponent ≤ exponent) :
    Int.ofNat (Int.toNat (exponent + Int.ofNat fmt.exponentBias)) -
        Int.ofNat fmt.exponentBias - Int.ofNat fmt.fracWidth =
      exponent - Int.ofNat fmt.fracWidth := by
  rw [ofNat_toNat_biasedExponent fmt exponent hmin]
  ring

/-- Removing the implicit leading bit from a normalized mantissa fits the fraction field. -/
theorem normalizedMantissa_sub_pow2_lt
    (fmt : FloatFormat) (mantissa : Nat)
    (hlow : pow2 fmt.fracWidth ≤ mantissa)
    (hhigh : mantissa < pow2 (fmt.fracWidth + 1)) :
    mantissa - pow2 fmt.fracWidth < 2 ^ fmt.fracWidth := by
  rw [pow2_eq_two_pow] at hlow hhigh ⊢
  rw [pow_succ] at hhigh
  omega

/-- Restoring the implicit leading bit reconstructs a normalized mantissa exactly. -/
theorem pow2_add_normalizedMantissa_sub (fmt : FloatFormat) (mantissa : Nat)
    (hlow : pow2 fmt.fracWidth ≤ mantissa) :
    pow2 fmt.fracWidth + (mantissa - pow2 fmt.fracWidth) = mantissa :=
  Nat.add_sub_of_le hlow

/-! ## Field-packing semantics -/

/--
Packing a normalized mantissa at a representable unbiased exponent preserves its exact value.
-/
theorem toReal_ofFields_normalized
    (fmt : FloatFormat) (mantissa : Nat) (exponent : Int)
    (hlow : pow2 fmt.fracWidth ≤ mantissa)
    (hhigh : mantissa < pow2 (fmt.fracWidth + 1))
    (hmin : fmt.minNormalExponent ≤ exponent)
    (hmax : exponent ≤ fmt.maxNormalExponent)
    (hfinite :
      isFinite
          (ofFields fmt false
            (Int.toNat (exponent + Int.ofNat fmt.exponentBias))
            (mantissa - pow2 fmt.fracWidth)) =
        true) :
    toReal
        (ofFields fmt false
          (Int.toNat (exponent + Int.ofNat fmt.exponentBias))
          (mantissa - pow2 fmt.fracWidth)) =
      (mantissa : ℝ) * bpow (exponent - Int.ofNat fmt.fracWidth) := by
  rw [toReal_ofFields_normal_of_isFinite fmt false
    (Int.toNat (exponent + Int.ofNat fmt.exponentBias))
    (mantissa - pow2 fmt.fracWidth)
    (encodedExponent_ne_zero fmt exponent hmin)
    ((encodedExponent_le_maxFiniteExpField fmt exponent hmin hmax).trans_lt
      fmt.maxFiniteExpField_lt_two_pow)
    (normalizedMantissa_sub_pow2_lt fmt mantissa hlow hhigh)
    hfinite]
  simp only [Bool.false_eq_true, if_false, one_mul]
  rw [pow2_add_normalizedMantissa_sub fmt mantissa hlow]
  rw [decode_encodedExponent fmt exponent hmin]

/-- The downward zero-or-subnormal branch denotes its mantissa on the subnormal grid. -/
theorem toReal_roundSubnormalDown
    (fmt : FloatFormat) (mantissa : Nat)
    (hhigh : mantissa < pow2 fmt.fracWidth) :
    toReal
        (if mantissa = 0 then
          zero fmt false
        else
          ofFields fmt false 0 mantissa) =
      (mantissa : ℝ) * bpow (fmt.minSubnormalExponent) := by
  by_cases hzero : mantissa = 0
  · simp [hzero]
  · rw [if_neg hzero]
    rw [toReal_ofFields_subnormal fmt false mantissa hzero]
    · simp
    · simpa [pow2_eq_two_pow] using hhigh

/-- The minimum normal exponent encodes as biased exponent field one. -/
theorem encodedExponent_minNormal_eq_one (fmt : FloatFormat) :
    Int.toNat
        (fmt.minNormalExponent + Int.ofNat fmt.exponentBias) = 1 := by
  unfold FloatFormat.minNormalExponent
  simp

/--
The upward subnormal branch, including its smallest-normal boundary, preserves its grid value.
-/
theorem toReal_roundSubnormalUp
    (fmt : FloatFormat) (mantissa : Nat)
    (hzero : mantissa ≠ 0)
    (hhigh : mantissa ≤ pow2 fmt.fracWidth) :
    toReal
        (if mantissa = 0 then
          posMinSubnormal fmt
        else if pow2 fmt.fracWidth ≤ mantissa then
          ofFields fmt false 1 0
        else
          ofFields fmt false 0 mantissa) =
      (mantissa : ℝ) * bpow (fmt.minSubnormalExponent) := by
  rw [if_neg hzero]
  by_cases hnormal : pow2 fmt.fracWidth ≤ mantissa
  · have heq : mantissa = pow2 fmt.fracWidth :=
      Nat.le_antisymm hhigh hnormal
    rw [if_pos hnormal, heq]
    rw [show (1 : Nat) = Int.toNat
        (fmt.minNormalExponent + Int.ofNat fmt.exponentBias) by
      symm
      exact encodedExponent_minNormal_eq_one fmt]
    have hpack :
        toReal
            (ofFields fmt false
              (Int.toNat
                (fmt.minNormalExponent + Int.ofNat fmt.exponentBias))
              0) =
          (pow2 fmt.fracWidth : ℝ) *
            bpow
              (fmt.minNormalExponent -
                Int.ofNat fmt.fracWidth) := by
      have hmaxExp : 1 ≤ fmt.maxFiniteExpField :=
        Nat.succ_le_iff.mpr fmt.maxFiniteExpField_pos
      have hpair :
          1 < fmt.maxFiniteExpField ∨
            1 = fmt.maxFiniteExpField ∧
              0 ≤ fmt.maxFiniteFracField := by
        rcases hmaxExp.lt_or_eq with hlt | heq
        · exact Or.inl hlt
        · exact Or.inr ⟨heq, Nat.zero_le _⟩
      have hfiniteOne :
          isFinite (ofFields fmt false 1 0) = true :=
        isFinite_ofFields_normal_of_le_maxFinite fmt false 1 0
          (by decide)
          (hmaxExp.trans_lt fmt.maxFiniteExpField_lt_two_pow)
          (Nat.two_pow_pos _)
          hpair
      have hfinite :
          isFinite
              (ofFields fmt false
                (Int.toNat
                  (fmt.minNormalExponent + Int.ofNat fmt.exponentBias))
                0) =
            true := by
        rw [encodedExponent_minNormal_eq_one]
        exact hfiniteOne
      simpa using
        toReal_ofFields_normalized fmt (pow2 fmt.fracWidth)
          (fmt.minNormalExponent) le_rfl
          (pow2_lt_pow2_succ fmt.fracWidth) le_rfl
          (minNormalExponent_le_maxNormalExponent fmt)
          (by simpa only [Nat.sub_self] using hfinite)
    rw [hpack]
    congr 1
  · rw [if_neg hnormal]
    rw [toReal_ofFields_subnormal fmt false mantissa hzero]
    · simp
    · simpa [pow2_eq_two_pow] using Nat.lt_of_not_ge hnormal


end

end Model
end LeanFloat.Floats.Formats.BinaryInterchange
