/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.FixedPoint.Configured.Conversion.Proof

/-!
# Exact fixed-point conversion instances

This module installs exact-rational destination quantization and its canonical context for
unbounded configured fixed point.
-/

@[expose] public section

namespace LeanFloat.Floats

open LeanFloat.Numerics

namespace ExecFloat.FixedPoint
namespace Conversion

variable {radix : Radix} {fractionalDigits : Nat}

/-- Every exact fixed-point grid quantizes finite rationals with ties to even. -/
instance quantizer :
    LeanFloat.Floats.ExecFloat.Quantizer
      (ExecFloat.FixedPoint radix fractionalDigits) Rat where
  Context := Unit
  run := run
  spec := spec
  correct := implements_run

/-- Exact fixed-point conversion has one canonical context. -/
instance defaultQuantizer :
    LeanFloat.Floats.ExecFloat.DefaultQuantizer
      (ExecFloat.FixedPoint radix fractionalDigits) Rat where
  defaultContext := ()

end Conversion
end ExecFloat.FixedPoint
end LeanFloat.Floats
