/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Transcendentals.Hyperbolic

/-!
# Format-generic executable sine and cosine

Finite arguments are reduced against a configurable fixed-point approximation of `pi / 2`.
Reduced sine and cosine values are evaluated from exact common-denominator Taylor polynomials and
rounded once to `Model fmt`.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model

namespace Transcendentals

/-- Evaluate the reduced sine and cosine kernels and round each result once. -/
def sinCosTaylorSmallWith (fmt : FloatFormat) (config : Config)
    (value : Numerics.Dyadic) : Model fmt × Model fmt :=
  let squared : Numerics.Dyadic :=
    { negative := false
      significand := value.significand * value.significand
      exponent := value.exponent + value.exponent }
  let sinNumerator := evalDyadicPolyAsc config.sinCoeffsAsc squared
  let cosNumerator := evalDyadicPolyAsc config.cosCoeffsAsc squared
  let sinDyadic := mulDyadic value sinNumerator
  ( roundDyadicDivNat fmt sinDyadic config.sinDenominator
  , roundDyadicDivNat fmt cosNumerator config.cosDenominator )

/-- Reduce a finite dyadic argument and restore the resulting trigonometric quadrant. -/
def sinCosScaledWith (fmt : FloatFormat) (config : Config)
    (value : Numerics.Dyadic) : Model fmt × Model fmt :=
  let fixedValue := config.trigFixed.ofDyadic value
  let quadrant := FixedPoint.roundQuotientEven fixedValue config.halfPiFixed
  let remainder := fixedValue - quadrant * config.halfPiFixed
  let reduced := sinCosTaylorSmallWith fmt config (config.trigFixed.toDyadic remainder)
  match quadrant % 4 with
  | 0 => reduced
  | 1 => (reduced.2, neg reduced.1)
  | 2 => (neg reduced.1, neg reduced.2)
  | _ => (neg reduced.2, reduced.1)

end Transcendentals

/-- Evaluate sine and cosine with a provider called only for finite nonzero inputs. -/
def sinCosWithProvider {fmt : FloatFormat}
    (getConfig : Unit → Transcendentals.Config)
    (x : Model fmt) : Model fmt × Model fmt :=
  if isNaN x then
    let quiet := quietNaN x
    (quiet, quiet)
  else if isInf x then
    (invalidResult fmt, invalidResult fmt)
  else if isZero x then
    (x, posOne fmt)
  else
    match toDyadic? x with
    | none => (invalidResult fmt, invalidResult fmt)
    | some exact =>
        Transcendentals.sinCosScaledWith fmt (getConfig ()) exact

/-- Joint deterministic sine/cosine evaluation with explicit approximation data. -/
def sinCosWith {fmt : FloatFormat}
    (config : Transcendentals.Config) (x : Model fmt) : Model fmt × Model fmt :=
  sinCosWithProvider (fun _ => config) x

/-- Deterministic sine with explicit approximation data. -/
@[inline] def sinWith {fmt : FloatFormat}
    (config : Transcendentals.Config) (x : Model fmt) : Model fmt :=
  (sinCosWith config x).1

/-- Deterministic cosine with explicit approximation data. -/
@[inline] def cosWith {fmt : FloatFormat}
    (config : Transcendentals.Config) (x : Model fmt) : Model fmt :=
  (sinCosWith config x).2

/-- The configured approximation to pi, rounded once to the destination format. -/
def piWith (fmt : FloatFormat) (config : Transcendentals.Config) : Model fmt :=
  roundDyadic fmt (config.trigFixed.toDyadic (2 * config.halfPiFixed))

/-- Joint sine/cosine evaluation using the default configuration. -/
@[inline] def sinCos {fmt : FloatFormat} (x : Model fmt) : Model fmt × Model fmt :=
  sinCosWithProvider (fun _ => Transcendentals.Config.forFormat fmt) x

/-- Sine using the default configuration for the destination format. -/
@[inline] def sin {fmt : FloatFormat} (x : Model fmt) : Model fmt :=
  (sinCosWithProvider (fun _ => Transcendentals.Config.forFormat fmt) x).1

/-- Cosine using the default configuration for the destination format. -/
@[inline] def cos {fmt : FloatFormat} (x : Model fmt) : Model fmt :=
  (sinCosWithProvider (fun _ => Transcendentals.Config.forFormat fmt) x).2

/-- Pi using the default configuration for the destination format. -/
@[inline] def pi (fmt : FloatFormat) : Model fmt :=
  piWith fmt (Transcendentals.Config.forFormat fmt)

end Model
end LeanFloat.Floats.Formats.BinaryInterchange
