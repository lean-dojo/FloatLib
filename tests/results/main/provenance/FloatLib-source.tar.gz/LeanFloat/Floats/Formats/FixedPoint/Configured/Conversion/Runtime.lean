/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.FixedPoint.Configured.Runtime
public import LeanFloat.Floats.ExecFloat.Conversion.Core

/-!
# Exact fixed-point conversion runtime

An unbounded configured fixed-point destination has no overflow and no exceptional values. Every
finite rational is rounded once to the nearest grid coefficient, with ties to even. Infinity and
exceptional observations are rejected because the representation has no corresponding code.

Proofs of the reduction equations live in `Conversion.Proof`; destination capability instances
live in `Conversion.Instances`.
-/

@[expose] public section

namespace LeanFloat.Floats

open LeanFloat.Numerics

namespace ExecFloat.FixedPoint
namespace Conversion

variable {radix : Radix} {fractionalDigits : Nat}

/-- Quantize one complete rational observation into an unbounded fixed-point grid. -/
@[inline] def run (_context : Unit) :
    NumericalValue Rat →
      LeanFloat.Floats.ExecFloat.ConversionOutcome
        (ExecFloat.FixedPoint radix fractionalDigits)
  | .finite exact =>
      let rounded : ExecFloat.FixedPoint radix fractionalDigits :=
        ExecFloat.FixedPoint.roundRat exact
      .success rounded
        { inexact := ExecFloat.FixedPoint.toRat rounded != exact }
  | .infinity negative =>
      .failure (.infinity .source negative)
  | .exceptional exceptional =>
      .failure (.exceptional .source exceptional)

/-- Retained singleton relation for exact fixed-point conversion. -/
def spec :
    Quantization.Spec Unit (NumericalValue Rat)
      (LeanFloat.Floats.ExecFloat.ConversionOutcome
        (ExecFloat.FixedPoint radix fractionalDigits)) :=
  Quantization.Spec.ofFunction run

/-- Exact fixed-point values decode canonically to rational observations. -/
instance exactDecoder :
    LeanFloat.Floats.ExecFloat.ExactDecoder
      (ExecFloat.FixedPoint radix fractionalDigits) Rat where
  decode value := .finite (ExecFloat.FixedPoint.toRat value)

end Conversion
end ExecFloat.FixedPoint
end LeanFloat.Floats
