/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.Flocq.Theory.NumericalSystem
public import LeanFloat.Numerics.Operation.Semantics

/-!
# Exact executable arithmetic for integer-mantissa floats

Negation and multiplication preserve the `FloatRep` representation exactly: they require only
integer arithmetic on the stored mantissas and exponents. Addition is intentionally absent because
choosing and rounding a target exponent belongs to a concrete format policy.

The real-valued decoder is proof-facing and erased from compiled kernels.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.Flocq.FloatRep

open LeanFloat.Numerics

variable {β : Numerics.Radix}

/-- Negate the stored integer mantissa. -/
@[inline] def neg (x : FloatRep β) : FloatRep β :=
  { mantissa := -x.mantissa
    exponent := x.exponent }

/-- Multiply mantissas and add exponents without rounding. -/
@[inline] def mul (x y : FloatRep β) : FloatRep β :=
  { mantissa := x.mantissa * y.mantissa
    exponent := x.exponent + y.exponent }

/-- Executable mantissa negation denotes exact real negation. -/
@[simp] theorem toReal_neg (x : FloatRep β) :
    toReal (neg x) = -toReal x := by
  simp [neg, toReal]

/-- Executable mantissa/exponent multiplication denotes exact real multiplication. -/
@[simp] theorem toReal_mul (x y : FloatRep β) :
    toReal (mul x y) = toReal x * toReal y := by
  simp [mul, toReal, bpow.add_exp]
  ring

/-- Executable mantissa negation exactly refines real negation. -/
theorem neg_refines (β : Numerics.Radix) :
    Operation.Finite1 (numericalSystem β) (numericalSystem β)
      neg (fun value : ℝ => -value) := by
  unfold Operation.Finite1 Operation.RefinesFinite1 NumericalSystem.Represents numericalSystem
  intro x value hx
  simp only [NumericalValue.finite.injEq] at hx ⊢
  rw [toReal_neg]
  exact congrArg Neg.neg hx

/-- Executable mantissa/exponent multiplication exactly refines real multiplication. -/
theorem mul_refines (β : Numerics.Radix) :
    Operation.Finite2 (numericalSystem β) (numericalSystem β)
      (numericalSystem β) mul (fun left right : ℝ => left * right) := by
  unfold Operation.Finite2 Operation.RefinesFinite2 NumericalSystem.Represents numericalSystem
  intro x y left right hx hy
  simp only [NumericalValue.finite.injEq] at hx hy ⊢
  rw [toReal_mul, hx, hy]

end LeanFloat.Floats.Formats.Flocq.FloatRep
