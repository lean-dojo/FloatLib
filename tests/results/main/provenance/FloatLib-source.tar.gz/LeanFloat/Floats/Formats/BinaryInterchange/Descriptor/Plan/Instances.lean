/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Descriptor.Plan.Candidates
public import LeanFloat.Floats.ExecFloat.Core.Capability

/-!
# Binary descriptor arithmetic capabilities

These instances register the complete certified candidate sets with the universal `ExecFloat`
interface. Public arithmetic projects the memoized selected implementation and does not rerun the
selector.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange

instance addCapability (format : FloatFormat)
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor (Descriptor format)] :
    LeanFloat.Floats.ExecFloat.Add (Descriptor format) where
  spec := Descriptor.Spec.add
  candidates := Descriptor.Plan.addCandidates format

instance subCapability (format : FloatFormat)
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor (Descriptor format)] :
    LeanFloat.Floats.ExecFloat.Sub (Descriptor format) where
  spec := Descriptor.Spec.sub
  candidates := Descriptor.Plan.subCandidates format

instance mulCapability (format : FloatFormat)
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor (Descriptor format)] :
    LeanFloat.Floats.ExecFloat.Mul (Descriptor format) where
  spec := Descriptor.Spec.mul
  candidates := Descriptor.Plan.mulCandidates format

instance divCapability (format : FloatFormat)
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor (Descriptor format)] :
    LeanFloat.Floats.ExecFloat.Div (Descriptor format) where
  spec := Descriptor.Spec.div
  candidates := Descriptor.Plan.divCandidates format

instance sqrtCapability (format : FloatFormat)
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor (Descriptor format)] :
    LeanFloat.Floats.ExecFloat.Sqrt (Descriptor format) where
  spec := Descriptor.Spec.sqrt
  candidates := Descriptor.Plan.sqrtCandidates format

instance fmaCapability (format : FloatFormat)
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor (Descriptor format)] :
    LeanFloat.Floats.ExecFloat.Fma (Descriptor format) where
  spec := Descriptor.Spec.fma
  candidates := Descriptor.Plan.fmaCandidates format

end LeanFloat.Floats.Formats.BinaryInterchange
