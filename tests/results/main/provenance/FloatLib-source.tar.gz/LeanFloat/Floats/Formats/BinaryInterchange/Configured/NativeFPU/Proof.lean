/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.NativeFPU.Runtime
import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Core.Proof

/-!
# Correctness of configured fixed-format software operations

The public definitions in `NativeFPU.Runtime` are the proved fixed-word software operations in
both logical and compiled execution. These theorems connect each binary32 and binary64 operation
to the independent configured specification. Host experiments live in the separately imported
`NativeFPU.Unchecked` module and cannot enter this proof surface transitively. The historical
namespace and theorem names remain public for source compatibility.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Configured.NativeFPU

/-! ## Binary32 -/

/-- Certified software binary32 addition agrees with the independent configured specification. -/
theorem add32_eq_spec
    {width_le : FloatFormat.binary32.bitWidth ≤ 32}
    (left right : Binary32Value width_le) :
    add32 left right = Spec.add left right :=
  Backend.wordAdd_eq_spec left right

/-- Certified software binary32 subtraction agrees with the independent configured specification. -/
theorem sub32_eq_spec
    {width_le : FloatFormat.binary32.bitWidth ≤ 32}
    (left right : Binary32Value width_le) :
    sub32 left right = Spec.sub left right :=
  Backend.wordSub_eq_spec left right

/-- Certified software binary32 multiplication agrees with the configured specification. -/
theorem mul32_eq_spec
    {width_le : FloatFormat.binary32.bitWidth ≤ 32}
    (left right : Binary32Value width_le) :
    mul32 left right = Spec.mul left right :=
  Backend.wordMul_eq_spec left right

/-- Certified software binary32 division agrees with the independent configured specification. -/
theorem div32_eq_spec
    {width_le : FloatFormat.binary32.bitWidth ≤ 32}
    (left right : Binary32Value width_le) :
    div32 left right = Spec.div left right :=
  Backend.wordDiv_eq_spec left right

/-- Certified software binary32 square root agrees with the configured specification. -/
theorem sqrt32_eq_spec
    {width_le : FloatFormat.binary32.bitWidth ≤ 32}
    (value : Binary32Value width_le) :
    sqrt32 value = Spec.sqrt value :=
  Backend.wordSqrt_eq_spec value

/-- The direct-carrier binary32 FMA agrees with the independent configured specification. -/
theorem softwareFma32_eq_spec
    {width_le : FloatFormat.binary32.bitWidth ≤ 32}
    (left right addend : Binary32Value width_le) :
    softwareFma32 left right addend = Spec.fma left right addend :=
  Backend.wordFma_eq_spec left right addend

/-! ## Binary64 -/

/-- Certified software binary64 addition agrees with the independent configured specification. -/
theorem add64_eq_spec
    {width_le : FloatFormat.binary64.bitWidth ≤ 64}
    (left right : Binary64Value width_le) :
    add64 left right = Spec.add left right :=
  Backend.wordAdd_eq_spec left right

/-- Certified software binary64 subtraction agrees with the independent configured specification. -/
theorem sub64_eq_spec
    {width_le : FloatFormat.binary64.bitWidth ≤ 64}
    (left right : Binary64Value width_le) :
    sub64 left right = Spec.sub left right :=
  Backend.wordSub_eq_spec left right

/-- Certified software binary64 multiplication agrees with the configured specification. -/
theorem mul64_eq_spec
    {width_le : FloatFormat.binary64.bitWidth ≤ 64}
    (left right : Binary64Value width_le) :
    mul64 left right = Spec.mul left right :=
  Backend.wordMul_eq_spec left right

/-- Certified software binary64 division agrees with the independent configured specification. -/
theorem div64_eq_spec
    {width_le : FloatFormat.binary64.bitWidth ≤ 64}
    (left right : Binary64Value width_le) :
    div64 left right = Spec.div left right :=
  Backend.wordDiv_eq_spec left right

/-- Certified software binary64 square root agrees with the configured specification. -/
theorem sqrt64_eq_spec
    {width_le : FloatFormat.binary64.bitWidth ≤ 64}
    (value : Binary64Value width_le) :
    sqrt64 value = Spec.sqrt value :=
  Backend.wordSqrt_eq_spec value

/-- The direct-carrier binary64 FMA agrees with the independent configured specification. -/
theorem softwareFma64_eq_spec
    {width_le : FloatFormat.binary64.bitWidth ≤ 64}
    (left right addend : Binary64Value width_le) :
    softwareFma64 left right addend = Spec.fma left right addend :=
  Backend.wordFma_eq_spec left right addend

end LeanFloat.Floats.Formats.BinaryInterchange.Configured.NativeFPU
