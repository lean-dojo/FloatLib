/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.Logarithmic.Exact.Proof
public meta import Lean.Elab.Command
public import LeanFloat.Floats.ExecFloat.Info

/-!
# Inspection for exact logarithmic codes

The exact logarithmic core represents zero or a signed integral power of a chosen radix.
Multiplication is the only operation and is exact exponent addition. Addition is not exact on
integral powers of the radix, so addition, division, and conversion require a separate
approximation policy and are intentionally absent.

This optional meta module makes that boundary visible through `#float_info`. It reports the proved
real denotation and multiplication refinement while avoiding claims about bounded hardware
encodings, fractional log fields, or a universal six-operation API.
-/

public meta section

namespace LeanFloat.Floats.Formats.Logarithmic.FloatInfo.Command

open Lean Elab Command Meta
open LeanFloat.Numerics
open LeanFloat.Floats.ExecFloat

/--
Build the logarithmic description shared by the exact code and its configured `ExecFloat`
wrapper. Both carriers use the same value set and exact multiplication law; only execution and
wrapper-level theorem entries differ.
-/
meta def profile (base : Nat) : FormatProfile where
  family := "radix-parametric logarithmic number system"
  standard := "mathematical logarithmic format; no external encoding standard claimed"
  declarationPrefix := "LeanFloat.Floats.Formats.Logarithmic."
  representation :=
    [ ⟨"storage", "zero, or a sign bit and an unbounded Int exponent"⟩
    , ⟨"radix", toString base⟩
    , ⟨"nonzero value", s!"±{base}^exponent"⟩
    , ⟨"mantissa", "none"⟩
    , ⟨"exponent width", "unbounded"⟩
    ]
  values :=
    [ ⟨"zero", "one unsigned zero code"⟩
    , ⟨"nonzero finite values", s!"signed integral powers of {base}"⟩
    , ⟨"infinity", "no"⟩
    , ⟨"NaN", "no"⟩
    ]
  rounding :=
    [ ⟨"multiplication", "exact; signs xor and exponents add"⟩
    , ⟨"overflow/underflow", "none; the exponent is unbounded"⟩
    , ⟨"addition and division",
        "not supplied; the sum of two integral powers of the radix is in general not one"⟩
    , ⟨"conversion", "not supplied by this exact core"⟩
    ]
  execution :=
    [ ⟨"carrier", "inductive zero/value code with Bool sign and Int exponent"⟩
    , ⟨"dispatch", "direct constructor matching and integer exponent addition"⟩
    , ⟨"backend proof", "multiplication refinement is checked against real multiplication"⟩
    ]
  specializedOperations :=
    [ ⟨"mul", "the only arithmetic operation: exact sign xor and unbounded exponent addition"⟩ ]
  theoremSurfaces :=
    [ { topic := "exact real interpretation"
        declarations :=
          [ ``LeanFloat.Floats.Formats.Logarithmic.Code.toReal_zero
          , ``LeanFloat.Floats.Formats.Logarithmic.Code.toReal_mul
          ]
        applicability := .verifiedForType
        scope := "every code and every validated radix" }
    , { topic := "representation and multiplication refinement"
        declarations :=
          [ ``LeanFloat.Floats.Formats.Logarithmic.numericalSystem_represents_iff
          , ``LeanFloat.Floats.Formats.Logarithmic.mul_refines
          ]
        applicability := .verifiedForType
        scope := "all logarithmic codes; multiplication is exact over their real denotations"
        numericalGuarantee? := some {
          kinds := [.exactness]
          statement :=
            "Multiplication has zero real error because signs combine and unbounded exponents add exactly." } }
    ]
  nonclaims :=
    [ "the universal six-operation `ExecFloat` API is implemented for this carrier"
    , "addition, subtraction, division, square root, fused multiply-add, or transcendental functions are provided"
    , "a bounded hardware encoding or a fractional logarithm field is implied"
    ]

elab_rules : command
  | `(#float_info%$tk $type:term) =>
      LeanFloat.Floats.ExecFloat.FloatInfo.Command.withElaboratedType
          type fun typeExpr => do
        let some arguments ←
            unfoldUntilAppArgs? ``LeanFloat.Floats.Formats.Logarithmic.Code 1 typeExpr
          | throwUnsupportedSyntax
        let base ←
          Inspection.readNatProjection
            "logarithmic-format radix" ``Radix.base arguments[0]!
        logInfoAt tk <| ← Inspection.renderProfile (profile base) typeExpr .none

end LeanFloat.Floats.Formats.Logarithmic.FloatInfo.Command
