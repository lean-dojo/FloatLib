/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import Mathlib.Analysis.Complex.Trigonometric
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.DerivHyp
public import LeanFloat.Floats.Formats.BinaryInterchange.Rounding.Proof
public import LeanFloat.Floats.Interval.Quantized

/-!
# Proof contracts for transcendental approximations

The executable transcendental kernels are deterministic approximation algorithms. This module
deliberately does not turn determinism into an accuracy claim. Instead it provides the proof
objects needed to state, compose, and check three increasingly strong guarantees:

1. a real function value lies in a proved enclosure;
2. an executable result satisfies a proved absolute-error budget; and
3. an enclosure is narrow enough that both endpoints round to the same destination value.

The last condition yields a kernel-checked correctly-rounded real value. It is the standard
enclosure-stabilization criterion used by multiple-precision reference implementations, but the
theorem below is independent of any external oracle. An Arb or MPFR result enters this theorem only
after its enclosure fact has been justified inside the chosen trust boundary.

IEEE exceptional-value behavior and the sign of an exact zero remain separate bit-level
obligations. `roundAt` is the finite real grid semantics.

## References

* IEEE 754-2019, Section 9.2, recommended correctly rounded operations.
* F. de Dinechin, C. Lauter, and J.-M. Muller, “Fast and correctly rounded logarithms in
  double-precision,” RAIRO-Theoretical Informatics and Applications 41(1), 2007.
* S. Boldo and G. Melquiond, “Flocq: A Unified Library for Proving Floating-Point Algorithms in
  Coq,” IEEE ARITH 2011.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model.Transcendentals.Contract

open LeanFloat.Floats.Interval

/-- A checked closed real enclosure of `f x`. -/
structure RealEnclosure (f : ℝ → ℝ) (x : ℝ) where
  /-- Proved lower endpoint. -/
  lower : ℝ
  /-- Proved upper endpoint. -/
  upper : ℝ
  /-- The lower endpoint does not exceed the exact value. -/
  lower_le : lower ≤ f x
  /-- The exact value does not exceed the upper endpoint. -/
  le_upper : f x ≤ upper

namespace RealEnclosure

/-- The exact function value belongs to its enclosure. -/
theorem mem_Icc {f : ℝ → ℝ} {x : ℝ} (enclosure : RealEnclosure f x) :
    f x ∈ Set.Icc enclosure.lower enclosure.upper :=
  ⟨enclosure.lower_le, enclosure.le_upper⟩

/-- Every proved enclosure has ordered endpoints. -/
theorem lower_le_upper {f : ℝ → ℝ} {x : ℝ} (enclosure : RealEnclosure f x) :
    enclosure.lower ≤ enclosure.upper :=
  enclosure.lower_le.trans enclosure.le_upper

/--
Any candidate lying in the same enclosure has absolute error at most its width.

This conservative bound is often sufficient for a first verified implementation. A sharper
algorithm-specific proof can populate `ApproximationCertificate` directly.
-/
theorem abs_sub_le_width {f : ℝ → ℝ} {x candidate : ℝ}
    (enclosure : RealEnclosure f x)
    (hcandidate : enclosure.lower ≤ candidate ∧ candidate ≤ enclosure.upper) :
    |candidate - f x| ≤ enclosure.upper - enclosure.lower := by
  apply (abs_le).2
  constructor <;> linarith [enclosure.lower_le, enclosure.le_upper]

/-- Build an enclosure by monotonicity from a real input interval. -/
def ofMonotone {f : ℝ → ℝ} (hf : Monotone f) (input : RInterval)
    {x : ℝ} (hx : x ∈ input) : RealEnclosure f x where
  lower := f input.lo
  upper := f input.hi
  lower_le := hf hx.1
  le_upper := hf hx.2

/-- Round a proved real enclosure outward with any sound endpoint rounder. -/
noncomputable def outward {f : ℝ → ℝ} {x : ℝ}
    (rounder : Rounder) (enclosure : RealEnclosure f x) : RealEnclosure f x where
  lower := rounder.down enclosure.lower
  upper := rounder.up enclosure.upper
  lower_le := (rounder.down_le enclosure.lower).trans enclosure.lower_le
  le_upper := enclosure.le_upper.trans (rounder.le_up enclosure.upper)

/-- Sound exponential enclosure on an input interval. -/
noncomputable def exp (input : RInterval) {x : ℝ} (hx : x ∈ input) :
    RealEnclosure Real.exp x :=
  ofMonotone Real.exp_monotone input hx

/-- Sound hyperbolic-sine enclosure on an input interval. -/
noncomputable def sinh (input : RInterval) {x : ℝ} (hx : x ∈ input) :
    RealEnclosure Real.sinh x :=
  ofMonotone Real.sinh_strictMono.monotone input hx

/-- Global sound sine enclosure. -/
def sin (x : ℝ) : RealEnclosure Real.sin x where
  lower := -1
  upper := 1
  lower_le := Real.neg_one_le_sin x
  le_upper := Real.sin_le_one x

/-- Global sound cosine enclosure. -/
def cos (x : ℝ) : RealEnclosure Real.cos x where
  lower := -1
  upper := 1
  lower_le := Real.neg_one_le_cos x
  le_upper := Real.cos_le_one x

/-- Global sound hyperbolic-tangent enclosure. -/
def tanh (x : ℝ) : RealEnclosure Real.tanh x where
  lower := -1
  upper := 1
  lower_le := (Real.neg_one_lt_tanh x).le
  le_upper := (Real.tanh_lt_one x).le

/--
Sound hyperbolic-cosine enclosure on an input interval.

The upper endpoint uses the largest absolute endpoint because `cosh` is even and increases with
absolute value.
-/
noncomputable def cosh (input : RInterval) {x : ℝ} (hx : x ∈ input) :
    RealEnclosure Real.cosh x where
  lower := 1
  upper := Real.cosh (RInterval.absMax input)
  lower_le := Real.one_le_cosh x
  le_upper := by
    apply (Real.cosh_le_cosh).2
    have hmaxNonnegative : 0 ≤ RInterval.absMax input :=
      (abs_nonneg input.lo).trans (le_max_left |input.lo| |input.hi|)
    simpa only [abs_of_nonneg hmaxNonnegative] using
      (RInterval.abs_le_absMax (I := input) hx)

/-- Convert the existing proved logarithm interval into the common enclosure contract. -/
noncomputable def log (rounder : Rounder) (input : RInterval)
    {x : ℝ} (hpositive : 0 < input.lo) (hx : x ∈ input) :
    RealEnclosure Real.log x :=
  let output := RInterval.log rounder input
  let sound := RInterval.mem_log (R := rounder) hpositive hx
  { lower := output.lo
    upper := output.hi
    lower_le := sound.1
    le_upper := sound.2 }

/--
Convert the existing proved square-root interval into the common enclosure contract.

No sign hypothesis is needed because `Real.sqrt` is monotone on all of `ℝ`; the enclosure is
informative only when `input` is nonnegative.
-/
noncomputable def sqrt (rounder : Rounder) (input : RInterval)
    {x : ℝ} (hx : x ∈ input) :
    RealEnclosure Real.sqrt x :=
  let output := RInterval.sqrt rounder input
  let sound := RInterval.mem_sqrt (R := rounder) hx
  { lower := output.lo
    upper := output.hi
    lower_le := sound.1
    le_upper := sound.2 }

end RealEnclosure

/--
A proved enclosure whose endpoints select one nearest-even destination-grid value.

This is a mathematical certificate. Computing the endpoints may use interval arithmetic, a formal
polynomial proof, or an explicitly trusted external enclosure source.
-/
structure StableEnclosure (fmt : FloatFormat) (f : ℝ → ℝ) (x : ℝ)
    extends RealEnclosure f x where
  /-- Both enclosure endpoints round to the same finite-grid real value. -/
  endpoints_round_same : roundAt fmt lower = roundAt fmt upper

namespace StableEnclosure

/-- A stable enclosure determines the correctly rounded real value of the exact function. -/
theorem roundAt_eq_roundAt_lower {fmt : FloatFormat} {f : ℝ → ℝ} {x : ℝ}
    (enclosure : StableEnclosure fmt f x) :
    roundAt fmt (f x) = roundAt fmt enclosure.lower := by
  apply le_antisymm
  · calc
      roundAt fmt (f x) ≤ roundAt fmt enclosure.upper :=
        roundAt_mono fmt enclosure.le_upper
      _ = roundAt fmt enclosure.lower := enclosure.endpoints_round_same.symm
  · exact roundAt_mono fmt enclosure.lower_le

end StableEnclosure

/--
A finite encoded result backed by a stable real enclosure.

The final equality connects the stored result to the lower endpoint's rounded value. Together with
stability, this proves correct nearest-even rounding of the exact function in finite real
semantics.
-/
structure CertifiedRoundedResult
    (fmt : FloatFormat) (f : ℝ → ℝ) (x : ℝ)
    extends StableEnclosure fmt f x where
  /-- Encoded result returned by an implementation. -/
  value : Model fmt
  /-- The encoded result is finite, so `toReal` is its complete numerical magnitude. -/
  value_finite : isFinite value = true
  /-- The implementation selected the endpoint-certified rounded real value. -/
  value_eq_lower_round : toReal value = roundAt fmt lower

namespace CertifiedRoundedResult

/-- The certified encoded result has the correctly rounded real value of `f x`. -/
theorem toReal_value_eq_roundAt {fmt : FloatFormat} {f : ℝ → ℝ} {x : ℝ}
    (result : CertifiedRoundedResult fmt f x) :
    toReal result.value = roundAt fmt (f x) := by
  rw [result.value_eq_lower_round, result.toStableEnclosure.roundAt_eq_roundAt_lower]

end CertifiedRoundedResult

/--
Whole-algorithm absolute-error contract for an executable unary approximation.

No executable kernel receives this label merely by inhabiting the structure's parameters; a proof
must establish the output finiteness and error inequality for every finite input in scope.
-/
structure ApproximationCertificate
    (fmt : FloatFormat)
    (f : ℝ → ℝ)
    (approximation : Model fmt → Model fmt)
    (errorBudget : Model fmt → ℝ) : Prop where
  /-- Every advertised error budget is nonnegative. -/
  budget_nonnegative : ∀ input, 0 ≤ errorBudget input
  /-- Finite inputs in scope produce finite outputs. -/
  output_finite :
    ∀ input, isFinite input = true → isFinite (approximation input) = true
  /-- The decoded result satisfies the advertised real absolute-error budget. -/
  error_le :
    ∀ input, isFinite input = true →
      |toReal (approximation input) - f (toReal input)| ≤ errorBudget input

/--
Whole-algorithm correctly-rounded finite-real contract.

This is a proposition rather than a data record: both components are proof obligations and no
runtime information is retained.
-/
def CorrectlyRoundedCertificate
    (fmt : FloatFormat)
    (f : ℝ → ℝ)
    (implementation : Model fmt → Model fmt) : Prop :=
  (∀ input, isFinite input = true → isFinite (implementation input) = true) ∧
  (∀ input, isFinite input = true →
    toReal (implementation input) = roundAt fmt (f (toReal input)))

namespace CorrectlyRoundedCertificate

/-- Finite inputs in scope produce finite outputs. -/
theorem output_finite {fmt : FloatFormat} {f : ℝ → ℝ}
    {implementation : Model fmt → Model fmt}
    (certificate : CorrectlyRoundedCertificate fmt f implementation) :
    ∀ input, isFinite input = true → isFinite (implementation input) = true :=
  certificate.1

/-- Every finite result equals nearest-even rounding of the exact real function. -/
theorem toReal_eq_roundAt {fmt : FloatFormat} {f : ℝ → ℝ}
    {implementation : Model fmt → Model fmt}
    (certificate : CorrectlyRoundedCertificate fmt f implementation) :
    ∀ input, isFinite input = true →
      toReal (implementation input) = roundAt fmt (f (toReal input)) :=
  certificate.2

end CorrectlyRoundedCertificate

end Model.Transcendentals.Contract
end LeanFloat.Floats.Formats.BinaryInterchange
