/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Carrier
public import LeanFloat.Floats.Formats.FixedPoint.Exact.Runtime

/-!
# Configured exact fixed-point identity

This module defines the encoded family and public `ExecFloat.FixedPoint` type. Executable
operations, refinement proofs, planner metadata, and dispatch instances live in downstream
modules.
-/

@[expose] public section

namespace LeanFloat.Floats

open LeanFloat.Numerics

namespace ExecFloat
namespace FixedPoint

/-- Type-level identity of an exact fixed-point grid. -/
inductive Family (radix : Radix) (fractionalDigits : Nat) where
  | format

instance (radix : Radix) (fractionalDigits : Nat) :
    EncodedFormat (Family radix fractionalDigits) where
  Code := Formats.FixedPoint.Code radix fractionalDigits
  Scalar := ℚ

instance (radix : Radix) (fractionalDigits : Nat) :
    FormatSemantics (Family radix fractionalDigits) :=
  FormatSemantics.ofFinite _ fun code ↦ code.toRat

end FixedPoint

/-- Exact radix-parametric fixed point on the common executable carrier. -/
abbrev FixedPoint (radix : Radix) (fractionalDigits : Nat) :=
  LeanFloat.Floats.ExecFloat (FixedPoint.Family radix fractionalDigits)

end ExecFloat

end LeanFloat.Floats
