/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Transcendentals.FixedPoint
public import LeanFloat.Floats.Formats.BinaryInterchange.Transcendentals.Config
public import LeanFloat.Floats.Formats.BinaryInterchange.Transcendentals.Contract
public import LeanFloat.Floats.Formats.BinaryInterchange.Transcendentals.ExpLog
public import LeanFloat.Floats.Formats.BinaryInterchange.Transcendentals.Hyperbolic
public import LeanFloat.Floats.Formats.BinaryInterchange.Transcendentals.Trig
public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.Power
public import LeanFloat.Numerics.Capabilities.Elementary

/-!
# Format-generic executable transcendental functions

This module exports deterministic `exp`, `log`, `sinh`, `cosh`, `tanh`, `sin`, and `cos` operations
for `Model fmt`, together with reusable fixed-point primitives and explicit approximation
configuration.

## What is executable and what is proved

* `Model.exp`, `log`, `sinh`, `cosh`, `tanh`, `sin`, and `cos` are pure executable kernels. Their
  exceptional-value behavior is deterministic, but they currently have no global real-error or
  correct-rounding theorem. The intended accuracy is one final nearest-even rounding of an
  approximation whose own error is small against the destination precision: `sin`, `cos`, and the
  small-argument branches of `sinh` and `tanh` evaluate exact Taylor polynomials whose length grows
  with `fracWidth` and round once; `exp` and `log` work in fixed point with
  `GenerationPolicy.guardBits` extra bits. The coefficient schedules and guard budgets are design
  choices, not proved error bounds. Results within one unit in the last place are a target, not a
  library guarantee; only a certificate from `Contract` turns an enclosure into a theorem.
* `Model.Transcendentals.Contract` supplies kernel-checked real enclosures and certificate types.
  These are proof objects over `ℝ`; an executable kernel gains an accuracy claim only when a proof
  connects that kernel to one of those contracts.
* `LeanFloatTests.Arb.ModelTranscendentals` is an optional `IO` adapter supporting explicit IEEE
  rounding directions. It trusts Arb/python-flint to enclose the real function and fails if an
  enclosure does not stabilize to one destination value.

There is no dedicated tangent kernel. Computing `sin x / cos x` is available as ordinary
composition, with a rounding after sine, cosine, and division and the expected sensitivity near
zeros of cosine. The pure kernels also do not currently return IEEE status flags or accept a
per-call directed-rounding mode.

`ExactExpression` can round an exactly represented rational expression once, but real
transcendentals are not rational operations in general. A composition of these kernels therefore
approximates and rounds at each function boundary. Certifying one final rounding for the whole
composition requires a real enclosure or another exact-real procedure covering that composition.

`import LeanFloat` does not load this module, so `Model.exp`, `Model.pow`, and `MathFunctions`
are absent from the default environment. Import this module, or
`LeanFloat.Floats.Formats.BinaryInterchange.Configured.Transcendentals`, by name. Kernel
submodules remain importable individually; `#float_info` still loads `Contract` through
`Info/Profile.lean` without exposing these kernels.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model

open LeanFloat.Numerics

/-- Deterministic floating-point exponentiation. -/
instance {fmt : FloatFormat} : Pow (Model fmt) (Model fmt) where
  pow := pow

/-- Generic deterministic transcendental and elementary functions. -/
instance {fmt : FloatFormat} : MathFunctions (Model fmt) where
  exp := exp
  tanh := tanh
  cosh := cosh
  sqrt := sqrt
  abs := abs
  log := log
  pi := pi fmt
  cos := cos
  sin := sin
  sinh := sinh

end Model
end LeanFloat.Floats.Formats.BinaryInterchange
