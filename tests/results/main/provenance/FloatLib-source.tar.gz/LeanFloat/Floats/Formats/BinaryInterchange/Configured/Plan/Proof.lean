/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Core.Capability

/-!
# Selection proofs for configured binary execution plans

This module relates first-order public entry points to the proof-carrying candidate selected by a
backend policy. Keeping the lemma separate lets execution-only modules avoid importing selection
proofs unless they need the equality.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Configured.Plan

open LeanFloat.Floats.ExecFloat
open LeanFloat.Floats.ExecFloat.Backend
/-! ## First-order capability proofs -/

/--
Relate a proved first-order entry point to the certificate selected from a complete portfolio.

This lemma deliberately returns only an equality, not a `Capability` structure. Public
monomorphic instances must construct their capability directly so Lean can reduce the `execute`
projection to the named kernel during code generation. Hiding that structure construction behind
a helper leaves a runtime capability object and an indirect `lean_apply_N` call in the hot path.
-/
theorem firstOrder_eq_selected
    {F : Type} [LeanFloat.Numerics.EncodedFormat F]
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor F]
    (operation : Operation)
    (spec : LeanFloat.Floats.ExecFloat.OperationSignature F operation)
    (candidates : CandidateSet (Certified spec))
    (execute : LeanFloat.Floats.ExecFloat.OperationSignature F operation)
    (execute_eq_spec : execute = spec) :
    execute = (selectCertified planning.policy candidates).run :=
  execute_eq_spec.trans
    (selectCertified_run_eq_spec planning.policy candidates).symm

end LeanFloat.Floats.Formats.BinaryInterchange.Configured.Plan
