/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.Codebook.Core.Runtime
public import LeanFloat.Numerics.Core.Proof

/-!
# Proof-indexed views of exact finite codebooks

The views in this module attach erased denotation proofs to the same exact-width runtime bit
vector. They introduce no additional executable representation.
-/

@[expose] public section

open LeanFloat.Numerics

namespace LeanFloat.Floats.Formats.Codebook

universe u

variable {width : Nat} {α : Type u}

/-- A codebook word bundled with an erased proof of its complete denotation. -/
abbrev At (book : Codebook width α) (value : NumericalValue α) :=
  book.numericalSystem.At value

/-- A codebook word bundled with an erased proof of its finite denotation. -/
abbrev AtFinite (book : Codebook width α) (value : α) :=
  book.numericalSystem.AtFinite value

/-- The numerical-system wrapper preserves the codebook's denotation definitionally. -/
theorem numericalSystem_denote (book : Codebook width α) (code : Code book) :
    book.numericalSystem.denote code = book.denote code :=
  rfl

end LeanFloat.Floats.Formats.Codebook
