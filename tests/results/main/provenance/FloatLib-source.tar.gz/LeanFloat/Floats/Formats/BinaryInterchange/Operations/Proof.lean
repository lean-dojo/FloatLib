/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module -- shake: keep-all

public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.Adjacent.Proof.Boundaries
public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.Adjacent.Proof.Core
public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.Compare.Proof
public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.MixedPrecision.MatmulProof
public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.Proof.Exponent
public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.Proof.InvalidSignals
public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.Proof.Remainder
public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.Proof.RoundToIntegral

/-!
# Contracts for standard binary operations

This module collects the independently owned proof families for comparison, adjacent-value
operations, IEEE remainder, integral rounding, exponent operations, and the `invalid` indicators
of the status-bearing selection operations.
-/
