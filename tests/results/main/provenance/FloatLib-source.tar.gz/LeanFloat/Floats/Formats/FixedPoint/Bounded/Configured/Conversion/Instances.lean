/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.FixedPoint.Bounded.Configured.Conversion.Proof

/-!
# Bounded fixed-point conversion instances

This module installs exact-rational destination quantization under an explicit overflow policy.
The context-free instance chooses checked conversion and therefore rejects overflow.
-/

@[expose] public section

namespace LeanFloat.Floats

open LeanFloat.Numerics

namespace ExecFloat.BoundedFixedPoint
namespace Conversion

variable {radix : Radix} {fractionalDigits width : Nat}

/-- Bounded fixed-point conversion requires an explicit overflow policy. -/
instance quantizer :
    LeanFloat.Floats.ExecFloat.Quantizer
      (ExecFloat.BoundedFixedPoint radix fractionalDigits width) Rat where
  Context := OverflowPolicy
  run := run
  spec := spec
  correct := implements_run

/-- Context-free bounded conversion is checked and rejects overflow. -/
instance defaultQuantizer :
    LeanFloat.Floats.ExecFloat.DefaultQuantizer
      (ExecFloat.BoundedFixedPoint radix fractionalDigits width) Rat where
  defaultContext := .reject

end Conversion
end ExecFloat.BoundedFixedPoint
end LeanFloat.Floats
