/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module -- shake: keep-all

public import LeanFloat.Floats.Formats.Block.SharedScale.Proof
public import LeanFloat.Floats.Formats.Block.Configured.Proof
public import LeanFloat.Floats.Formats.Block.Configured.Conversion.Runtime
public import LeanFloat.Floats.Formats.Block.Configured.Conversion.Proof
public import LeanFloat.Floats.Formats.Block.Configured.Conversion.Instances
public meta import LeanFloat.Floats.Formats.Block.Configured.Info
public meta import LeanFloat.Floats.Formats.Block.SharedScale.Info

/-!
# Contextual and block-scaled numerical formats

This module exports formats whose runtime codes and scalar meanings are whole blocks rather than
single IEEE-style words.

## References

* Open Compute Project, *OCP Microscaling Formats (MX) Specification, Version 1.0*,
  <https://www.opencompute.org/documents/ocp-microscaling-formats-mx-v1-0-spec-final-pdf>.
-/

@[expose] public section
