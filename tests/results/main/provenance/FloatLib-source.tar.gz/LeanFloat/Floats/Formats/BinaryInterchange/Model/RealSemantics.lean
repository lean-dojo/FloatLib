/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Dyadic.Rational
public import LeanFloat.Floats.Formats.Flocq.Theory.Core
import LeanFloat.Numerics.Exact.Dyadic.Arithmetic.Proof
public import LeanFloat.Floats.Formats.BinaryInterchange.Dyadic.Classification

/-!
# Real interpretation of binary models

This module assigns exact real values to finite format-parameterized bit patterns. It deliberately
does not define arithmetic: operation refinement belongs in later modules, after the executable
operation has been related to one exact dyadic intermediate and one rounding step.
-/

@[expose] public section

noncomputable section

open LeanFloat.Floats.Formats.Flocq

namespace LeanFloat.Numerics.Dyadic

/-- Interpret an exact dyadic `(-1)^sign * significand * 2^exponent` as a real. -/
noncomputable def toReal (d : Dyadic) : ℝ :=
  (d.signedSignificand : ℝ) *
    LeanFloat.Floats.Formats.Flocq.bpow LeanFloat.Numerics.binaryRadix d.exponent

/-- The exact rational and real interpretations of a dyadic agree. -/
@[simp, norm_cast] theorem cast_toRat (d : Dyadic) :
    (d.toRat : ℝ) = d.toReal := by
  simp [toRat, toReal, LeanFloat.Floats.Formats.Flocq.bpow,
    LeanFloat.Numerics.binaryRadix, LeanFloat.Numerics.Radix.toReal,
    Rat.cast_zpow]

/-- Casting the signed significand separates its sign from its natural magnitude. -/
@[simp] theorem cast_signedSignificand (d : Dyadic) :
    (d.signedSignificand : ℝ) =
      (if d.negative then (-1 : ℝ) else 1) * (d.significand : ℝ) := by
  cases hnegative : d.negative <;>
    simp [signedSignificand, hnegative]

/-- A nonnegative dyadic constructor has the expected unsigned real denotation. -/
@[simp] theorem toReal_mk_false (significand : Nat) (exponent : Int) :
    (Dyadic.mk false significand exponent).toReal =
      (significand : ℝ) *
        LeanFloat.Floats.Formats.Flocq.bpow LeanFloat.Numerics.binaryRadix exponent := by
  simp [toReal]

end LeanFloat.Numerics.Dyadic

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model
namespace Dyadic

/-- A dyadic with zero mantissa denotes zero, independently of its sign and exponent. -/
@[simp] theorem toReal_of_mantissa_zero (sign : Bool) (exponent : Int) :
    (Numerics.Dyadic.mk sign 0 exponent).toReal = 0 := by
  cases sign <;>
    simp [Numerics.Dyadic.toReal, Numerics.Dyadic.signedSignificand]

/-- Numerics.Dyadic real semantics expressed using a signed integer significand. -/
theorem toReal_eq_signedSignificand (d : Numerics.Dyadic) :
    d.toReal = (d.signedSignificand : ℝ) *
      LeanFloat.Floats.Formats.Flocq.bpow LeanFloat.Numerics.binaryRadix d.exponent := by
  rfl

/-- Left-shifting a signed significand multiplies its real value by the matching power of two. -/
theorem signedSignificand_shiftLeft (d : Numerics.Dyadic) (shift : Nat) :
    ((Numerics.Dyadic.mk d.negative
      (Nat.shiftLeft d.significand shift) 0).signedSignificand : ℝ) =
      (d.signedSignificand : ℝ) *
        LeanFloat.Floats.Formats.Flocq.bpow LeanFloat.Numerics.binaryRadix (Int.ofNat shift) := by
  cases hs : d.negative <;>
    simp [Numerics.Dyadic.signedSignificand, hs, Nat.shiftLeft_eq,
      LeanFloat.Floats.Formats.Flocq.bpow,
      LeanFloat.Numerics.binaryRadix, Numerics.Radix.toReal]

/-- Exact dyadic addition agrees with addition in the real semantics. -/
theorem toReal_addDyadic (a b : Numerics.Dyadic) :
    (addDyadic a b).toReal = a.toReal + b.toReal := by
  have h :=
    congrArg (fun value : Rat => (value : ℝ))
      (Numerics.Dyadic.add_toRat a b)
  simpa only [addDyadic, Numerics.Dyadic.cast_toRat, Rat.cast_add] using h

/-- The exact dyadic product used by `Model.mul` agrees with real multiplication. -/
theorem toReal_mul (a b : Numerics.Dyadic) :
    (Numerics.Dyadic.mk (Bool.xor a.negative b.negative)
      (a.significand * b.significand) (a.exponent + b.exponent)).toReal =
      a.toReal * b.toReal := by
  cases ha : a.negative <;> cases hb : b.negative <;>
    simp [Numerics.Dyadic.toReal, Numerics.Dyadic.signedSignificand,
      ha, hb, Bool.xor, bpow.add_exp] <;> ring

end Dyadic

/-- Real interpretation for finite values (undefined for NaN/Inf). -/
noncomputable def toReal? {fmt : FloatFormat} (x : Model fmt) : Option ℝ :=
  match toDyadic? x with
  | some d => some d.toReal
  | none => none

/-- Total real interpretation (maps NaN/Inf to `0`; use `toReal?` for proofs). -/
noncomputable def toReal {fmt : FloatFormat} (x : Model fmt) : ℝ :=
  match toReal? x with
  | some r => r
  | none => 0

/-- Real interpretation of Lean's unpacked logical float; NaN and infinity map to zero. -/
noncomputable def unpackedToReal (x : Float.Model.UnpackedFloat) : ℝ :=
  match unpackedToDyadic? x with
  | some d => d.toReal
  | none => 0

/-- Both signed zeros of Lean's unpacked float model denote the real zero. -/
@[simp] theorem unpackedToReal_zero (sign : Float.Model.UnpackedFloat.Sign) :
    unpackedToReal (.zero sign) = 0 := by
  cases sign <;>
    simp [unpackedToReal, unpackedToDyadic?, Numerics.Dyadic.toReal,
      Numerics.Dyadic.signedSignificand]

/-- A finite unpacked model value denotes its signed integer mantissa times its dyadic scale. -/
@[simp] theorem unpackedToReal_finite
    (sign : Float.Model.UnpackedFloat.Sign) (mantissa : Nat) (exponent : Int)
    (hm : 0 < mantissa) :
    unpackedToReal (.finite sign mantissa exponent hm) =
      (if modelSignBit sign then (-1 : ℝ) else 1) * (mantissa : ℝ) *
        LeanFloat.Floats.Formats.Flocq.bpow LeanFloat.Numerics.binaryRadix exponent := by
  cases sign <;>
    simp [unpackedToReal, unpackedToDyadic?, Numerics.Dyadic.toReal,
      Numerics.Dyadic.signedSignificand, modelSignBit]

/-- `toReal` is the dyadic denotation on finite values and zero on NaN and infinities. -/
lemma toReal_eq {fmt : FloatFormat} (x : Model fmt) :
    toReal x = match toDyadic? x with
      | some d => d.toReal
      | none => 0 := by
  cases h : toDyadic? x <;> simp [toReal, toReal?, h]

/-- The policy-aware zero constructor denotes zero for every encoding. -/
@[simp] theorem toReal_zero (fmt : FloatFormat) (sign : Bool) :
    toReal (zero fmt sign) = 0 := by
  rw [toReal_eq, toDyadic?_zero]
  simp [Numerics.Dyadic.toReal, Numerics.Dyadic.signedSignificand]

/-- Executable and logical decoding agree for formats represented by Lean's IEEE model. -/
theorem toReal_eq_unpackedToReal_toModel {fmt : FloatFormat} (hfmt : fmt.isIEEE = true)
    (x : Model fmt) :
    toReal x = unpackedToReal (toModel x) := by
  rw [toReal_eq, toDyadic?_ieee_eq_model fmt hfmt x]
  rfl

end Model
end LeanFloat.Floats.Formats.BinaryInterchange

end -- noncomputable section
