/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Numerics.Operation.Context

/-!
# IEEE rounding modes for `Model`

The four modes below are the deterministic rounding-direction attributes defined by IEEE 754.
They are separate from the broader quantization policy vocabulary, which also contains stochastic
and non-IEEE nearest-away modes.

This is the shared mode definition for executable rounding and its proofs.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model

/-- Deterministic IEEE-754 rounding-direction attribute. -/
inductive IEEERoundingMode where
  /-- Round to the nearest representable value, breaking ties toward an even significand. -/
  | nearestEven
  /-- Round toward zero. -/
  | towardZero
  /-- Round toward positive infinity. -/
  | towardPositiveInfinity
  /-- Round toward negative infinity. -/
  | towardNegativeInfinity
  deriving DecidableEq, Repr

namespace IEEERoundingMode

/--
All deterministic IEEE rounding modes.

Exhaustive checks should use this list instead of repeating the constructors, so adding or
reordering a mode cannot silently leave part of the validation surface behind.
-/
def all : List IEEERoundingMode :=
  [ .nearestEven, .towardZero, .towardPositiveInfinity, .towardNegativeInfinity ]

/--
A concise, stable name for diagnostics and interchange files.

The directed modes use the customary `towardPositive` and `towardNegative` spellings; their
constructors retain the more explicit `Infinity` suffix used in proofs and APIs.
-/
def name : IEEERoundingMode → String
  | .nearestEven => "nearestEven"
  | .towardZero => "towardZero"
  | .towardPositiveInfinity => "towardPositive"
  | .towardNegativeInfinity => "towardNegative"

instance : ToString IEEERoundingMode where
  toString := name

/--
The quantization-policy rounding mode with the same direction.

`Numerics.RoundingMode` also contains nearest-away and stochastic rounding, which have no IEEE
direction attribute; this map is therefore an embedding, not a bijection.
-/
def toRoundingMode : IEEERoundingMode → Numerics.RoundingMode
  | .nearestEven => .nearestEven
  | .towardZero => .towardZero
  | .towardPositiveInfinity => .towardPositive
  | .towardNegativeInfinity => .towardNegative

end IEEERoundingMode

end Model
end LeanFloat.Floats.Formats.BinaryInterchange

namespace LeanFloat.IEEERounding

/-!
The optional `LeanFloat.IEEERounding` scope provides mathematical spellings for the two directed
infinity modes. Keeping these notations scoped prevents them from changing the meaning of `∞` in
files that use extended real numbers.
-/

/-- Round toward positive infinity. Requires `open scoped LeanFloat.IEEERounding`. -/
scoped notation "+∞" =>
  Floats.Formats.BinaryInterchange.Model.IEEERoundingMode.towardPositiveInfinity

/-- Round toward negative infinity. Requires `open scoped LeanFloat.IEEERounding`. -/
scoped notation "-∞" =>
  Floats.Formats.BinaryInterchange.Model.IEEERoundingMode.towardNegativeInfinity

end LeanFloat.IEEERounding
