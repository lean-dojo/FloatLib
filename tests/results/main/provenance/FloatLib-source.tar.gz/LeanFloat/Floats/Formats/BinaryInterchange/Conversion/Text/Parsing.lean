/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Rounding.Directed.Runtime

/-!
# Exact binary-float parsing

The parser accepts ordinary signed decimal integers and fractions, together with the compact
`m * 2^e` notation emitted for exact values with large binary exponents. Decimal input is rounded
directly from an exact integer ratio, while radix-two input is rounded from an exact dyadic. No
text is converted through Lean's host `Float` or C `double`.

The special spellings are `inf`, `-inf`, and `nan`. A format that cannot represent the requested
special value returns an explicit error rather than silently substituting a finite value.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model

/-- Why exact character input could not produce a value in the requested format. -/
inductive ParseError where
  /-- The input contains no non-whitespace characters. -/
  | emptyInput
  /-- The input is not a supported decimal, radix-two, infinity, or NaN spelling. -/
  | invalidSyntax (input : String)
  /-- The input requests an infinity from a finite-only encoding. -/
  | unsupportedInfinity (negative : Bool)
  /-- The input requests a NaN from an encoding with no NaN representation. -/
  | unsupportedNaN
  deriving Repr, DecidableEq

/-- Concise human-readable explanation of a character-input failure. -/
def ParseError.message : ParseError → String
  | .emptyInput => "empty floating-point input"
  | .invalidSyntax input => s!"invalid floating-point input: {input}"
  | .unsupportedInfinity false => "the destination format has no positive infinity"
  | .unsupportedInfinity true => "the destination format has no negative infinity"
  | .unsupportedNaN => "the destination format has no NaN representation"

instance : ToString ParseError where
  toString := ParseError.message

/--
Parse and round character input into an arbitrary binary-interchange format.

Finite decimal syntax denotes an exact rational number. Compact `m * 2^e` syntax denotes an exact
dyadic. In both cases the exact value is rounded once under `rounding`. Unsupported special values
and malformed text return `ParseError`; there is no zero or host-float fallback.
-/
def parse (fmt : FloatFormat) (rounding : IEEERoundingMode) (input : String) :
    Except ParseError (Model fmt) :=
  let splitSign (text : String) : Bool × String :=
    if text.startsWith "-" then
      (true, (text.drop 1).toString)
    else if text.startsWith "+" then
      (false, (text.drop 1).toString)
    else
      (false, text)
  let parseDecimal (text : String) :
      Option ((Bool × Nat × Nat) ⊕ LeanFloat.Numerics.Dyadic) := do
    let (negative, magnitudeText) := splitSign text
    let (whole, fraction) ←
      match magnitudeText.splitOn "." with
      | [whole] =>
          if whole.isEmpty then none else some (whole, "")
      | [whole, fraction] =>
          if whole.isEmpty && fraction.isEmpty then none
          else some (whole, fraction)
      | _ => none
    let wholeDigits := if whole.isEmpty then "0" else whole
    let wholeValue ← wholeDigits.toNat?
    let fractionValue ←
      if fraction.isEmpty then some 0 else fraction.toNat?
    let denominator := 10 ^ fraction.length
    let numerator := wholeValue * denominator + fractionValue
    pure (.inl (negative, numerator, denominator))
  let parseDyadic (text : String) :
      Option ((Bool × Nat × Nat) ⊕ LeanFloat.Numerics.Dyadic) := do
    let compact := text.replace " " ""
    let (coefficientText, exponentText) ←
      match compact.splitOn "*2^" with
      | [coefficientText, exponentText] => some (coefficientText, exponentText)
      | _ => none
    let (negative, magnitudeText) := splitSign coefficientText
    if magnitudeText.isEmpty || exponentText.isEmpty then
      none
    else
      let significand ← magnitudeText.toNat?
      let exponent ← exponentText.toInt?
      pure (.inr { negative, significand, exponent })
  let parseFinite (text : String) :
      Option ((Bool × Nat × Nat) ⊕ LeanFloat.Numerics.Dyadic) :=
    -- `format` prints dyadics as `m * 2^e`. Detect the marker after removing its presentation
    -- spaces so parser/formatter round trips use the same exact syntax.
    if (text.replace " " "").contains "*2^" then parseDyadic text else parseDecimal text
  let trimmed := input.trimAscii.toString
  if trimmed.isEmpty then
    .error .emptyInput
  else
    match trimmed with
    | "inf" | "+inf" =>
        match infinity? fmt false with
        | some value => .ok value
        | none => .error (.unsupportedInfinity false)
    | "-inf" =>
        match infinity? fmt true with
        | some value => .ok value
        | none => .error (.unsupportedInfinity true)
    | "nan" =>
        match canonicalNaN? fmt with
        | some value => .ok value
        | none => .error .unsupportedNaN
    | finite =>
        match parseFinite finite with
        | some (.inl (negative, numerator, denominator)) =>
            .ok (roundRatWithRounding fmt rounding negative numerator denominator)
        | some (.inr exact) =>
            .ok (roundDyadicWithRounding fmt rounding exact)
        | none => .error (.invalidSyntax input)

/-- Nearest-even character input, the default used by ordinary floating-point conversion. -/
def parseNearest (fmt : FloatFormat) (input : String) :
    Except ParseError (Model fmt) :=
  parse fmt .nearestEven input

end LeanFloat.Floats.Formats.BinaryInterchange.Model
