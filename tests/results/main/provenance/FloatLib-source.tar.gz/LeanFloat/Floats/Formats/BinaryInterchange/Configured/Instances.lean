/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Instances -- shake: keep
public import LeanFloat.Floats.Formats.BinaryInterchange.DirectedSemantics.Rational.Conversion
public import LeanFloat.Floats.Formats.BinaryInterchange.Conversion.Text.Formatting
public import LeanFloat.Floats.ExecFloat.Comparison
public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Storage.Family.Proof
public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Value.Core
public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.Compare.Proof

/-!
# Ordinary Lean instances for configured binary values

Configured binary values `ExecFloat (Configured.Family format code plan)` receive the ordinary
Lean interfaces here, generically in the storage codec, so byte, machine-word, and wide carriers
share one set of instances. Numerical literals are rounded once from exact rationals. Display,
comparison, equality, and hashing operate on the exact-width model, independently of the packed
carrier.

Two different notions of equality are installed and callers must keep them apart.

* `==` (`BEq`) is IEEE numerical equality through `ExecFloat.compareEqual`: `NaN == NaN` is
  `false` and `-0 == +0` is `true`. `List.contains`, `List.elem`, and every other `BEq`-based
  search use this notion.
* `=` (`DecidableEq`) is structural equality of the stored interchange word: `-0 = +0` is false
  and every NaN equals itself. `decide (x = y)`, `List.Nodup`, `Multiset`, and `Finset` use this
  notion. `Hashable` hashes the same word, so `x = y` implies `hash x = hash y`.

Consequently `LawfulBEq` does not hold, and `Std.HashMap` or `Std.HashSet` keyed by these values
is unsupported because `==` is not reflexive on NaN.

`<` and `≤` are the IEEE partial order: `a < b` holds exactly when the numerical comparison
returns `some .lt`, and `a ≤ b` when it returns `some .lt` or `some .eq`. Every comparison
involving a NaN is false, so `a ≤ a` fails for NaN and these relations are not a `Preorder`.
`max` and `min` are IEEE `maximum` and `minimum`: they propagate NaN and order `-0` below `+0`,
so `max a b = if a ≤ b then b else a` fails on NaN inputs.
-/

@[expose] public section

namespace LeanFloat.Floats

open LeanFloat.Floats.Formats.BinaryInterchange

namespace Formats.BinaryInterchange.Model

variable {fmt : FloatFormat}

/-- IEEE comparison is unordered whenever either operand is a NaN. -/
theorem compare_eq_none_of_isNaN {x y : Model fmt}
    (h : isNaN x = true ∨ isNaN y = true) :
    compare x y = none := by
  have hor : (isNaN x || isNaN y) = true := by
    rcases h with h | h <;> simp [h]
  simp [compare, hor]

/-- A non-NaN value is ordered equal to itself once NaNs have been excluded. -/
theorem compareNonNaN_self (x : Model fmt) (h : isNaN x = false) :
    compareNonNaN x x h h = .eq := by
  unfold compareNonNaN
  by_cases hinf : isInf x = true
  · simp [hinf]
  · simp [hinf, cmpDyadic]

/-- Every non-NaN value compares equal to itself. -/
theorem compare_self_of_isNaN_eq_false (x : Model fmt) (h : isNaN x = false) :
    compare x x = some .eq := by
  simp [compare, h, compareNonNaN_self]

end Formats.BinaryInterchange.Model

namespace ExecFloat.Binary

variable {format : FloatFormat} {plan : Configured.StoragePlan format} {code : Type}
    [LeanFloat.Floats.ExecFloat.ModelCodec plan (Model format) code]

/--
Configured binary comparison follows the descriptor's IEEE-style numerical order.

NaNs are unordered, signed zeros compare equal, and every other pair is ordered by exact value.
-/
instance :
    LeanFloat.Floats.ExecFloat.Comparison (Configured.Family format code plan) where
  compare left right := Model.compare (toModel left) (toModel right)

/-- The stored word determines the value, so decoding to the model is injective. -/
@[simp] theorem toModel_inj
    {left right : LeanFloat.Floats.ExecFloat (Configured.Family format code plan)} :
    toModel left = toModel right ↔ left = right :=
  ⟨Configured.Family.toModel_injective, fun h => h ▸ rfl⟩

/-- Comparison on configured values is comparison of their exact-width models. -/
theorem compare_eq_compare_toModel
    (left right : LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) :
    LeanFloat.Floats.ExecFloat.compare left right =
      Model.compare (toModel left) (toModel right) :=
  rfl

/-- Comparison against a NaN is unordered. -/
theorem compare_eq_none_of_isNaN
    {left right : LeanFloat.Floats.ExecFloat (Configured.Family format code plan)}
    (h : isNaN left = true ∨ isNaN right = true) :
    LeanFloat.Floats.ExecFloat.compare left right = none :=
  Model.compare_eq_none_of_isNaN h

/-- The default configured binary value is positive zero. -/
instance : Inhabited (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) where
  default := zero false

/-- The default configured binary value is positive zero. -/
@[simp] theorem default_eq_zero :
    (default : LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) = zero false :=
  rfl

/--
Structural equality of the stored interchange word.

This differs from `==`: `-0 = +0` is false and a NaN equals itself. Deciding equality on the
exact-width model keeps the instance independent of the packed carrier.
-/
instance : DecidableEq (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) :=
  fun left right =>
    if h : toModel left = toModel right then
      isTrue (Configured.Family.toModel_injective h)
    else
      isFalse fun equality => h (congrArg toModel equality)

/--
Hash of the complete interchange word.

The hash agrees with structural equality `=`, not with numerical equality `==`: `-0` and `+0`
hash differently.
-/
instance : Hashable (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) where
  hash value := hash (toNatBits value)

/-- The hash of a configured binary value is the hash of its interchange word. -/
theorem hash_eq_hash_toNatBits
    (value : LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) :
    hash value = hash (toNatBits value) :=
  rfl

/-- IEEE strict order: `a < b` holds when the numerical comparison returns `some .lt`. -/
instance : LT (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) where
  lt left right := LeanFloat.Floats.ExecFloat.compareLess left right = true

/-- IEEE weak order: `a ≤ b` holds when the comparison returns `some .lt` or `some .eq`. -/
instance : LE (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) where
  le left right := LeanFloat.Floats.ExecFloat.compareLessEqual left right = true

/-- `<` is decided by the executable comparison. -/
instance (left right : LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) :
    Decidable (left < right) :=
  inferInstanceAs (Decidable (LeanFloat.Floats.ExecFloat.compareLess left right = true))

/-- `≤` is decided by the executable comparison. -/
instance (left right : LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) :
    Decidable (left ≤ right) :=
  inferInstanceAs (Decidable (LeanFloat.Floats.ExecFloat.compareLessEqual left right = true))

/--
IEEE `maximum`: NaN operands propagate as a quiet NaN and `max (-0) (+0) = +0`.

This is not the order-theoretic maximum of `≤`, which is undefined on NaN.
-/
instance : Max (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) where
  max left right :=
    LeanFloat.Floats.ExecFloat.ModelCodec.liftBinary
      (Model := Model format) (plan := plan) Model.maximum left right

/--
IEEE `minimum`: NaN operands propagate as a quiet NaN and `min (-0) (+0) = -0`.

This is not the order-theoretic minimum of `≤`, which is undefined on NaN.
-/
instance : Min (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) where
  min left right :=
    LeanFloat.Floats.ExecFloat.ModelCodec.liftBinary
      (Model := Model format) (plan := plan) Model.minimum left right

/-- `max` decodes to IEEE `maximum` on the exact-width models. -/
@[simp] theorem toModel_max
    (left right : LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) :
    toModel (max left right) = Model.maximum (toModel left) (toModel right) :=
  LeanFloat.Floats.ExecFloat.ModelCodec.decode_liftBinary
    (Model := Model format) (plan := plan) Model.maximum left right

/-- `min` decodes to IEEE `minimum` on the exact-width models. -/
@[simp] theorem toModel_min
    (left right : LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) :
    toModel (min left right) = Model.minimum (toModel left) (toModel right) :=
  LeanFloat.Floats.ExecFloat.ModelCodec.decode_liftBinary
    (Model := Model format) (plan := plan) Model.minimum left right

section Order

variable {left right : LeanFloat.Floats.ExecFloat (Configured.Family format code plan)}

/-- `<` is the executable strict comparison. -/
theorem lt_iff_compareLess :
    left < right ↔ LeanFloat.Floats.ExecFloat.compareLess left right = true :=
  Iff.rfl

/-- `≤` is the executable weak comparison. -/
theorem le_iff_compareLessEqual :
    left ≤ right ↔ LeanFloat.Floats.ExecFloat.compareLessEqual left right = true :=
  Iff.rfl

/-- `<` holds exactly when the model comparison returns `some .lt`. -/
theorem lt_iff_compare_eq_lt :
    left < right ↔ Model.compare (toModel left) (toModel right) = some .lt := by
  rw [lt_iff_compareLess, LeanFloat.Floats.ExecFloat.compareLess, compare_eq_compare_toModel]
  exact beq_iff_eq

/-- `<` on configured values is `Model.lt` on their models. -/
theorem lt_iff_lt_toModel :
    left < right ↔ Model.lt (toModel left) (toModel right) :=
  lt_iff_compare_eq_lt

/-- `≤` holds exactly when the model comparison returns `some .lt` or `some .eq`. -/
theorem le_iff_compare_eq_lt_or_eq :
    left ≤ right ↔
      Model.compare (toModel left) (toModel right) = some .lt ∨
        Model.compare (toModel left) (toModel right) = some .eq := by
  rw [le_iff_compareLessEqual, LeanFloat.Floats.ExecFloat.compareLessEqual,
    compare_eq_compare_toModel]
  generalize Model.compare (toModel left) (toModel right) = order
  rcases order with _ | (_ | _ | _) <;> simp

/-- `≤` on configured values is `Model.le` on their models. -/
theorem le_iff_le_toModel :
    left ≤ right ↔ Model.le (toModel left) (toModel right) := by
  rw [le_iff_compare_eq_lt_or_eq, Model.le]
  generalize Model.compare (toModel left) (toModel right) = order
  rcases order with _ | (_ | _ | _) <;> simp

/-- `≤` is `<` or numerical equality `==`. -/
theorem le_iff_lt_or_compareEqual :
    left ≤ right ↔
      left < right ∨ LeanFloat.Floats.ExecFloat.compareEqual left right = true := by
  rw [le_iff_compare_eq_lt_or_eq, lt_iff_compare_eq_lt,
    LeanFloat.Floats.ExecFloat.compareEqual, compare_eq_compare_toModel, beq_iff_eq]

/-- Nothing is strictly below or above a NaN. -/
theorem not_lt_of_isNaN (h : isNaN left = true ∨ isNaN right = true) :
    ¬ left < right := by
  rw [lt_iff_compare_eq_lt, Model.compare_eq_none_of_isNaN h]
  exact nofun

/-- Nothing is weakly below or above a NaN. -/
theorem not_le_of_isNaN (h : isNaN left = true ∨ isNaN right = true) :
    ¬ left ≤ right := by
  rw [le_iff_compare_eq_lt_or_eq, Model.compare_eq_none_of_isNaN h]
  rintro (h | h) <;> cases h

/-- Strict order is irreflexive, for NaN because it is unordered and otherwise by equality. -/
theorem lt_irrefl (value : LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) :
    ¬ value < value := by
  rw [lt_iff_compare_eq_lt]
  cases h : isNaN value
  · rw [Model.compare_self_of_isNaN_eq_false _ h]
    simp
  · rw [Model.compare_eq_none_of_isNaN (Or.inl h)]
    exact nofun

/-- `≤` is reflexive exactly on non-NaN values. -/
theorem le_self_iff (value : LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) :
    value ≤ value ↔ isNaN value = false := by
  rw [le_iff_compare_eq_lt_or_eq]
  cases h : isNaN value
  · simp [Model.compare_self_of_isNaN_eq_false _ h]
  · simp [Model.compare_eq_none_of_isNaN (Or.inl h)]

end Order

end ExecFloat.Binary

namespace Formats.BinaryInterchange

/-- Configured binary values print their mathematical value rather than their packed carrier. -/
instance {format : FloatFormat} {plan : Configured.StoragePlan format} {code : Type}
    [codec : LeanFloat.Floats.ExecFloat.ModelCodec plan (Model format) code] :
    LeanFloat.Floats.ExecFloat.FormatDisplay (Configured.Family format code plan) where
  format raw := Model.format (codec.toModel raw)

/-- Numeral literals are rounded once from the exact natural number into the destination format. -/
instance {format : FloatFormat} {plan : Configured.StoragePlan format} {code : Type}
    [LeanFloat.Floats.ExecFloat.ModelCodec plan (Model format) code] (value : Nat) :
    OfNat (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) value where
  ofNat :=
    Configured.Family.ofModel <|
      Model.roundRatQ format (value : Rat)

/--
Scientific and decimal literals are rounded once from their exact rational value into the
destination format.
-/
instance {format : FloatFormat} {plan : Configured.StoragePlan format} {code : Type}
    [LeanFloat.Floats.ExecFloat.ModelCodec plan (Model format) code] :
    OfScientific (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) where
  ofScientific mantissa exponentSign decimalExponent :=
    Configured.Family.ofModel <|
      Model.roundRatQ format <|
        (OfScientific.ofScientific mantissa exponentSign decimalExponent : Rat)

/-- Negation follows the destination format's signed-zero and exceptional-value policy. -/
instance {format : FloatFormat} {plan : Configured.StoragePlan format} {code : Type}
    [LeanFloat.Floats.ExecFloat.ModelCodec plan (Model format) code] :
    Neg (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) where
  neg value :=
    LeanFloat.Floats.ExecFloat.ModelCodec.liftUnary
      (Model := Model format) (plan := plan) Model.neg value

end Formats.BinaryInterchange
end LeanFloat.Floats
