/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Status.Runtime

/-!
# Executable binary format casts

Turn a bit pattern in one binary float layout (`src`) into a bit pattern in another
(`dst`), for example binary32 to bfloat16 or binary16 to binary64.

There is **no** host `Float` involved. The kernel does three conceptual jobs:

1. classify the source bits (NaN / ∞ / finite),
2. if finite, recover the **exact** rational value the bits represent,
3. pack that value into the destination grid by rounding if needed.

---

## Finite path: “dyadic, then RNE”

### What “finite” means here
Source is **not** NaN and **not** ±∞. That includes normal numbers, subnormals, and ±0.

### What a **dyadic** is
A finite IEEE binary float is always a number of the form

```text
(±)  mant × 2^exp
```

with an integer mantissa and an integer power-of-two scale. We call that pair a
`Numerics.Dyadic` (see `Dyadic.lean`). It is an **exact** mathematical intermediate:
decode does not lose information about the source number. Examples:

- source = binary32 `1.0` → dyadic for exactly `1`
- source = binary32 `0.1` (which is already rounded in f32) → dyadic for **that** f32 value,
  not the real-world decimal 0.1

So cast is **format conversion**, not “recompute the user meant 0.1 more precisely.”

### What **RNE** means here
**R**ound to **N**earest, ties to **E**ven, the IEEE 754 default rounding mode.

The destination format can only store numbers on its own grid (fewer or more bits than `src`).
`roundDyadic dst` takes the exact dyadic and produces the `Model dst` value whose decode
is as close as possible to that dyadic; if two neighbors are equally close, it picks the one
with an even least significand bit (ties-to-even).

Consequences you should expect:

| Situation | Result |
|-----------|--------|
| `dst` can represent the value exactly (often when widening, e.g. f16 → f32 for many numbers) | Bit pattern is the exact value in `dst`; no further rounding error |
| Value sits between two `dst` numbers (often when narrowing, e.g. f32 → bf16) | One RNE step may change the value slightly relative to the source |
| Magnitude too large for `dst` | Overflow → ±∞ in `dst` (same rule as other `roundDyadic` overflow) |
| Magnitude too tiny for `dst` | Underflow → ±0 or a subnormal in `dst` |

This is the **same** intermediate style used by executable add/mul in this kernel
(decode → exact dyadic ops → one round back to bits), applied to conversion of a single value.

### Pipeline (finite)
```text
Model src
    │  toDyadic?
    ▼
  Numerics.Dyadic  (± mant × 2^exp)     -- exact meaning of the source bits
    │  roundDyadic dst
    ▼
Model dst                  -- nearest dst code (RNE), or 0 / ∞ on under/overflow
```

---

## Specials (non-finite)

| Source | Destination |
|--------|-------------|
| NaN    | quiet NaN in `dst`; source **sign** bit preserved |
| ±∞     | same-sign infinity in `dst` |

Payload bits of a NaN are **preserved** when `src` and `dst` have the same
exponent and fraction widths (quiet bit OR'd on). For unequal layouts only the
sign is kept; the payload becomes a canonical quiet pattern in `dst`.

After NaN and infinity are excluded, finiteness is proved and exact dyadic extraction is total.
The cast therefore has no hidden default for an impossible decode failure.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model

/--
Widen a finite value when source and destination have the same exponent semantics.

The exponent field is copied and the source fraction is shifted into the high end of the wider
destination fraction. Equal exponent width, bias, and encoding make this field copy
value-preserving. The hypotheses are retained in the term so callers cannot accidentally use this
operation as a narrowing conversion or cross an encoding boundary.
-/
@[inline] def widenExact {src dst : FloatFormat} (x : Model src)
    (_ : src.expWidth = dst.expWidth)
    (_ : src.exponentBias = dst.exponentBias)
    (_ : src.encoding = dst.encoding)
    (_ : src.fracWidth ≤ dst.fracWidth) : Model dst :=
  let shift := dst.fracWidth - src.fracWidth
  ofFields dst (signBit x) (expField x)
    (Nat.shiftLeft (fracField x) shift)

/--
Cast `x` from format `src` into format `dst`.

**Finite values:** decode the source bits to an exact dyadic (`mant × 2^exp`), then
pack that value into `dst` with round-to-nearest, ties-to-even (`roundDyadic`).
That may overflow to ±∞ or flush to ±0/subnormal if `dst` cannot hold the magnitude;
it may also change the value slightly when `dst` has coarser precision than `src`.

**Inf:** same-sign infinity when `dst` supports infinity, otherwise the same-sign maximum finite
value.

**NaN:** if `src = dst`, quiet the existing encoding while retaining its representable payload.
Otherwise emit the destination's canonical NaN when it has one, or positive zero for a finite-only
destination. Payloads are not remapped across unequal formats.

**Finite, `src = dst`:** short-circuits to `x` unchanged. Decoding to a dyadic and
rounding back into the same grid is a true identity for finite values, so this skips the
decode/round work entirely. This matters for uniform-format `SitePolicy`s, where `mulAcc` and
`dotSequential` cast every operand even though storage, product, and accumulator formats agree.
-/
@[inline] def cast (src dst : FloatFormat) (x : Model src) : Model dst :=
  if hnan : isNaN x = true then
    if h : src = dst then
      -- The dependent equality transports the exact-width payload without truncation.
      h ▸ quietNaN x
    else
      invalidResult dst
  else if hinf : isInf x = true then
    infinityOrMaxFinite dst (signBit x)
  else
    have hfinite : isFinite x = true :=
      isFinite_eq_true_of_isNaN_eq_false_of_isInf_eq_false x
        (Bool.eq_false_of_not_eq_true hnan)
        (Bool.eq_false_of_not_eq_true hinf)
    if h : src = dst then
      h ▸ x
    else if hexp : src.expWidth = dst.expWidth then
      if hbias : src.exponentBias = dst.exponentBias then
        if hencoding : src.encoding = dst.encoding then
          if hfrac : src.fracWidth ≤ dst.fracWidth then
            widenExact x hexp hbias hencoding hfrac
          else
            roundDyadic dst (finiteDyadic x hfinite)
        else
          roundDyadic dst (finiteDyadic x hfinite)
      else
        roundDyadic dst (finiteDyadic x hfinite)
    else
      roundDyadic dst (finiteDyadic x hfinite)

/--
Cast `x` using any IEEE rounding direction.

NaNs and infinities follow the same explicit value-class policy as `cast`, because a rounding
direction has no numerical effect on them. Finite identity casts and compatible widenings remain
exact fast paths. Every other finite conversion decodes once to an exact dyadic and rounds once in
the destination format.
-/
@[inline] def castWithRounding (src dst : FloatFormat) (x : Model src)
    (mode : IEEERoundingMode := .nearestEven) : Model dst :=
  match mode with
  | .nearestEven => cast src dst x
  | mode =>
      if hnan : isNaN x = true then
        cast src dst x
      else if hinf : isInf x = true then
        cast src dst x
      else
        have hfinite : isFinite x = true :=
          isFinite_eq_true_of_isNaN_eq_false_of_isInf_eq_false x
            (Bool.eq_false_of_not_eq_true hnan)
            (Bool.eq_false_of_not_eq_true hinf)
        if h : src = dst then
          h ▸ x
        else if hexp : src.expWidth = dst.expWidth then
          if hbias : src.exponentBias = dst.exponentBias then
            if hencoding : src.encoding = dst.encoding then
              if hfrac : src.fracWidth ≤ dst.fracWidth then
                widenExact x hexp hbias hencoding hfrac
              else
                roundDyadicWithRounding dst mode (finiteDyadic x hfinite)
            else
              roundDyadicWithRounding dst mode (finiteDyadic x hfinite)
          else
            roundDyadicWithRounding dst mode (finiteDyadic x hfinite)
        else
          roundDyadicWithRounding dst mode (finiteDyadic x hfinite)

/--
Cast `x` and report the IEEE exception indicators raised by the conversion.

A signaling NaN raises invalid. A quiet NaN raises invalid only when the destination cannot
represent a NaN at all. Infinity is exact when the destination preserves infinity; conversion to
a finite-only destination reports overflow and inexactness. Finite values use the same exact
dyadic witness for both directed rounding and status classification.
-/
def castWithStatus (src dst : FloatFormat) (x : Model src)
    (mode : IEEERoundingMode := .nearestEven) : IEEEOutcome dst :=
  let value := castWithRounding src dst x mode
  if hnan : isNaN x = true then
    outcomeWithInvalid value (isSNaN x || !isNaN value)
  else if hinf : isInf x = true then
    if isInf value then
      { value, status := .clear }
    else
      { value, status := { overflow := true, inexact := true } }
  else
    have hfinite : isFinite x = true :=
      isFinite_eq_true_of_isNaN_eq_false_of_isInf_eq_false x
        (Bool.eq_false_of_not_eq_true hnan)
        (Bool.eq_false_of_not_eq_true hinf)
    let exact := finiteDyadic x hfinite
    { value, status := dyadicRoundingStatus dst mode exact value }

end Model
end LeanFloat.Floats.Formats.BinaryInterchange
