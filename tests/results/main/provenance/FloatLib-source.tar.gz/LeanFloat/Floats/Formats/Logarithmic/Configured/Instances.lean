/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Instances -- shake: keep
public import LeanFloat.Floats.Formats.Logarithmic.Configured.Plan
public import LeanFloat.Floats.ExecFloat.Core.Capability

/-!
# Dispatch instance for exact logarithmic multiplication

The ordinary `ExecFloat` multiplication interface selects the certified direct logarithmic
kernel.
-/

@[expose] public section

namespace LeanFloat.Floats.ExecFloat.Logarithmic

open LeanFloat.Numerics

variable {radix : Radix}

/-- Exact logarithmic multiplication participates in ordinary `ExecFloat` dispatch. -/
@[always_inline] instance
    [planning : Backend.PolicyFor (Family radix)] :
    ExecFloat.Mul (Family radix) :=
  ExecFloat.Capability.ofDirectKernel
    .mul Logarithmic.mul Plan.mulCertified Logarithmic.mul rfl

end LeanFloat.Floats.ExecFloat.Logarithmic
