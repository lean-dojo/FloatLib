/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Format.Definition
public import LeanFloat.Floats.ExecFloat.Backends.Selection.Metadata

/-!
# Cost estimates for binary descriptor execution

These engineering priors guide static candidate selection; they never affect semantics or
refinement. The model follows the threshold selection used by GMP and the separation of planning
from execution used by FFTW.

Generated-code inspection and benchmark calibration remain necessary because Lean's compiler,
target architecture, and workload can move useful thresholds.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Descriptor.Plan

open LeanFloat.Floats.ExecFloat
open LeanFloat.Floats.ExecFloat.Backend

/--
Coarse superlinear work estimate for exact significand arithmetic.

This is intentionally cheap to reduce at specialization time. It is an engineering feature, not
an asymptotic-complexity theorem.
-/
@[inline] def quadraticWork (bits : Nat) : Nat :=
  bits * bits / 16

/--
Width- and operation-sensitive estimate for the total exact baseline.

Above 128 bits the constants come from `benchmarks/scripts/format-comparison.sh` on the
`binary-software` lane (256, 512, 1024, and 4096 bits, three trials, 2026-09-07): the exact
baseline is dominated by a fixed number of arbitrary-precision allocations, so its cost is nearly
flat in the width, about 4.1 µs for addition at 256 bits and 5.3 µs at 4096 bits, with the limb
count entering only through the arbitrary-precision work itself. One unit is approximately 100 ns.
-/
def genericEstimate (format : FloatFormat) (operation : Operation) : Candidate :=
  let bits := format.bitWidth
  let limbs := (bits + 31) / 32
  let work :=
    if bits ≤ 8 then
      -- Calibrated by `execFloatBackendCalibration`; one unit is approximately 100 ns
      -- on the reference host. Repeated full-horizon trials put generic subtraction near
      -- 31 units and generic FMA near 16. Only ratios within this plan affect selection.
      match operation with
      | .add => 18
      | .sub => 31
      | .mul => 18
      | .div => 20
      | .sqrt => 29
      | .fma => 16
    else if bits ≤ 128 then
      match operation with
      | .add | .sub => 80 + 4 * bits
      | .mul => 120 + quadraticWork bits
      | .div => 180 + 2 * quadraticWork bits
      | .sqrt => 220 + 2 * quadraticWork bits
      | .fma => 180 + 2 * quadraticWork bits
    else
      match operation with
      | .add => 41 + limbs / 10
      | .sub => 47 + limbs / 10
      | .mul => 39 + limbs / 4
      | .div => 45 + limbs / 2
      | .sqrt => 80 + 5 * limbs / 2
      | .fma => 37 + limbs / 4
  {
    name := s!"binary-interchange {operation.longLabel} exact baseline"
    kind := .generic
    steadyCost := work
    allocations := if bits ≤ 8 then 0 else if bits ≤ 64 then 1 else 3
  }

/--
Estimate for a monomorphic binary32 or binary64 specialization.

Addition, subtraction, multiplication, and division were recalibrated from the 2026-09-07
format-comparison run (`benchmarks/scripts/format-comparison.sh`, `binary-software` lane): the
configured binary32 and binary64 operations measured 38 and 280 ns for addition, 48 and 239 ns for
multiplication, and 68 and 1610 ns for division, so the shared per-operation numbers below are the
geometric means of the two widths on the approximately 100 ns unit scale.
-/
def fixedFormatEstimate (operation : Operation) : Candidate where
  name := s!"binary-interchange {operation.longLabel} fixed-format kernel"
  kind := .fixedFormat
  steadyCost :=
    match operation with
    | .add | .sub => 1
    | .mul => 1
    | .div => 3
    | .sqrt => 55
    | .fma => 28

/--
Estimate for a reusable one-word kernel on a structurally eligible descriptor.

Tiny-format constants are calibrated against the same descriptor carrier as the table candidate.
For wider formats only the ordering relative to the exact baseline matters; the addition,
subtraction, multiplication, and division constants were recalibrated from the 2026-09-07
format-comparison run, where the configured binary16 and 24-bit rows measured 20 and 23 ns for
addition, 24 and 29 ns for multiplication, and 317 and 440 ns for division.
-/
def nativeWordEstimate (format : FloatFormat) (operation : Operation) : Candidate where
  name := s!"binary-interchange {operation.longLabel} native-word kernel"
  kind := .nativeWord
  steadyCost :=
    if format.bitWidth ≤ 8 then
      -- The word FMA repeatedly measured near 18 units, independently of tiny encoded width.
      match operation with
      | .add => 12
      | .sub => 14
      | .mul => 8
      | .div => 11
      | .sqrt => 22 + format.bitWidth
      | .fma => 18
    else
      match operation with
      | .add | .sub => 1
      | .mul => 1
      | .div => 4
      | .sqrt => 82
      | .fma => 46

/-- Estimate for a fixed-count native-limb kernel. -/
def fixedLimbEstimate (operation : Operation) : Candidate where
  name := s!"binary-interchange {operation.longLabel} fixed-limb kernel"
  kind := .fixedLimbs
  steadyCost :=
    match operation with
    | .add | .sub => 48
    | .mul => 80
    | .div => 190
    | .sqrt => 230
    | .fma => 150

/--
Estimate for the wide-limb kernel over a runtime-sized buffer of 32-bit limbs.

The constants are whole-call times measured with `benchmarks/scripts/format-comparison.sh` on the
`binary-software` lane (256, 512, 1024, and 4096 bits, three trials, 2026-09-07), in the same
100 ns units as `genericEstimate`: addition and subtraction grow linearly in the limb count, about
0.85 units per limb over a 6 unit base, while multiplication and fused multiply-add pay the
schoolbook product, about `limbs^2 / 20` units plus a linear term. Against the nearly flat exact
baseline this makes the kernel win for addition and subtraction up to about 1500 bits, for
multiplication up to about 580 bits, and for fused multiply-add up to about 350 bits, which matches
the measured crossovers. Both candidates allocate on every call; the allocation count is set equal
to the baseline's so the comparison reduces to the measured times. Division and square root have
no wide-limb kernel and receive the baseline cost so they are never preferred.
-/
def wideLimbEstimate (format : FloatFormat) (operation : Operation) : Candidate :=
  let limbs := (format.bitWidth + 31) / 32
  {
    name := s!"binary-interchange {operation.longLabel} wide-limb kernel"
    kind := .wideLimbs
    storage := .wideLimbs
    steadyCost :=
      match operation with
      | .add | .sub => 6 + 17 * limbs / 20
      | .mul => 3 + 6 * limbs / 5 + limbs * limbs / 20
      | .fma => 6 + 2 * limbs + limbs * limbs / 20
      | .div | .sqrt => (genericEstimate format operation).steadyCost
    allocations := 3
  }

/--
Calibrated table-generation work per encoded result.

The small width bands capture the measured decrease in generator overhead per entry as a table
gets larger. They depend only on encoded width and operation, never on a catalogued format name.
-/
def tableGenerationCost (format : FloatFormat) (operation : Operation) : Nat :=
  let bits := format.bitWidth
  match operation with
  | .add =>
      if bits ≤ 4 then 28 else if bits ≤ 6 then 24 else 22
  | .sub =>
      if bits ≤ 4 then 30 else if bits ≤ 6 then 29 else 25
  | .mul =>
      if bits ≤ 4 then 28 else if bits ≤ 6 then 26 else 22
  | .div =>
      if bits ≤ 4 then 28 else if bits ≤ 6 then 26 else 23
  | .sqrt =>
      if bits ≤ 4 then 36 else if bits ≤ 6 then 24 else 23
  | .fma =>
      if bits ≤ 4 then 34 else if bits ≤ 5 then 31 else 28

/--
Estimate for a dense byte table over all encoded operands.

One result occupies one byte because this candidate is only constructed when `bitWidth ≤ 8`.
The selector's memory policy independently rejects tables that are valid but too large.

`execFloatBackendCalibration` showed table construction to be approximately linear in the number
of encoded results for each operation. The operation-specific coefficient is therefore a more
accurate and more stable prior than multiplying by the public generic-kernel estimate: table
generation runs below the `ExecFloat` carrier boundary and has a different constant factor.
-/
def tableEstimate (format : FloatFormat) (operation : Operation) : Candidate :=
  let radix := 2 ^ format.bitWidth
  let entries := radix ^ operation.arity
  {
    name := s!"binary-interchange {operation.longLabel} exhaustive table"
    kind := .exhaustiveTable
    steadyCost := 3
    setupCost := entries * tableGenerationCost format operation
    setupAllocations := 1
    residentBytes := entries
  }

end LeanFloat.Floats.Formats.BinaryInterchange.Descriptor.Plan
