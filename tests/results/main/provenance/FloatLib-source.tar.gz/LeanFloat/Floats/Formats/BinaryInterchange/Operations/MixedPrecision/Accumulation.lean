/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Arithmetic.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Conversion.Cast.Runtime
public import LeanFloat.Numerics.Reduction

/-!
# Mixed-precision multiply-accumulate

Real hardware rarely multiplies and accumulates in the same dtype as storage.
Classic example:

```text
load   bf16
mul    bf16   (or product in a product format)
add    f32    (wide accumulator)
store  f32
```

This file makes those roles explicit for `Model` and provides the sequential dot kernel.
Matrix execution and real-error theorems live in the sibling `Matmul`, `Proof`, and
`MatmulProof` modules; automatic plan selection remains out of scope.

---

## `SitePolicy`: what each format is for

| Field | Role |
|-------|------|
| `storage` | Format of the **inputs** `a` and `b` as we hold them |
| `product` | Format of the **multiply** `a * b` |
| `accumulator` | Format of running **sum** we add the product into |
| `output` | Format of the final write (`dotSequential` casts here; `mulAcc` does not) |

Any of these may be equal (uniform f32) or differ (mixed). Casts between them use
`Model.cast` (exact dyadic decode of source bits, then RNE into the next format).

---

## What `mulAcc` does (unfused)

```text
a, b  : storage
          │ cast → product
          ▼
        mul  (in product)          -- one RNE product in `product` format
          │ cast → accumulator
          ▼
   acc + product   (in accumulator)  -- one RNE add in `accumulator` format
          │
          ▼
        new acc : accumulator
```

**Unfused** means three rounding opportunities on the path product → sum:

1. (optional) storage → product if formats differ,
2. multiply rounds into `product`,
3. cast product → accumulator if formats differ,
4. add rounds into `accumulator`.

Use `ExecFloat.fma` when the product and sum must be fused into one rounding. `SitePolicy`
currently describes only the explicit unfused `mulAcc` path; it does not silently contract it.

---

## What `dotSequential` does (sequential mixed-precision reduction)

```text
acc₀  = +0  (in accumulator format)

acc₁  = mulAcc (xs[0], ys[0], acc₀)
acc₂  = mulAcc (xs[1], ys[1], acc₁)
  ⋮
accₙ  = mulAcc (xs[n-1], ys[n-1], accₙ₋₁)

result = cast accumulator → output (accₙ)
```

So `dotSequential` is exactly "left-to-right sum of products", each product-add step still
subject to the mixed-format rules of `mulAcc`. That is **one** legal reduction order (sequential /
Horner-style accumulation). Pairwise or GPU-tree reductions can give different bit results; we
do not claim bitwise equality with those here.

Both inputs must have the same length. A mismatch is reported explicitly. Empty inputs produce
`+0` cast into `output`.

---

## Out of scope for this runtime module

- Matrix tiling or an optimized BLAS kernel
- Pairwise or nondeterministic reduction families
- Choosing a `SitePolicy` automatically

The sibling `Proof` module bounds `dotSequential` against its exact real dot product, and
`MatmulProof` specializes that theorem to successful matrix entries.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model

/--
Roles of formats at one arithmetic site.

Does not include reduction tree choice or fused vs unfused FMA (later).
-/
structure SitePolicy where
  /-- Format of input operands. -/
  storage : FloatFormat
  /-- Format in which the product is formed. -/
  product : FloatFormat
  /-- Format holding the running sum. -/
  accumulator : FloatFormat
  /-- Format of the final write after a reduction (`dotSequential` ends with a cast here). -/
  output : FloatFormat
  deriving DecidableEq, Repr

namespace SitePolicy

/-- Every role uses the same format (classic single-dtype path). -/
@[inline] def uniform (fmt : FloatFormat) : SitePolicy where
  storage := fmt
  product := fmt
  accumulator := fmt
  output := fmt

/--
Store and multiply in `storeProd`, accumulate and (intended) write-out in `accOut`.

Common ML pattern: bf16/f16 storage+product, f32 accumulator/output.
-/
@[inline] def mixedStoreProductAcc (storeProd accOut : FloatFormat) : SitePolicy where
  storage := storeProd
  product := storeProd
  accumulator := accOut
  output := accOut

end SitePolicy

/--
One unfused mixed-precision step: `acc ← cast(mul(cast a, cast b)) + acc`.

- Inputs `a`, `b` are in `p.storage`.
- Product is computed in `p.product` (after casting inputs into that format).
- Product is cast into `p.accumulator` and added to `acc`.
- Returns the new accumulator value (still `p.accumulator`).

Does **not** cast to `p.output`; callers that need a final store should
`cast p.accumulator p.output result`.
-/
@[inline] def mulAcc (p : SitePolicy)
    (a b : Model p.storage)
    (acc : Model p.accumulator) :
    Model p.accumulator :=
  let aP : Model p.product := cast p.storage p.product a
  let bP : Model p.product := cast p.storage p.product b
  let prod : Model p.product := mul aP bP
  let prodA : Model p.accumulator := cast p.product p.accumulator prod
  add prodA acc

/--
Sequential mixed-precision dot product under site policy `p`:

```text
  Σᵢ  xs[i] · ys[i]
```

where each product-add is `mulAcc` (storage → product → accumulator), and the completed
accumulator is cast once into `p.output`.

**Order:** left-to-right over every input index.
Addition is not associative, so another parenthesization can differ in the last bits.

The inputs must have equal lengths. A mismatch returns `ReductionError.lengthMismatch`; empty
inputs return `+0` cast from the accumulator format into `p.output`.
-/
def dotSequential (p : SitePolicy)
    (xs ys : Array (Model p.storage)) :
    Except Numerics.ReductionError (Model p.output) :=
  if xs.size != ys.size then
    .error (.lengthMismatch xs.size ys.size)
  else
    let acc0 : Model p.accumulator := posZero p.accumulator
    let acc : Model p.accumulator :=
      Id.run do
        let mut acc := acc0
        for i in [:xs.size] do
          acc := mulAcc p xs[i]! ys[i]! acc
        pure acc
    .ok (cast p.accumulator p.output acc)

/-- Sequential dot product with a single format in every arithmetic role. -/
@[inline] def dotSequentialUniform (fmt : FloatFormat)
    (xs ys : Array (Model fmt)) :
    Except Numerics.ReductionError (Model fmt) :=
  dotSequential (SitePolicy.uniform fmt) xs ys

end Model
end LeanFloat.Floats.Formats.BinaryInterchange
