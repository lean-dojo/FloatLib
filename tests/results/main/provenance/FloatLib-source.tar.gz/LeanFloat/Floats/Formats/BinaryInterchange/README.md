# Binary interchange

Descriptor-driven executable binary family. The format-independent carrier is `ExecFloat`; this
directory is `Model fmt` (`BitVec fmt.bitWidth`) plus IEEE-style operations, rounding, and proofs.

Import `LeanFloat.Floats.Formats.BinaryInterchange` to run it.
Import `.Semantics` when proving rounded-real facts.
Theorems: [THEOREMS.md](../../THEOREMS.md). Backends: [Backends/README.md](../../ExecFloat/Backends/README.md).

A custom format is an ordinary descriptor:

```lean
abbrev X71 := ExecFloat.Binary (exponentBits := 11) (fractionBits := 59)
```

| Name | Exp | Frac | Bits |
| --- | ---: | ---: | ---: |
| `binary16` | 5 | 10 | 16 |
| `bfloat16` | 8 | 7 | 16 |
| `binary32` | 8 | 23 | 32 |
| `binary64` | 11 | 52 | 64 |
| `binary128` | 15 | 112 | 128 |
| `binary256` | 19 | 236 | 256 |

No theorem is specialized to this table unless its name says so. Non-IEEE encodings:
`finiteMaxNaN`, `finiteUnsignedZero`, `finite`, or `custom`.

## What is and is not claimed

| Family | Status |
| --- | --- |
| `Proof.*_eq_spec` | every `FloatFormat` |
| Field decode, classification, exact dyadics | every `FloatFormat` |
| Real-number / Lean-model arithmetic refinement | IEEE (`fmt.isIEEE = true`); finite values |
| Remainder, `roundToIntegral*`, `scaleB`, `logB` | implemented with theorems |
| Integer conversion | `DType`; IEEE needed for the real nearest-even theorem |
| `totalOrder` / `totalOrderMag` | not public |
| `quantum` / `sameQuantum` | not public |
| Decimal interchange | none; decimal text parses into a binary destination |
| Text round-trip theorem | not claimed; formatting a NaN as `nan` drops sign/payload |
| Elementary functions (`exp`, `log`, trig, `pow`) | named import `Configured.Transcendentals` (or the model barrel); representation bridges only |

## Overflow by encoding

`maxFinite` carries the sign of the exact result. Invalid NaN word is `Model.invalidResult`.
"Away from zero" is IEEE 754-2019 §7.4. `overflow := .saturate` always returns signed `maxFinite`.
`underflow := .flushToZero` replaces a subnormal by signed zero.

| Encoding | Overflow, nearest | Toward zero | Toward ±∞ | `x / 0` (finite nonzero) | Invalid |
| --- | --- | --- | --- | --- | --- |
| `.ieee` | signed ∞ | signed `maxFinite` | ∞ if away from zero, else `maxFinite` | signed ∞ | canonical qNaN |
| `.finiteMaxNaN` | NaN word | signed `maxFinite` | NaN if away from zero, else `maxFinite` | NaN word | NaN word |
| `.finiteUnsignedZero` | NaN word (negative-zero pattern) | signed `maxFinite` | same as `.finiteMaxNaN` | NaN word | NaN word |
| `.finite` | signed `maxFinite` | signed `maxFinite` | signed `maxFinite` | signed `maxFinite` | `+0` |

A finite-only encoding has no NaN; use status-bearing ops when the invalid flag matters.

Ordinary notation is nearest-even. Status ops take an explicit `rounding :=` and return a pair.
`Model.Interval fmt` uses directed kernels; a denominator containing zero, or NaN/unordered
endpoints, becomes `whole fmt`.
