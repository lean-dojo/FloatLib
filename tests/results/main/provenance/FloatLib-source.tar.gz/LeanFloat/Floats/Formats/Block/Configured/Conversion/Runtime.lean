/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.Block.Configured.Runtime
public import LeanFloat.Floats.ExecFloat.Conversion.Core

/-!
# Shared-scale block conversion runtime

A shared-scale block cannot be quantized honestly without choosing its common exponent. This
module therefore defines conversion with an explicit `Int` context. The capability instance is
installed separately without a `DefaultQuantizer`, so the exponent choice can never become an
invisible global default.
-/

@[expose] public section

namespace LeanFloat.Floats

open LeanFloat.Numerics

namespace ExecFloat.SharedScale
namespace Conversion

variable {lanes : Nat}

/-- Conversion status records whether any lane changed at the selected shared scale. -/
@[inline] def status (exact : Vector Rat lanes) (rounded : ExecFloat.SharedScale lanes) :
    LeanFloat.Floats.ExecFloat.ConversionStatus :=
  { inexact := decide (ExecFloat.SharedScale.decode rounded ≠ exact) }

/-- Quantize a complete block observation at an explicitly supplied shared exponent. -/
@[inline] def run (exponent : Int) :
    NumericalValue (Vector Rat lanes) →
      LeanFloat.Floats.ExecFloat.ConversionOutcome (ExecFloat.SharedScale lanes)
  | .finite exact =>
      let rounded := ExecFloat.SharedScale.quantizeAt exponent exact
      .success rounded (status exact rounded)
  | .infinity negative =>
      .failure (.infinity .source negative)
  | .exceptional exceptional =>
      .failure (.exceptional .source exceptional)

/--
Relational shared-scale conversion contract.

Finite success must satisfy the lane-wise nearest-even `QuantizesAt` relation. Non-finite inputs
are rejected because this unbounded block family has no corresponding codes.
-/
def spec (exponent : Int)
    (input : NumericalValue (Vector Rat lanes))
    (outcome : LeanFloat.Floats.ExecFloat.ConversionOutcome
      (ExecFloat.SharedScale lanes)) : Prop :=
  match input with
  | .finite exact =>
      ∃ rounded,
        outcome = .success rounded (status exact rounded) ∧
          Formats.Block.QuantizesAt exponent exact rounded.toCode
  | .infinity negative =>
      outcome = .failure (.infinity .source negative)
  | .exceptional exceptional =>
      outcome = .failure (.exceptional .source exceptional)

/-- Shared-scale values decode to their exact rational vector. -/
instance exactDecoder :
    LeanFloat.Floats.ExecFloat.ExactDecoder
      (ExecFloat.SharedScale lanes) (Vector Rat lanes) where
  decode value := .finite (ExecFloat.SharedScale.decode value)

end Conversion
end ExecFloat.SharedScale
end LeanFloat.Floats
