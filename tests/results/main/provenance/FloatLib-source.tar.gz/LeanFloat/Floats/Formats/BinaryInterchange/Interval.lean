/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module -- shake: keep-all

public import LeanFloat.Floats.Formats.BinaryInterchange.Interval.Core
public import LeanFloat.Floats.Formats.BinaryInterchange.Interval.Arithmetic
public import LeanFloat.Floats.Formats.BinaryInterchange.Interval.Activations
public meta import LeanFloat.Floats.Formats.BinaryInterchange.Interval.Info
import Mathlib.Analysis.SpecialFunctions.Trigonometric.DerivHyp
import Mathlib.Analysis.SpecialFunctions.Pow.Real

/-!
# Format-generic executable intervals

Public entry point for `Model.Interval fmt`, including endpoint construction, outward-rounded
arithmetic, conservative division, elementary activation ranges, and proof-aware
`#float_info` inspection.
-/

@[expose] public section
