/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Model.Fields.Proof
public import LeanFloat.Floats.Formats.BinaryInterchange.DirectedSemantics.Internal -- shake: keep

/-!
# Internal lemmas for directed rational packing

The public packing theorems need a collection of field bounds, finiteness facts, and denotation
identities that are useful during the proof but not meaningful as a user API. They live here so
the main directed-rounding files can present the mathematical argument without a long prelude of
bit-layout bookkeeping.

This module is imported privately on purpose. New code should depend on the resulting public
packing contract rather than coupling itself to these intermediate lemma shapes.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model
namespace Packing.Internal

open LeanFloat.Floats
open LeanFloat.Floats.Formats.Flocq
open Directed.Internal

noncomputable section

/-- An in-range IEEE subnormal fraction field denotes a finite value. -/
theorem isFinite_ofFields_subnormal
    (fmt : FloatFormat) (hfmt : fmt.isIEEE = true) (mantissa : Nat)
    (_hmantissa : mantissa < 2 ^ fmt.fracWidth) :
    isFinite (ofFields fmt false 0 mantissa) = true :=
  isFinite_ofFields_ieee fmt hfmt false 0 mantissa fmt.expAllOnesNat_pos

/-- The canonical IEEE minimum-normal field pair denotes a finite value. -/
theorem isFinite_ofFields_minNormal
    (fmt : FloatFormat) (hfmt : fmt.isIEEE = true) :
    isFinite (ofFields fmt false 1 0) = true :=
  isFinite_ofFields_ieee fmt hfmt false 1 0
    (by
      have hfour : 4 ≤ 2 ^ fmt.expWidth := by
        simpa using
          Nat.pow_le_pow_right (by decide : 0 < (2 : Nat))
            fmt.expWidth_ge_two
      unfold FloatFormat.expAllOnesNat
      omega)

/-- Positive IEEE overflow rounds to positive infinity when the direction is upward. -/
theorem directedOverflow_false_true_eq_posInf
    (fmt : FloatFormat) (hfmt : fmt.isIEEE = true) :
    directedOverflow fmt false true = posInf fmt := by
  simp [directedOverflow, nativeOverflow,
    FloatFormat.encoding_eq_ieee_of_isIEEE fmt hfmt]

end

end Packing.Internal
end Model
end LeanFloat.Floats.Formats.BinaryInterchange
