/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Reduction.Proof

/-!
# Correctly rounded binary reductions

This module exports the executable exact-accumulation kernels and their correctness proofs.
Runtime-only consumers should import `Reduction.Runtime`.
-/
