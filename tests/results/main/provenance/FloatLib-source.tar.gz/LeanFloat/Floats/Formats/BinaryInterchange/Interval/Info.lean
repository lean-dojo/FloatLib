/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.IntervalSemantics
public import LeanFloat.Floats.Formats.BinaryInterchange.Info.Profile
public meta import LeanFloat.Floats.Formats.BinaryInterchange.Info.Command

/-!
# Proof-aware inspection of executable binary intervals

This module registers `Model.Interval fmt` with `#float_info`. Interval operations are deliberately
reported as an outward-rounded specialized API, not as scalar `ExecFloat` capabilities. The report
distinguishes the raw two-endpoint carrier from `Interval.Valid`, and it names the exact hypotheses
under which each operation is a proved real or extended-real enclosure.
-/

public meta section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.FloatInfo

open LeanFloat.Floats.ExecFloat

/-- Descriptor summary reused by the interval-format inspection report. -/
meta abbrev BinarySummary :=
  LeanFloat.Floats.Formats.BinaryInterchange.FloatInfo.Summary

/-- Build the execution and enclosure-proof profile for a binary endpoint interval. -/
meta def profile (summary : BinarySummary) : FormatProfile where
  family := "binary-interchange closed interval"
  standard :=
    "outward-rounded interval carrier over " ++
      LeanFloat.Floats.Formats.BinaryInterchange.FloatInfo.standardName summary
  declarationPrefix := "LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval."
  representation :=
    [ ⟨"storage", "one lower and one upper binary `Model` endpoint"⟩
    , ⟨"endpoint payload bits", toString summary.bitWidth⟩
    , ⟨"combined endpoint payload", s!"{2 * summary.bitWidth} bits"⟩
    , ⟨"endpoint exponent bits", toString summary.expWidth⟩
    , ⟨"endpoint fraction bits", toString summary.fracWidth⟩
    , ⟨"endpoint encoding",
        LeanFloat.Floats.Formats.BinaryInterchange.FloatInfo.encodingName summary.encoding⟩
    ]
  values :=
    [ ⟨"raw carrier", "every pair of endpoint encodings, including unordered or exceptional pairs"⟩
    , ⟨"valid interval", "both endpoints finite and ordered by the executable numerical order"⟩
    , ⟨"valid extended interval", "ordered non-NaN endpoints; infinities are permitted"⟩
    , ⟨"whole interval",
        "[-∞,+∞] when supported; otherwise the two maximal finite endpoints"⟩
    , ⟨"NaN endpoints",
        "representable when the endpoint format has NaN, but excluded by `Interval.Valid`"⟩
    ]
  rounding :=
    [ ⟨"lower endpoints", "rounded toward negative infinity"⟩
    , ⟨"upper endpoints", "rounded toward positive infinity"⟩
    , ⟨"multiplication / division", "all four endpoint corners contribute to the enclosure"⟩
    , ⟨"division through zero",
        "returns the whole interval because one closed interval cannot represent two rays"⟩
    ]
  execution :=
    [ ⟨"carrier", "a direct pair of endpoints; no interval heap object or hidden precision state"⟩
    , ⟨"dispatch", "composes the endpoint format's directed kernels and executable comparisons"⟩
    , ⟨"soundness domain",
        "neg/relu/abs support infinite endpoints; directed arithmetic and sqrt require " ++
        "their stated input and format hypotheses"⟩
    ]
  specializedOperations :=
    [ ⟨"point / hull / whole",
        "construct degenerate, endpoint-hull, and conservative full-range intervals"⟩
    , ⟨"neg / add / sub",
        "endpoint-reversing negation and outward-rounded additive arithmetic"⟩
    , ⟨"mul / div / inv",
        "four-corner outward arithmetic with conservative zero-denominator handling"⟩
    , ⟨"relu / abs / sqrt",
        "executable activation ranges with checked enclosure theorems"⟩
    ]
  theoremSurfaces :=
    [ { topic := "validity and real/extended-real membership"
        declarations :=
          [ ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.mem_iff
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.realMem_iff
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.eRealMem_iff
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.Valid.lo_isFinite
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.Valid.hi_isFinite
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.Valid.toReal_ordered
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.eRealMem_coe_iff_of_valid
          ]
        applicability := .verifiedForType
        scope := "raw membership is executable; real semantics requires finite ordered endpoints"
        numericalGuarantee? := some {
          kinds := [.range]
          statement :=
            "A valid endpoint pair denotes exactly the closed real interval between its decoded endpoints." } }
    , { topic := "order and point-interval semantics"
        declarations :=
          [ ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.le_iff_leB_eq_true
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.leB_eq_true_iff_toReal_le_of_isFinite
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.le_iff_toReal_le_of_isFinite
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.valid_point_of_isFinite
          ]
        applicability := .verifiedForType
        scope := "finite endpoints for the real-order equivalences"
        numericalGuarantee? := some {
          kinds := [.range, .exactness]
          statement :=
            "Executable endpoint order agrees with real order, and a finite point interval contains exactly its represented value." } }
    , { topic := "outward-rounded arithmetic enclosures"
        declarations :=
          [ ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.add_sound
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.sub_sound
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.mul_sound
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.div_sound
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.inv_sound
          ]
        applicability :=
          LeanFloat.Floats.Formats.BinaryInterchange.FloatInfo.ieeeApplicability summary
        scope :=
          "valid finite input intervals; division uses the whole interval when the denominator contains zero"
        numericalGuarantee? := some {
          kinds := [.range]
          statement :=
            "Outward-rounded add, subtract, multiply, divide, and reciprocal contain every exact real result." } }
    , { topic := "format-generic negation and activation enclosures"
        declarations :=
          [ ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.neg_sound_extended
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.relu_sound_extended
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.abs_sound_extended
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.neg_validExtended
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.relu_validExtended
          , ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.abs_validExtended
          ]
        applicability := .verifiedForType
        scope := "ValidExtended input and a real member interpreted in EReal; every descriptor"
        numericalGuarantee? := some {
          kinds := [.range]
          statement :=
            "Negation, ReLU, and absolute value preserve validity and real-member enclosure, " ++
            "including infinite endpoints." } }
    , { topic := "outward-rounded square-root enclosure"
        declarations :=
          [ ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.sqrt_sound ]
        applicability :=
          LeanFloat.Floats.Formats.BinaryInterchange.FloatInfo.ieeeApplicability summary
        scope :=
          "valid input interval with a nonnegative decoded lower endpoint and a represented real member"
        numericalGuarantee? := some {
          kinds := [.range]
          statement :=
            "The outward-rounded square-root interval contains the exact square root of every represented member." } }
    ]
  nonclaims :=
    [ "every raw endpoint pair is a valid or nonempty mathematical interval"
    , "ordinary scalar `ExecFloat` arithmetic is installed on the interval carrier"
    , "a scalar conversion policy determines whether casts should preserve endpoints, width, or enclosure"
    , "division through zero returns a disconnected interval set; the executable result is one conservative hull"
    , "compiled MPFI, Arb, SIMD, or hardware interval arithmetic is equivalent to these kernels"
    ]

end LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.FloatInfo

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.FloatInfo.Command

open Lean Elab Command Meta
open LeanFloat.Floats.ExecFloat

elab_rules : command
  | `(#float_info%$tk $type:term) =>
      LeanFloat.Floats.ExecFloat.FloatInfo.Command.withElaboratedType
          type fun typeExpr => do
        let some arguments ←
            unfoldUntilAppArgs?
              ``LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval 1 typeExpr
          | throwUnsupportedSyntax
        let summary ←
          LeanFloat.Floats.Formats.BinaryInterchange.FloatInfo.inspectSummary arguments[0]!
        logInfoAt tk <| ←
          Inspection.renderProfile
            (LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.FloatInfo.profile summary)
            typeExpr
            .none

end LeanFloat.Floats.Formats.BinaryInterchange.Model.Interval.FloatInfo.Command
