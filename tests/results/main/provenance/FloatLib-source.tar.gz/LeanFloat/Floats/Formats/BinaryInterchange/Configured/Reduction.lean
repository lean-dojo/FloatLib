/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Reduction.Proof

/-!
# Correctly rounded configured binary reductions

Public entry point for executable configured `sum` and `dot` operations and their refinement
theorems. Execution-only consumers may import `Configured.Reduction.Runtime`.
-/
