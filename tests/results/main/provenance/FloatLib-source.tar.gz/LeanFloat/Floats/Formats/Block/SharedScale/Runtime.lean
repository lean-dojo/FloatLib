/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.Block.SharedScale.Core

/-!
# Executable shared-scale quantization

The kernel rounds each exact rational lane to a nearest-even integer significand at the
caller-selected binary exponent.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.Block

open LeanFloat.Numerics

/-- Quantize every rational lane at an explicitly supplied shared exponent. -/
@[inline] def quantizeAt {lanes : Nat} (exponent : Int) (input : Vector Rat lanes) :
    SharedScaleCode lanes where
  exponent := exponent
  significands :=
    Vector.ofFn fun lane =>
      roundRatEven (input[lane.val] / scale exponent)

end LeanFloat.Floats.Formats.Block
