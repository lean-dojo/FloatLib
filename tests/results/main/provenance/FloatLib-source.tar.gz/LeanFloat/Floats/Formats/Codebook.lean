/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module -- shake: keep-all

public import LeanFloat.Floats.Formats.Codebook.Arithmetic.Proof
public import LeanFloat.Floats.Formats.Codebook.Automation
public import LeanFloat.Floats.Formats.Codebook.Configured.Catalog
public import LeanFloat.Floats.Formats.Codebook.Configured.Proof
public import LeanFloat.Floats.Formats.Codebook.Configured.Conversion.Runtime
public import LeanFloat.Floats.Formats.Codebook.Configured.Conversion.Proof
public meta import LeanFloat.Floats.Formats.Codebook.Configured.Info
public meta import LeanFloat.Floats.Formats.Codebook.Info

/-!
# Exact-width lookup numerical systems

This is the public entry point for lookup-table numerical formats. It exports the generic
codebook representation, the supplied catalog, proved catalog arithmetic, the configured
`ExecFloat.Codebook` carrier, numerical automation, and `#float_info` support.

Import narrower submodules when defining another codebook family internally.

Unlike standardized interchange formats, a codebook is defined by its complete denotation table.
Consequently, the table itself is the authoritative format specification; LeanFloat does not
silently infer arithmetic from bit width or element type.

## Reference

The `CodebookSpec` declaration records the decode table, exceptional entries, and arithmetic
policy used by executable codebook values.
-/

@[expose] public section
