/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Conversion.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Value.Core

/-!
# Configured binary-interchange conversion runtime

This adapter supplies the configured carrier's `ofModel` bridge to the representation-independent
binary conversion policy. Exact rounding happens before packing, so storage and backend selection
cannot change conversion semantics. The exact domain is `SignedRat`, so casts and mixed-format
operations into a configured binary destination keep the sign of zero.
-/

@[expose] public section

namespace LeanFloat.Floats

open LeanFloat.Numerics
open LeanFloat.Floats.Formats.BinaryInterchange

namespace ExecFloat.Binary
namespace Conversion

variable {format : FloatFormat} {plan : Configured.StoragePlan format} {code : Type}
    [LeanFloat.Floats.ExecFloat.ModelCodec plan (Model format) code]

/-- Pack a rounded binary model through the configured destination codec. -/
@[always_inline, inline] def configuredPack (value : Model format) :
    LeanFloat.Floats.ExecFloat (Configured.Family format code plan) :=
  ExecFloat.Binary.ofModel value

/-- Quantize one finite signed rational into the configured binary destination. -/
@[inline] def quantizeFinite (context : Context) (exact : SignedRat) :
    LeanFloat.Floats.ExecFloat.ConversionOutcome
      (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) :=
  quantizeFiniteWith configuredPack context exact

/-- Apply the explicit exceptional-value policy to a configured binary destination. -/
@[inline] def quantizeExceptional (context : Context) (exceptional : ExceptionalValue) :
    LeanFloat.Floats.ExecFloat.ConversionOutcome
      (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) :=
  quantizeExceptionalWith configuredPack context exceptional

/-- Apply the explicit infinity policy to a configured binary destination. -/
@[inline] def quantizeInfinity (context : Context) (negative : Bool) :
    LeanFloat.Floats.ExecFloat.ConversionOutcome
      (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) :=
  quantizeInfinityWith configuredPack context negative

/-- Reference conversion for every complete exact observation. -/
@[inline] def run (context : Context) :
    NumericalValue SignedRat →
      LeanFloat.Floats.ExecFloat.ConversionOutcome
        (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) :=
  runWith configuredPack context

/--
Retained singleton relation for configured binary conversion.

This is the graph of `run`; see `Binary.Conversion.specWith` for what gives the rounder its
meaning.
-/
def spec :
    Quantization.Spec Context (NumericalValue SignedRat)
      (LeanFloat.Floats.ExecFloat.ConversionOutcome
        (LeanFloat.Floats.ExecFloat (Configured.Family format code plan))) :=
  specWith configuredPack

/-- Configured binary decoding selects the signed-rational exact domain, keeping signed zero. -/
instance exactDecoder :
    LeanFloat.Floats.ExecFloat.ExactDecoder
      (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) SignedRat where
  decode := ExecFloat.Binary.decode

end Conversion
end ExecFloat.Binary
end LeanFloat.Floats
