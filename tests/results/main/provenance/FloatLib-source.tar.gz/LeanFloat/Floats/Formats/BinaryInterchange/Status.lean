/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Status.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Status.Proof

/-!
# IEEE exception status

Public API for executable IEEE exception-status kernels and their correctness theorems.

Performance-sensitive code may import
`LeanFloat.Floats.Formats.BinaryInterchange.Status.Runtime` directly. Proof developments may
import `Status.Proof`; ordinary users should import this module.
-/
