/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Conversion.Proof

/-!
# Configured binary-interchange conversion instances

This module installs signed-rational quantization with explicit finite, infinity, and exceptional
policies for every configured binary-interchange destination.
-/

@[expose] public section

namespace LeanFloat.Floats

open LeanFloat.Numerics
open LeanFloat.Floats.Formats.BinaryInterchange

universe u v

namespace ExecFloat.Binary
namespace Conversion

variable {format : FloatFormat} {plan : Configured.StoragePlan format} {code : Type}
    [LeanFloat.Floats.ExecFloat.ModelCodec plan (Model format) code]

/-- Every configured binary destination supports policy-aware signed-rational quantization. -/
instance quantizer :
    LeanFloat.Floats.ExecFloat.Quantizer
      (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) SignedRat where
  Context := Context
  run := run
  spec := spec
  correct := implements_run

/-- Context-free conversion uses `Context.default`. -/
instance defaultQuantizer :
    LeanFloat.Floats.ExecFloat.DefaultQuantizer
      (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) SignedRat where
  defaultContext := Context.default

/--
A cast whose source decodes to a finite exact value is the canonical nearest-even rounding of
that value in the destination format.

The hypothesis names the decoded value, so the theorem applies to any source with an exact decoder
and an embedding into `SignedRat`. Together with `Model.toReal_roundRatScaled_eq_roundAt` it
gives a finite cast its real-number meaning.
-/
theorem cast_eq_roundRat_of_decodeTo_eq_finite {F : Type u} [EncodedFormat F]
    {SourceExact : Type v}
    [LeanFloat.Floats.ExecFloat.ExactDecoder (LeanFloat.Floats.ExecFloat F) SourceExact]
    [LeanFloat.Floats.ExecFloat.ExactMap SourceExact SignedRat]
    (value : LeanFloat.Floats.ExecFloat F) (exact : SignedRat)
    (hdecode :
      LeanFloat.Floats.ExecFloat.ExactDecoder.decodeTo (TargetExact := SignedRat) value =
        .finite exact) :
    LeanFloat.Floats.ExecFloat.cast
        (target := LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) value =
      .success
        (ofModel (Model.roundRat format exact.negative exact.value.num.natAbs exact.value.den))
        (finiteStatus Context.default exact.value
          (Model.roundRat format exact.negative exact.value.num.natAbs exact.value.den)) := by
  change run Context.default (LeanFloat.Floats.ExecFloat.ExactDecoder.decodeTo value) = _
  rw [hdecode]
  exact run_default_finite exact

end Conversion
end ExecFloat.Binary
end LeanFloat.Floats
