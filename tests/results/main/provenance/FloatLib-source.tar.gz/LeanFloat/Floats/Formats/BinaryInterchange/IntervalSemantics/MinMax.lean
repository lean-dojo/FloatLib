/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.Compare.Proof
public import LeanFloat.Floats.Formats.BinaryInterchange.Interval.Core

/-!
# Extended-real semantics of interval endpoint selection

IEEE `minimum` and `maximum` agree with lattice `min` and `max` on non-NaN values. This module
lifts that contract through the four-corner selectors used by executable interval multiplication
and division.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model

noncomputable section

/-- IEEE `minimum` is non-NaN when both operands are non-NaN. -/
theorem isNaN_minimum_eq_false_of_isNaN_eq_false
    {fmt : FloatFormat} (x y : Model fmt)
    (hxNaN : isNaN x = false) (hyNaN : isNaN y = false) :
    isNaN (minimum x y) = false := by
  have hchoose := chooseNaN2_none_of_not_isNaN x y hxNaN hyNaN
  simp only [minimum, withNaNSelection_of_none _ _ hchoose]
  cases horder : compareNonNaN x y hxNaN hyNaN with
  | lt => simpa [horder] using hxNaN
  | gt => simpa [horder] using hyNaN
  | eq =>
      by_cases hzero : isZero x = true ∧ isZero y = true
      · by_cases hsign : signBit x = true ∨ signBit y = true <;>
          simp [hzero]
      · simpa [horder, hzero] using hxNaN

/-- IEEE `maximum` is non-NaN when both operands are non-NaN. -/
theorem isNaN_maximum_eq_false_of_isNaN_eq_false
    {fmt : FloatFormat} (x y : Model fmt)
    (hxNaN : isNaN x = false) (hyNaN : isNaN y = false) :
    isNaN (maximum x y) = false := by
  have hchoose := chooseNaN2_none_of_not_isNaN x y hxNaN hyNaN
  simp only [maximum, withNaNSelection_of_none _ _ hchoose]
  cases horder : compareNonNaN x y hxNaN hyNaN with
  | lt => simpa [horder] using hyNaN
  | gt => simpa [horder] using hxNaN
  | eq =>
      by_cases hzero : isZero x = true ∧ isZero y = true
      · by_cases hsign : signBit x = false ∨ signBit y = false <;>
          simp [hzero]
      · simpa [horder, hzero] using hxNaN

/-- `minimumNumber` never returns a NaN unless both operands are NaNs. -/
theorem isNaN_minimumNumber_eq_false_of_not_both
    {fmt : FloatFormat} (x y : Model fmt)
    (h : isNaN x = false ∨ isNaN y = false) :
    isNaN (minimumNumber x y) = false := by
  rcases h with hx | hy
  · cases hy : isNaN y
    · rw [minimumNumber_eq_minimum_of_not_isNaN x y hx hy]
      exact isNaN_minimum_eq_false_of_isNaN_eq_false x y hx hy
    · rw [minimumNumber_of_isNaN_right x y hx hy]
      exact hx
  · cases hx : isNaN x
    · rw [minimumNumber_eq_minimum_of_not_isNaN x y hx hy]
      exact isNaN_minimum_eq_false_of_isNaN_eq_false x y hx hy
    · rw [minimumNumber_of_isNaN_left x y hx hy]
      exact hy

/-- `maximumNumber` never returns a NaN unless both operands are NaNs. -/
theorem isNaN_maximumNumber_eq_false_of_not_both
    {fmt : FloatFormat} (x y : Model fmt)
    (h : isNaN x = false ∨ isNaN y = false) :
    isNaN (maximumNumber x y) = false := by
  rcases h with hx | hy
  · cases hy : isNaN y
    · rw [maximumNumber_eq_maximum_of_not_isNaN x y hx hy]
      exact isNaN_maximum_eq_false_of_isNaN_eq_false x y hx hy
    · rw [maximumNumber_of_isNaN_right x y hx hy]
      exact hx
  · cases hx : isNaN x
    · rw [maximumNumber_eq_maximum_of_not_isNaN x y hx hy]
      exact isNaN_maximum_eq_false_of_isNaN_eq_false x y hx hy
    · rw [maximumNumber_of_isNaN_left x y hx hy]
      exact hy

namespace Interval

/-- Extended-real semantics of the four-way minimum on non-NaN inputs. -/
theorem toEReal_minOfFour_eq
    {fmt : FloatFormat} (a b c d : Model fmt)
    (haNaN : isNaN a = false) (hbNaN : isNaN b = false)
    (hcNaN : isNaN c = false) (hdNaN : isNaN d = false) :
    toEReal (minOfFour a b c d) =
      min (min (toEReal a) (toEReal b)) (min (toEReal c) (toEReal d)) := by
  have habNaN :=
    isNaN_minimum_eq_false_of_isNaN_eq_false a b haNaN hbNaN
  have hcdNaN :=
    isNaN_minimum_eq_false_of_isNaN_eq_false c d hcNaN hdNaN
  unfold minOfFour
  rw [toEReal_minimum_eq_min (minimum a b) (minimum c d) habNaN hcdNaN,
    toEReal_minimum_eq_min a b haNaN hbNaN,
    toEReal_minimum_eq_min c d hcNaN hdNaN]

/-- Extended-real semantics of the four-way maximum on non-NaN inputs. -/
theorem toEReal_maxOfFour_eq
    {fmt : FloatFormat} (a b c d : Model fmt)
    (haNaN : isNaN a = false) (hbNaN : isNaN b = false)
    (hcNaN : isNaN c = false) (hdNaN : isNaN d = false) :
    toEReal (maxOfFour a b c d) =
      max (max (toEReal a) (toEReal b)) (max (toEReal c) (toEReal d)) := by
  have habNaN :=
    isNaN_maximum_eq_false_of_isNaN_eq_false a b haNaN hbNaN
  have hcdNaN :=
    isNaN_maximum_eq_false_of_isNaN_eq_false c d hcNaN hdNaN
  unfold maxOfFour
  rw [toEReal_maximum_eq_max (maximum a b) (maximum c d) habNaN hcdNaN,
    toEReal_maximum_eq_max a b haNaN hbNaN,
    toEReal_maximum_eq_max c d hcNaN hdNaN]

/--
Pointwise upper bounds on four non-NaN values bound their executable four-way minimum.
-/
theorem toEReal_minOfFour_le_of_le
    {fmt : FloatFormat} (a b c d : Model fmt)
    (haNaN : isNaN a = false) (hbNaN : isNaN b = false)
    (hcNaN : isNaN c = false) (hdNaN : isNaN d = false)
    {a' b' c' d' : EReal}
    (ha : toEReal a ≤ a') (hb : toEReal b ≤ b')
    (hc : toEReal c ≤ c') (hd : toEReal d ≤ d') :
    toEReal (minOfFour a b c d) ≤ min (min a' b') (min c' d') := by
  rw [toEReal_minOfFour_eq a b c d haNaN hbNaN hcNaN hdNaN]
  exact min_le_min (min_le_min ha hb) (min_le_min hc hd)

/--
Pointwise lower bounds on four non-NaN values bound their executable four-way maximum.
-/
theorem le_toEReal_maxOfFour_of_le
    {fmt : FloatFormat} (a b c d : Model fmt)
    (haNaN : isNaN a = false) (hbNaN : isNaN b = false)
    (hcNaN : isNaN c = false) (hdNaN : isNaN d = false)
    {a' b' c' d' : EReal}
    (ha : a' ≤ toEReal a) (hb : b' ≤ toEReal b)
    (hc : c' ≤ toEReal c) (hd : d' ≤ toEReal d) :
    max (max a' b') (max c' d') ≤ toEReal (maxOfFour a b c d) := by
  rw [toEReal_maxOfFour_eq a b c d haNaN hbNaN hcNaN hdNaN]
  exact max_le_max (max_le_max ha hb) (max_le_max hc hd)

end Interval
end

end Model
end LeanFloat.Floats.Formats.BinaryInterchange
