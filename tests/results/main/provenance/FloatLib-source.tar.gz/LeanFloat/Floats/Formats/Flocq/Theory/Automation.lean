/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.Flocq.Theory.Arithmetic
public import LeanFloat.Numerics.Automation.Numerics -- shake: keep

/-!
# FloatRep rules for numerical automation

The rules expose exact negation and multiplication through the shared operation contracts.
Concrete evaluation reduces only the executable integer carrier; real decoding remains proof-only.
-/

public meta section

namespace LeanFloat.Floats.Formats.Flocq.FloatRep

open LeanFloat.Numerics

attribute [aesop safe apply (rule_sets := [Numerics])]
  neg_refines
  mul_refines

attribute [numerics_simps]
  toReal_neg
  toReal_mul
  numericalSystem_represents_iff

attribute [numerics_reduction]
  neg
  mul

end LeanFloat.Floats.Formats.Flocq.FloatRep
