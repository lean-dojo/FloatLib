/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Conversion.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Conversion.Proof

/-!
# Exact conversion into binary-interchange models

This module exports the representation-independent runtime policy and its proof contract. Carrier
adapters are split into the `Runtime`, `Proof`, and `Instances` modules below
`Configured.Conversion` and `StaticByte.Conversion`.
-/
