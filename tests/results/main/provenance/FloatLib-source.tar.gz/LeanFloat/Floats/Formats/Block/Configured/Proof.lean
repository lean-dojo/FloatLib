/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.Block.Configured.Runtime
public import LeanFloat.Floats.Formats.Block.SharedScale.Proof

/-!
# Correctness of configured shared-scale blocks

The configured wrapper preserves complete codes and the underlying contextual quantization
specification.

These theorems show that storage packing is observationally transparent: decoding a configured
block recovers the same shared scale and element meanings as the generic model. Quantization
correctness remains parameterized by the caller-selected exponent, matching the runtime API instead
of baking in one calibration policy.
-/

@[expose] public section

namespace LeanFloat.Floats.ExecFloat.SharedScale

open LeanFloat.Numerics

variable {lanes : Nat}

/-- Unwrapping a freshly wrapped shared-scale block returns the original code. -/
@[simp, grind =] theorem toCode_ofCode (code : Formats.Block.SharedScaleCode lanes) :
    toCode (ofCode code) = code :=
  rfl

/-- Rewrapping the code of a shared-scale block returns the original value. -/
@[simp, grind =] theorem ofCode_toCode (value : ExecFloat.SharedScale lanes) :
    ofCode value.toCode = value :=
  ExecFloat.ofRaw_raw value

/-- Quantization records exactly the shared exponent supplied by the caller. -/
@[simp, grind =] theorem exponent_quantizeAt
    (exponent : Int) (input : Vector Rat lanes) :
    (quantizeAt exponent input).exponent = exponent :=
  rfl

/-- Each decoded quantized lane is its nearest-even integer multiple of the shared scale. -/
@[simp, grind =] theorem decode_quantizeAt_get (exponent : Int)
    (input : Vector Rat lanes) (lane : Fin lanes) :
    (decode (quantizeAt exponent input))[lane.val] =
      (roundRatEven
        (input[lane.val] / Formats.Block.scale exponent) : Rat) *
        Formats.Block.scale exponent :=
  Formats.Block.decode_quantizeAt_get exponent input lane

/-- The configured wrapper preserves relational contextual quantization. -/
theorem quantizesAt_quantizeAt (exponent : Int) (input : Vector Rat lanes) :
    Formats.Block.QuantizesAt exponent input (quantizeAt exponent input).toCode :=
  Formats.Block.quantizesAt_quantizeAt exponent input

end LeanFloat.Floats.ExecFloat.SharedScale
