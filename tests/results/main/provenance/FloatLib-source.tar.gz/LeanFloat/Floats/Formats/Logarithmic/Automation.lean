/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.Logarithmic.Exact.Proof
public import LeanFloat.Numerics.Automation.Numerics -- shake: keep

/-!
# Logarithmic-system rules for numerical automation

Multiplication is exact in the encoded sign/exponent representation. The real-valued decoder is
proof-facing and remains absent from compiled kernels.
-/

public meta section

open LeanFloat.Numerics

namespace LeanFloat.Floats.Formats.Logarithmic

attribute [numerics_simps]
  Code.toReal_mul
  numericalSystem_represents_iff

attribute [aesop safe apply (rule_sets := [Numerics])]
  mul_refines

attribute [numerics_reduction]
  Code.toReal
  Code.mul
  numericalSystem

end LeanFloat.Floats.Formats.Logarithmic
