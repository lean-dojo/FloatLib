/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.Flocq.Theory.Analysis.Neighbors
public import LeanFloat.Floats.Formats.Flocq.Theory.Analysis.StandardUlp
public import LeanFloat.Floats.Formats.Flocq.Theory.Analysis.Sterbenz
public import LeanFloat.Floats.Formats.Flocq.Theory.Analysis.SterbenzFLT
public import LeanFloat.Floats.Formats.Flocq.Theory.Analysis.Ulp
public import LeanFloat.Floats.Formats.Flocq.Theory.Arithmetic
public import LeanFloat.Floats.Formats.Flocq.Theory.Automation
public import LeanFloat.Floats.Formats.Flocq.Theory.Core
public import LeanFloat.Floats.Formats.Flocq.Theory.Error.Addition
public import LeanFloat.Floats.Formats.Flocq.Theory.Error.Bounds
public import LeanFloat.Floats.Formats.Flocq.Theory.Error.Directed
public import LeanFloat.Floats.Formats.Flocq.Theory.Error.DivisionSqrt
public import LeanFloat.Floats.Formats.Flocq.Theory.Error.Exactness
public import LeanFloat.Floats.Formats.Flocq.Theory.Error.Multiplication
public import LeanFloat.Floats.Formats.Flocq.Theory.Error.Relative
public import LeanFloat.Floats.Formats.Flocq.Theory.Format.Digits
public import LeanFloat.Floats.Formats.Flocq.Theory.Format.Formats
public import LeanFloat.Floats.Formats.Flocq.Theory.Format.Generic
public import LeanFloat.Floats.Formats.Flocq.Theory.Format.Magnitude
public import LeanFloat.Floats.Formats.Flocq.Theory.Format.Theorems
public import LeanFloat.Floats.Formats.Flocq.Theory.NumericalSystem
public import LeanFloat.Floats.Formats.Flocq.Theory.Rounding.Away
public import LeanFloat.Floats.Formats.Flocq.Theory.Rounding.Core
public import LeanFloat.Floats.Formats.Flocq.Theory.Rounding.Double
public import LeanFloat.Floats.Formats.Flocq.Theory.Rounding.Generic
public import LeanFloat.Floats.Formats.Flocq.Theory.Rounding.Nearest
public import LeanFloat.Floats.Formats.Flocq.Theory.Rounding.Odd
public import LeanFloat.Floats.Formats.Flocq.Theory.Rounding.Order
public import LeanFloat.Floats.Formats.Flocq.Theory.Rounding.Predicates
public import LeanFloat.Floats.Formats.Flocq.Theory.Rounding.Properties
public import LeanFloat.Floats.Formats.Flocq.Theory.Scalar.NF
public import LeanFloat.Floats.Formats.Flocq.Theory.Scalar.Representable
public import LeanFloat.Floats.Formats.Flocq.Theory.Special.FTZ

/-!
# Flocq-style rounded-real theory

This is the “rounding-on-ℝ” side of LeanFloat’s float models. We use it when we want to talk about
formats and rounding generically, without committing to a concrete IEEE bit encoding:

- generic format/rounding infrastructure,
- exact executable negation and multiplication on integer mantissa/exponent codes,
- the rounded scalar type `NF`,
- ULP-style error bounds and small calculation libraries.

Most files that are *not* bit-level IEEE execution live under `LeanFloat/Floats/Formats/Flocq/Theory/`.

The rounded-real API uses namespace-local mathematical names such as `FloatRep`, `genericFormat`,
`round`, `ulp`, and `bpow`; no historical application-specific prefix leaks into the theory.

## Analysis

This layer studies spacing rather than defining formats or rounding modes.  It provides ULP
functions, adjacent representable values, and Sterbenz exact-subtraction results.  The
representability of the rounded-addition error, which is the specification of the TwoSum and
FastTwoSum error-free transformations, is proved in `Theory.Error.Addition`; the operation-level
exactness of those algorithms is not formalized.

## References

- P. H. Sterbenz, *Floating-Point Computation*, Prentice-Hall, 1974.
- N. J. Higham, *Accuracy and Stability of Numerical Algorithms*, second edition, SIAM, 2002.

## Error

This module collects the generic error results used by format-specific
`BinaryInterchange.Model.roundAt` theorems, runtime-refinement proofs, verifier margins, and
numerical analyses. Import a child module when developing the theory itself; downstream users can
import this module.

## Format

This module collects the radix, magnitude, exponent-function, and representability theory used by
LeanFloat's real-valued floating-point model.  The organization follows the generic-format layer of
Flocq, while the declarations and proofs here are native Lean.

This module excludes rounding modes and error bounds. A client that only needs to
state that a value belongs to a format should not need to import the rest of numerical analysis.

## References

- S. Boldo and G. Melquiond, "Flocq: A Unified Library for Proving Floating-Point Algorithms in
  Coq," *IEEE ARITH*, 2011, doi:10.1109/ARITH.2011.40.
- IEEE, *IEEE Standard for Floating-Point Arithmetic*, IEEE 754-2019.

## Rounding

This module contains rounding functions and their semantic laws: directed modes, nearest choices,
order properties, round-to-odd, round-away, and double rounding.  It is independent of concrete
IEEE bit encodings; a format supplies the representable grid and a rounding policy selects a point
on that grid.

## References

- IEEE, *IEEE Standard for Floating-Point Arithmetic*, IEEE 754-2019, Sections 4 and 7.
- D. Goldberg, "What Every Computer Scientist Should Know About Floating-Point Arithmetic,"
  *ACM Computing Surveys* 23(1), 1991, doi:10.1145/103162.103163.

## Scalar

`NF` is the scalar-facing interface to generic rounding. This folder keeps the carrier and its
representability invariant together. The raw carrier may contain any real value; statements that
require membership in the declared grid use `NF.IsRepresentable` explicitly.
-/

@[expose] public section
