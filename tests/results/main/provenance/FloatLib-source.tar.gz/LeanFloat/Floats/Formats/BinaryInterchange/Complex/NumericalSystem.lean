/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Complex.Semantics
public import LeanFloat.Numerics.Core.Proof
public import LeanFloat.Numerics.Operation.Semantics

/-!
# Executable complex values as numerical systems

A complex code is ordinary only when both scalar components are finite.  The finite semantic
domain is `ℂ`; any component containing NaN or infinity is classified as undefined rather than
being assigned an invented complex value.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex

open LeanFloat.Numerics

/-- Complex semantics over an arbitrary component format. -/
noncomputable def numericalSystem (fmt : FloatFormat) : NumericalSystem where
  Code := ExecComplex fmt
  Scalar := ℂ
  denote z :=
    if isFinite z then .finite (toComplex z)
    else .exceptional .undefined

/-- An executable complex value with an erased proof of its complete denotation. -/
abbrev AtValue (fmt : FloatFormat) (value : NumericalValue ℂ) :=
  (numericalSystem fmt).At value

/-- An executable complex value with an erased proof of its finite complex value. -/
abbrev At (fmt : FloatFormat) (value : ℂ) :=
  (numericalSystem fmt).AtFinite value

/-- Finite executable components denote their assembled mathematical complex value. -/
theorem numericalSystem_represents_of_isFinite {fmt : FloatFormat} (z : ExecComplex fmt)
    (hz : isFinite z = true) :
    (numericalSystem fmt).Represents z (toComplex z) := by
  simp [NumericalSystem.Represents, numericalSystem, hz]

/-- A complex code represents a value exactly when both components are finite and decode to it. -/
@[simp] theorem represents_iff {fmt : FloatFormat} (z : ExecComplex fmt) (value : ℂ) :
    (numericalSystem fmt).Represents z value ↔
      isFinite z = true ∧ toComplex z = value := by
  unfold NumericalSystem.Represents numericalSystem
  cases hfinite : isFinite z <;> simp [hfinite]

/-- Componentwise sign negation refines exact complex negation. -/
theorem neg_refines (fmt : FloatFormat) :
    Operation.Finite1 (numericalSystem fmt) (numericalSystem fmt)
      ExecComplex.neg (fun value : ℂ => -value) := by
  unfold Operation.Finite1 Operation.RefinesFinite1
  intro z value hz
  obtain ⟨hzFinite, rfl⟩ := (represents_iff z value).1 hz
  apply (represents_iff _ _).2
  refine ⟨?_, toComplex_neg z hzFinite⟩
  simpa [ExecComplex.isFinite, ExecComplex.neg] using hzFinite

/-- Conjugation refines exact mathematical complex conjugation. -/
theorem conj_refines (fmt : FloatFormat) :
    Operation.Finite1 (numericalSystem fmt) (numericalSystem fmt)
      ExecComplex.conj (starRingEnd ℂ) := by
  unfold Operation.Finite1 Operation.RefinesFinite1
  intro z value hz
  obtain ⟨hzFinite, rfl⟩ := (represents_iff z value).1 hz
  apply (represents_iff _ _).2
  refine ⟨?_, toComplex_conj z hzFinite⟩
  simpa [ExecComplex.isFinite, ExecComplex.conj] using hzFinite

/-- Complex addition refines its explicit componentwise rounded semantics. -/
theorem add_refines (fmt : FloatFormat) (hfmt : fmt.isIEEE = true) :
    Operation.Finite2If (numericalSystem fmt) (numericalSystem fmt)
      (numericalSystem fmt) ExecComplex.add (roundedAdd fmt)
      (fun _ _ result => isFinite result = true) := by
  unfold Operation.Finite2If
  intro x y left right hx hy hout
  obtain ⟨hxFinite, rfl⟩ := (represents_iff x left).1 hx
  obtain ⟨hyFinite, rfl⟩ := (represents_iff y right).1 hy
  exact (represents_iff _ _).2
    ⟨hout, toComplex_add_eq_roundedAdd x y hfmt hxFinite hyFinite hout⟩

/-- Complex subtraction refines its explicit componentwise rounded semantics. -/
theorem sub_refines (fmt : FloatFormat) (hfmt : fmt.isIEEE = true) :
    Operation.Finite2If (numericalSystem fmt) (numericalSystem fmt)
      (numericalSystem fmt) ExecComplex.sub (roundedSub fmt)
      (fun _ _ result => isFinite result = true) := by
  unfold Operation.Finite2If
  intro x y left right hx hy hout
  obtain ⟨hxFinite, rfl⟩ := (represents_iff x left).1 hx
  obtain ⟨hyFinite, rfl⟩ := (represents_iff y right).1 hy
  exact (represents_iff _ _).2
    ⟨hout, toComplex_sub_eq_roundedSub x y hfmt hxFinite hyFinite hout⟩

/-- Complex multiplication refines all six scalar rounding sites in `roundedMul`. -/
theorem mul_refines (fmt : FloatFormat) (hfmt : fmt.isIEEE = true) :
    Operation.Finite2If (numericalSystem fmt) (numericalSystem fmt)
      (numericalSystem fmt) ExecComplex.mul (roundedMul fmt)
      (fun x y _ => MulFinite x y) := by
  unfold Operation.Finite2If
  intro x y left right hx hy hfinite
  obtain ⟨_, rfl⟩ := (represents_iff x left).1 hx
  obtain ⟨_, rfl⟩ := (represents_iff y right).1 hy
  exact (represents_iff _ _).2
    ⟨hfinite.2.2.2.2.2.2, toComplex_mul_eq_roundedMul x y hfmt hfinite⟩

end LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex
