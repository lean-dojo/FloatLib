/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Arithmetic.Runtime
public import LeanFloat.Floats.ExecFloat.Backends.Dispatch.Add.Proof
public import LeanFloat.Floats.ExecFloat.Backends.Dispatch.Div.Proof
public import LeanFloat.Floats.ExecFloat.Backends.Dispatch.Fma.Proof
public import LeanFloat.Floats.ExecFloat.Backends.Dispatch.Mul.Proof
public import LeanFloat.Floats.ExecFloat.Backends.Dispatch.Sqrt.Proof

/-!
# Refinement of format-parameterized binary arithmetic

The executable model operations agree with the independent descriptor-aware specifications for
every validated `FloatFormat`.

These are the family-level refinement theorems used before a result is transported to configured
storage. Keeping specifications independent of the executable definitions makes the claims useful
for arbitrary precision and for future optimized backends, rather than proving only that a function
equals itself after unfolding.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model
namespace Proof

/-- Public addition agrees with its descriptor-aware specification for every `FloatFormat`. -/
@[grind =] theorem add_eq_spec {fmt : FloatFormat} (x y : Model fmt) :
    add x y = Spec.add x y :=
  AddBackend.word_eq_spec x y

/-- Public subtraction agrees with its descriptor-aware specification for every `FloatFormat`. -/
@[grind =] theorem sub_eq_spec {fmt : FloatFormat} (x y : Model fmt) :
    sub x y = Spec.sub x y :=
  AddBackend.subWord_eq_spec x y

/-- Public multiplication agrees with its descriptor-aware specification for every `FloatFormat`. -/
@[grind =] theorem mul_eq_spec {fmt : FloatFormat} (x y : Model fmt) :
    mul x y = Spec.mul x y :=
  MulBackend.word_eq_spec x y

/-- Public division agrees with its descriptor-aware specification for every `FloatFormat`. -/
@[grind =] theorem div_eq_spec {fmt : FloatFormat} (x y : Model fmt) :
    div x y = Spec.div x y :=
  DivBackend.word_eq_spec x y

/-- Public square root agrees with its descriptor-aware specification for every `FloatFormat`. -/
@[grind =] theorem sqrt_eq_spec {fmt : FloatFormat} (x : Model fmt) :
    sqrt x = Spec.sqrt x :=
  SqrtBackend.dispatch_eq_spec x

/-- Public FMA agrees with its descriptor-aware specification for every `FloatFormat`. -/
@[grind =] theorem fma_eq_spec {fmt : FloatFormat} (x y z : Model fmt) :
    fma x y z = Spec.fma x y z :=
  FmaBackend.dispatch_eq_spec x y z

end Proof
end Model
end LeanFloat.Floats.Formats.BinaryInterchange
