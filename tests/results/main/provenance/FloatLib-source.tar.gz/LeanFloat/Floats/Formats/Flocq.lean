/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.Flocq.Theory
public import LeanFloat.Floats.Formats.Flocq.Calculation.Bracket
public import LeanFloat.Floats.Formats.Flocq.Calculation.Arithmetic
public import LeanFloat.Floats.Formats.Flocq.Calculation.Operations
public import LeanFloat.Floats.Formats.Flocq.Calculation.Round
public import LeanFloat.Floats.Formats.Flocq.GenericFormat

/-!
# Flocq-style numerical format family

This module exports the native rounded-real theorem library, its representation-level
calculation layer, and the semantic embedding of radix/exponent-function generic formats into
LeanFloat's representation-independent format and quantization interfaces.

## References

* S. Boldo and G. Melquiond, “Flocq: A Unified Library for Proving Floating-Point
  Algorithms in Coq,” ARITH 2011, DOI 10.1109/ARITH.2011.40.
* Flocq project documentation and source,
  <https://flocq.gitlabpages.inria.fr/flocq/>.

## Calculation

This layer turns the generic Flocq-style format theory into calculations. It provides exact
mantissa/exponent operations, locates values between adjacent representable numbers, and applies
directed or nearest rounding.

The calculation modules remain separate from `Theory`: proofs can reason from the abstract format
laws, while executable formats can reuse one rounding implementation.
-/

@[expose] public section
