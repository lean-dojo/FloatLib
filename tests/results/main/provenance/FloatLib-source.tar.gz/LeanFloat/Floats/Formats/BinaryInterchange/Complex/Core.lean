/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Arithmetic.Runtime

/-!
# Executable complex numbers over an arbitrary binary format

`ExecComplex fmt` stores one `Model fmt` for each Cartesian component. The format parameter is
not fixed to binary32: the same definition supports binary16, bfloat16, binary64, binary128,
binary256, and custom exponent/fraction widths.

Complex multiplication uses four scalar multiplications followed by one subtraction and one
addition. This explicit evaluation order matters in floating-point arithmetic and is reflected by
the semantic theorem in `ExecComplex.Semantics`.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange

/-- A complex value whose real and imaginary components share the binary format `fmt`. -/
structure ExecComplex (fmt : FloatFormat) where
  /-- Real component. -/
  re : Model fmt
  /-- Imaginary component. -/
  im : Model fmt
  deriving DecidableEq, Repr

namespace ExecComplex

/-- A complex value is finite exactly when both encoded components are finite. -/
@[inline] def isFinite {fmt : FloatFormat} (z : ExecComplex fmt) : Bool :=
  Model.isFinite z.re && Model.isFinite z.im

/-- Componentwise sign negation. -/
@[inline] def neg {fmt : FloatFormat} (z : ExecComplex fmt) : ExecComplex fmt :=
  ⟨Model.neg z.re, Model.neg z.im⟩

/-- Componentwise floating-point addition. -/
@[inline] def add {fmt : FloatFormat} (x y : ExecComplex fmt) : ExecComplex fmt :=
  ⟨Model.add x.re y.re, Model.add x.im y.im⟩

/-- Componentwise floating-point subtraction. -/
@[inline] def sub {fmt : FloatFormat} (x y : ExecComplex fmt) : ExecComplex fmt :=
  ⟨Model.sub x.re y.re, Model.sub x.im y.im⟩

namespace Internal

/-- Real component of the specified non-fused complex product. -/
@[noinline] def mulReal {fmt : FloatFormat} (x y : ExecComplex fmt) : Model fmt :=
  Model.sub (Model.mul x.re y.re) (Model.mul x.im y.im)

/-- Imaginary component of the specified non-fused complex product. -/
@[noinline] def mulImag {fmt : FloatFormat} (x y : ExecComplex fmt) : Model fmt :=
  Model.add (Model.mul x.re y.im) (Model.mul x.im y.re)

end Internal

/--
Floating-point complex multiplication with an explicit non-fused evaluation order.

Each of the four component products is rounded in `fmt`; the real subtraction and imaginary
addition are then rounded once more in the same format.
-/
@[inline] def mul {fmt : FloatFormat} (x y : ExecComplex fmt) : ExecComplex fmt :=
  ⟨Internal.mulReal x y, Internal.mulImag x y⟩

/-- Complex conjugation; only the imaginary sign bit changes. -/
@[inline] def conj {fmt : FloatFormat} (z : ExecComplex fmt) : ExecComplex fmt :=
  ⟨z.re, Model.neg z.im⟩

instance {fmt : FloatFormat} : Neg (ExecComplex fmt) := ⟨neg⟩
instance {fmt : FloatFormat} : Add (ExecComplex fmt) := ⟨add⟩
instance {fmt : FloatFormat} : Sub (ExecComplex fmt) := ⟨sub⟩
instance {fmt : FloatFormat} : Mul (ExecComplex fmt) := ⟨mul⟩

/-- Boolean finiteness separates into the corresponding facts for both components. -/
theorem isFinite_eq_true_iff {fmt : FloatFormat} (z : ExecComplex fmt) :
    isFinite z = true ↔
      Model.isFinite z.re = true ∧ Model.isFinite z.im = true := by
  simp [isFinite]

end ExecComplex
end LeanFloat.Floats.Formats.BinaryInterchange
