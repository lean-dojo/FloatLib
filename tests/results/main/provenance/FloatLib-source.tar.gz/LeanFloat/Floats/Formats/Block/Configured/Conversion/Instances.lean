/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.Block.Configured.Conversion.Proof

/-!
# Shared-scale block conversion instances

This module installs block quantization with an explicit shared exponent. It deliberately does not
install `DefaultQuantizer`.
-/

@[expose] public section

namespace LeanFloat.Floats

open LeanFloat.Numerics

namespace ExecFloat.SharedScale
namespace Conversion

variable {lanes : Nat}

/--
Shared-scale destinations support quantization only with an explicit exponent context.

There is intentionally no `DefaultQuantizer` instance.
-/
instance quantizer :
    LeanFloat.Floats.ExecFloat.Quantizer
      (ExecFloat.SharedScale lanes) (Vector Rat lanes) where
  Context := Int
  run := run
  spec := spec
  correct := implements_run

end Conversion
end ExecFloat.SharedScale
end LeanFloat.Floats
