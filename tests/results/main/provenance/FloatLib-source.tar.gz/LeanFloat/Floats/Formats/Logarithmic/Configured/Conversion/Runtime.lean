/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.Logarithmic.Configured.Runtime
public import LeanFloat.Floats.ExecFloat.Conversion.Core

/-!
# Runtime conversion source for configured logarithmic values

Every exact logarithmic value is zero or a signed integral power of its radix and therefore has an
exact rational observation. No destination quantizer is installed until a caller chooses explicit
nearest-power, tie, underflow, and bounded-exponent policies.
-/

@[expose] public section

namespace LeanFloat.Floats

open LeanFloat.Numerics

namespace ExecFloat.Logarithmic
namespace Conversion

variable {radix : Radix}

/-- Decode a configured logarithmic value to its exact rational meaning. -/
instance exactDecoder :
    LeanFloat.Floats.ExecFloat.ExactDecoder
      (ExecFloat.Logarithmic radix) Rat where
  decode value := .finite value.toCode.toRat

end Conversion
end ExecFloat.Logarithmic
end LeanFloat.Floats
