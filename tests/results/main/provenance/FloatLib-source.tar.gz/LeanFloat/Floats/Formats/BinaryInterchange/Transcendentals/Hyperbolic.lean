/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.Compare.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Transcendentals.ExpLog
public import LeanFloat.Floats.Formats.BinaryInterchange.Arithmetic.Runtime

/-!
# Format-generic executable hyperbolic functions

`sinh`, `cosh`, and `tanh` are built from exact dyadics, exact rationals, and the configured
exponential kernel, so the same algorithms elaborate for arbitrary binary descriptors.

For `|x| < 1/2` the small branches of `sinh` and `tanh` evaluate the odd Taylor polynomial stored in
`Config.sinhCoeffsAsc` exactly and round once. The polynomial length is chosen by
`Config.sinhTerms` from the destination fraction width using an analytic Taylor-tail target. The
`tanh` small branch converts the truncated `sinh` value `s` through
`s / sqrt (1 + s^2)` with an integer square root carrying `tanhGuardBits` extra bits. These choices
are accuracy design rationale, not kernel-checked real-error or ULP theorems. Larger arguments go
through `exp`, whose error is likewise inherited without a stated bound.

These are executable approximations, not correctly rounded libm theorems. The branch structure and
the way each constant is built stay visible so future real-error proofs can refer to one generic
implementation rather than a family of copied width-specific programs.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model

namespace Transcendentals

/-- Exact dyadic multiplication without rounding. -/
@[inline] def mulDyadic (left right : Numerics.Dyadic) : Numerics.Dyadic :=
  { negative := Bool.xor left.negative right.negative
    significand := left.significand * right.significand
    exponent := left.exponent + right.exponent }

/-- Embed an integer as an exact dyadic. -/
@[inline] def dyadicOfInt (value : Int) : Numerics.Dyadic :=
  { negative := value < 0
    significand := value.natAbs
    exponent := 0 }

/-- Exact dyadic one. -/
@[inline] def oneDyadic : Numerics.Dyadic :=
  { negative := false, significand := 1, exponent := 0 }

/-- Exact dyadic zero. -/
@[inline] def zeroDyadic : Numerics.Dyadic :=
  { negative := false, significand := 0, exponent := 0 }

/--
Evaluate ascending integer coefficients as an exact polynomial in a dyadic argument.

An empty coefficient list evaluates to zero.
-/
def evalDyadicPolyAsc
    (coefficients : List Int) (value : Numerics.Dyadic) : Numerics.Dyadic :=
  let step (state : Numerics.Dyadic × Numerics.Dyadic)
      (coefficient : Int) : Numerics.Dyadic × Numerics.Dyadic :=
    let power := state.1
    let accumulator := state.2
    let term := mulDyadic (dyadicOfInt coefficient) power
    (mulDyadic power value, addDyadic accumulator term)
  (coefficients.foldl step (oneDyadic, zeroDyadic)).2

/-- Round the exact rational `value / denominator` to the destination format. -/
def roundDyadicDivNat
    (fmt : FloatFormat) (value : Numerics.Dyadic) (denominator : Nat) : Model fmt :=
  if value.significand == 0 then
    zero fmt value.negative
  else
    roundRatScaled fmt value.negative value.significand denominator value.exponent

/-- Round a nonnegative natural number directly into the destination format. -/
@[inline] def ofNat (fmt : FloatFormat) (value : Nat) : Model fmt :=
  roundDyadic fmt { negative := false, significand := value, exponent := 0 }

/--
Exact numerator of the truncated odd Taylor series of `sinh` at a dyadic argument.

The value `sinhSeriesNumerator config x / config.sinhDenominator` is the polynomial
`x + x^3/3! + ... ` truncated to `config.sinhCoeffsAsc.length` terms.
-/
def sinhSeriesNumerator (config : Config) (exact : Numerics.Dyadic) : Numerics.Dyadic :=
  mulDyadic exact (evalDyadicPolyAsc config.sinhCoeffsAsc (mulDyadic exact exact))

/-- Evaluate the truncated `sinh` series at a finite input and round once. -/
def sinhTaylorSmallWith {fmt : FloatFormat}
    (config : Config) (x : Model fmt) : Model fmt :=
  match toDyadic? x with
  | none => invalidResult fmt
  | some exact =>
      roundDyadicDivNat fmt (sinhSeriesNumerator config exact) config.sinhDenominator

/-- Extra bits carried by the integer square root in the small-argument `tanh` branch. -/
def tanhGuardBits : Nat := 8

/--
Evaluate `tanh` for small arguments from the truncated `sinh` series and round once.

Writing the truncated series as `s = a / sqrt b`-compatible integers, we use
`tanh x = s / sqrt (1 + s^2) = a / sqrt (D^2 + a^2)` with `a` the integer numerator scaled to a
common power of two and `D` the series denominator. The quotient is produced as a floor integer
square root `q = floor (sqrt (a^2 * 4^k / b))` where `k` is chosen so `q` carries at least
`fmt.fracWidth + tanhGuardBits` significant bits; then `q * 2^(-k)` is rounded once. The square
root guard budget is intended to keep its truncation below the destination rounding scale. This
module does not yet prove a real-error or ULP bound for the construction.
-/
def tanhTaylorSmallWith {fmt : FloatFormat}
    (config : Config) (x : Model fmt) : Model fmt :=
  match toDyadic? x with
  | none => invalidResult fmt
  | some exact =>
      let numerator := sinhSeriesNumerator config exact
      let squaredDenominator := config.sinhDenominator * config.sinhDenominator
      let (a, b) : Nat × Nat :=
        match numerator.exponent with
        | .ofNat shift =>
            let a := numerator.significand * pow2 shift
            (a, squaredDenominator + a * a)
        | .negSucc shift =>
            let a := numerator.significand
            (a, squaredDenominator * pow2 (2 * (shift + 1)) + a * a)
      if a == 0 then
        zero fmt exact.negative
      else
        let k := fmt.fracWidth + tanhGuardBits + (Nat.log2 b + 1) / 2 + 1 - Nat.log2 a
        let q := Nat.sqrt (a * a * pow2 (2 * k) / b)
        roundDyadic fmt { negative := exact.negative, significand := q, exponent := -(Int.ofNat k) }

end Transcendentals

/-- Evaluate the exponential branch used by `sinhWithProvider`. -/
@[noinline] def sinhLarge {fmt : FloatFormat}
    (getConfig : Unit → Transcendentals.Config)
    (x half : Model fmt) : Model fmt :=
  let config := getConfig ()
  mul (sub (expWith config x) (expWith config (neg x))) half

/--
Evaluate hyperbolic sine with a delayed configuration provider.

Inputs of magnitude below one half use the exact truncated series with a single rounding; other
finite inputs use `(exp x - exp (-x)) / 2`.
-/
def sinhWithProvider {fmt : FloatFormat}
    (getConfig : Unit → Transcendentals.Config) (x : Model fmt) : Model fmt :=
  match chooseNaN1 x with
  | some nan => nan
  | none =>
      if isInf x then
        x
      else
        let half := roundDyadic fmt { negative := false, significand := 1, exponent := -1 }
        match compare (abs x) half with
        | some .lt => Transcendentals.sinhTaylorSmallWith (getConfig ()) x
        | _ => sinhLarge getConfig x half

/-- Evaluate hyperbolic cosine with a delayed configuration provider. -/
def coshWithProvider {fmt : FloatFormat}
    (getConfig : Unit → Transcendentals.Config) (x : Model fmt) : Model fmt :=
  match chooseNaN1 x with
  | some nan => nan
  | none =>
      if isInf x then
        nativeOverflow fmt false
      else
        let half := roundDyadic fmt { negative := false, significand := 1, exponent := -1 }
        let config := getConfig ()
        mul (add (expWith config x) (expWith config (neg x))) half

/-- Evaluate hyperbolic tangent with a provider called only after handling special values. -/
def tanhWithProvider {fmt : FloatFormat}
    (getConfig : Unit → Transcendentals.Config) (x : Model fmt) : Model fmt :=
  match chooseNaN1 x with
  | some nan => nan
  | none =>
      if isInf x then
        if signBit x then negOne fmt else posOne fmt
      else if isZero x then
        x
      else
        let one := posOne fmt
        let two := Transcendentals.ofNat fmt 2
        let half := roundDyadic fmt { negative := false, significand := 1, exponent := -1 }
        let magnitude := abs x
        match compare magnitude half with
        | some .lt =>
            Transcendentals.tanhTaylorSmallWith (getConfig ()) x
        | _ =>
            let config := getConfig ()
            let exponential := expWith config (add magnitude magnitude)
            let raw := sub one (div two (add exponential one))
            let boundary := Transcendentals.tanhTaylorSmallWith config half
            let positive :=
              match compare raw boundary with
              | some .lt => boundary
              | _ => raw
            if signBit x then neg positive else positive

/-- Deterministic hyperbolic sine using the configured exponential kernel. -/
def sinhWith {fmt : FloatFormat}
    (config : Transcendentals.Config) (x : Model fmt) : Model fmt :=
  sinhWithProvider (fun _ => config) x

/-- Deterministic hyperbolic cosine using the configured exponential kernel. -/
def coshWith {fmt : FloatFormat}
    (config : Transcendentals.Config) (x : Model fmt) : Model fmt :=
  coshWithProvider (fun _ => config) x

/--
Deterministic hyperbolic tangent.

Inputs of magnitude below one half use the exact truncated `sinh` series and the identity
`tanh x = s / sqrt (1 + s^2)`. Larger finite inputs use `1 - 2 / (exp (2 * |x|) + 1)` and are
clamped from below to the small-branch value at one half, preserving monotonicity across the branch.
-/
def tanhWith {fmt : FloatFormat}
    (config : Transcendentals.Config) (x : Model fmt) : Model fmt :=
  tanhWithProvider (fun _ => config) x

/-- Hyperbolic sine using the default configuration for the destination format. -/
@[inline] def sinh {fmt : FloatFormat} (x : Model fmt) : Model fmt :=
  sinhWithProvider (fun _ => Transcendentals.Config.forFormat fmt) x

/-- Hyperbolic cosine using the default configuration for the destination format. -/
@[inline] def cosh {fmt : FloatFormat} (x : Model fmt) : Model fmt :=
  coshWithProvider (fun _ => Transcendentals.Config.forFormat fmt) x

/-- Hyperbolic tangent using the default configuration for the destination format. -/
@[inline] def tanh {fmt : FloatFormat} (x : Model fmt) : Model fmt :=
  tanhWithProvider (fun _ => Transcendentals.Config.forFormat fmt) x

end Model
end LeanFloat.Floats.Formats.BinaryInterchange
