/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.Codebook.Configured.Conversion.Runtime
public import LeanFloat.Floats.ExecFloat.Conversion.Runtime

/-!
# Proof contract for configured codebook decoding

A configured codebook installs the generic `ExactDecoder` interface used by format-independent
algorithms. This bridge records that the installed operation is exactly the codebook's public
table lookup; the proof is definitional by design.
-/

@[expose] public section

namespace LeanFloat.Floats

namespace ExecFloat.Codebook
namespace Conversion

universe u

variable {width : Nat} {α : Type u} {book : Formats.Codebook width α}

/-- The installed source capability is definitionally the codebook's public decoder. -/
@[simp, grind =] theorem exactDecoder_run (value : ExecFloat.Codebook book) :
    LeanFloat.Floats.ExecFloat.ExactDecoder.run value =
      ExecFloat.Codebook.decode value :=
  rfl

end Conversion
end ExecFloat.Codebook
end LeanFloat.Floats
