/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Conversion.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Model.ExactNumericalSystem
public import LeanFloat.Floats.Formats.BinaryInterchange.StaticByte.Core.Runtime

/-!
# Static-byte exact conversion runtime

This module implements exact decoding through `SignedRat`, explicit-policy quantization, and the
conversion specification for every nominal family backed by `StaticByte.Family`.

This adapter covers OCP FP8 and MX element formats, ONNX finite-only formats, and future
at-most-eight-bit binary-interchange families without format-specific conversion instances.
Arithmetic tables remain an execution concern and are not used by conversion. Typeclass
installation lives in `Conversion.Instances`; correctness equations live in `Conversion.Proof`.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.StaticByte
namespace Conversion

open LeanFloat.Numerics

universe u

variable {F : Type u} [Family F]

/-- Decode a static-byte value into the signed-rational domain, keeping the sign of zero. -/
@[inline] def decode (value : LeanFloat.Floats.ExecFloat F) : NumericalValue SignedRat :=
  ((Model.exactNumericalSystem (Family.format (F := F))).denote (toModel value)).map
    SignedRat.ofDyadic

/-- Pack a rounded binary model into the nominal family's direct byte carrier. -/
@[always_inline, inline] def pack
    (value : ModelValue (Family.format (F := F))) :
    LeanFloat.Floats.ExecFloat F :=
  ofModel value

/-- Quantize one finite signed rational into the nominal static-byte destination. -/
@[inline] def quantizeFinite
    (context : LeanFloat.Floats.ExecFloat.Binary.Conversion.Context) (exact : SignedRat) :
    LeanFloat.Floats.ExecFloat.ConversionOutcome (LeanFloat.Floats.ExecFloat F) :=
  LeanFloat.Floats.ExecFloat.Binary.Conversion.quantizeFiniteWith pack context exact

/-- Apply the explicit infinity policy to a nominal static-byte destination. -/
@[inline] def quantizeInfinity
    (context : LeanFloat.Floats.ExecFloat.Binary.Conversion.Context) (negative : Bool) :
    LeanFloat.Floats.ExecFloat.ConversionOutcome (LeanFloat.Floats.ExecFloat F) :=
  LeanFloat.Floats.ExecFloat.Binary.Conversion.quantizeInfinityWith pack context negative

/-- Apply the explicit exceptional-value policy to a nominal static-byte destination. -/
@[inline] def quantizeExceptional
    (context : LeanFloat.Floats.ExecFloat.Binary.Conversion.Context)
    (exceptional : ExceptionalValue) :
    LeanFloat.Floats.ExecFloat.ConversionOutcome (LeanFloat.Floats.ExecFloat F) :=
  LeanFloat.Floats.ExecFloat.Binary.Conversion.quantizeExceptionalWith
    pack context exceptional

/-- Reference conversion for every complete exact observation. -/
@[inline] def run
    (context : LeanFloat.Floats.ExecFloat.Binary.Conversion.Context) :
    NumericalValue SignedRat →
      LeanFloat.Floats.ExecFloat.ConversionOutcome (LeanFloat.Floats.ExecFloat F) :=
  LeanFloat.Floats.ExecFloat.Binary.Conversion.runWith pack context

/-- Retained singleton relation for static-byte binary conversion. -/
def spec :
    Quantization.Spec LeanFloat.Floats.ExecFloat.Binary.Conversion.Context
      (NumericalValue SignedRat)
      (LeanFloat.Floats.ExecFloat.ConversionOutcome (LeanFloat.Floats.ExecFloat F)) :=
  LeanFloat.Floats.ExecFloat.Binary.Conversion.specWith pack

/-- Every nominal static-byte binary source decodes exactly through `SignedRat`. -/
instance exactDecoder :
    LeanFloat.Floats.ExecFloat.ExactDecoder (LeanFloat.Floats.ExecFloat F) SignedRat where
  decode := decode

end Conversion
end LeanFloat.Floats.Formats.BinaryInterchange.StaticByte
