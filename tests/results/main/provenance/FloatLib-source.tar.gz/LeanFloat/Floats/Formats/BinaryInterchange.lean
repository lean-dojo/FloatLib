/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module -- shake: keep-all

public import LeanFloat.Floats.Formats.BinaryInterchange.Model.Carrier
public import LeanFloat.Floats.Formats.BinaryInterchange.Model.Lean
public import LeanFloat.Floats.Formats.BinaryInterchange.Dyadic.Rational
public import LeanFloat.Floats.Formats.BinaryInterchange.Model.ExactValue
public import LeanFloat.Floats.Formats.BinaryInterchange.Arithmetic.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Rounding.Mode
public import LeanFloat.Floats.Formats.BinaryInterchange.Rounding.Directed.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Status.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Conversion.Cast.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Reduction.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.MixedPrecision.Accumulation
public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.MixedPrecision.Matmul
public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.Compare.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Interval.Activations
public import LeanFloat.Floats.Formats.BinaryInterchange.Model.Instances
public import LeanFloat.Floats.Formats.BinaryInterchange.Format.Catalog
public import LeanFloat.Floats.Formats.BinaryInterchange.Arithmetic.Proof
public import LeanFloat.Floats.Formats.BinaryInterchange.Semantics
public import LeanFloat.Floats.Formats.BinaryInterchange.Proof.Finite
public import LeanFloat.Floats.Formats.BinaryInterchange.Automation
public import LeanFloat.Floats.Formats.BinaryInterchange.Automation.Finite
public import LeanFloat.Floats.Formats.BinaryInterchange.Complex.Automation
public meta import LeanFloat.Floats.Formats.BinaryInterchange.Complex.Info
public import LeanFloat.Floats.Formats.BinaryInterchange.DType.Cast
public import LeanFloat.Floats.Formats.BinaryInterchange.Descriptor.Backends
public import LeanFloat.Floats.Formats.BinaryInterchange.Descriptor.Plan.Instances
public import LeanFloat.Floats.Formats.BinaryInterchange.Conversion
public import LeanFloat.Floats.Formats.BinaryInterchange.Configured
public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Conversion.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Conversion.Proof
public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Conversion.Instances
public import LeanFloat.Floats.Formats.BinaryInterchange.DType.Semantics
public import LeanFloat.Floats.Formats.BinaryInterchange.Reduction
public import LeanFloat.Floats.Formats.BinaryInterchange.StaticByte
public import LeanFloat.Floats.Formats.BinaryInterchange.Interval
public import LeanFloat.Floats.Formats.BinaryInterchange.Rounding.Policy.Agreement
public meta import LeanFloat.Floats.Formats.BinaryInterchange.Info.Profile
public meta import LeanFloat.Floats.Formats.BinaryInterchange.Info.Command

/-!
# Binary-interchange formats

Descriptors for sign/exponent/fraction encodings, with exact decoding, directed and status-bearing
arithmetic, software backends, and refinement proofs. The descriptors cover IEEE layouts and
finite-only exceptional-value policies.

`Configured` supplies the `ExecFloat.Binary` API. The descriptor-level `Model` supports bit-level
and mathematical proofs. Scalar conversions and finite reductions are included; reductions
accumulate the exact sum or dot product and round the final result once.

## References

* IEEE Standard for Floating-Point Arithmetic, IEEE 754-2019,
  <https://doi.org/10.1109/IEEESTD.2019.8766229>.
* Open Compute Project, *8-bit Floating Point Specification*, revision 1.0,
  <https://www.opencompute.org/documents/ocp-8-bit-floating-point-specification-ofp8-revision-1-0-2023-12-01-pdf-1>.

## Runtime

Public runtime entry point for the generic kernel (`Model fmt`): layout, all four IEEE rounding modes,
exception status, dyadic/rational rounding, arithmetic, comparisons, format casts,
outward-rounded intervals, mixed-precision `mulAcc` / `dotSequential` / `matmul`, and
standard numeric instances.

Elementary functions (`exp`, `log`, `sin`, ...) and `Model.pow` are not on this import.
Import `LeanFloat.Floats.Formats.BinaryInterchange.Configured.Transcendentals` (or the
model barrel `BinaryInterchange.Transcendentals`) by name to install `Model.exp`,
`Model.pow`, and `MathFunctions`. That is a named import for unproved software kernels, not
the host-FPU path. Certified `sqrt` and `abs` stay on this import; only their
`MathFunctions` names move with the opt-in.

Import `LeanFloat.Floats.ExecFloat` for the universal capability API, or this module directly for
descriptor-model execution. Import `LeanFloat.Floats.Formats.BinaryInterchange.Semantics` for the
descriptor model's real-refinement theorems.
-/

@[expose] public section
