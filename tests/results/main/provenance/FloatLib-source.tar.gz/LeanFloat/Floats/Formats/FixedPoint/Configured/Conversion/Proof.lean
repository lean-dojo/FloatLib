/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.FixedPoint.Configured.Conversion.Runtime
public import LeanFloat.Floats.ExecFloat.Conversion.Runtime

/-!
# Exact fixed-point conversion proofs

This module proves the observable reduction equations and the declared singleton quantization
contract for unbounded configured fixed point.
-/

@[expose] public section

namespace LeanFloat.Floats

open LeanFloat.Numerics

namespace ExecFloat.FixedPoint
namespace Conversion

variable {radix : Radix} {fractionalDigits : Nat}

/-- Finite rationals are rounded once to the destination's fixed grid. -/
@[simp, grind =] theorem run_finite (exact : Rat) :
    run (radix := radix) (fractionalDigits := fractionalDigits)
        () (.finite exact) =
      let rounded : ExecFloat.FixedPoint radix fractionalDigits :=
        ExecFloat.FixedPoint.roundRat exact
      .success rounded
        { inexact := ExecFloat.FixedPoint.toRat rounded != exact } :=
  rfl

/-- The executable converter implements its declared singleton relation. -/
theorem implements_run :
    Quantization.Spec.Implements
      (spec (radix := radix) (fractionalDigits := fractionalDigits))
      (run (radix := radix) (fractionalDigits := fractionalDigits)) :=
  Quantization.Spec.implements_ofFunction run

/-- The installed decoder exposes the exact stored rational. -/
@[simp, grind =] theorem exactDecoder_run
    (value : ExecFloat.FixedPoint radix fractionalDigits) :
    LeanFloat.Floats.ExecFloat.ExactDecoder.run value =
      .finite (ExecFloat.FixedPoint.toRat value) :=
  rfl

/-- Infinity is rejected because an exact fixed-point grid has no infinite code. -/
@[simp, grind =] theorem run_infinity (negative : Bool) :
    run (radix := radix) (fractionalDigits := fractionalDigits)
        () (.infinity negative) =
      .failure (.infinity .source negative) :=
  rfl

/-- Exceptional observations are rejected because exact fixed point has no reserved code. -/
@[simp, grind =] theorem run_exceptional (exceptional : ExceptionalValue) :
    run (radix := radix) (fractionalDigits := fractionalDigits)
        () (.exceptional exceptional) =
      .failure (.exceptional .source exceptional) :=
  rfl

end Conversion
end ExecFloat.FixedPoint
end LeanFloat.Floats
