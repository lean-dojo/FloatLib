/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.Flocq.Theory.Core
public import LeanFloat.Numerics.Core.Proof

/-!
# Radix-parametric floats as numerical systems

`FloatRep β` is not restricted to base two: `β` may be the supplied decimal radix or any radix
at least two.  This adapter demonstrates that the general interface is independent of binary bit
layouts while retaining the existing Flocq-style interpretation `m * β^e`.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.Flocq.FloatRep

open LeanFloat.Numerics

/-- Real semantics of an integer-mantissa, integer-exponent float at arbitrary radix. -/
noncomputable def numericalSystem (β : Numerics.Radix) : NumericalSystem where
  Code := FloatRep β
  Scalar := ℝ
  denote x := .finite (toReal x)

/-- An integer-mantissa float with an erased proof of its complete real denotation. -/
abbrev At (β : Numerics.Radix) (value : NumericalValue ℝ) :=
  (numericalSystem β).At value

/-- An integer-mantissa float with an erased proof of its finite real value. -/
abbrev AtFinite (β : Numerics.Radix) (value : ℝ) :=
  (numericalSystem β).AtFinite value

/-- Representation in the generic numerical-system interface is equality of real denotations. -/
@[simp] theorem numericalSystem_represents_iff {β : Numerics.Radix} (x : FloatRep β) (r : ℝ) :
    (numericalSystem β).Represents x r ↔ toReal x = r := by
  simp [NumericalSystem.Represents, numericalSystem]

end LeanFloat.Floats.Formats.Flocq.FloatRep
