/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Plan.Automatic
public import LeanFloat.Floats.ExecFloat.Core.Capability

/-!
# Capability instances for configured binary formats

Representation-independent instances serve custom carriers. Higher-priority instances for
`Configured.Code` expose byte tables after dependent elimination of the selected storage plan, and
give the machine-word plans and the two-word wide formats a first-order entry point so public
arithmetic on a closed `ExecFloat.Binary` type compiles to one direct call into a kernel
specialized to its descriptor.

The priorities encode capability preference, not numerical semantics: every candidate must supply
the same refinement contract before it can be selected. Keeping this wiring in one module makes
backend choice inspectable and prevents storage-specific instances from leaking through the rest
of the configured API.
-/

@[expose] public section
namespace LeanFloat.Floats.Formats.BinaryInterchange.Configured

instance (priority := 100) addCapability
    (format : FloatFormat) (plan : StoragePlan format) (code : Type)
    [LeanFloat.Floats.ExecFloat.ModelCodec plan (Model format) code]
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor (Family format code plan)] :
    LeanFloat.Floats.ExecFloat.Add (Family format code plan) where
  spec := Spec.add
  candidates := Plan.addCandidates format plan

instance (priority := 100) subCapability
    (format : FloatFormat) (plan : StoragePlan format) (code : Type)
    [LeanFloat.Floats.ExecFloat.ModelCodec plan (Model format) code]
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor (Family format code plan)] :
    LeanFloat.Floats.ExecFloat.Sub (Family format code plan) where
  spec := Spec.sub
  candidates := Plan.subCandidates format plan

instance (priority := 100) mulCapability
    (format : FloatFormat) (plan : StoragePlan format) (code : Type)
    [LeanFloat.Floats.ExecFloat.ModelCodec plan (Model format) code]
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor (Family format code plan)] :
    LeanFloat.Floats.ExecFloat.Mul (Family format code plan) where
  spec := Spec.mul
  candidates := Plan.mulCandidates format plan

instance (priority := 100) divCapability
    (format : FloatFormat) (plan : StoragePlan format) (code : Type)
    [LeanFloat.Floats.ExecFloat.ModelCodec plan (Model format) code]
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor (Family format code plan)] :
    LeanFloat.Floats.ExecFloat.Div (Family format code plan) where
  spec := Spec.div
  candidates := Plan.divCandidates format plan

instance (priority := 100) sqrtCapability
    (format : FloatFormat) (plan : StoragePlan format) (code : Type)
    [LeanFloat.Floats.ExecFloat.ModelCodec plan (Model format) code]
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor (Family format code plan)] :
    LeanFloat.Floats.ExecFloat.Sqrt (Family format code plan) where
  spec := Spec.sqrt
  candidates := Plan.sqrtCandidates format plan

instance (priority := 100) fmaCapability
    (format : FloatFormat) (plan : StoragePlan format) (code : Type)
    [LeanFloat.Floats.ExecFloat.ModelCodec plan (Model format) code]
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor (Family format code plan)] :
    LeanFloat.Floats.ExecFloat.Fma (Family format code plan) where
  spec := Spec.fma
  candidates := Plan.fmaCandidates format plan

/-!
Higher-priority built-in-carrier instances match `Code plan` before inspecting the plan. This
works for every statically computed precision, including a `forKnownWidth` expression that has not
yet reduced to a storage constructor during typeclass indexing. The dependent candidate helpers
then add direct byte tables exactly when the selected plan is `.byte`.

Families with a custom carrier continue to use the representation-independent instances above.
-/

/-!
Closed plan witnesses for the binary32 and binary64 IEEE interchange layouts.

The public `ExecFloat.Binary` module attaches first-order operation instances to its own
parameterized family. Keeping only the plan witnesses here avoids a second nominal capability
surface while still sharing the carrier computation and certified candidate portfolio.
-/
/-- Built-in packed-storage plan for IEEE binary32. -/
abbrev binary32Plan : StoragePlan FloatFormat.binary32 :=
  StoragePlan.forKnownWidth FloatFormat.binary32 32 rfl

/-- Built-in packed-storage plan for IEEE binary64. -/
abbrev binary64Plan : StoragePlan FloatFormat.binary64 :=
  StoragePlan.forKnownWidth FloatFormat.binary64 64 rfl

/-!
## First-order entry points

Each instance below also names a first-order entry point. For a plan whose
`StoragePlan.firstOrderDispatch` holds, `execute` is the structural dispatcher itself, which is
total and proved equal to the specification, so a monomorphic caller compiles to one direct call
into a copy of the dispatcher specialized to its descriptor instead of projecting a memoized
certificate closure and applying it to boxed operands. For every other plan `execute` runs the
memoized planner selection, exactly as the representation-independent instances do.
`implementation` is the planner's selection in both cases, and the refinement equation between the
two rests on both being equal to the specification.

The decision is a Boolean function of the plan and the descriptor, evaluated inside the `execute`
lambda rather than by a `match` around the whole record. The compiler reduces a projection of an
instance only through straight-line code, and it does so before it specializes kernels; a `match`
at the top of the instance would postpone inlining until after specialization, and the two-word
kernels would then be called with an open descriptor. With a closed type the decision folds at the
use site and only the selected branch remains.

The machine-word plans use `Backend.wordAdd` and its siblings; the wide plan uses them exactly
when the descriptor satisfies `Model.NativePair.Eligible`, that is for binary128 and every other
layout of at most 128 bits whose fraction is wider than one word, so the two-word kernels and the
width-generic finite fallback they share are specialized to the descriptor and every layout constant
becomes a compile-time constant. Square root and fused multiply-add name
`Backend.fixedLimbSqrt` and `Backend.fixedLimbFma`, the dispatchers whose two-word branch the
planner selects for these formats and which fold to the word kernels for the machine-word plans.

The byte plan keeps the memoized planner selection because its table candidate must be constructed
once and shared. Wide formats above 128 bits and the limb plan keep it because their kernels enter
through the planner as certified candidates and must be what `execute` runs.
-/

/--
Whether the structural dispatcher is the first-order entry point of a storage plan.

The machine-word plans always route through it. The wide plan routes through it exactly when the
descriptor is pair-eligible, so the two-word kernels are reached by a monomorphic call. The byte
plan and the limb plan are excluded because their tables and limb kernels operate on the carrier
itself and enter through the planner as certified candidates.
-/
@[inline] def StoragePlan.firstOrderDispatch {format : FloatFormat} : StoragePlan format → Bool
  | .word16 _ | .word32 _ | .word64 _ => true
  | .wide => decide (Model.NativePair.Eligible format)
  | .byte _ | .limbs _ => false

@[always_inline] instance (priority := 200) automaticAddCapability
    (format : FloatFormat) (plan : StoragePlan format)
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor
      (Family format (Code plan) plan)] :
    LeanFloat.Floats.ExecFloat.Add (Family format (Code plan) plan) :=
  let selection := Thunk.mk fun _ =>
    LeanFloat.Floats.ExecFloat.Backend.selectCertified planning.policy
      (Plan.automaticAddCandidates format plan)
  { spec := Spec.add
    candidates := Plan.automaticAddCandidates format plan
    selection := selection
    execute := fun left right =>
      if plan.firstOrderDispatch then Backend.wordAdd left right else selection.get.run left right
    execute_eq_implementation := by
      funext left right
      split
      · have h :=
          (LeanFloat.Floats.ExecFloat.Backend.selectCertified_run_eq_spec planning.policy
            (Plan.automaticAddCandidates format plan)).symm
        exact (Backend.wordAdd_eq_spec left right).trans (congrFun (congrFun h left) right)
      · rfl }

@[always_inline] instance (priority := 200) automaticSubCapability
    (format : FloatFormat) (plan : StoragePlan format)
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor
      (Family format (Code plan) plan)] :
    LeanFloat.Floats.ExecFloat.Sub (Family format (Code plan) plan) :=
  let selection := Thunk.mk fun _ =>
    LeanFloat.Floats.ExecFloat.Backend.selectCertified planning.policy
      (Plan.automaticSubCandidates format plan)
  { spec := Spec.sub
    candidates := Plan.automaticSubCandidates format plan
    selection := selection
    execute := fun left right =>
      if plan.firstOrderDispatch then Backend.wordSub left right else selection.get.run left right
    execute_eq_implementation := by
      funext left right
      split
      · have h :=
          (LeanFloat.Floats.ExecFloat.Backend.selectCertified_run_eq_spec planning.policy
            (Plan.automaticSubCandidates format plan)).symm
        exact (Backend.wordSub_eq_spec left right).trans (congrFun (congrFun h left) right)
      · rfl }

@[always_inline] instance (priority := 200) automaticMulCapability
    (format : FloatFormat) (plan : StoragePlan format)
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor
      (Family format (Code plan) plan)] :
    LeanFloat.Floats.ExecFloat.Mul (Family format (Code plan) plan) :=
  let selection := Thunk.mk fun _ =>
    LeanFloat.Floats.ExecFloat.Backend.selectCertified planning.policy
      (Plan.automaticMulCandidates format plan)
  { spec := Spec.mul
    candidates := Plan.automaticMulCandidates format plan
    selection := selection
    execute := fun left right =>
      if plan.firstOrderDispatch then Backend.wordMul left right else selection.get.run left right
    execute_eq_implementation := by
      funext left right
      split
      · have h :=
          (LeanFloat.Floats.ExecFloat.Backend.selectCertified_run_eq_spec planning.policy
            (Plan.automaticMulCandidates format plan)).symm
        exact (Backend.wordMul_eq_spec left right).trans (congrFun (congrFun h left) right)
      · rfl }

@[always_inline] instance (priority := 200) automaticDivCapability
    (format : FloatFormat) (plan : StoragePlan format)
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor
      (Family format (Code plan) plan)] :
    LeanFloat.Floats.ExecFloat.Div (Family format (Code plan) plan) :=
  let selection := Thunk.mk fun _ =>
    LeanFloat.Floats.ExecFloat.Backend.selectCertified planning.policy
      (Plan.automaticDivCandidates format plan)
  { spec := Spec.div
    candidates := Plan.automaticDivCandidates format plan
    selection := selection
    execute := fun left right =>
      if plan.firstOrderDispatch then Backend.wordDiv left right else selection.get.run left right
    execute_eq_implementation := by
      funext left right
      split
      · have h :=
          (LeanFloat.Floats.ExecFloat.Backend.selectCertified_run_eq_spec planning.policy
            (Plan.automaticDivCandidates format plan)).symm
        exact (Backend.wordDiv_eq_spec left right).trans (congrFun (congrFun h left) right)
      · rfl }

@[always_inline] instance (priority := 200) automaticSqrtCapability
    (format : FloatFormat) (plan : StoragePlan format)
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor
      (Family format (Code plan) plan)] :
    LeanFloat.Floats.ExecFloat.Sqrt (Family format (Code plan) plan) :=
  let selection := Thunk.mk fun _ =>
    LeanFloat.Floats.ExecFloat.Backend.selectCertified planning.policy
      (Plan.automaticSqrtCandidates format plan)
  { spec := Spec.sqrt
    candidates := Plan.automaticSqrtCandidates format plan
    selection := selection
    execute := fun value =>
      if plan.firstOrderDispatch then Backend.fixedLimbSqrt value else selection.get.run value
    execute_eq_implementation := by
      funext value
      split
      · have h :=
          (LeanFloat.Floats.ExecFloat.Backend.selectCertified_run_eq_spec planning.policy
            (Plan.automaticSqrtCandidates format plan)).symm
        exact (Backend.fixedLimbSqrt_eq_spec value).trans (congrFun h value)
      · rfl }

@[always_inline] instance (priority := 200) automaticFmaCapability
    (format : FloatFormat) (plan : StoragePlan format)
    [planning : LeanFloat.Floats.ExecFloat.Backend.PolicyFor
      (Family format (Code plan) plan)] :
    LeanFloat.Floats.ExecFloat.Fma (Family format (Code plan) plan) :=
  let selection := Thunk.mk fun _ =>
    LeanFloat.Floats.ExecFloat.Backend.selectCertified planning.policy
      (Plan.automaticFmaCandidates format plan)
  { spec := Spec.fma
    candidates := Plan.automaticFmaCandidates format plan
    selection := selection
    execute := fun left right addend =>
      if plan.firstOrderDispatch then
        Backend.fixedLimbFma left right addend
      else
        selection.get.run left right addend
    execute_eq_implementation := by
      funext left right addend
      split
      · have h :=
          (LeanFloat.Floats.ExecFloat.Backend.selectCertified_run_eq_spec planning.policy
            (Plan.automaticFmaCandidates format plan)).symm
        exact (Backend.fixedLimbFma_eq_spec left right addend).trans
          (congrFun (congrFun (congrFun h left) right) addend)
      · rfl }

end LeanFloat.Floats.Formats.BinaryInterchange.Configured
