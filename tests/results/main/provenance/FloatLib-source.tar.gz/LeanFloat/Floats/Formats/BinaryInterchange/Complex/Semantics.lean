/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Complex.Core
public import LeanFloat.Floats.Formats.BinaryInterchange.Arithmetic.SignedSemantics.Subtraction
public import Mathlib.Data.Complex.Basic

/-!
# Real and complex semantics of `ExecComplex`

The component map `toComplex` embeds finite executable values into mathematical complex numbers.
Addition and subtraction round each component once. Multiplication records all six rounding sites:
four scalar products, the subtraction forming the real component, and the addition forming the
imaginary component. The resulting theorem describes the program that actually runs rather than
silently identifying it with exact complex multiplication.

The finiteness assumptions rule out overflow to infinity and NaN. They are explicit because the
real-number semantics intentionally does not assign real values to IEEE special encodings.

## Reference

- N. J. Higham, *Accuracy and Stability of Numerical Algorithms*, second edition, SIAM, 2002,
  Section 3.6. https://doi.org/10.1137/1.9780898718027
- IEEE Standard for Floating-Point Arithmetic, IEEE 754-2019.
  https://doi.org/10.1109/IEEESTD.2019.8766229
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace ExecComplex

noncomputable section

/-- Interpret both finite components as real numbers and assemble a mathematical complex value. -/
noncomputable def toComplex {fmt : FloatFormat} (z : ExecComplex fmt) : ℂ :=
  ⟨Model.toReal z.re, Model.toReal z.im⟩

/-- Componentwise nearest-even semantics for complex addition. -/
noncomputable def roundedAdd (fmt : FloatFormat) (x y : ℂ) : ℂ :=
  ⟨Model.roundAt fmt (x.re + y.re), Model.roundAt fmt (x.im + y.im)⟩

/-- Componentwise nearest-even semantics for complex subtraction. -/
noncomputable def roundedSub (fmt : FloatFormat) (x y : ℂ) : ℂ :=
  ⟨Model.roundAt fmt (x.re - y.re), Model.roundAt fmt (x.im - y.im)⟩

/--
The rounded real semantics of the evaluation order used by `ExecComplex.mul`.

This is not exact complex multiplication: each product is rounded before the final rounded
subtraction or addition.
-/
noncomputable def roundedMul (fmt : FloatFormat) (x y : ℂ) : ℂ :=
  ⟨Model.roundAt fmt
      (Model.roundAt fmt (x.re * y.re) - Model.roundAt fmt (x.im * y.im)),
    Model.roundAt fmt
      (Model.roundAt fmt (x.re * y.im) + Model.roundAt fmt (x.im * y.re))⟩

/-- Negation of finite executable components agrees exactly with complex negation. -/
theorem toComplex_neg {fmt : FloatFormat} (z : ExecComplex fmt)
    (hz : isFinite z = true) :
    toComplex (-z) = -toComplex z := by
  obtain ⟨hzre, hzim⟩ := (isFinite_eq_true_iff z).1 hz
  apply Complex.ext
  · exact Model.toReal_neg z.re hzre
  · exact Model.toReal_neg z.im hzim

/-- Complex conjugation is exact on finite components because it changes only one sign bit. -/
theorem toComplex_conj {fmt : FloatFormat} (z : ExecComplex fmt)
    (hz : isFinite z = true) :
    toComplex (conj z) = starRingEnd ℂ (toComplex z) := by
  obtain ⟨_, hzim⟩ := (isFinite_eq_true_iff z).1 hz
  apply Complex.ext
  · rfl
  · exact Model.toReal_neg z.im hzim

/-- Executable complex addition refines componentwise rounded mathematical addition. -/
theorem toComplex_add_eq_roundedAdd {fmt : FloatFormat} (x y : ExecComplex fmt)
    (hfmt : fmt.isIEEE = true)
    (hx : isFinite x = true) (hy : isFinite y = true)
    (hout : isFinite (x + y) = true) :
    toComplex (x + y) = roundedAdd fmt (toComplex x) (toComplex y) := by
  obtain ⟨hxre, hxim⟩ := (isFinite_eq_true_iff x).1 hx
  obtain ⟨hyre, hyim⟩ := (isFinite_eq_true_iff y).1 hy
  obtain ⟨hore, hoim⟩ := (isFinite_eq_true_iff (x + y)).1 hout
  apply Complex.ext
  · exact Model.toReal_add_eq_roundAt x.re y.re hfmt hxre hyre hore
  · exact Model.toReal_add_eq_roundAt x.im y.im hfmt hxim hyim hoim

/-- Executable complex subtraction refines componentwise rounded mathematical subtraction. -/
theorem toComplex_sub_eq_roundedSub {fmt : FloatFormat} (x y : ExecComplex fmt)
    (hfmt : fmt.isIEEE = true)
    (hx : isFinite x = true) (hy : isFinite y = true)
    (hout : isFinite (x - y) = true) :
    toComplex (x - y) = roundedSub fmt (toComplex x) (toComplex y) := by
  obtain ⟨hxre, hxim⟩ := (isFinite_eq_true_iff x).1 hx
  obtain ⟨hyre, hyim⟩ := (isFinite_eq_true_iff y).1 hy
  obtain ⟨hore, hoim⟩ := (isFinite_eq_true_iff (x - y)).1 hout
  apply Complex.ext
  · exact Model.toReal_sub_eq_roundAt x.re y.re hfmt hxre hyre hore
  · exact Model.toReal_sub_eq_roundAt x.im y.im hfmt hxim hyim hoim

/--
All scalar intermediates required to interpret one executable complex multiplication over `ℝ`.

The predicate includes finite inputs, four finite component products, and finite final components.
It is the natural domain of the exact evaluation-order refinement theorem below.
-/
def MulFinite {fmt : FloatFormat} (x y : ExecComplex fmt) : Prop :=
  isFinite x = true ∧
  isFinite y = true ∧
  Model.isFinite (Model.mul x.re y.re) = true ∧
  Model.isFinite (Model.mul x.im y.im) = true ∧
  Model.isFinite (Model.mul x.re y.im) = true ∧
  Model.isFinite (Model.mul x.im y.re) = true ∧
  isFinite (x * y) = true

/--
Executable complex multiplication agrees with its six-step rounded real semantics.

This theorem is format-generic and keeps every intermediate rounding visible. In particular, it
does not assert equality with exact multiplication in `ℂ`, which would be false in general.
-/
theorem toComplex_mul_eq_roundedMul {fmt : FloatFormat} (x y : ExecComplex fmt)
    (hfmt : fmt.isIEEE = true)
    (h : MulFinite x y) :
    toComplex (x * y) = roundedMul fmt (toComplex x) (toComplex y) := by
  rcases h with ⟨hx, hy, hac, hbd, had, hbc, hout⟩
  obtain ⟨hxre, hxim⟩ := (isFinite_eq_true_iff x).1 hx
  obtain ⟨hyre, hyim⟩ := (isFinite_eq_true_iff y).1 hy
  obtain ⟨hore, hoim⟩ := (isFinite_eq_true_iff (x * y)).1 hout
  apply Complex.ext
  · change
      Model.toReal (Model.sub (Model.mul x.re y.re) (Model.mul x.im y.im)) =
        Model.roundAt fmt
          (Model.roundAt fmt
              (Model.toReal x.re * Model.toReal y.re) -
            Model.roundAt fmt
              (Model.toReal x.im * Model.toReal y.im))
    rw [Model.toReal_sub_eq_roundAt _ _ hfmt hac hbd hore]
    rw [Model.toReal_mul_eq_roundAt x.re y.re hfmt hxre hyre hac]
    rw [Model.toReal_mul_eq_roundAt x.im y.im hfmt hxim hyim hbd]
  · change
      Model.toReal (Model.add (Model.mul x.re y.im) (Model.mul x.im y.re)) =
        Model.roundAt fmt
          (Model.roundAt fmt
              (Model.toReal x.re * Model.toReal y.im) +
            Model.roundAt fmt
              (Model.toReal x.im * Model.toReal y.re))
    rw [Model.toReal_add_eq_roundAt _ _ hfmt had hbc hoim]
    rw [Model.toReal_mul_eq_roundAt x.re y.im hfmt hxre hyim had]
    rw [Model.toReal_mul_eq_roundAt x.im y.re hfmt hxim hyre hbc]

end
end ExecComplex
end LeanFloat.Floats.Formats.BinaryInterchange
