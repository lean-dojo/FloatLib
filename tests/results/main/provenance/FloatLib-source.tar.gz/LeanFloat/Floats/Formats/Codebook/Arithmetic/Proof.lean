/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.Codebook.Arithmetic.Runtime
public import LeanFloat.Numerics.Operation.Semantics
public import Mathlib.Algebra.Group.Nat.Defs
public import Mathlib.Algebra.Ring.Int.Defs

/-!
# Correctness of catalog-codebook arithmetic

The proofs exhaust the finite stored words and show that the direct kernels refine integer
negation and multiplication. Reserved ternary words are handled by checked operations.

Exhaustion is appropriate here because a catalog codebook is itself finite data, not because the
library assumes a particular low-bit width. The generic statements are parameterized by the
declared table, and the checked boundary makes malformed or reserved encodings explicit instead of
assigning them an accidental arithmetic meaning.
-/

@[expose] public section

open LeanFloat.Numerics

namespace LeanFloat.Floats.Formats.Codebook

private theorem bitVec1_cases (x : BitVec 1) :
    x = BitVec.ofNat 1 0 ∨ x = BitVec.ofNat 1 1 := by
  revert x
  decide

private theorem bitVec2_cases (x : BitVec 2) :
    x = BitVec.ofNat 2 0 ∨ x = BitVec.ofNat 2 1 ∨
      x = BitVec.ofNat 2 2 ∨ x = BitVec.ofNat 2 3 := by
  revert x
  decide

namespace Catalog.bipolar1

/-- Bipolar negation exactly refines integer negation. -/
theorem neg_refines :
    Operation.Finite1 Catalog.bipolar1.numericalSystem
      Catalog.bipolar1.numericalSystem neg (fun x : ℤ => -x) := by
  intro code value hvalue
  rcases bitVec1_cases code with hcode | hcode <;> subst code
  all_goals
    simp [NumericalSystem.Represents, Codebook.numericalSystem,
      Catalog.bipolar1] at hvalue
  all_goals
    injection hvalue with hvalue
    subst value
    simp [NumericalSystem.Represents, Codebook.numericalSystem,
      Catalog.bipolar1, neg]

/-- Bipolar multiplication exactly refines integer multiplication. -/
theorem mul_refines :
    Operation.Finite2 Catalog.bipolar1.numericalSystem
      Catalog.bipolar1.numericalSystem Catalog.bipolar1.numericalSystem
      mul (fun x y : ℤ => x * y) := by
  intro left right x y hx hy
  rcases bitVec1_cases left with hleft | hleft <;> subst left <;>
    rcases bitVec1_cases right with hright | hright <;> subst right
  all_goals
    simp [NumericalSystem.Represents, Codebook.numericalSystem,
      Catalog.bipolar1] at hx hy
  all_goals
    injection hx with hx
    injection hy with hy
    subst x
    subst y
    simp [NumericalSystem.Represents, Codebook.numericalSystem,
      Catalog.bipolar1, mul]

end Catalog.bipolar1

namespace Catalog.ternary2

/-- Checked ternary negation exactly refines integer negation on finite inputs. -/
theorem neg_refines :
    Operation.Checked1 Catalog.ternary2.numericalSystem
      Catalog.ternary2.numericalSystem neg? (fun x : ℤ => .finite (-x)) := by
  intro code value hvalue
  rcases bitVec2_cases code with hcode | hcode | hcode | hcode <;> subst code
  all_goals
    simp [NumericalSystem.Represents, Codebook.numericalSystem,
      Catalog.ternary2] at hvalue
  all_goals
    injection hvalue with hvalue
    subst value
    simp [Codebook.Code, Codebook.numericalSystem, Catalog.ternary2, neg?]

/-- Checked ternary multiplication exactly refines integer multiplication on finite inputs. -/
theorem mul_refines :
    Operation.Checked2 Catalog.ternary2.numericalSystem
      Catalog.ternary2.numericalSystem Catalog.ternary2.numericalSystem
      mul? (fun x y : ℤ => .finite (x * y)) := by
  intro left right x y hx hy
  rcases bitVec2_cases left with hleft | hleft | hleft | hleft <;> subst left <;>
    rcases bitVec2_cases right with hright | hright | hright | hright <;> subst right
  all_goals
    simp [NumericalSystem.Represents, Codebook.numericalSystem,
      Catalog.ternary2] at hx hy
  all_goals
    injection hx with hx
    injection hy with hy
    subst x
    subst y
    simp [Codebook.Code, Codebook.numericalSystem, Catalog.ternary2, mul?]

end Catalog.ternary2

end LeanFloat.Floats.Formats.Codebook
