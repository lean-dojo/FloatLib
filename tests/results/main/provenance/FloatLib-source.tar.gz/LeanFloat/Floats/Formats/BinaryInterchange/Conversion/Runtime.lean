/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Rounding.Policy.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Status.Runtime
public import LeanFloat.Floats.ExecFloat.Conversion.Core
public import LeanFloat.Numerics.Exact.SignedRat

/-!
# Binary-interchange conversion runtime

This module contains the representation-independent conversion policy for every
binary-interchange family. A concrete carrier supplies only a `pack` function from its
`Model format`; configured machine-word formats and nominal static-byte formats therefore share
one exact quantizer.

The exact domain is `SignedRat`, so the sign of a zero input reaches the destination. Finite values
are rounded once by `Model.Policy.roundRat`, with the sign bit taken from the signed rational and
the magnitude from its value. Infinity and exceptional observations use separate explicit policies
because finite-only formats cannot preserve every IEEE value class. Status flags are computed from
exact rational comparisons, never through a host floating-point value.

`specWith pack` is the graph of `runWith pack`: the relation permits exactly the value the
executable rounder returns. The mathematical meaning of that rounder is supplied by the
`Model.Policy.roundRat*` theorems in `Rounding/Policy/Proof.lean`, and by `Model.roundRat`'s
descriptor semantics; the conversion layer adds only the packing and the explicit policies.
-/

@[expose] public section

namespace LeanFloat.Floats

open LeanFloat.Numerics
open LeanFloat.Floats.Formats.BinaryInterchange

namespace ExecFloat.Binary
namespace Conversion

universe u

/-- Policy for an infinity presented to a binary-interchange destination. -/
inductive InfinityPolicy where
  /-- Preserve infinity when the destination encoding supports it; otherwise reject the cast. -/
  | preserve
  /-- Clamp infinity to the signed largest finite destination value. -/
  | saturate
  /-- Reject infinity even when the destination could represent it. -/
  | reject
  deriving DecidableEq, Repr

/-- Policy for NaN, NaR, reserved, or undefined observations. -/
inductive ExceptionalPolicy where
  /-- Produce the destination's canonical NaN when one exists. -/
  | canonicalNaN
  /-- Reject every exceptional observation. -/
  | reject
  deriving DecidableEq, Repr

/-- Complete explicit context for conversion into a binary-interchange destination. -/
structure Context where
  /-- Finite rounding, overflow, and underflow behavior. -/
  quantization : QuantizationPolicy := .nearestEven
  /-- Entropy consumed only by stochastic finite rounding. -/
  entropy : Nat := 0
  /-- Treatment of source infinity. -/
  infinity : InfinityPolicy := .preserve
  /-- Treatment of source exceptional values. -/
  exceptional : ExceptionalPolicy := .canonicalNaN
  deriving DecidableEq, Repr

/--
Canonical binary conversion context.

Finite values use nearest-even/native-overflow/gradual-underflow behavior. Infinities and
exceptional values retain their value class when the destination encoding supports that class;
otherwise conversion fails explicitly.
-/
def Context.default : Context := {}

namespace Context

/--
Canonical conversion context with one caller-selected finite rounding direction.

Native overflow, gradual underflow, infinity preservation, and canonical-NaN mapping retain their
default behavior. Use a record update when any of those policies must also change.
-/
@[inline] def withRounding (rounding : RoundingMode) : Context :=
  { quantization := { rounding } }

end Context

/-- Truthful family-independent status derived from exact rational binary rounding. -/
@[inline] def finiteStatus {format : FloatFormat}
    (context : Context) (exact : Rat) (rounded : Model format) :
    LeanFloat.Floats.ExecFloat.ConversionStatus :=
  let numerator := exact.num.natAbs
  let denominator := exact.den
  let overflow := Model.rationalMagnitudeOverflows format numerator denominator
  let inexact := Model.toRat? rounded != some exact
  { inexact
    overflow
    underflow := Model.isTinyAfterRounding rounded && inexact
    saturated := overflow && context.quantization.overflow == .saturate }

/--
Round one finite signed rational and pack the resulting binary model into a destination carrier.

The sign bit of the result comes from `exact.negative`, so a negative zero rounds to the
destination's negative zero when the encoding has one. `pack` is the only representation-specific
argument. It is deliberately applied after exact rounding, so changing storage or an execution
backend cannot change numerical meaning.
-/
@[inline] def quantizeFiniteWith {format : FloatFormat} {Destination : Type u}
    (pack : Model format → Destination) (context : Context) (exact : SignedRat) :
    LeanFloat.Floats.ExecFloat.ConversionOutcome Destination :=
  match Model.Policy.roundRat format context.quantization context.entropy
      exact.negative exact.value.num.natAbs exact.value.den with
  | some rounded =>
      .success (pack rounded) (finiteStatus context exact.value rounded)
  | none =>
      .failure .unsupportedPolicy

/-- Apply the exceptional-value policy and pack a supported canonical NaN. -/
@[inline] def quantizeExceptionalWith {format : FloatFormat} {Destination : Type u}
    (pack : Model format → Destination) (context : Context)
    (exceptional : ExceptionalValue) :
    LeanFloat.Floats.ExecFloat.ConversionOutcome Destination :=
  match context.exceptional with
  | .reject =>
      .failure (.exceptional .source exceptional)
  | .canonicalNaN =>
      match Model.canonicalNaN? format with
      | some value =>
          .success (pack value) { mappedSpecial := true }
      | none =>
          .failure (.exceptional .source exceptional)

/-- Apply the infinity policy and pack the selected binary model value. -/
@[inline] def quantizeInfinityWith {format : FloatFormat} {Destination : Type u}
    (pack : Model format → Destination) (context : Context) (negative : Bool) :
    LeanFloat.Floats.ExecFloat.ConversionOutcome Destination :=
  match context.infinity with
  | .reject =>
      .failure (.infinity .source negative)
  | .saturate =>
      .success (pack (Model.maxFinite format negative))
        { inexact := true
          overflow := true
          saturated := true
          mappedSpecial := true }
  | .preserve =>
      match Model.infinity? format negative with
      | some value => .success (pack value)
      | none => .failure (.infinity .source negative)

/-- Reference conversion shared by every carrier for the same binary descriptor. -/
@[inline] def runWith {format : FloatFormat} {Destination : Type u}
    (pack : Model format → Destination) (context : Context) :
    NumericalValue SignedRat → LeanFloat.Floats.ExecFloat.ConversionOutcome Destination
  | .finite exact => quantizeFiniteWith pack context exact
  | .infinity negative => quantizeInfinityWith pack context negative
  | .exceptional exceptional => quantizeExceptionalWith pack context exceptional

/--
Retained singleton relation for a carrier adapter using `pack`.

This is the graph of `runWith pack`. Its content is the executable rounder; see the module
docstring for where that rounder's meaning is proved.
-/
def specWith {format : FloatFormat} {Destination : Type u}
    (pack : Model format → Destination) :
    Quantization.Spec Context (NumericalValue SignedRat)
      (LeanFloat.Floats.ExecFloat.ConversionOutcome Destination) :=
  Quantization.Spec.ofFunction (runWith pack)

end Conversion
end ExecFloat.Binary
end LeanFloat.Floats
