/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Rounding.Directed.Dyadic

/-!
# Executable normalization for directed dyadic rounding

These helpers move a positive mantissa to a requested leading-bit position. Downward
normalization discards low bits; upward normalization rounds them toward positive infinity.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model

/-- Floor a positive mantissa while moving its leading bit to `leadingBit`. -/
def roundMantissaToLeadingBitDown (mantissa leadingBit : Nat) : Nat :=
  if leadingBit ≤ mantissa.log2 then
    Nat.shiftRight mantissa (mantissa.log2 - leadingBit)
  else
    Nat.shiftLeft mantissa (leadingBit - mantissa.log2)

/-- Ceil a positive mantissa while moving its leading bit to `leadingBit`. -/
def roundMantissaToLeadingBitUp (mantissa leadingBit : Nat) : Nat :=
  if leadingBit ≤ mantissa.log2 then
    shiftRightCeilPow2 mantissa (mantissa.log2 - leadingBit)
  else
    Nat.shiftLeft mantissa (leadingBit - mantissa.log2)

end Model
end LeanFloat.Floats.Formats.BinaryInterchange
