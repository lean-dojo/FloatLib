/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Plan.Candidates
public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Storage.Codecs
public import LeanFloat.Floats.ExecFloat.Backends.WideLimb.Addition.Proof
public import LeanFloat.Floats.ExecFloat.Backends.WideLimb.Multiplication.Proof
public import LeanFloat.Floats.ExecFloat.Backends.WideLimb.Fma.Proof

/-!
# Certified wide-limb candidates for the limb carrier

Formats wider than 128 bits store their values as limb arrays (`StoragePlan.limbs`), the carrier
the wide-limb kernels operate on directly. This module wraps those kernels as `Backend.Certified`
candidates for addition, subtraction, multiplication, and fused multiply-add, each proved equal to
the configured reference operation through `Model.WideLimb.toModel_add` and its siblings together
with the codec laws. Division and square root have no wide-limb kernel and keep the structural
portfolio. A candidate is offered only when `Model.WideLimb.Eligible` holds, a decidable test on
the descriptor.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Configured.Plan

open LeanFloat.Floats.ExecFloat
open LeanFloat.Floats.ExecFloat.Backend

variable (format : FloatFormat) (width_gt : 128 < format.bitWidth)

/-- The direct wide-limb estimate: no carrier conversion, limb arithmetic only. -/
def wideLimbEstimate (operation : Operation) : Candidate :=
  { Descriptor.Plan.wideLimbEstimate format operation with marshallingCost := 0 }

/-- Certified wide-limb addition on the limb carrier. -/
def wideLimbAdd (h : Model.WideLimb.Eligible format) :
    Certified (@Spec.add format (.limbs width_gt) (Code (.limbs width_gt)) inferInstance) :=
  Certified.binary (wideLimbEstimate format .add) Spec.add
    (LeanFloat.Floats.ExecFloat.applyBinary (Model.WideLimb.add format))
    fun left right => by
      apply LeanFloat.Floats.ExecFloat.ext
      change Model.WideLimb.add format left.raw right.raw =
        Model.WideLimb.ofModel
          (Model.Spec.add (Model.WideLimb.toModel left.raw) (Model.WideLimb.toModel right.raw))
      rw [← Model.WideLimb.toModel_add h, Model.WideLimb.ofModel_toModel]

/-- Certified wide-limb subtraction on the limb carrier. -/
def wideLimbSub (h : Model.WideLimb.Eligible format) :
    Certified (@Spec.sub format (.limbs width_gt) (Code (.limbs width_gt)) inferInstance) :=
  Certified.binary (wideLimbEstimate format .sub) Spec.sub
    (LeanFloat.Floats.ExecFloat.applyBinary (Model.WideLimb.sub format))
    fun left right => by
      apply LeanFloat.Floats.ExecFloat.ext
      change Model.WideLimb.sub format left.raw right.raw =
        Model.WideLimb.ofModel
          (Model.Spec.sub (Model.WideLimb.toModel left.raw) (Model.WideLimb.toModel right.raw))
      rw [← Model.WideLimb.toModel_sub h, Model.WideLimb.ofModel_toModel]

/-- Certified wide-limb multiplication on the limb carrier. -/
def wideLimbMul (h : Model.WideLimb.Eligible format) :
    Certified (@Spec.mul format (.limbs width_gt) (Code (.limbs width_gt)) inferInstance) :=
  Certified.binary (wideLimbEstimate format .mul) Spec.mul
    (LeanFloat.Floats.ExecFloat.applyBinary (Model.WideLimb.mul format))
    fun left right => by
      apply LeanFloat.Floats.ExecFloat.ext
      change Model.WideLimb.mul format left.raw right.raw =
        Model.WideLimb.ofModel
          (Model.Spec.mul (Model.WideLimb.toModel left.raw) (Model.WideLimb.toModel right.raw))
      rw [← Model.WideLimb.toModel_mul h, Model.WideLimb.ofModel_toModel]

/-- Certified wide-limb fused multiply-add on the limb carrier. -/
def wideLimbFma (h : Model.WideLimb.Eligible format) :
    Certified (@Spec.fma format (.limbs width_gt) (Code (.limbs width_gt)) inferInstance) :=
  Certified.ternary (wideLimbEstimate format .fma) Spec.fma
    (LeanFloat.Floats.ExecFloat.applyTernary (Model.WideLimb.fma format))
    fun left right addend => by
      apply LeanFloat.Floats.ExecFloat.ext
      change Model.WideLimb.fma format left.raw right.raw addend.raw =
        Model.WideLimb.ofModel
          (Model.Spec.fma (Model.WideLimb.toModel left.raw) (Model.WideLimb.toModel right.raw)
            (Model.WideLimb.toModel addend.raw))
      rw [← Model.WideLimb.toModel_fma h, Model.WideLimb.ofModel_toModel]

/-- Offer wide-limb addition exactly when the descriptor is eligible. -/
def wideLimbAdd? :
    Option (Certified (@Spec.add format (.limbs width_gt) (Code (.limbs width_gt)) inferInstance)) :=
  if h : Model.WideLimb.Eligible format then some (wideLimbAdd format width_gt h) else none

/-- Offer wide-limb subtraction exactly when the descriptor is eligible. -/
def wideLimbSub? :
    Option (Certified (@Spec.sub format (.limbs width_gt) (Code (.limbs width_gt)) inferInstance)) :=
  if h : Model.WideLimb.Eligible format then some (wideLimbSub format width_gt h) else none

/-- Offer wide-limb multiplication exactly when the descriptor is eligible. -/
def wideLimbMul? :
    Option (Certified (@Spec.mul format (.limbs width_gt) (Code (.limbs width_gt)) inferInstance)) :=
  if h : Model.WideLimb.Eligible format then some (wideLimbMul format width_gt h) else none

/-- Offer wide-limb fused multiply-add exactly when the descriptor is eligible. -/
def wideLimbFma? :
    Option (Certified (@Spec.fma format (.limbs width_gt) (Code (.limbs width_gt)) inferInstance)) :=
  if h : Model.WideLimb.Eligible format then some (wideLimbFma format width_gt h) else none

end LeanFloat.Floats.Formats.BinaryInterchange.Configured.Plan
