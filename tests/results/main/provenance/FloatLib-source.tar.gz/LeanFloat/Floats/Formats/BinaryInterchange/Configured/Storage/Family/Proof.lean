/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Storage.Family.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Model.NumericalSystem

/-!
# Configured binary-family conversion proofs

The configured runtime/model conversions are mutual inverses. Their injectivity and
`FormatSemantics` instance are consequences of the codec laws, independent of the chosen carrier.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Configured

open LeanFloat.Numerics
namespace Family

variable {format : FloatFormat} {plan : StoragePlan format} {code : Type}
    [codec : LeanFloat.Floats.ExecFloat.ModelCodec plan (Model format) code]
/-- Decoding immediately after packing through a configured codec is lossless. -/
@[simp, grind =] theorem toModel_ofModel (value : Model format) :
    toModel (plan := plan) (code := code)
      (ofModel (plan := plan) (code := code) value) = value :=
  LeanFloat.Floats.ExecFloat.ModelCodec.decode_encode
    (F := Family format code plan) (plan := plan) value

/-- Packing immediately after decoding a configured value is lossless. -/
@[simp, grind =] theorem ofModel_toModel
    (value : LeanFloat.Floats.ExecFloat (Family format code plan)) :
    ofModel (code := code) (toModel (code := code) value) = value :=
  LeanFloat.Floats.ExecFloat.ModelCodec.encode_decode
    (plan := plan) value

/-- Model decoding is injective because packing is its inverse. -/
theorem toModel_injective
    {left right : LeanFloat.Floats.ExecFloat (Family format code plan)}
    (equality : toModel (code := code) left = toModel (code := code) right) :
    left = right :=
  LeanFloat.Floats.ExecFloat.ModelCodec.decode_injective
    (plan := plan) equality

noncomputable instance :
    FormatSemantics (Family format code plan) where
  denote bits := Model.toNumericalValue (codec.toModel bits)

end Family

end LeanFloat.Floats.Formats.BinaryInterchange.Configured
