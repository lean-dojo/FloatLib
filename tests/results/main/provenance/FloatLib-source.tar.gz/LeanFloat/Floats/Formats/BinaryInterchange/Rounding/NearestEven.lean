/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Dyadic.Rational
public import LeanFloat.Floats.Formats.Flocq.Theory.Rounding.Core

/-!
# Nearest-even rounding lemmas

This module connects the format-independent integer primitives in `Numerics` to LeanFloat's
rounded-real nearest-even operation.

Generic shift-rounding equations and floor bounds live in
`Numerics.Quantization.Deterministic.ShiftRight`, where fixed-point and other binary
quantizations can reuse them. This module adds the binary-format results: normalized-significand
bounds, equivalence with quotient rounding, oddness of `nearestEven`, and nonnegative rational
rounding.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model

open LeanFloat.Floats.Formats.Flocq
open LeanFloat.Numerics

/--
Nearest-even averaging preserves the normalized interval for every significand precision.
-/
theorem roundShiftRightEven_add_normalized_bounds
    (precision left right : Nat)
    (hleft : 2 ^ precision ≤ left ∧ left < 2 ^ (precision + 1))
    (hright : 2 ^ precision ≤ right ∧ right < 2 ^ (precision + 1)) :
    2 ^ precision ≤ roundShiftRightEven (left + right) 1 ∧
      roundShiftRightEven (left + right) 1 < 2 ^ (precision + 1) := by
  change
    2 ^ precision ≤
        Numerics.roundShiftRightEven (left + right) 1 ∧
      Numerics.roundShiftRightEven (left + right) 1 <
        2 ^ (precision + 1)
  have hpowUpper : 2 ^ (precision + 1) = 2 * 2 ^ precision := by
    rw [pow_succ]
    omega
  have hpowNext : 2 ^ (precision + 2) = 2 * 2 ^ (precision + 1) := by
    rw [show precision + 2 = (precision + 1) + 1 by omega, pow_succ]
    omega
  have hupperPositive : 0 < 2 ^ (precision + 1) := by
    positivity
  have hsumLower : 2 ^ (precision + 1) ≤ left + right := by
    rw [hpowUpper]
    omega
  have hsumUpper : left + right ≤ 2 ^ (precision + 2) - 2 := by
    rw [hpowNext]
    omega
  have hfloorLower : 2 ^ precision ≤ (left + right) >>> 1 := by
    rw [Nat.shiftRight_eq_div_pow]
    norm_num
    rw [hpowUpper] at hsumLower
    omega
  have hroundLower :=
    shiftRight_le_roundShiftRightEven (left + right) 1
  constructor
  · exact le_trans hfloorLower hroundLower
  by_cases hmax : left + right = 2 ^ (precision + 2) - 2
  · have hmaxForm :
        2 ^ (precision + 2) - 2 =
          2 * (2 ^ (precision + 1) - 1) := by
      rw [hpowNext]
      omega
    rw [hmax, hmaxForm, roundShiftRightEven_two_mul]
    omega
  · have hsumUpper' : left + right < 2 ^ (precision + 2) - 2 :=
      lt_of_le_of_ne hsumUpper hmax
    have hfloorUpper :
        (left + right) >>> 1 ≤ 2 ^ (precision + 1) - 2 := by
      rw [Nat.shiftRight_eq_div_pow]
      norm_num
      rw [hpowNext] at hsumUpper'
      omega
    have hroundUpper :=
      roundShiftRightEven_le_shiftRight_add1 (left + right) 1
    norm_num [Nat.shiftRight_eq_div_pow] at hroundUpper
    omega

/-- Power-of-two shift rounding agrees with generic nearest-even quotient rounding. -/
theorem roundShiftRightEven_eq_roundQuotientEven_pow2 (n shift : Nat) :
    roundShiftRightEven n shift = roundQuotientEven n (pow2 shift) := by
  classical
  cases shift with
  | zero =>
      simp [roundShiftRightEven_def, roundQuotientEven, pow2, Nat.div_one, Nat.mod_one]
  | succ shift =>
      let denominator := pow2 (shift + 1)
      let half := pow2 shift
      have hdenominator : denominator = 2 * half := by
        simp [denominator, half, pow2_eq_two_pow, pow_succ, Nat.mul_comm]
      have hquotient :
          n >>> (shift + 1) = n / denominator := by
        simpa [denominator, pow2_eq_two_pow] using
          Nat.shiftRight_eq_div_pow n (shift + 1)
      have hremainder :
          n - (n >>> (shift + 1) <<< (shift + 1)) = n % denominator := by
        have hshiftLeft :
            (n >>> (shift + 1) <<< (shift + 1)) =
              (n / denominator) * denominator := by
          simp [Nat.shiftLeft_eq, hquotient, denominator, pow2_eq_two_pow,
            Nat.mul_comm]
        rw [hshiftLeft]
        have hdivision :
            (n / denominator) * denominator + n % denominator = n := by
          simpa [Nat.mul_comm] using Nat.div_add_mod n denominator
        calc
          n - (n / denominator) * denominator =
              ((n / denominator) * denominator + n % denominator) -
                (n / denominator) * denominator := by simp [hdivision]
          _ = n % denominator := Nat.add_sub_cancel_left _ _
      have hround :
          roundShiftRightEven n (shift + 1) =
            (let quotient := n / denominator
             let remainder := n % denominator
             if remainder < half then quotient
             else if half < remainder then quotient + 1
             else if quotient % 2 == 0 then quotient else quotient + 1) := by
        have hremainder' :
            n - (n / denominator) <<< (shift + 1) = n % denominator := by
          simpa [hquotient] using hremainder
        simp [roundShiftRightEven_def, denominator, half, hquotient, hremainder']
      have hquotientRound :
          roundQuotientEven n denominator =
            (let quotient := n / denominator
             let remainder := n % denominator
             let twice := 2 * remainder
             if twice < denominator then quotient
             else if denominator < twice then quotient + 1
             else if quotient % 2 == 0 then quotient else quotient + 1) := by
        simp [roundQuotientEven, denominator]
      rw [hround]
      have hpow :
          roundQuotientEven n (pow2 (shift + 1)) =
            roundQuotientEven n denominator := by
        rfl
      rw [hpow, hquotientRound]
      simp only
      by_cases hlt : n % denominator < half
      · have htwice : 2 * (n % denominator) < denominator := by
          have hmul :
              2 * (n % denominator) < 2 * half :=
            (Nat.mul_lt_mul_left (by decide : 0 < (2 : Nat))).2 hlt
          simpa [hdenominator, Nat.mul_assoc] using hmul
        simp [hlt, htwice]
      · by_cases hgt : half < n % denominator
        · have htwice : denominator < 2 * (n % denominator) := by
            have hmul :
                2 * half < 2 * (n % denominator) :=
              (Nat.mul_lt_mul_left (by decide : 0 < (2 : Nat))).2 hgt
            exact lt_of_eq_of_lt hdenominator hmul
          have hnotLt : ¬2 * (n % denominator) < denominator :=
            not_lt_of_ge htwice.le
          simp [hlt, hgt, hnotLt, htwice]
        · have hremainderEq : n % denominator = half :=
            le_antisymm (le_of_not_gt hgt) (le_of_not_gt hlt)
          have htwice : 2 * (n % denominator) = denominator := by
            calc
              2 * (n % denominator) = 2 * half := by simp [hremainderEq]
              _ = denominator := hdenominator.symm
          simp [hlt, hgt, htwice]

/-- Nearest-even integer rounding commutes with negation. -/
theorem nearestEven_neg (x : ℝ) :
    nearestEven (-x) = -nearestEven x := by
  by_cases hint : x = (⌊x⌋ : ℝ)
  · have hceil : ⌈x⌉ = ⌊x⌋ := Int.ceil_eq_iff.2 ⟨by linarith, hint.le⟩
    have hfloorNeg : ⌊-x⌋ = -⌊x⌋ := by rw [Int.floor_neg, hceil]
    have hx : x - (⌊x⌋ : ℝ) = 0 := by linarith
    have hnegx : -x - -(⌊x⌋ : ℝ) = 0 := by linarith
    simp [nearestEven, hfloorNeg, hx, hnegx]
  · have hnotMem : x ∉ Set.range ((↑·) : ℤ → ℝ) := by
      rintro ⟨n, rfl⟩
      exact hint (by simp)
    have hceil : ⌈x⌉ = ⌊x⌋ + 1 := (Int.ceil_eq_floor_add_one_iff_notMem x).2 hnotMem
    have hfloorNeg : ⌊-x⌋ = -⌊x⌋ - 1 := by
      rw [Int.floor_neg, hceil]
      ring
    have hlt : (⌊x⌋ : ℝ) < x := lt_of_le_of_ne (Int.floor_le x) (Ne.symm hint)
    have hgt : x < (⌊x⌋ : ℝ) + 1 := Int.lt_floor_add_one x
    have hparity : Even (-⌊x⌋ - 1) ↔ ¬Even ⌊x⌋ := by
      rw [show -⌊x⌋ - 1 = -(⌊x⌋ + 1) by ring, even_neg, Int.even_add_one]
    simp only [nearestEven, hfloorNeg, Int.cast_sub, Int.cast_neg, Int.cast_one, hparity]
    split_ifs <;> first | omega | linarith

/-- Nearest-even rounding never exceeds a natural upper bound of its argument. -/
theorem nearestEven_le_natCast_of_le {value : ℝ} {bound : Nat} (hvalue : value ≤ bound) :
    nearestEven value ≤ Int.ofNat bound := by
  have hbound : nearestEven (bound : ℝ) = Int.ofNat bound := by
    simpa using ValidRnd.id (rnd := nearestEven) (Int.ofNat bound)
  simpa [hbound] using ValidRnd.monotone (rnd := nearestEven) value bound hvalue

/-- Nearest-even rounding never drops below a natural lower bound of its argument. -/
theorem natCast_le_nearestEven_of_le {bound : Nat} {value : ℝ} (hvalue : (bound : ℝ) ≤ value) :
    Int.ofNat bound ≤ nearestEven value := by
  have hbound : nearestEven (bound : ℝ) = Int.ofNat bound := by
    simpa using ValidRnd.id (rnd := nearestEven) (Int.ofNat bound)
  simpa [hbound] using ValidRnd.monotone (rnd := nearestEven) bound value hvalue

private theorem fract_real_div_nat (num den : Nat) (hden : den ≠ 0) :
    (num : ℝ) / (den : ℝ) - ((num / den : Nat) : ℝ) =
      ((num % den : Nat) : ℝ) / (den : ℝ) := by
  have hdivision : den * (num / den) + num % den = num :=
    Nat.div_add_mod num den
  have hdivisionReal :
      ((den * (num / den) : Nat) : ℝ) + ((num % den : Nat) : ℝ) =
        (num : ℝ) := by
    exact_mod_cast hdivision
  have hdenReal : (den : ℝ) ≠ 0 := by
    exact_mod_cast hden
  have hsplit :
      (num : ℝ) / (den : ℝ) =
        ((num / den : Nat) : ℝ) + ((num % den : Nat) : ℝ) / (den : ℝ) := by
    have h := congrArg (fun value : ℝ => value / (den : ℝ)) hdivisionReal
    simp [add_div, hdenReal] at h
    simpa using h.symm
  rw [hsplit]
  ring

/--
The floor of a quotient of natural numbers in `ℝ` is their natural-number quotient.
-/
theorem floor_real_nat_div (num den : Nat) :
    (⌊(num : ℝ) / (den : ℝ)⌋ : Int) = (num / den : Nat) := by
  calc
    (⌊(num : ℝ) / (den : ℝ)⌋ : Int) =
        (⌊(((num : ℚ) / (den : ℚ)) : ℝ)⌋ : Int) := by simp
    _ = (⌊((num : ℚ) / (den : ℚ))⌋ : Int) := by
      simpa using Rat.floor_cast (α := ℝ) ((num : ℚ) / (den : ℚ))
    _ = (num / den : Nat) := by
      simpa using Rat.floor_natCast_div_natCast num den

private theorem div_lt_half_iff (remainder den : Nat) (hden : den ≠ 0) :
    ((remainder : ℝ) / (den : ℝ) < (2⁻¹ : ℝ)) ↔
      2 * remainder < den := by
  have hdenPos : (0 : ℝ) < (den : ℝ) := by
    exact_mod_cast Nat.pos_of_ne_zero hden
  have htwoPos : (0 : ℝ) < (2 : ℝ) := by norm_num
  have hdivision :
      ((remainder : ℝ) / (den : ℝ) < (2⁻¹ : ℝ)) ↔
        (remainder : ℝ) < (2⁻¹ : ℝ) * (den : ℝ) := by
    simpa using div_lt_iff₀ hdenPos
  have hscale :
      (2 : ℝ) * ((2⁻¹ : ℝ) * (den : ℝ)) = (den : ℝ) := by
    ring
  constructor
  · intro h
    have hremainder :
        (remainder : ℝ) < (2⁻¹ : ℝ) * (den : ℝ) :=
      hdivision.mp h
    have hscaled :
        (2 : ℝ) * (remainder : ℝ) <
          (2 : ℝ) * ((2⁻¹ : ℝ) * (den : ℝ)) :=
      mul_lt_mul_of_pos_left hremainder htwoPos
    have hscaled' :
        (2 : ℝ) * (remainder : ℝ) < (den : ℝ) := by
      simpa [hscale] using hscaled
    have hcast : ((2 * remainder : Nat) : ℝ) < (den : ℝ) := by
      simpa [Nat.cast_mul] using hscaled'
    exact_mod_cast hcast
  · intro h
    have hcast : ((2 * remainder : Nat) : ℝ) < (den : ℝ) := by
      exact_mod_cast h
    have hscaled :
        (2 : ℝ) * (remainder : ℝ) < (den : ℝ) := by
      simpa [Nat.cast_mul] using hcast
    have hscaled' :
        (2 : ℝ) * (remainder : ℝ) <
          (2 : ℝ) * ((2⁻¹ : ℝ) * (den : ℝ)) := by
      simpa [hscale] using hscaled
    have hremainder :
        (remainder : ℝ) < (2⁻¹ : ℝ) * (den : ℝ) :=
      (mul_lt_mul_iff_right₀ htwoPos).mp hscaled'
    exact hdivision.mpr hremainder

private theorem half_lt_div_iff (remainder den : Nat) (hden : den ≠ 0) :
    ((2⁻¹ : ℝ) < (remainder : ℝ) / (den : ℝ)) ↔
      den < 2 * remainder := by
  have hdenPos : (0 : ℝ) < (den : ℝ) := by
    exact_mod_cast Nat.pos_of_ne_zero hden
  have htwoPos : (0 : ℝ) < (2 : ℝ) := by norm_num
  have hdivision :
      ((2⁻¹ : ℝ) < (remainder : ℝ) / (den : ℝ)) ↔
        (2⁻¹ : ℝ) * (den : ℝ) < (remainder : ℝ) := by
    simpa using lt_div_iff₀ hdenPos
  have hscale :
      (2 : ℝ) * ((2⁻¹ : ℝ) * (den : ℝ)) = (den : ℝ) := by
    ring
  constructor
  · intro h
    have hremainder :
        (2⁻¹ : ℝ) * (den : ℝ) < (remainder : ℝ) :=
      hdivision.mp h
    have hscaled :
        (2 : ℝ) * ((2⁻¹ : ℝ) * (den : ℝ)) <
          (2 : ℝ) * (remainder : ℝ) :=
      mul_lt_mul_of_pos_left hremainder htwoPos
    have hscaled' :
        (den : ℝ) < (2 : ℝ) * (remainder : ℝ) := by
      simpa [hscale] using hscaled
    have hcast : (den : ℝ) < ((2 * remainder : Nat) : ℝ) := by
      simpa [Nat.cast_mul] using hscaled'
    exact_mod_cast hcast
  · intro h
    have hcast : (den : ℝ) < ((2 * remainder : Nat) : ℝ) := by
      exact_mod_cast h
    have hscaled :
        (den : ℝ) < (2 : ℝ) * (remainder : ℝ) := by
      simpa [Nat.cast_mul] using hcast
    have hscaled' :
        (2 : ℝ) * ((2⁻¹ : ℝ) * (den : ℝ)) <
          (2 : ℝ) * (remainder : ℝ) := by
      simpa [hscale] using hscaled
    have hremainder :
        (2⁻¹ : ℝ) * (den : ℝ) < (remainder : ℝ) :=
      (mul_lt_mul_iff_right₀ htwoPos).mp hscaled'
    exact hdivision.mpr hremainder

/-- Nearest-even rounding of a nonnegative rational agrees with `roundQuotientEven`. -/
theorem nearestEven_div_eq_roundQuotientEven
    (num den : Nat) (hden : den ≠ 0) :
    nearestEven ((num : ℝ) / (den : ℝ)) =
      Int.ofNat (roundQuotientEven num den) := by
  classical
  let quotient := num / den
  let remainder := num % den
  have hfloor :
      (⌊((num : ℝ) / (den : ℝ))⌋ : Int) = quotient := by
    simpa [quotient] using floor_real_nat_div num den
  have hfract :
      ((num : ℝ) / (den : ℝ)) - (quotient : ℝ) =
        (remainder : ℝ) / (den : ℝ) := by
    simpa [quotient, remainder] using fract_real_div_nat num den hden
  unfold nearestEven
  simp [hfloor]
  rw [hfract]
  simp [roundQuotientEven, quotient, remainder]
  have hlt :
      (((num % den : Nat) : ℝ) / (den : ℝ) < (2⁻¹ : ℝ)) ↔
        2 * (num % den) < den := by
    simpa using div_lt_half_iff (num % den) den hden
  have hgt :
      ((2⁻¹ : ℝ) < ((num % den : Nat) : ℝ) / (den : ℝ)) ↔
        den < 2 * (num % den) := by
    simpa using half_lt_div_iff (num % den) den hden
  by_cases htwoLt : 2 * (num % den) < den
  · have hrLt :
        ((num % den : Nat) : ℝ) / (den : ℝ) < (2⁻¹ : ℝ) :=
      hlt.mpr htwoLt
    simp [htwoLt, hrLt]
  · have hrNotLt :
        ¬((num % den : Nat) : ℝ) / (den : ℝ) < (2⁻¹ : ℝ) := by
      exact fun h => htwoLt (hlt.mp h)
    by_cases htwoGt : den < 2 * (num % den)
    · have hrGt :
          (2⁻¹ : ℝ) < ((num % den : Nat) : ℝ) / (den : ℝ) :=
        hgt.mpr htwoGt
      simp [htwoLt, hrNotLt, htwoGt, hrGt]
    · have hrNotGt :
          ¬(2⁻¹ : ℝ) < ((num % den : Nat) : ℝ) / (den : ℝ) := by
        exact fun h => htwoGt (hgt.mp h)
      simp [htwoLt, hrNotLt, htwoGt, hrNotGt, Nat.even_iff]

/-- Nearest-even rounding after division by `2^shift` is executable shift rounding. -/
theorem nearestEven_div_pow2_eq_roundShiftRightEven (num shift : Nat) :
    nearestEven ((num : ℝ) / (pow2 shift : ℝ)) =
      Int.ofNat (roundShiftRightEven num shift) := by
  have hden : pow2 shift ≠ 0 := by
    simp [pow2_eq_two_pow]
  rw [nearestEven_div_eq_roundQuotientEven num (pow2 shift) hden]
  simp [roundShiftRightEven_eq_roundQuotientEven_pow2]

end Model
end LeanFloat.Floats.Formats.BinaryInterchange
