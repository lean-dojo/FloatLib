/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Operations.Runtime
import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Rounding.Proof
public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.Proof

/-!
# Packing correctness for configured standard operations

Every theorem states that decoding a configured result recovers the single descriptor-model
operation used to compute it. Status-bearing operations preserve all five indicators exactly.

These are packing-boundary theorems, not independent arithmetic proofs: backend capabilities have
already established their operation refinements. Centralizing the final transport keeps the public
carrier lightweight and gives users stable equations for values and exception flags regardless of
which storage plan was selected.
-/

@[expose] public section

namespace LeanFloat.Floats.ExecFloat.Binary

open LeanFloat.Floats.Formats.BinaryInterchange

variable {format : FloatFormat} {plan : Configured.StoragePlan format} {code : Type}
    [LeanFloat.Floats.ExecFloat.ModelCodec plan (Model format) code]

local notation "Value" =>
  LeanFloat.Floats.ExecFloat (Configured.Family format code plan)

/-- Decoding configured IEEE remainder gives the descriptor-model remainder. -/
@[simp, grind =] theorem toModel_remainder (dividend divisor : Value) :
    toModel (remainder dividend divisor) =
      Model.remainder (toModel dividend) (toModel divisor) := by
  simp [remainder, toModel, Configured.Family.toModel]

/-- Decoding configured remainder preserves both its value and all IEEE status indicators. -/
@[simp, grind =] theorem IEEEOutcome.toModel_remainderWithStatus
    (dividend divisor : Value) :
    IEEEOutcome.toModel (remainderWithStatus dividend divisor) =
      Model.remainderWithStatus
        (ExecFloat.Binary.toModel dividend)
        (ExecFloat.Binary.toModel divisor) := by
  simp [remainderWithStatus]

/-- Decoding configured integral rounding gives integral rounding in the descriptor model. -/
@[simp, grind =] theorem toModel_roundToIntegral
    (value : Value) (rounding : Model.IEEERoundingMode) :
    toModel (roundToIntegral value rounding) =
      Model.roundToIntegral (toModel value) rounding := by
  simp [roundToIntegral, toModel, Configured.Family.toModel]

/-- Configured integral rounding preserves the descriptor-model value and IEEE status. -/
@[simp, grind =] theorem IEEEOutcome.toModel_roundToIntegralExactWithStatus
    (value : Value) (rounding : Model.IEEERoundingMode) :
    IEEEOutcome.toModel (roundToIntegralExactWithStatus value rounding) =
      Model.roundToIntegralExactWithStatus (ExecFloat.Binary.toModel value) rounding := by
  simp [roundToIntegralExactWithStatus]

/-- Decoding configured power-of-two scaling gives descriptor-model scaling. -/
@[simp, grind =] theorem toModel_scaleB
    (value : Value) (scale : Int) (rounding : Model.IEEERoundingMode) :
    toModel (scaleB value scale rounding) =
      Model.scaleB (toModel value) scale rounding := by
  simp [scaleB, toModel, Configured.Family.toModel]

/-- Configured power-of-two scaling preserves the descriptor-model value and IEEE status. -/
@[simp, grind =] theorem IEEEOutcome.toModel_scaleBWithStatus
    (value : Value) (scale : Int) (rounding : Model.IEEERoundingMode) :
    IEEEOutcome.toModel (scaleBWithStatus value scale rounding) =
      Model.scaleBWithStatus (ExecFloat.Binary.toModel value) scale rounding := by
  simp [scaleBWithStatus]

/-- Decoding configured `logB` gives the descriptor-model leading binary exponent. -/
@[simp, grind =] theorem toModel_logB (value : Value) :
    toModel (logB value) = Model.logB (toModel value) := by
  simp [logB, toModel, Configured.Family.toModel]

/-- Configured `logB` preserves the descriptor-model value and IEEE status. -/
@[simp, grind =] theorem IEEEOutcome.toModel_logBWithStatus (value : Value) :
    IEEEOutcome.toModel (logBWithStatus value) =
      Model.logBWithStatus (ExecFloat.Binary.toModel value) := by
  simp [logBWithStatus]

/-- Decoding configured sign copying gives descriptor-model sign copying. -/
@[simp, grind =] theorem toModel_copySign (magnitude signSource : Value) :
    toModel (copySign magnitude signSource) =
      Model.copySign (toModel magnitude) (toModel signSource) := by
  simp [copySign, toModel, Configured.Family.toModel]

/-- Decoding configured absolute value gives descriptor-model absolute value. -/
@[simp, grind =] theorem toModel_abs (value : Value) :
    toModel (abs value) = Model.abs (toModel value) := by
  simp [abs, toModel, Configured.Family.toModel]

/-- Decoding the configured upward neighbor gives the descriptor-model upward neighbor. -/
@[simp, grind =] theorem toModel_nextUp (value : Value) :
    toModel (nextUp value) = Model.nextUp (toModel value) := by
  simp [nextUp, toModel, Configured.Family.toModel]

/-- Decoding the configured downward neighbor gives the descriptor-model downward neighbor. -/
@[simp, grind =] theorem toModel_nextDown (value : Value) :
    toModel (nextDown value) = Model.nextDown (toModel value) := by
  simp [nextDown, toModel, Configured.Family.toModel]

/-- Decoding configured `minNum` gives descriptor-model `minNum`. -/
@[simp, grind =] theorem toModel_minNum (left right : Value) :
    toModel (minNum left right) = Model.minNum (toModel left) (toModel right) := by
  simp [minNum, toModel, Configured.Family.toModel]

/-- Decoding configured `maxNum` gives descriptor-model `maxNum`. -/
@[simp, grind =] theorem toModel_maxNum (left right : Value) :
    toModel (maxNum left right) = Model.maxNum (toModel left) (toModel right) := by
  simp [maxNum, toModel, Configured.Family.toModel]

end LeanFloat.Floats.ExecFloat.Binary
