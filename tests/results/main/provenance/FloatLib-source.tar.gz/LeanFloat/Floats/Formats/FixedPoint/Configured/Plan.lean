/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.FixedPoint.Configured.Runtime
public import LeanFloat.Floats.ExecFloat.Backends.Selection.Certified

/-!
# Execution planning for exact fixed-point arithmetic

The direct integer-coefficient operations are both the executable implementations and their
reference specifications.

Exact fixed point needs no rounding backend when scales already agree, so introducing a separate
generic fallback would add indirection without semantic value. This plan exposes those direct
capabilities uniformly through `ExecFloat`, while conversions and mismatched-scale operations remain
under their explicit quantization contracts.
-/

@[expose] public section

namespace LeanFloat.Floats.ExecFloat.FixedPoint.Plan

open LeanFloat.Numerics

variable {radix : Radix} {fractionalDigits : Nat}

/-- Cost description of direct unbounded-integer coefficient arithmetic. -/
def estimate (operation : Backend.Operation) : Backend.Candidate where
  name := s!"exact fixed-point {repr operation}"
  kind := .custom "direct integer-coefficient kernel" 0
  storage := .custom
  steadyCost :=
    match operation with
    | .add | .sub => 2
    | _ => 3

/-- Certified exact same-scale addition. -/
def addCertified :
    Backend.Certified (FixedPoint.add (radix := radix)
      (fractionalDigits := fractionalDigits)) :=
  Backend.Certified.reference (estimate .add) FixedPoint.add

/-- Certified exact same-scale subtraction. -/
def subCertified :
    Backend.Certified (FixedPoint.sub (radix := radix)
      (fractionalDigits := fractionalDigits)) :=
  Backend.Certified.reference (estimate .sub) FixedPoint.sub

end LeanFloat.Floats.ExecFloat.FixedPoint.Plan
