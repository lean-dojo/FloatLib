/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module -- shake: keep-all

public import LeanFloat.Floats.Formats.Logarithmic.Automation
public import LeanFloat.Floats.Formats.Logarithmic.Configured.Instances
public import LeanFloat.Floats.Formats.Logarithmic.Configured.Conversion.Runtime
public import LeanFloat.Floats.Formats.Logarithmic.Configured.Conversion.Proof
public import LeanFloat.Floats.Formats.Logarithmic.Exact.Proof
public meta import LeanFloat.Floats.Formats.Logarithmic.Configured.Info
public meta import LeanFloat.Floats.Formats.Logarithmic.Exact.Info
public meta import LeanFloat.Numerics.Capabilities.Radix

/-!
# Exact logarithmic numbers

The exact value set is zero together with the signed integral powers `±β^e` of the radix `β`,
with `e` an unbounded integer. Multiplication is the only arithmetic operation supplied, and it is
exact because signs combine and exponents add. Addition is not exact in this form (the sum of two
powers of `β` is in general not a power of `β`), so neither addition nor division is provided;
they, like conversion rounding, require policies beyond this exact model. The family ships a
configured `ExecFloat.Logarithmic` carrier, proof automation, and `#float_info` support.

## References

* E. E. Swartzlander Jr. and A. G. Alexopoulos, “The Sign/Logarithm Number System,”
  *IEEE Transactions on Computers* C-24(12), 1975.
-/

@[expose] public section
