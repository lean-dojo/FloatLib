/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Carrier
public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Storage.Core
public import Mathlib.Algebra.Order.Algebra
public import Mathlib.Analysis.SpecialFunctions.Pow.Real

/-!
# Configured binary-family runtime conversion

This module exposes the executable conversion boundary between a configured `ExecFloat` value and
its binary proof model. The selected codec and its storage plan remain type-static.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Configured

open LeanFloat.Numerics
namespace Family

variable {format : FloatFormat} {plan : StoragePlan format} {code : Type}
    [codec : LeanFloat.Floats.ExecFloat.ModelCodec plan (Model format) code]

/-- Decode a configured executable value into the proof model. -/
@[always_inline, inline] def toModel
    (value : LeanFloat.Floats.ExecFloat (Family format code plan)) : Model format :=
  LeanFloat.Floats.ExecFloat.ModelCodec.decode (plan := plan) value

/-- Pack a proof-model value into configured runtime storage. -/
@[always_inline, inline] def ofModel
    (value : Model format) : LeanFloat.Floats.ExecFloat (Family format code plan) :=
  LeanFloat.Floats.ExecFloat.ModelCodec.encode
    (F := Family format code plan) (plan := plan) value

end Family

end LeanFloat.Floats.Formats.BinaryInterchange.Configured
