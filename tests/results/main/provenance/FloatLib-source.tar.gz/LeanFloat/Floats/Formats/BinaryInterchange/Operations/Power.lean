/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Operations.Compare.Runtime
public import LeanFloat.Floats.Formats.BinaryInterchange.Transcendentals.ExpLog
public import LeanFloat.Floats.Formats.BinaryInterchange.Arithmetic.Runtime

/-!
# Executable floating-point powers

`Model.pow` provides one deterministic power policy for every `FloatFormat`. Small integer
exponents use a linear sequence of rounded multiplications; larger integer exponents and
non-integer exponents use the generic `exp` and `log` kernels.

Integer exponents are classified directly from their dyadic representation. The classifier records
sign, parity, and an optional bounded magnitude without constructing an integer whose bit length is
controlled by the floating-point exponent field. This is essential for formats with wide exponent
fields.

As with the transcendental kernels, this is a deterministic executable policy, not a
correct-rounding theorem for real exponentiation.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange
namespace Model

namespace Power

/-- Largest integer exponent evaluated by the direct linear multiplication path. -/
def smallPowLimit : Nat := 256

/--
Information needed to evaluate a finite integral floating-point exponent.

`smallMagnitude?` is populated exactly when the magnitude is at most `smallPowLimit`.
-/
structure IntegerExponent where
  /-- Whether the nonzero integer is negative. -/
  negative : Bool
  /-- Whether its magnitude is odd. -/
  odd : Bool
  /-- Its magnitude when small enough for the linear multiplication path. -/
  smallMagnitude? : Option Nat
  deriving Repr, DecidableEq

/-- Retain a magnitude only when it is within the linear multiplication budget. -/
@[inline] def smallMagnitude (magnitude : Nat) : Option Nat :=
  if magnitude ≤ smallPowLimit then some magnitude else none

/--
Classify a finite dyadic as an integer.

For a nonnegative dyadic exponent, a bounded shift is performed only when the result could still be
at most `smallPowLimit`. For a negative exponent, divisibility is checked only after proving that
the required right shift fits within the mantissa's bit length.
-/
def classifyIntegerDyadic? (value : Numerics.Dyadic) : Option IntegerExponent :=
  if value.significand == 0 then
    some { negative := false, odd := false, smallMagnitude? := some 0 }
  else
    match value.exponent with
    | .ofNat shift =>
        let odd := shift == 0 && value.significand % 2 == 1
        let small? :=
          if shift ≤ Nat.log2 smallPowLimit then
            smallMagnitude (Nat.shiftLeft value.significand shift)
          else
            none
        some { negative := value.negative, odd, smallMagnitude? := small? }
    | .negSucc shift =>
        let denominatorShift := shift + 1
        if Nat.log2 value.significand < denominatorShift then
          none
        else
          let magnitude := Nat.shiftRight value.significand denominatorShift
          if Nat.shiftLeft magnitude denominatorShift == value.significand then
            some
              { negative := value.negative
                odd := magnitude % 2 == 1
                smallMagnitude? := smallMagnitude magnitude }
          else
            none

/-- Classify an executable finite value as an integer exponent. -/
@[inline] def classifyInteger? {fmt : FloatFormat}
    (value : Model fmt) : Option IntegerExponent :=
  (toDyadic? value).bind classifyIntegerDyadic?

/-- Repeated rounded multiplication in a fixed left-associated order. -/
def powNatLinear {fmt : FloatFormat} (base : Model fmt) : Nat → Model fmt
  | 0 => posOne fmt
  | exponent + 1 => mul base (powNatLinear base exponent)

/-- Evaluate an integer exponent whose magnitude is within `smallPowLimit`. -/
@[inline] def powSmallInteger {fmt : FloatFormat}
    (base : Model fmt) (metadata : IntegerExponent) (magnitude : Nat) : Model fmt :=
  if metadata.negative then
    div (posOne fmt) (powNatLinear base magnitude)
  else
    powNatLinear base magnitude

/--
Evaluate an integral exponent.

Large magnitudes use the deterministic general path `exp (b * log |a|)`.
-/
def powIntegerDet {fmt : FloatFormat}
    (base exponent : Model fmt) (metadata : IntegerExponent) : Model fmt :=
  match metadata.smallMagnitude? with
  | some magnitude => powSmallInteger base metadata magnitude
  | none => exp (mul exponent (log (abs base)))

end Power

/--
Deterministic executable floating-point exponentiation.

The special cases and branch order are explicit:

* `x^(+-0) = 1`, including a NaN base;
* `1^y = 1` except for a signaling-NaN exponent;
* infinite exponents are classified by `|x|` relative to one;
* finite negative bases require an integral exponent;
* signed zero and negative infinity retain a negative result exactly for odd integer exponents.
-/
def pow {fmt : FloatFormat} (base exponent : Model fmt) : Model fmt :=
  if isZero exponent then
    posOne fmt
  else if compare base (posOne fmt) = some .eq && !isSNaN exponent then
    posOne fmt
  else
    match chooseNaN2 base exponent with
    | some nan => nan
    | none =>
        if compare exponent (posOne fmt) = some .eq then
          base
        else if isInf exponent then
          match compare (abs base) (posOne fmt) with
          | some .lt =>
              if signBit exponent then nativeOverflow fmt false else zero fmt false
          | some .eq => posOne fmt
          | some .gt =>
              if signBit exponent then zero fmt false else nativeOverflow fmt false
          | none => invalidResult fmt
        else
          match compare base (zero fmt false) with
          | some .eq =>
              match Power.classifyInteger? exponent with
              | some metadata =>
                  match compare exponent (zero fmt false) with
                  | some .lt =>
                      nativeOverflow fmt (signBit base && metadata.odd)
                  | some .gt =>
                      zero fmt (signBit base && metadata.odd)
                  | _ => zero fmt false
              | none =>
                  match compare exponent (zero fmt false) with
                  | some .lt => nativeOverflow fmt false
                  | _ => zero fmt false
          | some .lt =>
              match Power.classifyInteger? exponent with
              | none =>
                  if isInf base then
                    match compare exponent (zero fmt false) with
                    | some .lt => zero fmt false
                    | some .gt => nativeOverflow fmt false
                    | _ => invalidResult fmt
                  else
                    invalidResult fmt
              | some metadata =>
                  let magnitude := Power.powIntegerDet base exponent metadata
                  if metadata.odd then neg (abs magnitude) else abs magnitude
          | _ =>
              match Power.classifyInteger? exponent with
              | some metadata => Power.powIntegerDet base exponent metadata
              | none => exp (mul exponent (log base))

end Model
end LeanFloat.Floats.Formats.BinaryInterchange
