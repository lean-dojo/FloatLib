/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Carrier
public import LeanFloat.Floats.Formats.Logarithmic.Exact.Proof

/-!
# Configured exact logarithmic identity

This module defines the encoded family and public `ExecFloat.Logarithmic` type. The representation
contains only zero or a sign with an unbounded integer exponent; it does not impose a bit layout.
-/

@[expose] public section

namespace LeanFloat.Floats

open LeanFloat.Numerics

namespace ExecFloat
namespace Logarithmic

/-- Type-level identity of an exact logarithmic format at one radix. -/
inductive Family (radix : Radix) where
  | format

instance (radix : Radix) : EncodedFormat (Family radix) where
  Code := Formats.Logarithmic.Code radix
  Scalar := ℝ

noncomputable instance (radix : Radix) : FormatSemantics (Family radix) :=
  FormatSemantics.ofFinite _ fun code ↦ code.toReal

end Logarithmic

/-- Exact zero and signed integral powers of `radix`, using the common `ExecFloat` carrier. -/
abbrev Logarithmic (radix : Radix) :=
  LeanFloat.Floats.ExecFloat (Logarithmic.Family radix)

end ExecFloat

end LeanFloat.Floats
