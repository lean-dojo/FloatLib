/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Conversion.Proof
public import LeanFloat.Floats.Formats.BinaryInterchange.StaticByte.Conversion.Runtime
public import LeanFloat.Floats.ExecFloat.Conversion.Runtime

/-!
# Static-byte exact conversion proofs

This module states the reduction equations for finite, infinite, and exceptional observations and
identifies the installed exact decoder with the public runtime function.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.StaticByte
namespace Conversion

open LeanFloat.Numerics

universe u

variable {F : Type u} [Family F]

/-- Finite observations are handled by the shared exact rational binary quantizer. -/
@[simp, grind =] theorem run_finite
    (context : LeanFloat.Floats.ExecFloat.Binary.Conversion.Context) (exact : SignedRat) :
    run (F := F) context (.finite exact) = quantizeFinite context exact :=
  rfl

/-- Infinity observations are handled only by the explicit infinity policy. -/
@[simp, grind =] theorem run_infinity
    (context : LeanFloat.Floats.ExecFloat.Binary.Conversion.Context) (negative : Bool) :
    run (F := F) context (.infinity negative) = quantizeInfinity context negative :=
  rfl

/-- Exceptional observations are handled only by the explicit exceptional policy. -/
@[simp, grind =] theorem run_exceptional
    (context : LeanFloat.Floats.ExecFloat.Binary.Conversion.Context)
    (exceptional : ExceptionalValue) :
    run (F := F) context (.exceptional exceptional) =
      quantizeExceptional context exceptional :=
  rfl

/-- The static-byte carrier converter implements its declared singleton relation. -/
theorem implements_run :
    Quantization.Spec.Implements (spec (F := F)) (run (F := F)) :=
  LeanFloat.Floats.ExecFloat.Binary.Conversion.implements_runWith pack

/-- The installed exact decoder is the public static-byte decoder. -/
@[simp, grind =] theorem exactDecoder_run (value : LeanFloat.Floats.ExecFloat F) :
    LeanFloat.Floats.ExecFloat.ExactDecoder.run value = decode value :=
  rfl

end Conversion
end LeanFloat.Floats.Formats.BinaryInterchange.StaticByte
