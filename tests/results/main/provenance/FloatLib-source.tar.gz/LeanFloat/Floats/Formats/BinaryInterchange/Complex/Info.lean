/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Complex.NumericalSystem
public import LeanFloat.Floats.Formats.BinaryInterchange.Info.Profile
public meta import LeanFloat.Floats.Formats.BinaryInterchange.Info.Command

/-!
# Proof-aware inspection of binary complex values

This module registers `ExecComplex fmt` with `#float_info`. Complex arithmetic is reported as a
specialized carrier API rather than as scalar `ExecFloat` arithmetic. That distinction matters:
the carrier has executable negation, conjugation, addition, subtraction, and multiplication, but
does not install a scalar conversion policy or silently claim exact complex multiplication.
-/

public meta section

namespace LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.FloatInfo

open LeanFloat.Floats.ExecFloat

/-- Descriptor summary reused by the complex-format inspection report. -/
meta abbrev BinarySummary :=
  LeanFloat.Floats.Formats.BinaryInterchange.FloatInfo.Summary

/-- Build the execution and proof profile for two-component binary complex values. -/
meta def profile (summary : BinarySummary) : FormatProfile where
  family := "binary-interchange complex"
  standard :=
    "Cartesian complex carrier over " ++
      LeanFloat.Floats.Formats.BinaryInterchange.FloatInfo.standardName summary
  declarationPrefix := "LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex."
  representation :=
    [ ⟨"storage", "two binary `Model` components in Cartesian form"⟩
    , ⟨"component bits", toString summary.bitWidth⟩
    , ⟨"combined component payload", s!"{2 * summary.bitWidth} bits"⟩
    , ⟨"component exponent bits", toString summary.expWidth⟩
    , ⟨"component fraction bits", toString summary.fracWidth⟩
    , ⟨"component encoding",
        LeanFloat.Floats.Formats.BinaryInterchange.FloatInfo.encodingName summary.encoding⟩
    ]
  values :=
    [ ⟨"finite complex values",
        "yes; both components must be finite and denote the corresponding real coordinates"⟩
    , ⟨"signed zeros", "retained independently by the real and imaginary components"⟩
    , ⟨"infinity", "available independently in either component when the component format has it"⟩
    , ⟨"NaN", "available independently in either component when the component format has it"⟩
    ]
  rounding :=
    [ ⟨"negation / conjugation", "exact sign-bit transformations on finite components"⟩
    , ⟨"addition / subtraction", "each real and imaginary component is rounded once"⟩
    , ⟨"multiplication",
        "four rounded products followed by one rounded subtraction and one rounded addition"⟩
    ]
  execution :=
    [ ⟨"carrier", "a direct pair of format-generic binary model values"⟩
    , ⟨"dispatch", "monomorphic composition of the component format's executable kernels"⟩
    , ⟨"multiplication order",
        "real = round(round(ac) - round(bd)); imaginary = round(round(ad) + round(bc))"⟩
    ]
  specializedOperations :=
    [ ⟨"negation / conjugation", "exact for finite inputs; theorem-linked complex semantics"⟩
    , ⟨"addition / subtraction",
        "componentwise rounded semantics with explicit finite-result hypotheses"⟩
    , ⟨"multiplication",
        "six visible scalar rounding sites with a checked evaluation-order refinement theorem"⟩
    ]
  theoremSurfaces :=
    [ { topic := "finite complex representation"
        declarations :=
          [ ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.isFinite_eq_true_iff
          , ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.numericalSystem_represents_of_isFinite
          , ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.represents_iff
          ]
        definitions := [``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.numericalSystem]
        applicability := .verifiedForType
        scope :=
          "both components are finite; exceptional component combinations remain undefined rather than being assigned an invented complex value" }
    , { topic := "exact complex sign transformations"
        declarations :=
          [ ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.toComplex_neg
          , ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.toComplex_conj
          , ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.neg_refines
          , ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.conj_refines
          ]
        applicability := .verifiedForType
        scope := "finite real and imaginary components"
        numericalGuarantee? := some {
          kinds := [.exactness]
          statement :=
            "Negation and conjugation preserve the exact finite complex value with zero arithmetic error." } }
    , { topic := "rounded addition and subtraction"
        declarations :=
          [ ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.toComplex_add_eq_roundedAdd
          , ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.toComplex_sub_eq_roundedSub
          , ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.add_refines
          , ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.sub_refines
          ]
        definitions :=
          [ ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.roundedAdd
          , ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.roundedSub
          ]
        applicability :=
          LeanFloat.Floats.Formats.BinaryInterchange.FloatInfo.ieeeApplicability summary
        scope := "finite inputs and finite componentwise output"
        numericalGuarantee? := some {
          kinds := [.rounding]
          statement :=
            "Each output component is one nearest-even rounding of the corresponding exact component sum or difference." } }
    , { topic := "non-fused rounded multiplication"
        declarations :=
          [ ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.toComplex_mul_eq_roundedMul
          , ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.mul_refines
          ]
        definitions :=
          [ ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.MulFinite
          , ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.roundedMul
          ]
        applicability :=
          LeanFloat.Floats.Formats.BinaryInterchange.FloatInfo.ieeeApplicability summary
        scope :=
          "finite inputs, four finite rounded component products, and finite final components"
        numericalGuarantee? := some {
          kinds := [.rounding]
          statement :=
            "The theorem fixes the six visible scalar rounding sites and their evaluation order; no smaller whole-complex error bound is inferred." } }
    ]
  nonclaims :=
    [ "the six-rounding multiplication is equal to exact multiplication in `ℂ`"
    , "division, square root, fused complex multiplication, or transcendental operations are installed"
    , "a scalar `ExactDecoder` or destination `Quantizer` preserves all componentwise exceptional metadata"
    , "compiled BLAS, SIMD, GPU, or host complex arithmetic is equivalent to this evaluation order"
    ]

end LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.FloatInfo

namespace LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.FloatInfo.Command

open Lean Elab Command Meta
open LeanFloat.Floats.ExecFloat

elab_rules : command
  | `(#float_info%$tk $type:term) =>
      LeanFloat.Floats.ExecFloat.FloatInfo.Command.withElaboratedType
          type fun typeExpr => do
        let some arguments ←
            unfoldUntilAppArgs?
              ``LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex 1 typeExpr
          | throwUnsupportedSyntax
        let summary ←
          LeanFloat.Floats.Formats.BinaryInterchange.FloatInfo.inspectSummary arguments[0]!
        logInfoAt tk <| ←
          Inspection.renderProfile
            (LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.FloatInfo.profile summary)
            typeExpr
            .none

end LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex.FloatInfo.Command
