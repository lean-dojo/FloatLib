/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Conversion.Text.Parsing
public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Value.CoreProof

/-!
# Character input for configured binary values

This module gives configured values the same exact parser as the descriptor model. A successful
parse changes only the storage representation; the decoded numerical value is unchanged.
-/

@[expose] public section

namespace LeanFloat.Floats.ExecFloat.Binary

open LeanFloat.Floats.Formats.BinaryInterchange

variable {format : FloatFormat} {plan : Configured.StoragePlan format} {code : Type}
    [LeanFloat.Floats.ExecFloat.ModelCodec plan (Model format) code]

/--
Parse exact decimal or radix-two text and round it once into the configured binary format.

Malformed text and unsupported special values return `Model.ParseError`; no fallback value is
invented.
-/
def parse (rounding : Model.IEEERoundingMode) (input : String) :
    Except Model.ParseError
      (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) :=
  (Model.parse format rounding input).map ofModel

/-- Nearest-even character input for a configured binary value. -/
def parseNearest (input : String) :
    Except Model.ParseError
      (LeanFloat.Floats.ExecFloat (Configured.Family format code plan)) :=
  parse .nearestEven input

/-- Decoding configured parse success gives exactly the descriptor-model parse result. -/
theorem map_toModel_parse (rounding : Model.IEEERoundingMode) (input : String) :
    (parse (format := format) (plan := plan) (code := code) rounding input).map toModel =
      Model.parse format rounding input := by
  cases hparse : Model.parse format rounding input with
  | error parseError =>
      unfold parse
      rw [hparse]
      rfl
  | ok value =>
      unfold parse
      rw [hparse]
      change
        Except.ok
            (toModel (ofModel (plan := plan) (code := code) value)) =
          Except.ok value
      rw [toModel_ofModel]

end LeanFloat.Floats.ExecFloat.Binary
