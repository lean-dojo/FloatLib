/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Model.ExactValue
public import LeanFloat.Numerics.Exact.Dyadic.Format

/-!
# Exact binary-float formatting

Finite values use the shared exact dyadic formatter. Signed zeros, infinities, and NaNs retain
the conventional spellings expected from a floating-point value.
-/

@[expose] public section

namespace LeanFloat.Floats.Formats.BinaryInterchange.Model

/-- Host-independent display of one binary-interchange value. -/
def format {fmt : FloatFormat} (value : Model fmt) : String :=
  match exactValue value with
  | .finite exact => exact.format
  | .infinity true => "-inf"
  | .infinity false => "inf"
  | .nan _ _ _ => "nan"

instance {fmt : FloatFormat} : ToString (Model fmt) where
  toString := format

end LeanFloat.Floats.Formats.BinaryInterchange.Model
