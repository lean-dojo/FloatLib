/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.ExecFloat.Carrier
public import LeanFloat.Floats.Formats.Block.SharedScale.Core

/-!
# Configured shared-scale block identity

The universal carrier stores one complete vector-valued block. Its lane count remains in the type,
and scale selection remains an explicit operation rather than an inferred scalar policy.
-/

@[expose] public section

namespace LeanFloat.Floats.ExecFloat

/-- A whole rational block with one caller-selected binary exponent. -/
abbrev SharedScale (lanes : Nat) :=
  LeanFloat.Floats.ExecFloat (Formats.Block.SharedScale lanes)

end LeanFloat.Floats.ExecFloat
