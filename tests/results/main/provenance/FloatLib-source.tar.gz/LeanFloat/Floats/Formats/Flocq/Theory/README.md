# Rounded-real theory (`Flocq/Theory`)

Generic rounded arithmetic over `ℝ`: radix powers, FIX/FLX/FLT and abrupt-underflow formats,
rounding modes, ULPs, error bounds, Sterbenz subtraction. Independent of any bit encoding or
executable kernel.

This follows Flocq's organization in Lean; it is not a line-by-line Coq port. Specialized
algorithm proofs and Coq application modules are not reproduced here. Executable binary behavior
is `Formats/BinaryInterchange/`, connected by explicit finite-result bridge theorems.
`Flocq/Calculation/` supplies brackets and truncation used by these proofs.

Public names: `bpow`, `genericFormat`, `ulp`, `round`. Import the folder module you need;
import `LeanFloat.Floats.Formats.Flocq.Theory` only for the full theory.

| Want | Use |
| --- | --- |
| Parametric rounding model on `ℝ` | `FloatRep` / `NF` |
| Executable bits + special values | `ExecFloat.Binary` |
| Finite real meaning of those bits | `Model.toReal`, `Model.roundAt fmt` |
| Host / accelerator result | separately stated conformance, not this layer |

`NF.ofReal` exists because some proofs need off-grid values; carry `NF.IsRepresentable` when the
argument must be on the grid. Affine quantization over exact rationals is
`LeanFloat.Numerics.Quantization`, not `FloatRep`.
