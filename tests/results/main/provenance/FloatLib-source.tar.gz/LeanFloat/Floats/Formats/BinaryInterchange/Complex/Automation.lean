/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Complex.NumericalSystem
public import LeanFloat.Numerics.Automation.Numerics -- shake: keep

/-!
# Complex `Model` rules for numerical automation

These rules expose the rounded complex semantics through the same operation contracts used by
scalar floats and other numerical systems. Executable complex arithmetic remains the direct
monomorphic code in `ExecComplex.Core`.
-/

public meta section

open LeanFloat.Numerics

namespace LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex

attribute [aesop safe apply (rule_sets := [Numerics])]
  neg_refines
  conj_refines
  add_refines
  sub_refines
  mul_refines

attribute [numerics_simps]
  represents_iff

end LeanFloat.Floats.Formats.BinaryInterchange.ExecComplex
