/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.NativeFPU.Proof

/-!
# Certified fixed-format software execution

This module exports proved configured binary32 and binary64 software execution. Guarded host-FPU
experiments require a separate explicit import of `Configured.NativeFPU.Unchecked`; they are not
compiler replacements and are absent from this certified API surface. The historical `NativeFPU`
module name is retained as a compatibility import path.
-/
