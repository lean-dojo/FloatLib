/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.FixedPoint.Bounded.Configured.Conversion.Runtime
public import LeanFloat.Floats.ExecFloat.Conversion.Runtime

/-!
# Bounded fixed-point conversion proofs

This module proves the observable policy equations and the declared singleton quantization
contract for configured bounded fixed point.
-/

@[expose] public section

namespace LeanFloat.Floats

open LeanFloat.Numerics

namespace ExecFloat.BoundedFixedPoint
namespace Conversion

variable {radix : Radix} {fractionalDigits width : Nat}

/-- Finite observations are handled by the selected bounded-overflow policy. -/
@[simp, grind =] theorem run_finite (policy : OverflowPolicy) (exact : Rat) :
    run (radix := radix) (fractionalDigits := fractionalDigits) (width := width)
        policy (.finite exact) =
      quantizeFinite policy exact :=
  rfl

/-- Bounded fixed point has no infinity code. -/
@[simp, grind =] theorem run_infinity (policy : OverflowPolicy) (negative : Bool) :
    run (radix := radix) (fractionalDigits := fractionalDigits) (width := width)
        policy (.infinity negative) =
      .failure (.infinity .source negative) :=
  rfl

/-- Bounded fixed point has no exceptional code. -/
@[simp, grind =] theorem run_exceptional
    (policy : OverflowPolicy) (exceptional : ExceptionalValue) :
    run (radix := radix) (fractionalDigits := fractionalDigits) (width := width)
        policy (.exceptional exceptional) =
      .failure (.exceptional .source exceptional) :=
  rfl

/-- The executable converter implements its declared singleton relation. -/
theorem implements_run :
    Quantization.Spec.Implements
      (spec (radix := radix) (fractionalDigits := fractionalDigits) (width := width))
      (run (radix := radix) (fractionalDigits := fractionalDigits) (width := width)) :=
  Quantization.Spec.implements_ofFunction run

/-- The installed decoder exposes the exact stored rational. -/
@[simp, grind =] theorem exactDecoder_run
    (value : ExecFloat.BoundedFixedPoint radix fractionalDigits width) :
    LeanFloat.Floats.ExecFloat.ExactDecoder.run value =
      .finite (ExecFloat.BoundedFixedPoint.toRat value) :=
  rfl

/-- Checked conversion reports `outOfRange` exactly when the checked constructor fails. -/
@[grind =] theorem run_reject_eq (exact : Rat) :
    run (radix := radix) (fractionalDigits := fractionalDigits) (width := width)
        .reject (.finite exact) =
      match ExecFloat.BoundedFixedPoint.ofRat? exact with
      | some rounded => .success rounded (finiteStatus .reject exact rounded)
      | none => .failure .outOfRange :=
  rfl

end Conversion
end ExecFloat.BoundedFixedPoint
end LeanFloat.Floats
