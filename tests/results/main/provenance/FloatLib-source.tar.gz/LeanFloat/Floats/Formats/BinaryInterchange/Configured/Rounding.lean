/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module -- shake: keep-all

public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Rounding.Proof
public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Value.CoreProof
public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.NativeDispatch
public import LeanFloat.Floats.Formats.BinaryInterchange.Configured.Value.Core
public import LeanFloat.Floats.Formats.BinaryInterchange.Status

/-!
# Explicit rounding for configured binary values

Public interface for explicitly rounded configured operations, IEEE status results, and their
packing-correctness theorems.

Execution-only consumers may import `Configured.Rounding.Runtime`; proof developments may import
`Configured.Rounding.Proof`. This compatibility module retains the broader value-proof and status
exports supplied by the original single-module interface.

This entry point also re-exports packing proofs from `Configured.Value.CoreProof` and the IEEE
status definitions. Proof code that only needs value packing, and not arithmetic backend
registration, should import `Configured.Value.CoreProof` directly.
-/
