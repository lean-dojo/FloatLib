/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats.Formats.FixedPoint.Bounded.Configured.Runtime
public import LeanFloat.Floats.ExecFloat.Conversion.Core

/-!
# Bounded fixed-point conversion runtime

Bounded fixed point has three materially different overflow semantics. `reject` returns
`outOfRange`, `wrap` reduces the rounded coefficient modulo the destination width, and `saturate`
clamps it to the signed endpoint. The context-free default is installed separately as checked
conversion, so a type alias can never silently change overflow behavior.
-/

@[expose] public section

namespace LeanFloat.Floats

open LeanFloat.Numerics

namespace ExecFloat.BoundedFixedPoint
namespace Conversion

/-- Overflow policy for conversion into bounded fixed point. -/
inductive OverflowPolicy where
  /-- Reject a rounded coefficient outside the signed destination range. -/
  | reject
  /-- Reduce the rounded coefficient modulo the destination width. -/
  | wrap
  /-- Clamp the rounded coefficient to the signed destination range. -/
  | saturate
  deriving DecidableEq, Repr

variable {radix : Radix} {fractionalDigits width : Nat}

/-- Whether the ties-to-even rounded coefficient fits the signed destination width. -/
@[inline] def coefficientInRange (exact : Rat) : Bool :=
  decide <|
    LeanFloat.Numerics.Representations.FixedInt.InRange width
      (Formats.FixedPoint.Bounded.coefficientOf radix fractionalDigits exact)

/-- Status for a delivered bounded fixed-point conversion. -/
@[inline] def finiteStatus (policy : OverflowPolicy) (exact : Rat)
    (rounded : ExecFloat.BoundedFixedPoint radix fractionalDigits width) :
    LeanFloat.Floats.ExecFloat.ConversionStatus :=
  let overflow := !coefficientInRange (radix := radix)
    (fractionalDigits := fractionalDigits) (width := width) exact
  { inexact := ExecFloat.BoundedFixedPoint.toRat rounded != exact
    overflow
    saturated := overflow && policy == .saturate
    wrapped := overflow && policy == .wrap }

/-- Quantize one finite rational according to the named bounded-overflow policy. -/
@[inline] def quantizeFinite (policy : OverflowPolicy) (exact : Rat) :
    LeanFloat.Floats.ExecFloat.ConversionOutcome
      (ExecFloat.BoundedFixedPoint radix fractionalDigits width) :=
  match policy with
  | .reject =>
      match ExecFloat.BoundedFixedPoint.ofRat? exact with
      | some rounded => .success rounded (finiteStatus policy exact rounded)
      | none => .failure .outOfRange
  | .wrap =>
      let rounded : ExecFloat.BoundedFixedPoint radix fractionalDigits width :=
        ExecFloat.BoundedFixedPoint.ofRatWrapping exact
      .success rounded (finiteStatus policy exact rounded)
  | .saturate =>
      let rounded : ExecFloat.BoundedFixedPoint radix fractionalDigits width :=
        ExecFloat.BoundedFixedPoint.ofRatSaturating exact
      .success rounded (finiteStatus policy exact rounded)

/-- Convert a complete rational observation under an explicit bounded-overflow policy. -/
@[inline] def run (policy : OverflowPolicy) :
    NumericalValue Rat →
      LeanFloat.Floats.ExecFloat.ConversionOutcome
        (ExecFloat.BoundedFixedPoint radix fractionalDigits width)
  | .finite exact => quantizeFinite policy exact
  | .infinity negative => .failure (.infinity .source negative)
  | .exceptional exceptional => .failure (.exceptional .source exceptional)

/-- Retained singleton relation for bounded fixed-point conversion. -/
def spec :
    Quantization.Spec OverflowPolicy (NumericalValue Rat)
      (LeanFloat.Floats.ExecFloat.ConversionOutcome
        (ExecFloat.BoundedFixedPoint radix fractionalDigits width)) :=
  Quantization.Spec.ofFunction run

/-- Bounded fixed-point values decode canonically to their exact stored rational. -/
instance exactDecoder :
    LeanFloat.Floats.ExecFloat.ExactDecoder
      (ExecFloat.BoundedFixedPoint radix fractionalDigits width) Rat where
  decode value := .finite (ExecFloat.BoundedFixedPoint.toRat value)

end Conversion
end ExecFloat.BoundedFixedPoint
end LeanFloat.Floats
