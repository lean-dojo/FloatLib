/-
Copyright (c) 2026 LeanFloat
Released under MIT license as described in the file LICENSE.
Authors: LeanFloat Team
-/

module

public import LeanFloat.Floats

/-!
# LeanFloat

Import `LeanFloat` for configured numerical types, arithmetic, refinement theorems, inspection
commands, and intervals. That import does not install `ExecFloat.Binary.exp`, `Model.exp`,
`Model.pow`, or `MathFunctions`; add
`LeanFloat.Floats.Formats.BinaryInterchange.Configured.Transcendentals` for those names.
Programs operate on `ExecFloat` values; proofs use `ExecFloat.Proof.*_eq_spec` to relate those
same calls to the selected format's reference semantics.

For smaller imports, choose a module under `LeanFloat.Numerics`, `LeanFloat.Kernels`, or
`LeanFloat.Floats`. Examples and developer tools have separate entry points.
-/

@[expose] public section
