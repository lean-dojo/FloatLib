import FloatSpec.src.IEEE754.BinarySingleNaN
import Lean.Meta.Tactic.Delta

set_option maxRecDepth 4096
set_option maxHeartbeats 1600000

/-!
Scratch benchmark of the upstream rounded SingleNaN algorithms.

Lean rejects adding `macro_inline` to imported declarations. Instead, the term
elaborator below delta-expands only the listed upstream bodies. It also
zeta-reduces Real-valued let bindings: Bsqrt's `input := F2R ...` occurs only in
proofs, but an unsubstituted let still triggers the compiler's noncomputability
check. Computational integer let bindings retain their original sharing.
The five `rfl` theorems check definitional equality with the public operations.
-/

open Lean Elab Term Meta in
elab "rounded_body% " t:term : term => do
  let body ← elabTerm t none
  let names := [
    ``FloatSpec.Calc.Bracket.new_location_even,
    ``FloatSpec.Calc.Bracket.new_location_odd,
    ``FloatSpec.Calc.Bracket.new_location,
    ``FloatSpec.Calc.Round.truncate_aux,
    ``FloatSpec.Calc.Round.truncate_triple,
    ``bsn_shr_fexp, ``binary_round_aux, ``binary_round,
    ``Binary.normalize,
    ``FloatSpec.Calc.Div.Fdiv_core, ``FloatSpec.Calc.Div.Fdiv,
    ``SFdiv_core_binary, ``SFsqrt_core_binary,
    ``BinarySingleNaN.Bplus, ``BinarySingleNaN.Bmult,
    ``BinarySingleNaN.Bdiv_finite, ``BinarySingleNaN.Bdiv, ``BinarySingleNaN.Bsqrt]
  let expanded ← deltaExpand (← instantiateMVars body) names.contains
  Core.transform expanded fun e => do
    match e with
    | .letE _ type value body _ =>
        if type.isConstOf ``Real then
          return .visit (body.instantiate1 value)
        else return .continue
    | _ => return .continue

namespace RoundedSFBench

abbrev SF := BinarySingleNaNFloat

variable {p emax : Int} [Prec_gt_0 p] [Prec_lt_emax p emax]

@[inline] def sfAdd (a b : SF p emax) : SF p emax :=
  rounded_body% BinarySingleNaN.Bplus RoundingMode.RNE a b

@[inline] def sfSub (a b : SF p emax) : SF p emax :=
  sfAdd a (BinarySingleNaN.Bopp b)

@[inline] def sfMul (a b : SF p emax) : SF p emax :=
  rounded_body% BinarySingleNaN.Bmult RoundingMode.RNE a b

@[inline] def sfDiv (a b : SF p emax) : SF p emax :=
  rounded_body% BinarySingleNaN.Bdiv RoundingMode.RNE a b

@[inline] def sfSqrt (a : SF p emax) : SF p emax :=
  rounded_body% BinarySingleNaN.Bsqrt RoundingMode.RNE a

theorem sfAdd_eq (a b : SF p emax) :
    sfAdd a b = BinarySingleNaN.Bplus RoundingMode.RNE a b := rfl

theorem sfSub_eq (a b : SF p emax) :
    sfSub a b = BinarySingleNaN.Bminus RoundingMode.RNE a b := rfl

theorem sfMul_eq (a b : SF p emax) :
    sfMul a b = BinarySingleNaN.Bmult RoundingMode.RNE a b := rfl

theorem sfDiv_eq (a b : SF p emax) :
    sfDiv a b = BinarySingleNaN.Bdiv RoundingMode.RNE a b := rfl

theorem sfSqrt_eq (a : SF p emax) :
    sfSqrt a = BinarySingleNaN.Bsqrt RoundingMode.RNE a := rfl

structure Row where
  width : Int
  profile : String
  am : Int
  ae : Int
  bm : Int
  be : Int
  deriving Inhabited

structure Batch where
  width : Int
  profile : String
  rows : Array Row
  deriving Inhabited

def parseInt (s : String) : IO Int :=
  match s.toInt? with
  | some n => pure n
  | none => throw <| IO.userError s!"invalid integer: {s}"

def load (file : System.FilePath) : IO (Array Batch) := do
  let text ← IO.FS.readFile file
  let mut batches : Array Batch := #[]
  for line in text.splitOn "\n" do
    if line.isEmpty then continue
    let [p, profile, am, ae, bm, be] := line.splitOn "\t"
      | throw <| IO.userError "invalid fixture row"
    let width ← parseInt p
    let row := Row.mk width profile (← parseInt am) (← parseInt ae)
      (← parseInt bm) (← parseInt be)
    if !batches.isEmpty && batches.back!.width == width &&
        batches.back!.profile == profile then
      batches := batches.modify (batches.size - 1) fun b => { b with rows := b.rows.push row }
    else
      batches := batches.push ⟨width, profile, #[row]⟩
  return batches

-- Runtime validation supplies the constructor proofs; none of this is timed.
def decode (p emax : Int) (m e : Int) : IO (SF p emax) := do
  if m == 0 then return .B754_zero false
  let (n, normalizedExponent) := shl_align_fexp (prec:=p) (emax:=emax) m.natAbs e
  if hn : 0 < n then
    if hb : specFloat_bounded (prec:=p) (emax:=emax) n normalizedExponent = true then
      return .B754_finite (m < 0) n normalizedExponent hn hb
    else
      throw <| IO.userError s!"invalid finite input: p={p} emax={emax} m={m} e={e}"
  else
    throw <| IO.userError "nonzero signed mantissa has zero magnitude"

def absInput (x : SF p emax) : SF p emax :=
  match x with
  | .B754_zero _ => .B754_zero false
  | .B754_infinity _ => .B754_infinity false
  | .B754_nan => .B754_nan
  | .B754_finite _ m e hm hb => .B754_finite false m e hm hb

def prepare (p emax : Int) (rows : Array Row) : IO (Array (SF p emax × SF p emax)) :=
  rows.mapM fun r => do
    return (← decode p emax r.am r.ae, ← decode p emax r.bm r.be)

-- tag, signed mantissa, exponent, sign flag. The sign flag distinguishes ±0/±∞.
def signature (x : SF p emax) : String :=
  match x with
  | .B754_nan => "nan\t0\t0\tfalse"
  | .B754_zero s => s!"zero\t0\t0\t{s}"
  | .B754_infinity s => s!"inf\t0\t0\t{s}"
  | .B754_finite s m e _ _ =>
      let signed : Int := if s then -(m : Int) else (m : Int)
      s!"finite\t{signed}\t{e}\t{s}"

-- All runtime result fields are consumed; format conversions are outside timing.
@[inline] def digest (x : SF p emax) : UInt64 :=
  let signWord (s : Bool) : UInt64 := if s then 0x9e3779b97f4a7c15 else 0
  match x with
  | .B754_nan => 0x7ff8000000000001
  | .B754_zero s => signWord s
  | .B754_infinity s => 0x7ff0000000000000 ^^^ signWord s
  | .B754_finite s m e _ _ =>
      m.toUInt64 ^^^ signWord s ^^^
        (e.natAbs.toUInt64 * 0x100000001b3) ^^^
        (if e < 0 then 0xd6e8feb86659fd93 else 0)

def operations : List (String × (SF p emax → SF p emax → SF p emax)) :=
  [("add", sfAdd), ("sub", sfSub), ("mul", sfMul), ("div", sfDiv),
    ("sqrt", fun x _ => sfSqrt x)]

@[noinline] def timeOne
    (f : SF p emax → SF p emax → SF p emax)
    (xs : Array (SF p emax × SF p emax)) (reps : Nat) : IO (Nat × UInt64) := do
  let start ← IO.monoNanosNow
  let mut checksum : UInt64 := 0
  for _ in [:reps] do
    for (a, b) in xs do
      checksum := checksum * 1099511628211 + digest (f a b)
  let stop ← IO.monoNanosNow
  return (stop - start, checksum)

def runPrepared (mode : String) (p emax : Int)
    (ops : List (String × (SF p emax → SF p emax → SF p emax))) (batch : Batch)
    (out : IO.FS.Handle) (reps : Nat) (onlyOp : String := "all") : IO Unit := do
  let ops := if onlyOp == "all" then ops else ops.filter fun entry => entry.1 == onlyOp
  let xs ← prepare p emax batch.rows
  let roots := xs.map fun (a, b) => (absInput a, b)
  if mode == "verify" then
    for (a, b) in xs do
      for (op, f) in ops do
        let x := if op == "sqrt" then absInput a else a
        out.putStrLn s!"{p}\t{batch.profile}\t{op}\t{signature (f x b)}"
  else
    for (op, f) in ops do
      let inputs := if op == "sqrt" then roots else xs
      let warm ← timeOne f inputs 1
      let result ← timeOne f inputs reps
      out.putStrLn s!"{p}\t{batch.profile}\t{op}\t{inputs.size * reps}\t{result.1}\t{result.2}"
      out.flush
      IO.println s!"{p} {batch.profile} {op} done (warm checksum {warm.2})"

-- Literal-format entry points match the FloatLib arm's specialization.
instance : Prec_gt_0 (8 : Int) := ⟨by decide⟩
instance : Prec_lt_emax (8 : Int) 16384 := ⟨by decide⟩
@[noinline] def sfAddP8 (a b : SF 8 16384) : SF 8 16384 :=
  sfAdd a b
@[noinline] def sfSubP8 (a b : SF 8 16384) : SF 8 16384 :=
  sfSub a b
@[noinline] def sfMulP8 (a b : SF 8 16384) : SF 8 16384 :=
  sfMul a b
@[noinline] def sfDivP8 (a b : SF 8 16384) : SF 8 16384 :=
  sfDiv a b
@[noinline] def sfSqrtP8 (a _b : SF 8 16384) : SF 8 16384 :=
  sfSqrt a
def opsP8 : List (String × (SF 8 16384 → SF 8 16384 → SF 8 16384)) :=
  [("add", sfAddP8), ("sub", sfSubP8), ("mul", sfMulP8),
    ("div", sfDivP8), ("sqrt", sfSqrtP8)]

instance : Prec_gt_0 (16 : Int) := ⟨by decide⟩
instance : Prec_lt_emax (16 : Int) 16384 := ⟨by decide⟩
@[noinline] def sfAddP16 (a b : SF 16 16384) : SF 16 16384 :=
  sfAdd a b
@[noinline] def sfSubP16 (a b : SF 16 16384) : SF 16 16384 :=
  sfSub a b
@[noinline] def sfMulP16 (a b : SF 16 16384) : SF 16 16384 :=
  sfMul a b
@[noinline] def sfDivP16 (a b : SF 16 16384) : SF 16 16384 :=
  sfDiv a b
@[noinline] def sfSqrtP16 (a _b : SF 16 16384) : SF 16 16384 :=
  sfSqrt a
def opsP16 : List (String × (SF 16 16384 → SF 16 16384 → SF 16 16384)) :=
  [("add", sfAddP16), ("sub", sfSubP16), ("mul", sfMulP16),
    ("div", sfDivP16), ("sqrt", sfSqrtP16)]

instance : Prec_gt_0 (24 : Int) := ⟨by decide⟩
instance : Prec_lt_emax (24 : Int) 16384 := ⟨by decide⟩
@[noinline] def sfAddP24 (a b : SF 24 16384) : SF 24 16384 :=
  sfAdd a b
@[noinline] def sfSubP24 (a b : SF 24 16384) : SF 24 16384 :=
  sfSub a b
@[noinline] def sfMulP24 (a b : SF 24 16384) : SF 24 16384 :=
  sfMul a b
@[noinline] def sfDivP24 (a b : SF 24 16384) : SF 24 16384 :=
  sfDiv a b
@[noinline] def sfSqrtP24 (a _b : SF 24 16384) : SF 24 16384 :=
  sfSqrt a
def opsP24 : List (String × (SF 24 16384 → SF 24 16384 → SF 24 16384)) :=
  [("add", sfAddP24), ("sub", sfSubP24), ("mul", sfMulP24),
    ("div", sfDivP24), ("sqrt", sfSqrtP24)]

instance : Prec_gt_0 (53 : Int) := ⟨by decide⟩
instance : Prec_lt_emax (53 : Int) 16384 := ⟨by decide⟩
@[noinline] def sfAddP53 (a b : SF 53 16384) : SF 53 16384 :=
  sfAdd a b
@[noinline] def sfSubP53 (a b : SF 53 16384) : SF 53 16384 :=
  sfSub a b
@[noinline] def sfMulP53 (a b : SF 53 16384) : SF 53 16384 :=
  sfMul a b
@[noinline] def sfDivP53 (a b : SF 53 16384) : SF 53 16384 :=
  sfDiv a b
@[noinline] def sfSqrtP53 (a _b : SF 53 16384) : SF 53 16384 :=
  sfSqrt a
def opsP53 : List (String × (SF 53 16384 → SF 53 16384 → SF 53 16384)) :=
  [("add", sfAddP53), ("sub", sfSubP53), ("mul", sfMulP53),
    ("div", sfDivP53), ("sqrt", sfSqrtP53)]

instance : Prec_gt_0 (113 : Int) := ⟨by decide⟩
instance : Prec_lt_emax (113 : Int) 16384 := ⟨by decide⟩
@[noinline] def sfAddP113 (a b : SF 113 16384) : SF 113 16384 :=
  sfAdd a b
@[noinline] def sfSubP113 (a b : SF 113 16384) : SF 113 16384 :=
  sfSub a b
@[noinline] def sfMulP113 (a b : SF 113 16384) : SF 113 16384 :=
  sfMul a b
@[noinline] def sfDivP113 (a b : SF 113 16384) : SF 113 16384 :=
  sfDiv a b
@[noinline] def sfSqrtP113 (a _b : SF 113 16384) : SF 113 16384 :=
  sfSqrt a
def opsP113 : List (String × (SF 113 16384 → SF 113 16384 → SF 113 16384)) :=
  [("add", sfAddP113), ("sub", sfSubP113), ("mul", sfMulP113),
    ("div", sfDivP113), ("sqrt", sfSqrtP113)]

instance : Prec_gt_0 (256 : Int) := ⟨by decide⟩
instance : Prec_lt_emax (256 : Int) 16384 := ⟨by decide⟩
@[noinline] def sfAddP256 (a b : SF 256 16384) : SF 256 16384 :=
  sfAdd a b
@[noinline] def sfSubP256 (a b : SF 256 16384) : SF 256 16384 :=
  sfSub a b
@[noinline] def sfMulP256 (a b : SF 256 16384) : SF 256 16384 :=
  sfMul a b
@[noinline] def sfDivP256 (a b : SF 256 16384) : SF 256 16384 :=
  sfDiv a b
@[noinline] def sfSqrtP256 (a _b : SF 256 16384) : SF 256 16384 :=
  sfSqrt a
def opsP256 : List (String × (SF 256 16384 → SF 256 16384 → SF 256 16384)) :=
  [("add", sfAddP256), ("sub", sfSubP256), ("mul", sfMulP256),
    ("div", sfDivP256), ("sqrt", sfSqrtP256)]

instance : Prec_gt_0 (512 : Int) := ⟨by decide⟩
instance : Prec_lt_emax (512 : Int) 16384 := ⟨by decide⟩
@[noinline] def sfAddP512 (a b : SF 512 16384) : SF 512 16384 :=
  sfAdd a b
@[noinline] def sfSubP512 (a b : SF 512 16384) : SF 512 16384 :=
  sfSub a b
@[noinline] def sfMulP512 (a b : SF 512 16384) : SF 512 16384 :=
  sfMul a b
@[noinline] def sfDivP512 (a b : SF 512 16384) : SF 512 16384 :=
  sfDiv a b
@[noinline] def sfSqrtP512 (a _b : SF 512 16384) : SF 512 16384 :=
  sfSqrt a
def opsP512 : List (String × (SF 512 16384 → SF 512 16384 → SF 512 16384)) :=
  [("add", sfAddP512), ("sub", sfSubP512), ("mul", sfMulP512),
    ("div", sfDivP512), ("sqrt", sfSqrtP512)]

instance : Prec_gt_0 (1024 : Int) := ⟨by decide⟩
instance : Prec_lt_emax (1024 : Int) 16384 := ⟨by decide⟩
@[noinline] def sfAddP1024 (a b : SF 1024 16384) : SF 1024 16384 :=
  sfAdd a b
@[noinline] def sfSubP1024 (a b : SF 1024 16384) : SF 1024 16384 :=
  sfSub a b
@[noinline] def sfMulP1024 (a b : SF 1024 16384) : SF 1024 16384 :=
  sfMul a b
@[noinline] def sfDivP1024 (a b : SF 1024 16384) : SF 1024 16384 :=
  sfDiv a b
@[noinline] def sfSqrtP1024 (a _b : SF 1024 16384) : SF 1024 16384 :=
  sfSqrt a
def opsP1024 : List (String × (SF 1024 16384 → SF 1024 16384 → SF 1024 16384)) :=
  [("add", sfAddP1024), ("sub", sfSubP1024), ("mul", sfMulP1024),
    ("div", sfDivP1024), ("sqrt", sfSqrtP1024)]

instance : Prec_gt_0 (2048 : Int) := ⟨by decide⟩
instance : Prec_lt_emax (2048 : Int) 16384 := ⟨by decide⟩
@[noinline] def sfAddP2048 (a b : SF 2048 16384) : SF 2048 16384 :=
  sfAdd a b
@[noinline] def sfSubP2048 (a b : SF 2048 16384) : SF 2048 16384 :=
  sfSub a b
@[noinline] def sfMulP2048 (a b : SF 2048 16384) : SF 2048 16384 :=
  sfMul a b
@[noinline] def sfDivP2048 (a b : SF 2048 16384) : SF 2048 16384 :=
  sfDiv a b
@[noinline] def sfSqrtP2048 (a _b : SF 2048 16384) : SF 2048 16384 :=
  sfSqrt a
def opsP2048 : List (String × (SF 2048 16384 → SF 2048 16384 → SF 2048 16384)) :=
  [("add", sfAddP2048), ("sub", sfSubP2048), ("mul", sfMulP2048),
    ("div", sfDivP2048), ("sqrt", sfSqrtP2048)]

instance : Prec_gt_0 (4096 : Int) := ⟨by decide⟩
instance : Prec_lt_emax (4096 : Int) 16384 := ⟨by decide⟩
@[noinline] def sfAddP4096 (a b : SF 4096 16384) : SF 4096 16384 :=
  sfAdd a b
@[noinline] def sfSubP4096 (a b : SF 4096 16384) : SF 4096 16384 :=
  sfSub a b
@[noinline] def sfMulP4096 (a b : SF 4096 16384) : SF 4096 16384 :=
  sfMul a b
@[noinline] def sfDivP4096 (a b : SF 4096 16384) : SF 4096 16384 :=
  sfDiv a b
@[noinline] def sfSqrtP4096 (a _b : SF 4096 16384) : SF 4096 16384 :=
  sfSqrt a
def opsP4096 : List (String × (SF 4096 16384 → SF 4096 16384 → SF 4096 16384)) :=
  [("add", sfAddP4096), ("sub", sfSubP4096), ("mul", sfMulP4096),
    ("div", sfDivP4096), ("sqrt", sfSqrtP4096)]

def runBatch (mode : String) (emax : Int) (batch : Batch)
    (out : IO.FS.Handle) (reps : Nat) (onlyOp : String := "all") : IO Unit := do
  if emax == 16384 then
    match batch.width with
    | 8 => runPrepared mode 8 16384 opsP8 batch out reps onlyOp
    | 16 => runPrepared mode 16 16384 opsP16 batch out reps onlyOp
    | 24 => runPrepared mode 24 16384 opsP24 batch out reps onlyOp
    | 53 => runPrepared mode 53 16384 opsP53 batch out reps onlyOp
    | 113 => runPrepared mode 113 16384 opsP113 batch out reps onlyOp
    | 256 => runPrepared mode 256 16384 opsP256 batch out reps onlyOp
    | 512 => runPrepared mode 512 16384 opsP512 batch out reps onlyOp
    | 1024 => runPrepared mode 1024 16384 opsP1024 batch out reps onlyOp
    | 2048 => runPrepared mode 2048 16384 opsP2048 batch out reps onlyOp
    | 4096 => runPrepared mode 4096 16384 opsP4096 batch out reps onlyOp
    | _ => throw <| IO.userError s!"unsupported static precision: {batch.width}"
  else
    -- Configurable formats retain the generic API; the agreed run uses static 16384.
    if hp : 0 < batch.width then
      if he : batch.width < emax then
        let ops := @operations batch.width emax ⟨hp⟩ ⟨he⟩
        runPrepared mode batch.width emax ops batch out reps onlyOp
      else throw <| IO.userError "precision must be below emax"
    else throw <| IO.userError "precision must be positive"

end RoundedSFBench

def main (args : List String) : IO Unit := do
  let (mode, input, output, count, emaxText, onlyOp) ← match args with
    | [mode, input, output, count] => pure (mode, input, output, count, "16384", "all")
    | [mode, input, output, count, emax] => pure (mode, input, output, count, emax, "all")
    | [mode, input, output, count, emax, op] => pure (mode, input, output, count, emax, op)
    | _ => throw <| IO.userError "usage: roundedsfbench verify|time INPUT OUTPUT REPETITIONS [EMAX [OP]]"
  unless mode == "verify" || mode == "time" do
    throw <| IO.userError "unknown mode"
  unless ["all", "add", "sub", "mul", "div", "sqrt"].contains onlyOp do
    throw <| IO.userError "unknown operation"
  let count ← RoundedSFBench.parseInt count
  unless 0 < count do throw <| IO.userError "repetitions must be positive"
  let emax ← RoundedSFBench.parseInt emaxText
  let batches ← RoundedSFBench.load input
  let out ← IO.FS.Handle.mk output .write
  for batch in batches do
    RoundedSFBench.runBatch mode emax batch out count.toNat onlyOp
