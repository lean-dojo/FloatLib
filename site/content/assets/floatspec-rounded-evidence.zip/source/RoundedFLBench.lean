import FloatLibBenchmarks.Public.Sweep

open FloatLib.Floats
open FloatLib.Floats.Formats.BinaryInterchange
open FloatLib.Numerics
open FloatLibBenchmarks.Support
open FloatLibBenchmarks.Public.Sweep
open scoped FloatLib.Floats.ExecFloat.Backend.PlanningThroughput

namespace RoundedFLBench

structure Row where
  width : Int
  profile : String
  am : Int
  ae : Int
  bm : Int
  be : Int
  deriving Inhabited

structure Batch where
  width : Int
  profile : String
  rows : Array Row
  deriving Inhabited

def parseInt (s : String) : IO Int :=
  match s.toInt? with
  | some n => pure n
  | none => throw <| IO.userError s!"invalid integer: {s}"

def load (file : System.FilePath) : IO (Array Batch) := do
  let text ← IO.FS.readFile file
  let mut batches : Array Batch := #[]
  for line in text.splitOn "\n" do
    if line.isEmpty then continue
    let [p, profile, am, ae, bm, be] := line.splitOn "\t"
      | throw <| IO.userError "invalid fixture row"
    let width ← parseInt p
    let row := Row.mk width profile (← parseInt am) (← parseInt ae)
      (← parseInt bm) (← parseInt be)
    if !batches.isEmpty && batches.back!.width == width &&
        batches.back!.profile == profile then
      batches := batches.modify (batches.size - 1) fun b => { b with rows := b.rows.push row }
    else
      batches := batches.push ⟨width, profile, #[row]⟩
  return batches

def signature {fmt : FloatFormat} (x : Model fmt) : String :=
  match Model.toDyadic? x with
  | some d =>
    if d.significand == 0 then s!"zero\t0\t0\t{d.negative}"
    else
      let m : Int := if d.negative then -(d.significand : Int) else d.significand
      s!"finite\t{m}\t{d.exponent}\t{d.negative}"
  | none =>
    if Model.isNaN x then "nan\t0\t0\tfalse"
    else s!"inf\t0\t0\t{Model.signBit x}"

abbrev T8 := ExecFloat.Binary (exponentBits := 15) (fractionBits := 7)
abbrev F8 := ExecFloat.Binary.Family 15 7

def input8 (m e : Int) : T8 :=
  BenchmarkCarrier.ofModel (Model := Model) (F := F8) <|
    Model.roundDyadic (ExecFloat.Binary.format 15 7) (Dyadic.ofScaledInt m e)

@[noinline] def add8 (a b : T8) : T8 := ExecFloat.add a b
@[noinline] def sub8 (a b : T8) : T8 := ExecFloat.sub a b
@[noinline] def mul8 (a b : T8) : T8 := ExecFloat.mul a b
@[noinline] def div8 (a b : T8) : T8 := ExecFloat.div a b
@[noinline] def sqrt8 (a _b : T8) : T8 := ExecFloat.sqrt a

@[noinline] def time8 (f : T8 → T8 → T8)
    (xs : Array (T8 × T8)) (reps : Nat) : IO (Nat × UInt64) := do
  let start ← IO.monoNanosNow
  let mut checksum : UInt64 := 0
  for _ in [:reps] do
    for (a, b) in xs do
      checksum := checksum * 1099511628211 + resultBits (f a b)
  let stop ← IO.monoNanosNow
  return (stop - start, checksum)

def run8 (mode : String) (batch : Batch) (out : IO.FS.Handle)
    (reps : Nat) (selected : String) : IO Unit := do
  let xs := batch.rows.map fun r => (input8 r.am r.ae, input8 r.bm r.be)
  let roots := batch.rows.map fun r =>
    (input8 (Int.ofNat r.am.natAbs) r.ae, input8 r.bm r.be)
  let ops : List (String × (T8 → T8 → T8)) :=
    [("add", add8), ("sub", sub8), ("mul", mul8), ("div", div8), ("sqrt", sqrt8)]
  let ops := ops.filter fun pair => selected == "all" || selected == pair.1
  if mode == "verify" then
    for i in [:xs.size] do
      for (op, f) in ops do
        let (a, b) := if op == "sqrt" then roots[i]! else xs[i]!
        let value := BenchmarkCarrier.toModel (Model := Model) (F := F8) (f a b)
        out.putStrLn s!"8\t{batch.profile}\t{op}\t{signature value}"
  else
    for (op, f) in ops do
      let inputs := if op == "sqrt" then roots else xs
      let warm ← time8 f inputs 1
      let result ← time8 f inputs reps
      out.putStrLn s!"8\t{batch.profile}\t{op}\t{inputs.size * reps}\t{result.1}\t{result.2}"
      out.flush
      IO.println s!"8 {batch.profile} {op} done (warm checksum {warm.2})"

abbrev T16 := ExecFloat.Binary (exponentBits := 15) (fractionBits := 15)
abbrev F16 := ExecFloat.Binary.Family 15 15

def input16 (m e : Int) : T16 :=
  BenchmarkCarrier.ofModel (Model := Model) (F := F16) <|
    Model.roundDyadic (ExecFloat.Binary.format 15 15) (Dyadic.ofScaledInt m e)

@[noinline] def add16 (a b : T16) : T16 := ExecFloat.add a b
@[noinline] def sub16 (a b : T16) : T16 := ExecFloat.sub a b
@[noinline] def mul16 (a b : T16) : T16 := ExecFloat.mul a b
@[noinline] def div16 (a b : T16) : T16 := ExecFloat.div a b
@[noinline] def sqrt16 (a _b : T16) : T16 := ExecFloat.sqrt a

@[noinline] def time16 (f : T16 → T16 → T16)
    (xs : Array (T16 × T16)) (reps : Nat) : IO (Nat × UInt64) := do
  let start ← IO.monoNanosNow
  let mut checksum : UInt64 := 0
  for _ in [:reps] do
    for (a, b) in xs do
      checksum := checksum * 1099511628211 + resultBits (f a b)
  let stop ← IO.monoNanosNow
  return (stop - start, checksum)

def run16 (mode : String) (batch : Batch) (out : IO.FS.Handle)
    (reps : Nat) (selected : String) : IO Unit := do
  let xs := batch.rows.map fun r => (input16 r.am r.ae, input16 r.bm r.be)
  let roots := batch.rows.map fun r =>
    (input16 (Int.ofNat r.am.natAbs) r.ae, input16 r.bm r.be)
  let ops : List (String × (T16 → T16 → T16)) :=
    [("add", add16), ("sub", sub16), ("mul", mul16), ("div", div16), ("sqrt", sqrt16)]
  let ops := ops.filter fun pair => selected == "all" || selected == pair.1
  if mode == "verify" then
    for i in [:xs.size] do
      for (op, f) in ops do
        let (a, b) := if op == "sqrt" then roots[i]! else xs[i]!
        let value := BenchmarkCarrier.toModel (Model := Model) (F := F16) (f a b)
        out.putStrLn s!"16\t{batch.profile}\t{op}\t{signature value}"
  else
    for (op, f) in ops do
      let inputs := if op == "sqrt" then roots else xs
      let warm ← time16 f inputs 1
      let result ← time16 f inputs reps
      out.putStrLn s!"16\t{batch.profile}\t{op}\t{inputs.size * reps}\t{result.1}\t{result.2}"
      out.flush
      IO.println s!"16 {batch.profile} {op} done (warm checksum {warm.2})"

abbrev T24 := ExecFloat.Binary (exponentBits := 15) (fractionBits := 23)
abbrev F24 := ExecFloat.Binary.Family 15 23

def input24 (m e : Int) : T24 :=
  BenchmarkCarrier.ofModel (Model := Model) (F := F24) <|
    Model.roundDyadic (ExecFloat.Binary.format 15 23) (Dyadic.ofScaledInt m e)

@[noinline] def add24 (a b : T24) : T24 := ExecFloat.add a b
@[noinline] def sub24 (a b : T24) : T24 := ExecFloat.sub a b
@[noinline] def mul24 (a b : T24) : T24 := ExecFloat.mul a b
@[noinline] def div24 (a b : T24) : T24 := ExecFloat.div a b
@[noinline] def sqrt24 (a _b : T24) : T24 := ExecFloat.sqrt a

@[noinline] def time24 (f : T24 → T24 → T24)
    (xs : Array (T24 × T24)) (reps : Nat) : IO (Nat × UInt64) := do
  let start ← IO.monoNanosNow
  let mut checksum : UInt64 := 0
  for _ in [:reps] do
    for (a, b) in xs do
      checksum := checksum * 1099511628211 + resultBits (f a b)
  let stop ← IO.monoNanosNow
  return (stop - start, checksum)

def run24 (mode : String) (batch : Batch) (out : IO.FS.Handle)
    (reps : Nat) (selected : String) : IO Unit := do
  let xs := batch.rows.map fun r => (input24 r.am r.ae, input24 r.bm r.be)
  let roots := batch.rows.map fun r =>
    (input24 (Int.ofNat r.am.natAbs) r.ae, input24 r.bm r.be)
  let ops : List (String × (T24 → T24 → T24)) :=
    [("add", add24), ("sub", sub24), ("mul", mul24), ("div", div24), ("sqrt", sqrt24)]
  let ops := ops.filter fun pair => selected == "all" || selected == pair.1
  if mode == "verify" then
    for i in [:xs.size] do
      for (op, f) in ops do
        let (a, b) := if op == "sqrt" then roots[i]! else xs[i]!
        let value := BenchmarkCarrier.toModel (Model := Model) (F := F24) (f a b)
        out.putStrLn s!"24\t{batch.profile}\t{op}\t{signature value}"
  else
    for (op, f) in ops do
      let inputs := if op == "sqrt" then roots else xs
      let warm ← time24 f inputs 1
      let result ← time24 f inputs reps
      out.putStrLn s!"24\t{batch.profile}\t{op}\t{inputs.size * reps}\t{result.1}\t{result.2}"
      out.flush
      IO.println s!"24 {batch.profile} {op} done (warm checksum {warm.2})"

abbrev T53 := ExecFloat.Binary (exponentBits := 15) (fractionBits := 52)
abbrev F53 := ExecFloat.Binary.Family 15 52

def input53 (m e : Int) : T53 :=
  BenchmarkCarrier.ofModel (Model := Model) (F := F53) <|
    Model.roundDyadic (ExecFloat.Binary.format 15 52) (Dyadic.ofScaledInt m e)

@[noinline] def add53 (a b : T53) : T53 := ExecFloat.add a b
@[noinline] def sub53 (a b : T53) : T53 := ExecFloat.sub a b
@[noinline] def mul53 (a b : T53) : T53 := ExecFloat.mul a b
@[noinline] def div53 (a b : T53) : T53 := ExecFloat.div a b
@[noinline] def sqrt53 (a _b : T53) : T53 := ExecFloat.sqrt a

@[noinline] def time53 (f : T53 → T53 → T53)
    (xs : Array (T53 × T53)) (reps : Nat) : IO (Nat × UInt64) := do
  let start ← IO.monoNanosNow
  let mut checksum : UInt64 := 0
  for _ in [:reps] do
    for (a, b) in xs do
      checksum := checksum * 1099511628211 + resultBits (f a b)
  let stop ← IO.monoNanosNow
  return (stop - start, checksum)

def run53 (mode : String) (batch : Batch) (out : IO.FS.Handle)
    (reps : Nat) (selected : String) : IO Unit := do
  let xs := batch.rows.map fun r => (input53 r.am r.ae, input53 r.bm r.be)
  let roots := batch.rows.map fun r =>
    (input53 (Int.ofNat r.am.natAbs) r.ae, input53 r.bm r.be)
  let ops : List (String × (T53 → T53 → T53)) :=
    [("add", add53), ("sub", sub53), ("mul", mul53), ("div", div53), ("sqrt", sqrt53)]
  let ops := ops.filter fun pair => selected == "all" || selected == pair.1
  if mode == "verify" then
    for i in [:xs.size] do
      for (op, f) in ops do
        let (a, b) := if op == "sqrt" then roots[i]! else xs[i]!
        let value := BenchmarkCarrier.toModel (Model := Model) (F := F53) (f a b)
        out.putStrLn s!"53\t{batch.profile}\t{op}\t{signature value}"
  else
    for (op, f) in ops do
      let inputs := if op == "sqrt" then roots else xs
      let warm ← time53 f inputs 1
      let result ← time53 f inputs reps
      out.putStrLn s!"53\t{batch.profile}\t{op}\t{inputs.size * reps}\t{result.1}\t{result.2}"
      out.flush
      IO.println s!"53 {batch.profile} {op} done (warm checksum {warm.2})"

abbrev T113 := ExecFloat.Binary (exponentBits := 15) (fractionBits := 112)
abbrev F113 := ExecFloat.Binary.Family 15 112

def input113 (m e : Int) : T113 :=
  BenchmarkCarrier.ofModel (Model := Model) (F := F113) <|
    Model.roundDyadic (ExecFloat.Binary.format 15 112) (Dyadic.ofScaledInt m e)

@[noinline] def add113 (a b : T113) : T113 := ExecFloat.add a b
@[noinline] def sub113 (a b : T113) : T113 := ExecFloat.sub a b
@[noinline] def mul113 (a b : T113) : T113 := ExecFloat.mul a b
@[noinline] def div113 (a b : T113) : T113 := ExecFloat.div a b
@[noinline] def sqrt113 (a _b : T113) : T113 := ExecFloat.sqrt a

@[noinline] def time113 (f : T113 → T113 → T113)
    (xs : Array (T113 × T113)) (reps : Nat) : IO (Nat × UInt64) := do
  let start ← IO.monoNanosNow
  let mut checksum : UInt64 := 0
  for _ in [:reps] do
    for (a, b) in xs do
      checksum := checksum * 1099511628211 + resultBits (f a b)
  let stop ← IO.monoNanosNow
  return (stop - start, checksum)

def run113 (mode : String) (batch : Batch) (out : IO.FS.Handle)
    (reps : Nat) (selected : String) : IO Unit := do
  let xs := batch.rows.map fun r => (input113 r.am r.ae, input113 r.bm r.be)
  let roots := batch.rows.map fun r =>
    (input113 (Int.ofNat r.am.natAbs) r.ae, input113 r.bm r.be)
  let ops : List (String × (T113 → T113 → T113)) :=
    [("add", add113), ("sub", sub113), ("mul", mul113), ("div", div113), ("sqrt", sqrt113)]
  let ops := ops.filter fun pair => selected == "all" || selected == pair.1
  if mode == "verify" then
    for i in [:xs.size] do
      for (op, f) in ops do
        let (a, b) := if op == "sqrt" then roots[i]! else xs[i]!
        let value := BenchmarkCarrier.toModel (Model := Model) (F := F113) (f a b)
        out.putStrLn s!"113\t{batch.profile}\t{op}\t{signature value}"
  else
    for (op, f) in ops do
      let inputs := if op == "sqrt" then roots else xs
      let warm ← time113 f inputs 1
      let result ← time113 f inputs reps
      out.putStrLn s!"113\t{batch.profile}\t{op}\t{inputs.size * reps}\t{result.1}\t{result.2}"
      out.flush
      IO.println s!"113 {batch.profile} {op} done (warm checksum {warm.2})"

abbrev T256 := ExecFloat.Binary (exponentBits := 15) (fractionBits := 255)
abbrev F256 := ExecFloat.Binary.Family 15 255

def input256 (m e : Int) : T256 :=
  BenchmarkCarrier.ofModel (Model := Model) (F := F256) <|
    Model.roundDyadic (ExecFloat.Binary.format 15 255) (Dyadic.ofScaledInt m e)

@[noinline] def add256 (a b : T256) : T256 := ExecFloat.add a b
@[noinline] def sub256 (a b : T256) : T256 := ExecFloat.sub a b
@[noinline] def mul256 (a b : T256) : T256 := ExecFloat.mul a b
@[noinline] def div256 (a b : T256) : T256 := ExecFloat.div a b
@[noinline] def sqrt256 (a _b : T256) : T256 := ExecFloat.sqrt a

@[noinline] def time256 (f : T256 → T256 → T256)
    (xs : Array (T256 × T256)) (reps : Nat) : IO (Nat × UInt64) := do
  let start ← IO.monoNanosNow
  let mut checksum : UInt64 := 0
  for _ in [:reps] do
    for (a, b) in xs do
      checksum := checksum * 1099511628211 + resultBits (f a b)
  let stop ← IO.monoNanosNow
  return (stop - start, checksum)

def run256 (mode : String) (batch : Batch) (out : IO.FS.Handle)
    (reps : Nat) (selected : String) : IO Unit := do
  let xs := batch.rows.map fun r => (input256 r.am r.ae, input256 r.bm r.be)
  let roots := batch.rows.map fun r =>
    (input256 (Int.ofNat r.am.natAbs) r.ae, input256 r.bm r.be)
  let ops : List (String × (T256 → T256 → T256)) :=
    [("add", add256), ("sub", sub256), ("mul", mul256), ("div", div256), ("sqrt", sqrt256)]
  let ops := ops.filter fun pair => selected == "all" || selected == pair.1
  if mode == "verify" then
    for i in [:xs.size] do
      for (op, f) in ops do
        let (a, b) := if op == "sqrt" then roots[i]! else xs[i]!
        let value := BenchmarkCarrier.toModel (Model := Model) (F := F256) (f a b)
        out.putStrLn s!"256\t{batch.profile}\t{op}\t{signature value}"
  else
    for (op, f) in ops do
      let inputs := if op == "sqrt" then roots else xs
      let warm ← time256 f inputs 1
      let result ← time256 f inputs reps
      out.putStrLn s!"256\t{batch.profile}\t{op}\t{inputs.size * reps}\t{result.1}\t{result.2}"
      out.flush
      IO.println s!"256 {batch.profile} {op} done (warm checksum {warm.2})"

abbrev T512 := ExecFloat.Binary (exponentBits := 15) (fractionBits := 511)
abbrev F512 := ExecFloat.Binary.Family 15 511

def input512 (m e : Int) : T512 :=
  BenchmarkCarrier.ofModel (Model := Model) (F := F512) <|
    Model.roundDyadic (ExecFloat.Binary.format 15 511) (Dyadic.ofScaledInt m e)

@[noinline] def add512 (a b : T512) : T512 := ExecFloat.add a b
@[noinline] def sub512 (a b : T512) : T512 := ExecFloat.sub a b
@[noinline] def mul512 (a b : T512) : T512 := ExecFloat.mul a b
@[noinline] def div512 (a b : T512) : T512 := ExecFloat.div a b
@[noinline] def sqrt512 (a _b : T512) : T512 := ExecFloat.sqrt a

@[noinline] def time512 (f : T512 → T512 → T512)
    (xs : Array (T512 × T512)) (reps : Nat) : IO (Nat × UInt64) := do
  let start ← IO.monoNanosNow
  let mut checksum : UInt64 := 0
  for _ in [:reps] do
    for (a, b) in xs do
      checksum := checksum * 1099511628211 + resultBits (f a b)
  let stop ← IO.monoNanosNow
  return (stop - start, checksum)

def run512 (mode : String) (batch : Batch) (out : IO.FS.Handle)
    (reps : Nat) (selected : String) : IO Unit := do
  let xs := batch.rows.map fun r => (input512 r.am r.ae, input512 r.bm r.be)
  let roots := batch.rows.map fun r =>
    (input512 (Int.ofNat r.am.natAbs) r.ae, input512 r.bm r.be)
  let ops : List (String × (T512 → T512 → T512)) :=
    [("add", add512), ("sub", sub512), ("mul", mul512), ("div", div512), ("sqrt", sqrt512)]
  let ops := ops.filter fun pair => selected == "all" || selected == pair.1
  if mode == "verify" then
    for i in [:xs.size] do
      for (op, f) in ops do
        let (a, b) := if op == "sqrt" then roots[i]! else xs[i]!
        let value := BenchmarkCarrier.toModel (Model := Model) (F := F512) (f a b)
        out.putStrLn s!"512\t{batch.profile}\t{op}\t{signature value}"
  else
    for (op, f) in ops do
      let inputs := if op == "sqrt" then roots else xs
      let warm ← time512 f inputs 1
      let result ← time512 f inputs reps
      out.putStrLn s!"512\t{batch.profile}\t{op}\t{inputs.size * reps}\t{result.1}\t{result.2}"
      out.flush
      IO.println s!"512 {batch.profile} {op} done (warm checksum {warm.2})"

abbrev T1024 := ExecFloat.Binary (exponentBits := 15) (fractionBits := 1023)
abbrev F1024 := ExecFloat.Binary.Family 15 1023

def input1024 (m e : Int) : T1024 :=
  BenchmarkCarrier.ofModel (Model := Model) (F := F1024) <|
    Model.roundDyadic (ExecFloat.Binary.format 15 1023) (Dyadic.ofScaledInt m e)

@[noinline] def add1024 (a b : T1024) : T1024 := ExecFloat.add a b
@[noinline] def sub1024 (a b : T1024) : T1024 := ExecFloat.sub a b
@[noinline] def mul1024 (a b : T1024) : T1024 := ExecFloat.mul a b
@[noinline] def div1024 (a b : T1024) : T1024 := ExecFloat.div a b
@[noinline] def sqrt1024 (a _b : T1024) : T1024 := ExecFloat.sqrt a

@[noinline] def time1024 (f : T1024 → T1024 → T1024)
    (xs : Array (T1024 × T1024)) (reps : Nat) : IO (Nat × UInt64) := do
  let start ← IO.monoNanosNow
  let mut checksum : UInt64 := 0
  for _ in [:reps] do
    for (a, b) in xs do
      checksum := checksum * 1099511628211 + resultBits (f a b)
  let stop ← IO.monoNanosNow
  return (stop - start, checksum)

def run1024 (mode : String) (batch : Batch) (out : IO.FS.Handle)
    (reps : Nat) (selected : String) : IO Unit := do
  let xs := batch.rows.map fun r => (input1024 r.am r.ae, input1024 r.bm r.be)
  let roots := batch.rows.map fun r =>
    (input1024 (Int.ofNat r.am.natAbs) r.ae, input1024 r.bm r.be)
  let ops : List (String × (T1024 → T1024 → T1024)) :=
    [("add", add1024), ("sub", sub1024), ("mul", mul1024), ("div", div1024), ("sqrt", sqrt1024)]
  let ops := ops.filter fun pair => selected == "all" || selected == pair.1
  if mode == "verify" then
    for i in [:xs.size] do
      for (op, f) in ops do
        let (a, b) := if op == "sqrt" then roots[i]! else xs[i]!
        let value := BenchmarkCarrier.toModel (Model := Model) (F := F1024) (f a b)
        out.putStrLn s!"1024\t{batch.profile}\t{op}\t{signature value}"
  else
    for (op, f) in ops do
      let inputs := if op == "sqrt" then roots else xs
      let warm ← time1024 f inputs 1
      let result ← time1024 f inputs reps
      out.putStrLn s!"1024\t{batch.profile}\t{op}\t{inputs.size * reps}\t{result.1}\t{result.2}"
      out.flush
      IO.println s!"1024 {batch.profile} {op} done (warm checksum {warm.2})"

abbrev T2048 := ExecFloat.Binary (exponentBits := 15) (fractionBits := 2047)
abbrev F2048 := ExecFloat.Binary.Family 15 2047

def input2048 (m e : Int) : T2048 :=
  BenchmarkCarrier.ofModel (Model := Model) (F := F2048) <|
    Model.roundDyadic (ExecFloat.Binary.format 15 2047) (Dyadic.ofScaledInt m e)

@[noinline] def add2048 (a b : T2048) : T2048 := ExecFloat.add a b
@[noinline] def sub2048 (a b : T2048) : T2048 := ExecFloat.sub a b
@[noinline] def mul2048 (a b : T2048) : T2048 := ExecFloat.mul a b
@[noinline] def div2048 (a b : T2048) : T2048 := ExecFloat.div a b
@[noinline] def sqrt2048 (a _b : T2048) : T2048 := ExecFloat.sqrt a

@[noinline] def time2048 (f : T2048 → T2048 → T2048)
    (xs : Array (T2048 × T2048)) (reps : Nat) : IO (Nat × UInt64) := do
  let start ← IO.monoNanosNow
  let mut checksum : UInt64 := 0
  for _ in [:reps] do
    for (a, b) in xs do
      checksum := checksum * 1099511628211 + resultBits (f a b)
  let stop ← IO.monoNanosNow
  return (stop - start, checksum)

def run2048 (mode : String) (batch : Batch) (out : IO.FS.Handle)
    (reps : Nat) (selected : String) : IO Unit := do
  let xs := batch.rows.map fun r => (input2048 r.am r.ae, input2048 r.bm r.be)
  let roots := batch.rows.map fun r =>
    (input2048 (Int.ofNat r.am.natAbs) r.ae, input2048 r.bm r.be)
  let ops : List (String × (T2048 → T2048 → T2048)) :=
    [("add", add2048), ("sub", sub2048), ("mul", mul2048), ("div", div2048), ("sqrt", sqrt2048)]
  let ops := ops.filter fun pair => selected == "all" || selected == pair.1
  if mode == "verify" then
    for i in [:xs.size] do
      for (op, f) in ops do
        let (a, b) := if op == "sqrt" then roots[i]! else xs[i]!
        let value := BenchmarkCarrier.toModel (Model := Model) (F := F2048) (f a b)
        out.putStrLn s!"2048\t{batch.profile}\t{op}\t{signature value}"
  else
    for (op, f) in ops do
      let inputs := if op == "sqrt" then roots else xs
      let warm ← time2048 f inputs 1
      let result ← time2048 f inputs reps
      out.putStrLn s!"2048\t{batch.profile}\t{op}\t{inputs.size * reps}\t{result.1}\t{result.2}"
      out.flush
      IO.println s!"2048 {batch.profile} {op} done (warm checksum {warm.2})"

abbrev T4096 := ExecFloat.Binary (exponentBits := 15) (fractionBits := 4095)
abbrev F4096 := ExecFloat.Binary.Family 15 4095

def input4096 (m e : Int) : T4096 :=
  BenchmarkCarrier.ofModel (Model := Model) (F := F4096) <|
    Model.roundDyadic (ExecFloat.Binary.format 15 4095) (Dyadic.ofScaledInt m e)

@[noinline] def add4096 (a b : T4096) : T4096 := ExecFloat.add a b
@[noinline] def sub4096 (a b : T4096) : T4096 := ExecFloat.sub a b
@[noinline] def mul4096 (a b : T4096) : T4096 := ExecFloat.mul a b
@[noinline] def div4096 (a b : T4096) : T4096 := ExecFloat.div a b
@[noinline] def sqrt4096 (a _b : T4096) : T4096 := ExecFloat.sqrt a

@[noinline] def time4096 (f : T4096 → T4096 → T4096)
    (xs : Array (T4096 × T4096)) (reps : Nat) : IO (Nat × UInt64) := do
  let start ← IO.monoNanosNow
  let mut checksum : UInt64 := 0
  for _ in [:reps] do
    for (a, b) in xs do
      checksum := checksum * 1099511628211 + resultBits (f a b)
  let stop ← IO.monoNanosNow
  return (stop - start, checksum)

def run4096 (mode : String) (batch : Batch) (out : IO.FS.Handle)
    (reps : Nat) (selected : String) : IO Unit := do
  let xs := batch.rows.map fun r => (input4096 r.am r.ae, input4096 r.bm r.be)
  let roots := batch.rows.map fun r =>
    (input4096 (Int.ofNat r.am.natAbs) r.ae, input4096 r.bm r.be)
  let ops : List (String × (T4096 → T4096 → T4096)) :=
    [("add", add4096), ("sub", sub4096), ("mul", mul4096), ("div", div4096), ("sqrt", sqrt4096)]
  let ops := ops.filter fun pair => selected == "all" || selected == pair.1
  if mode == "verify" then
    for i in [:xs.size] do
      for (op, f) in ops do
        let (a, b) := if op == "sqrt" then roots[i]! else xs[i]!
        let value := BenchmarkCarrier.toModel (Model := Model) (F := F4096) (f a b)
        out.putStrLn s!"4096\t{batch.profile}\t{op}\t{signature value}"
  else
    for (op, f) in ops do
      let inputs := if op == "sqrt" then roots else xs
      let warm ← time4096 f inputs 1
      let result ← time4096 f inputs reps
      out.putStrLn s!"4096\t{batch.profile}\t{op}\t{inputs.size * reps}\t{result.1}\t{result.2}"
      out.flush
      IO.println s!"4096 {batch.profile} {op} done (warm checksum {warm.2})"

end RoundedFLBench

def main (args : List String) : IO Unit := do
  let selected := args[4]?.getD "all"
  let [mode, input, output, count] := args.take 4
    | throw <| IO.userError "usage: roundedflbench verify|time INPUT OUTPUT REPETITIONS [OP]"
  unless mode == "verify" || mode == "time" do
    throw <| IO.userError "unknown mode"
  let count ← RoundedFLBench.parseInt count
  unless 0 < count do throw <| IO.userError "repetitions must be positive"
  let batches ← RoundedFLBench.load input
  let out ← IO.FS.Handle.mk output .write
  for batch in batches do
    match batch.width with
    | 8 => RoundedFLBench.run8 mode batch out count.toNat selected
    | 16 => RoundedFLBench.run16 mode batch out count.toNat selected
    | 24 => RoundedFLBench.run24 mode batch out count.toNat selected
    | 53 => RoundedFLBench.run53 mode batch out count.toNat selected
    | 113 => RoundedFLBench.run113 mode batch out count.toNat selected
    | 256 => RoundedFLBench.run256 mode batch out count.toNat selected
    | 512 => RoundedFLBench.run512 mode batch out count.toNat selected
    | 1024 => RoundedFLBench.run1024 mode batch out count.toNat selected
    | 2048 => RoundedFLBench.run2048 mode batch out count.toNat selected
    | 4096 => RoundedFLBench.run4096 mode batch out count.toNat selected
    | _ => throw <| IO.userError "unsupported benchmark precision"
