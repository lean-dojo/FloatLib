FloatSpec execution audit — commit `158263e983ec3925e02b10f5b312498bf414e0f1`

The faithful arbitrary-precision `BinarySingleNaN.Bplus/Bmult/Bdiv/Bsqrt`
definitions have computational integer bodies, despite explicit `noncomputable`
markers. Direct compiled calls are blocked by those markers and marked helpers.
Do **not** conclude that these operations require executing mathematical reals:
that is true of the older real-based APIs, not the faithful integer path.

Paths below are relative to `<scratch>/floatlib-floatspec-benchmark-obgwshab/FloatSpec`.
Upstream algorithm sources were read only. After authorization expanded, the
scratch `RoundedSFBench.lean` harness and its executable target were added.
The authorized native target build succeeded with Lean `v4.34.0-rc2`.
The full verification attempt was stopped at 8,675 completed output rows because
add/sub have the exponential runtime conversion described below. Its output is
preserved as `rounded-sf-verification.partial.tsv`; no full verification is active.
Only explicitly requested isolated diagnostic timings were run, not the published
benchmark batches. The parent owns cluster execution and comparison timings.

| Faithful public operation | Definition | Runtime dependency |
| --- | --- | --- |
| `BinarySingleNaN.Bplus` | `FloatSpec/src/IEEE754/BinarySingleNaN.lean:8184` | `Fplus_naive` → `Binary.normalize` → root `binary_round` |
| `BinarySingleNaN.Bmult` | same file, `8152` | integer mantissa product → root `binary_round_aux` |
| `BinarySingleNaN.Bdiv` | same file, `8296` | `BinarySingleNaN.Bdiv_finite` (`8279`) → `SFdiv_core_binary` (`4100`) → `FloatSpec.Calc.Div.Fdiv` |
| `BinarySingleNaN.Bsqrt` | same file, `8325` | `SFsqrt_core_binary` (`4186`) → `FloatSpec.Calc.Sqrt.Fsqrt`, then root `binary_round_aux` |

The NaN-payload-preserving counterparts `Binary.Bplus`, `Binary.Bmult`,
`Binary.Bdiv`, `Binary.Bsqrt` are in the same file at `7285`, `7589`, `7651`,
`6287`; they share the same integer rounding chain. Their extra arguments are
NaN handlers. The `FloatSpec.IEEE754.BinarySingleNaN.Source` wrappers at
`FloatSpec/src/IEEE754/BinarySingleNaNSourceFacade.lean:1725` (`Bmult`),
`1734` (`Bplus`), `1761` (`Bdiv`), `1770` (`Bsqrt`) only convert rounding modes
and call the faithful operations.

The exact dependency boundary:

- In `FloatSpec/src/IEEE754/BinarySingleNaN.lean`, `binary_round_aux:2554`
  calls `bsn_shr_fexp:2502` twice, with `choice_mode:1798` between them, then
  `binary_fit_aux:2362`. These perform truncation, mode-sensitive increment,
  carry renormalization and overflow selection. `binary_round:2609` adds
  `shl_align_fexp`; `Binary.normalize:7724` handles signed mantissas and zero.
- `bsn_shr_fexp` → `FloatSpec.Calc.Round.truncate_triple`
  (`FloatSpec/src/Calc/Round.lean:138`) → `truncate_aux` (`66`) →
  `FloatSpec.Calc.Bracket.new_location`
  (`FloatSpec/src/Calc/Bracket.lean:1629`) → `new_location_even:865` /
  `new_location_odd:1215`. Every one is explicitly `noncomputable`, but the
  bodies use only integer arithmetic and constructor/Ordering cases.
- `FloatSpec.Calc.Div.Fdiv` (`FloatSpec/src/Calc/Div.lean:408`) →
  `Fdiv_core:112` → `FloatSpec.Core.Zaux.Z_div_eucl`
  (`FloatSpec/src/Core/Zaux.lean:1934`, using `Int.fdiv`) and `new_location`.
  **It does not call** the genuinely real-based
  `Fdiv_core_from_real_midpoint_payload:91`.
- `FloatSpec.Calc.Sqrt.Fsqrt` (`FloatSpec/src/Calc/Sqrt.lean:630`) →
  `Fsqrt_core:304` uses integer powers, `Int.sqrt`, remainder and comparisons.
  Both are ordinary executable `def`s. The wrapper `SFsqrt_core_binary` is
  explicitly marked despite simply calling `Fsqrt`.
- `Zdigits` (`FloatSpec/src/Core/Digits.lean:4192`), root `shl_align_fexp`
  (`FloatSpec/src/IEEE754/Binary.lean:4792`), `choice_mode`, `binary_fit_aux`,
  `shr_record_of_loc:5059`, and `loc_of_shr_record:5051` are ordinary
  computational definitions. No `csimp`, `implemented_by`, `macro_inline`, or
  extern override was found in the FloatSpec Lean sources.
- The real `input`, `Real.sqrt input`, and correctness theorems inside faithful
  `Bsqrt` occur only in erased proofs. Likewise the classical case splits in
  `Binary.Bmult/Bdiv` construct proofs, not returned data. Their presence is
  not intrinsically required runtime computations. However, the explicit
  Real-valued `let input := F2R ...` in `Bsqrt` does trigger the compiler
  noncomputability check before unused-let elimination. Substituting this
  let-bound value into its proof uses removes that compiler blocker; the
  resulting wrapper remains definitionally equal to the upstream operation.

Actual real-based APIs to avoid conflating with the above:

- `BinarySingleNaNBridge.Bplus/Bmult/Bdiv/Bsqrt` in
  `FloatSpec/src/IEEE754/Binary.lean:1268/1260/1373/1402` compute with `B2R`,
  `roundReal:1253`, `round_to_generic`, and `real_to_FullFloat:1081`.
  Root `Bplus/Bmult/Bdiv/Bsqrt` in that file (`1456/1504/1544/1563`) use this
  older bridge.
- The blocking real chain includes `FloatSpec.Core.Generic_fmt.roundR`
  (`FloatSpec/src/Core/Generic_fmt.lean:2634`), `scaled_mantissa:193`,
  `cexp:176`, `FloatSpec.Core.Raux.mag`
  (`FloatSpec/src/Core/Raux.lean:3842`, real logarithms/floor), and
  `Zfloor/Zceil/Ztrunc:2203/2207/2211`. Removing keywords alone cannot compile
  that chain.
- `FloatSpec.Calc.Round.round` (`FloatSpec/src/Calc/Round.lean:56`) takes
  `ℝ` and calls `roundR`; it is not the integer IEEE rounding implementation.
- `ExperimentalBinaryRound.binary_round_aux`
  (`FloatSpec/src/IEEE754/Binary.lean:5107`) discards the rounding mode/location.
  It is explicitly documented as a partial helper, not a complete rounded
  operation.

Other executable operations, with their limits:

- FloatSpec itself has arbitrary-precision finite-input rounding-to-integer:
  root `SFnearbyint_binary_aux` / `SFnearbyint_binary` at
  `FloatSpec/src/IEEE754/BinarySingleNaN.lean:1840/1855`, with semantic theorem
  `Bnearbyint_correct_aux_nat:2111`. These are ordinary `def`s; they are not
  substitutes for rounded addition/multiplication/division/square root.
- `FloatSpec.Calc.Operations.Fplus/Fmult` at
  `FloatSpec/src/Calc/Operations.lean:191/494` are exact and unrounded;
  `pff_add/pff_mul` at `FloatSpec/src/Pff/Pff.lean:21955/21959` only wrap them.
  `Calc.Sqrt.Fsqrt` returns a mantissa/exponent/location triple, before final
  rounding. These are not complete IEEE-operation benchmark substitutes.
- Lean's bundled model **does** provide executable arbitrary-format rounded
  `Float.Model.UnpackedFloat.add/mul/div/sqrt`. Under
  `<home>/.elan/toolchains/leanprover--lean4---v4.34.0-rc2/src/lean/`,
  their definitions are `Init/Data/Float/Model/Unpacked/Operations/Add.lean:21`,
  `Mul.lean:21`, `Div.lean:46`, and `Sqrt.lean:43`. `Format`
  (`Init/Data/Float/Model/Format/Basic.lean:29`) accepts arbitrary natural
  mantissa/exponent bit counts. Rounding is nearest-even; `pack`
  (`Init/Data/Float/Model/Unpacked/Pack/Basic.lean:45`) completes finite overflow
  handling. I successfully compiled generic wrappers `pack f (add f x y)`,
  likewise `mul/div/sqrt`, without evaluating them. This is Lean's model, not
  FloatSpec's implementation; do not report its timings as FloatSpec timings.

Compiler distinction and minimal probes:

Explicit `noncomputable def` suppresses code generation even for `n + 1`.
Merely putting an otherwise computational `def` in `noncomputable section`
does not suppress successful compilation. Both behaviors were confirmed on
the pinned compiler. Relevant compiler source: `Lean/Elab/PreDefinition/Basic.lean:134`
and `Lean/Compiler/LCNF/ToLCNF.lean:440`.

The standalone `[macro_inline]` example worked only for same-module definitions.
**The actual imported-module attribute probe failed**: Lean rejects adding
`[macro_inline]` to declarations from imported modules. See
`logs/rounded-inline-probe.log`. Do not use the previously proposed attributes.

The working `RoundedUnfoldProbe.lean` uses `Lean.Meta.deltaExpand` with an exact
allowlist of the upstream definitions, followed by `Lean.Core.transform` to
zeta-reduce only Real-valued let bindings. Integer let bindings retain sharing.
Do not unfold generated `.match_*` auxiliaries: that exposes recursors which
the compiler cannot execute directly. Do not expand the entire prefix closure.

The exact allowlist is at `FloatSpec/RoundedSFBench.lean:22`. All four generic
wrappers compiled, and each `rfl` equality to the original public operation
passed (`logs/rounded-unfold-zeta-probe.log`, exit 0). The five RNE harness
wrappers, including subtraction, also compile and have `rfl` equality theorems.
They are inline, with 50 noinline monomorphic entry points across precisions
8, 16, 24, 53, 113, 256, 512, 1024, 2048, 4096 and fixed emax=16384.
`logs/rounded-sfbench-static-compile.log` is empty (successful exit 0).

Minimal constructor syntax (checked at runtime, outside timing):

```lean
let (n, e') := shl_align_fexp (prec:=p) (emax:=emax) m.natAbs e
if hn : 0 < n then
  if hb : specFloat_bounded (prec:=p) (emax:=emax) n e' = true then
    return BinarySingleNaNFloat.B754_finite (m < 0) n e' hn hb
  else throw <| IO.userError "invalid finite input"
else throw <| IO.userError "zero mantissa"
```

Handle `m=0` first with `.B754_zero false`. The shared signed-Int inputs cannot
encode negative zero. There are 120 nonzero short-mantissa operands (such as
±1), so raw constructor validation without the upstream exact left alignment
would reject them. For this format, minimum stored exponent is `3-16384-p`;
maximum stored exponent is `16384-p`. Full p-bit inputs are canonical except
for the exact short-mantissa padding above.

`RoundedSFBench.lean` CLI: `verify|time INPUT OUTPUT REPS [EMAX [OP]]`. OP is
`all`, `add`, `sub`, `mul`, `div`, or `sqrt`, selected before preparation/timing. The agreed
EMAX=16384 path selects monomorphic functions before timing; the optional
other-EMAX path uses the generic operations. Verification output is seven TSV
columns `p profile op tag signedMantissa exponent negative` (Boolean sign).
Timing output is six columns `p profile op calls nanoseconds checksum`.
Operations: RNE add/sub/mul/div/sqrt; sqrt gets the absolute first input.
One warmup pass; REPS timed passes. Every result's tag, sign, mantissa and
exponent is consumed by the checksum. No arithmetic algorithm was replaced.

Native runtime blocker and frozen build receipt:

- `BinarySingleNaN.Bplus`, at `FloatSpec/src/IEEE754/BinarySingleNaN.lean:8206`,
  calls `Binary.B2BSN (Binary.normalize ...)`. `Binary.normalize:7724` calls
  `Binary.standardFloatToBinaryFloatOfNotNaN:6263`, whose finite branch at
  `:6280` calls root `binaryPositiveOfNat`.
- `FloatSpec/src/IEEE754/Binary.lean:541` calls private
  `binaryPositiveOfNatSucc:529` on `n-1`. The recursive equation at `:531`
  decrements the Nat by one and increments the resulting Positive. Thus
  converting a normalized p-bit mantissa requires at least `2^(p-1)-1`
  recursive steps. This is runtime data conversion, not proof overhead.
  Subtraction has the same path unless cancellation or a special case avoids it.
- Mul/div/sqrt construct the Nat-backed SingleNaN carrier directly and avoid
  this Positive roundtrip. The `mxp`/`myp` Positive values in Bdiv's source are
  used only in proofs and disappear from the generated harness code.
- Generated C confirms the retained conversion:
  `.lake/build/ir/RoundedSFBench.c:15278` (static p8 add), `:26043` (static p24
  sub), and `.lake/build/ir/FloatSpec/src/IEEE754/Binary.c:4340` (recursive
  decrement-by-one call). No runtime `F2R`, `Real.sqrt`, or real-magnitude
  references occur in the harness C.
- `.lake/build/ir/RoundedSFBench.c:14104`, `:60278`, and `:61877` show the static
  add-p8/div-p4096/sqrt-p4096 entry points accepting only the two operands.
  `timeOne___redArg:13088` accepts only the function, prepared array, and reps.
  Its two clock calls are at `:13092` and `:13124`; the inner loop at `:12935`
  calls the already-selected function with `lean_apply_2`. Parsing, normalization,
  precision selection, operation filtering, and sqrt input sign preparation are
  outside these clocks.
- Isolated diagnostic runs used one actual shared fixture per precision,
  one warmup call, and one measured call. These are not published comparison
  timings. Add p8/p16/p24: 3,750 / 651,351 / 183,675,206 ns. A separate nonzero
  subtraction fixture gave 3,164 / 739,358 / 268,848,115 ns. The first subtraction
  diagnostic canceled to zero and is retained separately, not treated as evidence
  for the finite conversion cost.
- Mul/div/sqrt each completed the selected fixture at all ten precisions.
  At p4096 their respective diagnostic durations were
  6,975,936 / 12,084,570 / 6,535,329 ns. Diagnostic files are
  `../rounded-sf-diagnostic-*.tsv`. Reducing repetitions cannot make normal
  p53–4096 add/sub practical; parallel execution does not remove this per-call
  cost. Altering the Positive conversion would need a separately disclosed
  implementation optimization and is not part of this frozen harness.
- Final selector build log: `../logs/rounded-sfbench-build-selector.log`, exit 0,
  `Build completed successfully (6122 jobs)`. Source and binary are frozen.
  `RoundedSFBench.lean` SHA-256:
  `e3976c193d1345b6205e7435ee8d1c7c2ee6705c85bca0d20f598e5ae1118ed0`.
  `.lake/build/bin/roundedsfbench` SHA-256:
  `048a820fd5a0ccb5e273fdfc3d2a75f81b81a2667115922b788d97b82f706141`.

ExactBench source audit (read-only, no harness edits/builds):

- `FloatSpec/ExactBench.lean:10-15` directly wraps upstream exact add/sub/mul;
  it correctly labels these as unrounded, not complete rounded arithmetic.
- `:98-99` constructs both libraries' inputs outside timing. `:65-81` times
  operation/function-call/loop/checksum overhead together. Each result is
  consumed, and noinline entry points prevent eliminating whole operations.
  The digest excludes exponent, so it is not itself a full correctness check.
- `:83-93` writes verification outputs; it does not assert correctness inside
  Lean. `check_results.py:17-32` independently checks both outputs against
  Python integer alignment/product; `:35-55` checks timed digests against
  verified representation-specific outputs. Different representations can
  legitimately have different digests.
- `:101-115` uses four warmup passes, then one timed batch, alternating first
  library by case. `protocol.json` matches 256 fixtures × 1024 repetitions,
  three operations, three gap profiles and ten widths (90 timed cases).
- The Python checker checks total row counts but not uniqueness/completeness
  of every `(p,profile,op)` group, and timings alone do not enforce that verify
  ran first. These are harness limitations, not observed incorrect results.
- Single-round timings include result-consumption overhead and cannot support
  distributional claims or rounded-operation performance claims.
