"""Recheck the uncapped reruns and combine them with the completed first run."""
from collections import Counter, defaultdict
from pathlib import Path
import argparse
import csv
import hashlib
import json
import os
import statistics
import subprocess
import sys

from oracle import expected, fl_digest, parse_sig, repeated_hash, sf_digest

sys.set_int_max_str_digits(0)
ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
JOB = "<host>-v2"
RETRY_JOB = "<host>-retry24"


def read_json(path):
    return json.loads(path.read_text())


def write_json(path, value):
    temporary = path.with_suffix(".pending")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def retain_pod(archive, pod):
    uid = pod["metadata"]["uid"]
    old = archive.get(uid)
    terminal = ("Succeeded", "Failed")
    if (old and old["status"]["phase"] in terminal
            and pod["status"]["phase"] not in terminal):
        return
    archive[uid] = pod


def checked_arm(directory, task, arm, item, answers):
    verification = item["verification"]
    assert verification["timeout_seconds"] is None
    if verification["state"] != "ok":
        assert verification["state"] == "process_error", verification
        cleanup = directory / "crash-cleanup.json"
        if cleanup.exists():
            assert arm == "sf"
            record = read_json(cleanup)
            assert record["audit_sha256"] == digest(ROOT / "deadlock-audit.md")
            assert record["elapsed_time_not_used_as_criterion"]
            assert record["pod_uid"] == read_json(directory / "host.json")["pod_uid"]
            assert record["signal"] == "SIGKILL"
            assert verification["exit_code"] == -9
            return {"verification": "stack_overflow_deadlock", "timing": "not_run"}
        log = (directory / f"{arm}-verify.log").read_text()
        if verification["exit_code"] == -6 and "Stack overflow detected" in log:
            return {"verification": "stack_overflow", "timing": "not_run"}
        return {
            "verification": "process_error", "timing": "not_run",
            "exit_code": verification["exit_code"],
        }
    path = directory / f"{arm}-verify.tsv"
    assert digest(path) == verification["output_sha256"]
    lines = path.read_text().splitlines()
    assert len(lines) == len(answers) == 256
    digits = []
    for line, answer in zip(lines, answers):
        fields = line.split("\t")
        assert len(fields) == 7
        assert (int(fields[0]), fields[1], fields[2]) == (
            task["precision"], task["profile"], task["op"]
        )
        assert parse_sig(fields[3:]) == answer, (task, arm, fields, answer)
        digits.append(sf_digest(fields[3:]) if arm == "sf"
                      else fl_digest(fields[3:], task["precision"]))
    result = {"verification": "ok", "checked": 256, "timing": "not_run"}
    timing = item.get("timing")
    if not timing:
        return result
    assert timing["timeout_seconds"] is None
    if timing["state"] != "ok":
        assert timing["state"] == "process_error", timing
        result["timing"] = "process_error"
        return result
    path = directory / f"{arm}-time.tsv"
    assert digest(path) == timing["output_sha256"]
    lines = path.read_text().splitlines()
    assert len(lines) == 1
    p, profile, op, calls, nanos, sink = lines[0].split("\t")
    assert (int(p), profile, op) == (
        task["precision"], task["profile"], task["op"]
    )
    calls, nanos, sink = int(calls), int(nanos), int(sink)
    assert calls == 64 * 256 and nanos > 0
    assert sink == repeated_hash(digits, 64)
    assert sink == timing["checksum"] == timing["expected_checksum"]
    assert nanos / calls == timing["ns_per_call"]
    result.update(timing="ok", ns_per_call=nanos / calls)
    before = dict(line.split() for line in timing["cgroup_cpu_before"].splitlines())
    after = dict(line.split() for line in timing["cgroup_cpu_after"].splitlines())
    result["throttled_periods"] = int(after["nr_throttled"]) - int(before["nr_throttled"])
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--saved-pods", action="store_true")
    args = parser.parse_args()
    pod_path = ROOT / "pods-latest-combined.json"
    if not args.saved_pods:
        env = {k: v for k, v in os.environ.items()
               if k not in ("AWS_PROFILE", "AWS_DEFAULT_PROFILE")}
        pods = json.loads(subprocess.check_output([
            "kubectl", "get", "pods", "-n", "default",
            "-l", f"job-name in ({JOB},{RETRY_JOB})", "-o", "json",
        ], env=env))
        write_json(pod_path, pods)
    else:
        pods = read_json(pod_path)
    archive_path = ROOT / "pod-observations.json"
    archive = read_json(archive_path) if archive_path.exists() else {}
    for name in ("pods-before-crash-cleanup.json", "pods-v2-current.json",
                 "pods-v2-latest.json"):
        if not archive_path.exists() and (ROOT / name).exists():
            for pod in read_json(ROOT / name)["items"]:
                retain_pod(archive, pod)
    for pod in pods["items"]:
        labels = pod["metadata"]["labels"]
        assert labels["job-name"] in (JOB, RETRY_JOB)
        retain_pod(archive, pod)
    write_json(archive_path, archive)
    tasks = read_json(ROOT / "tasks.json")
    assert len(tasks) == 48
    retry_tasks = read_json(ROOT / "retry24/tasks.json")
    assert retry_tasks == tasks[4:6]
    initial = read_json(BASE / "summary.json")
    records = {entry["id"]: dict(entry, attempt="original") for entry in initial["cases"]}
    counts = Counter()
    checked = Counter()
    reruns = []
    hashes = {}
    for index, task in enumerate(tasks):
        directory = (ROOT / "retry24/results" / f"{index - 4:03d}" if index in (4, 5)
                     else ROOT / "results" / f"{index:03d}")
        host = read_json(directory / "host.json") if (directory / "host.json").exists() else None
        pod = archive.get(host["pod_uid"]) if host else None
        phase = pod["status"]["phase"] if pod else "not_retained"
        if pod:
            assert host["node"] == pod["spec"]["nodeName"]
            assert pod["metadata"]["labels"]["job-name"] == (
                RETRY_JOB if index in (4, 5) else JOB
            )
        receipt = directory / "result.json"
        entry = dict(task, attempt=str(directory.relative_to(BASE)), pod_phase=phase)
        if host:
            entry["pod_uid"] = host["pod_uid"]
        if receipt.exists():
            report = read_json(receipt)
            assert report["task"] == task and report["complete"]
            assert not report.get("worker_error"), report
            assert set(report["arms"]) == {"fl", "sf"}
            rows = []
            for line in (BASE / "inputs" / task["input"]).read_text().splitlines():
                p, profile, am, ae, bm, be = line.split("\t")
                rows.append((int(p), profile, int(am), int(ae), int(bm), int(be)))
            answers = [expected(row, task["op"]) for row in rows]
            for arm in ("fl", "sf"):
                result = checked_arm(directory, task, arm, report["arms"][arm], answers)
                checked[arm] += result.get("checked", 0)
                entry.update({f"{arm}_{k}": v for k, v in result.items()})
            status = next(
                (entry[f"{arm}_{stage}"] for stage in ("verification", "timing")
                 for arm in ("fl", "sf") if entry[f"{arm}_{stage}"] != "ok"),
                "ok",
            )
            entry["status"] = status
            entry["floatspec_over_floatlib"] = (
                entry["sf_ns_per_call"] / entry["fl_ns_per_call"] if status == "ok" else None
            )
        else:
            terminations = [c["state"].get("terminated", {})
                            for c in pod["status"].get("containerStatuses", [])] if pod else []
            if any(t.get("reason") == "OOMKilled" and t.get("exitCode") == 137
                   for t in terminations):
                heartbeat = read_json(directory / "heartbeat.json")
                assert heartbeat["arm"] == "sf" and heartbeat["mode"] == "verify"
                entry["status"] = "out_of_memory"
                entry["sf_verification"] = "out_of_memory"
            elif index in (14, 22):
                # Both were diagnosed before their nodes were scaled down.
                assert (ROOT / "deadlock-audit.md").exists()
                entry["status"] = "stack_overflow_deadlock"
                entry["sf_verification"] = "stack_overflow_deadlock"
                entry["diagnosis_sha256"] = digest(ROOT / "deadlock-audit.md")
                entry["termination"] = "node_scale_down"
            else:
                assert phase in ("Running", "Pending", "not_retained"), (index, phase)
                entry["status"] = "running"
            entry["floatspec_over_floatlib"] = None
        counts[entry["status"]] += 1
        reruns.append(entry)
        records[task["id"]] = entry
        if entry["status"] != "running":
            for path in directory.iterdir():
                if path.is_file():
                    hashes[str(path.relative_to(ROOT))] = digest(path)
    groups = defaultdict(list)
    for entry in records.values():
        if entry["floatspec_over_floatlib"] is not None:
            groups[entry["precision"], entry["op"]].append(entry)
    combined = []
    for (precision, op), entries in sorted(groups.items()):
        if len(entries) != 3:
            continue
        combined.append({
            "precision": precision, "operation": op, "profiles": 3,
            "floatlib_us": statistics.geometric_mean(e["fl_ns_per_call"] for e in entries) / 1000,
            "floatspec_us": statistics.geometric_mean(e["sf_ns_per_call"] for e in entries) / 1000,
            "floatspec_over_floatlib": statistics.geometric_mean(
                e["floatspec_over_floatlib"] for e in entries
            ),
            "min_profile_ratio": min(e["floatspec_over_floatlib"] for e in entries),
            "max_profile_ratio": max(e["floatspec_over_floatlib"] for e in entries),
        })
    audit = {
        "rerun_cases": 48, "rerun_states": dict(counts),
        "all_reruns_terminal": counts["running"] == 0,
        "combined_complete_pairs": sum(e["floatspec_over_floatlib"] is not None
                                      for e in records.values()),
        "rerun_checked_values": dict(checked), "rerun_numerical_differences": 0,
        "new_rerun_results_replace_old_timeouts": True,
        "verification_timeout_seconds": None, "timing_timeout_seconds": None,
        "memory_limit_gib": 8,
        "infrastructure_retries": [4, 5],
        "original_summary_sha256": digest(BASE / "summary.json"),
    }
    write_json(ROOT / "combined-summary.json", {
        "audit": audit, "by_precision": combined,
        "cases": sorted(records.values(), key=lambda e: e["id"]),
        "reruns": reruns,
    })
    write_json(ROOT / "result-hashes.json", hashes)
    with (ROOT / "by-precision.csv").open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(combined[0]))
        writer.writeheader()
        writer.writerows(combined)
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
