Read-only audit of v2 verification cases 012–023, 2026-09-22.

All twelve inspected processes have exhausted the arithmetic thread's native
stack and then self-deadlocked in Lean's SIGSEGV handler. They are not continuing
arithmetic. This conclusion comes from saved fault registers, memory mappings,
allocator lock addresses, and executable instructions; elapsed time is not the
classification criterion.

Scope: job-name=<host>-v2, indices 12–17 at p113
and 18–23 at p256, add/sub across the three profiles. The processes were still
in `sf verify`, with CoreDumping=0 and zero memory.events max/oom/oom_kill.
No process was stopped, signalled, attached with ptrace, killed, or changed.
No benchmark, source, wrapper, worker, or timeout was modified. This new audit
file is the only filesystem mutation by this audit.

Inspection used `/proc/PID/task/TID/{stat,syscall,wchan}`, `/proc/PID/maps`,
and read-only `pread` on `/proc/PID/mem`. The active handler stack was read in
1 KiB windows. The interrupted stack was initially read in 256-byte windows;
one additional 1 KiB window for index 12 emitted at most 20 executable pointers.
These are bounded stack observations, not an unbounded recursive backtrace.

Observed thread roles in every case:

- The process leader sleeps in a futex join waiting for the arithmetic thread.
- The io_uring thread sleeps in `io_sq_thread`.
- The event-loop thread sleeps in `ep_poll`.
- The arithmetic thread sleeps in `futex_wait_queue`, syscall 202,
  FUTEX_WAIT_PRIVATE (0x80), expected lock value 2, null timeout pointer.

The arithmetic thread is TID18/PID15 for even indices and TID10/PID7 for odd
indices. Its accumulated CPU time was approximately 10.37–11.12 seconds.
Index12 retained exactly utime=884 and stime=155 (100 ticks/second) from the
earlier inspection. No interpretation of wall time as arithmetic time is valid.

The decisive fault-and-lock evidence holds for all twelve cases:

1. The saved signal-frame RIP is libc `_int_realloc+9` (ELF offset 0x9acf9).
   That instruction is `push %rbx`.
2. Saved RSP is exactly the lower address of a 0x40000000-byte (1 GiB)
   writable thread-stack mapping.
3. Saved CR2 is RSP−8, inside the immediately preceding `---p` guard page.
   Saved TRAPNO=14 and ERR=6 agree with this stack write fault.
4. Saved RDI and RBX identify the allocator arena. That same address is the
   handler's current futex wait address, whose 32-bit value is 2.
5. The interrupted caller, libc `__libc_realloc`, acquires the arena lock at
   0x9bbf7, calls `_int_realloc` at 0x9bc0d, and releases the lock only after
   return, at 0x9bc17. The interrupted call therefore still holds the lock.
6. The handler calls `pthread_getattr_np`, which calls allocating libc routines
   that attempt to acquire this same lock. The original call cannot return and
   unlock until the signal handler returns; the handler cannot return while
   waiting for that lock. This establishes allocator reentrancy self-deadlock.

Per-case addresses from the saved signal frames:

| Index | Precision | Arithmetic TID | Locked arena = current futex | Saved RSP = stack lower address | Saved CR2 |
| --- | --- | --- | --- | --- | --- |
| 12 | 113 | 18 | 0x7ff75c000030 | 0x7ff764000000 | 0x7ff763fffff8 |
| 13 | 113 | 10 | 0x7f86dc000030 | 0x7f86e4000000 | 0x7f86e3fffff8 |
| 14 | 113 | 18 | 0x7fbd5c000030 | 0x7fbd64000000 | 0x7fbd63fffff8 |
| 15 | 113 | 10 | 0x7f6a9c000030 | 0x7f6aa4000000 | 0x7f6aa3fffff8 |
| 16 | 113 | 18 | 0x7fe828000030 | 0x7fe830000000 | 0x7fe82ffffff8 |
| 17 | 113 | 10 | 0x7f2510000030 | 0x7f2518000000 | 0x7f2517fffff8 |
| 18 | 256 | 18 | 0x7f28a8000030 | 0x7f28b0000000 | 0x7f28affffff8 |
| 19 | 256 | 10 | 0x7f2034000030 | 0x7f203c000000 | 0x7f203bfffff8 |
| 20 | 256 | 18 | 0x7f8b74000030 | 0x7f8b7c000000 | 0x7f8b7bfffff8 |
| 21 | 256 | 10 | 0x7f86c0000030 | 0x7f86c8000000 | 0x7f86c7fffff8 |
| 22 | 256 | 18 | 0x7f0554000030 | 0x7f055c000000 | 0x7f055bfffff8 |
| 23 | 256 | 10 | 0x7f24a0000030 | 0x7f24a8000000 | 0x7f24a7fffff8 |

Two observed handler paths lead to that same locked arena:

- Indices 12–15: `segv_handler → pthread_getattr_np → realloc/malloc →
  __lll_lock_wait_private`.
- Indices 16–23: `segv_handler → pthread_getattr_np →
  pthread_attr_setaffinity_np → __pthread_attr_extension → calloc →
  __lll_lock_wait_private`.

Executable evidence, from the frozen SF executable and the live pod's
`/usr/lib64/libc.so.6`:

| Location | Observed instruction/return site |
| --- | --- |
| SF virtual 0x5ea0b60 | `segv_handler` calls `pthread_getattr_np` |
| SF virtual 0x5ea0b65 | Handler return site present in all twelve stacks |
| libc 0x8c6c5 / return 0x8c6ca | `pthread_getattr_np` calls `realloc` |
| libc 0x9b5f3 / return 0x9b5f8 | `malloc` calls `__lll_lock_wait_private` |
| libc 0x8c729 / return 0x8c72e | `pthread_getattr_np` calls `pthread_attr_setaffinity_np` |
| libc 0x8969b / return 0x896a0 | affinity helper calls `__pthread_attr_extension` |
| libc 0x8936e / return 0x89373 | attribute extension calls `calloc` |
| libc 0x9c41b / return 0x9c420 | `calloc` calls `__lll_lock_wait_private` |
| libc 0x3fc30 | `__restore_rt` identifies the signal-frame boundary |
| libc 0x9acf9 | Interrupted `_int_realloc+9`, `push %rbx`, faults on stack guard |

Signal-frame decoding used the x86-64 ucontext layout in
`/usr/include/sys/ucontext.h`: ucontext immediately follows the restorer
address; mcontext begins 40 bytes into ucontext; RDI, RSP, RIP, and CR2 are
greg indices 8, 15, 16, and 22. The independently checked instruction,
guard-page location, register values, and arena equality agree across all
twelve frames.

The connection to the FloatSpec conversion is also visible in index12's
bounded interrupted-stack observation. After GMP allocation frames, it contains
`lean_nat_big_sub` return addresses and repeated return address 0x1e0956c at
16-byte intervals. This is the recursive call return site in
`lp_FloatSpec___private_FloatSpec_src_IEEE754_Binary_0__binaryPositiveOfNatSucc`.
The innermost call to `lean_nat_big_sub` returns to 0x1e09561. Both match the
frozen executable disassembly.

Relevant upstream source, relative to the frozen FloatSpec checkout:

- `FloatSpec/src/IEEE754/Binary.lean:529`: `binaryPositiveOfNatSucc` recursively
  decrements the Nat value before applying `binaryPositiveSucc`.
- `FloatSpec/src/IEEE754/Binary.lean:541`: `binaryPositiveOfNat` calls that helper
  on `n - 1`.
- `FloatSpec/src/IEEE754/BinarySingleNaN.lean:6280`: conversion of the rounded
  finite mantissa calls `binaryPositiveOfNat`.
- `FloatSpec/src/IEEE754/BinarySingleNaN.lean:7741`: `Binary.normalize` calls
  that conversion.
- `FloatSpec/src/IEEE754/BinarySingleNaN.lean:8206`: `Bplus` uses
  `Binary.normalize`; `Bminus` calls `Bplus` at line 8214.

For SF `.text`, the ELF virtual addresses above are file offsets plus 0x1000.
This matters when comparing `/proc` mapping-relative offsets with `objdump`.
For example, stack-scanned file offset 0x1e0856c corresponds to virtual
0x1e0956c, and file offset 0x5e9fb65 corresponds to virtual 0x5ea0b65.

The empty error logs and CoreDumping=0 are explained by where execution stops:
the handler has not returned from `pthread_getattr_np`, so it has not reached
the stack-overflow message at SF virtual 0x5ea0c06 or `abort` at 0x5ea0c0b.
This differs from the p53 cases that printed the message and then entered
core-dump processing.

Recommended result wording: “Verification stack overflow followed by allocator
self-deadlock in the Lean runtime signal handler, directly observed in all
twelve p113/p256 add/sub cases.” These processes have no completed verification
or arithmetic timing. Do not classify them as elapsed-time timeouts, completed
slow arithmetic, numerical mismatches, or OOM. This finding is specific to the
inspected frozen executable/runtime and cases; it makes no blanket claim about
other operations, implementations, or IEEE formats.

No run-control decision or timeout change was made by this audit.
