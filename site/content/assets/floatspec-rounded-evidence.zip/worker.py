"""Run one paired arithmetic case; retain checks, timings, and failures."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time

from oracle import OPS, expected, parse_sig, sf_digest, fl_digest, repeated_hash

sys.set_int_max_str_digits(0)
ROOT = Path(__file__).resolve().parent
INDEX = int(os.environ["JOB_COMPLETION_INDEX"])
TASK = json.loads((ROOT / "tasks.json").read_text())[INDEX]
OUT = ROOT / "results" / f"{INDEX:03d}"
OUT.mkdir(exist_ok=True)
if (OUT / "result.json").exists():
    raise RuntimeError("Refusing to replace an existing result")
LOCAL = Path(tempfile.mkdtemp(prefix="float-benchmark-"))
AFFINITY = sorted(os.sched_getaffinity(0))
CPU = AFFINITY[INDEX % len(AFFINITY)]
os.sched_setaffinity(0, {CPU})
shutil.copy2(ROOT / "inputs" / TASK["input"], LOCAL / "input.tsv")
for arm in ("fl", "sf"):
    shutil.copy2(ROOT / "bin" / f"rounded{arm}bench", LOCAL / arm)
    (LOCAL / arm).chmod(0o755)


def read_optional(path):
    try:
        return Path(path).read_text()
    except OSError:
        return None


def save_json(path, value):
    temporary = path.with_suffix(".pending")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


HOST = {
    "hostname": socket.gethostname(),
    "node": os.environ.get("POD_NODE_NAME"),
    "pod_uid": os.environ.get("POD_UID"),
    "initial_affinity": AFFINITY,
    "selected_cpu": CPU,
    "cpuinfo": read_optional("/proc/cpuinfo"),
    "cgroup": read_optional("/proc/self/cgroup"),
    "cpu_max": read_optional("/sys/fs/cgroup/cpu.max"),
    "cpuset_effective": read_optional("/sys/fs/cgroup/cpuset.cpus.effective"),
    "kernel": os.uname().release,
}
save_json(OUT / "host.json", HOST)
ROWS = []
for line in (LOCAL / "input.tsv").read_text().splitlines():
    p, profile, am, ae, bm, be = line.split("\t")
    ROWS.append((int(p), profile, int(am), int(ae), int(bm), int(be)))
assert len(ROWS) == 256
EXPECTED = [expected(row, TASK["op"]) for row in ROWS]
REPORT = {"task": TASK, "timing_rounds": 1, "arms": {}, "complete": False}


def command(arm, mode, target, reps):
    args = [
        str(LOCAL / arm), mode, str(LOCAL / "input.tsv"),
        str(target), str(reps),
    ]
    if arm == "sf":
        args.append("16384")
    args.append(TASK["op"])
    return args


def invoke(arm, mode, reps, timeout):
    target = LOCAL / f"{arm}-{mode}.tsv"
    log = OUT / f"{arm}-{mode}.log"
    args = command(arm, mode, target, reps)
    start = time.monotonic()
    before = read_optional("/sys/fs/cgroup/cpu.stat")
    try:
        with log.open("w") as handle:
            process = subprocess.run(
                args, stdout=handle, stderr=subprocess.STDOUT, timeout=timeout
            )
        state = "ok" if process.returncode == 0 else "process_error"
        code = process.returncode
    except subprocess.TimeoutExpired:
        state, code = "timeout", None
    record = {
        "state": state,
        "exit_code": code,
        "wall_seconds": time.monotonic() - start,
        "timeout_seconds": timeout,
        "command": args,
        "cgroup_cpu_before": before,
        "cgroup_cpu_after": read_optional("/sys/fs/cgroup/cpu.stat"),
    }
    if target.exists():
        shutil.copy2(target, OUT / target.name)
        record["output_sha256"] = hashlib.sha256(target.read_bytes()).hexdigest()
    return record, target


try:
    for arm in (("fl", "sf") if INDEX % 2 == 0 else ("sf", "fl")):
        item = REPORT["arms"][arm] = {}
        verification, output = invoke(arm, "verify", 1, 120)
        item["verification"] = verification
        save_json(OUT / "progress.json", REPORT)
        if verification["state"] != "ok":
            continue
        lines = output.read_text().splitlines()
        if len(lines) != len(ROWS):
            verification.update(state="row_count_error", rows=len(lines))
            continue
        digits = []
        errors = []
        for i, (line, wanted) in enumerate(zip(lines, EXPECTED)):
            fields = line.split("\t")
            assert len(fields) == 7, fields
            key = (int(fields[0]), fields[1], fields[2])
            assert key == (TASK["precision"], TASK["profile"], TASK["op"]), key
            actual = parse_sig(fields[3:])
            if actual != wanted:
                errors.append({
                    "index": i, "actual": str(actual), "expected": str(wanted),
                    "fields": fields,
                })
            digits.append(
                sf_digest(fields[3:]) if arm == "sf"
                else fl_digest(fields[3:], TASK["precision"])
            )
        verification.update(
            checked=len(lines), differences=len(errors), first_errors=errors[:8]
        )
        if errors:
            verification["state"] = "numerical_difference"
            continue
        timing, output = invoke(arm, "time", 64, 180)
        item["timing"] = timing
        if timing["state"] == "ok":
            lines = output.read_text().splitlines()
            assert len(lines) == 1, lines
            p, profile, op, calls, nanos, sink = lines[0].split("\t")
            assert (int(p), profile, op) == (
                TASK["precision"], TASK["profile"], TASK["op"]
            )
            calls, nanos, sink = int(calls), int(nanos), int(sink)
            assert calls == 256 * 64
            assert nanos > 0
            wanted_sink = repeated_hash(digits, 64)
            timing.update(
                calls=calls, total_ns=nanos, ns_per_call=nanos / calls,
                checksum=sink, expected_checksum=wanted_sink,
            )
            if sink != wanted_sink:
                timing["state"] = "checksum_difference"
        save_json(OUT / "progress.json", REPORT)
    REPORT["complete"] = True
except BaseException as error:
    REPORT["worker_error"] = repr(error)
    raise
finally:
    save_json(OUT / "result.json", REPORT)
    print(json.dumps(REPORT), flush=True)
