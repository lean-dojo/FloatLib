from pathlib import Path
from fractions import Fraction
from math import isqrt,prod
from collections import defaultdict
import json,sys,hashlib
R=Path(__file__).resolve().parent
OPS=['add','sub','mul','div','sqrt']
MASK=(1<<64)-1
FACTOR=1099511628211

def dyadic(m,e):return Fraction(m<<e,1) if e>=0 else Fraction(m,1<<-e)
def log2rat(x):
 n,d=x.numerator,x.denominator
 k=n.bit_length()-d.bit_length()
 if (n < d<<k) if k>=0 else (n<<-k < d):k-=1
 return k

def round_nearest(x,p,sqrt=False,zero_sign=False):
 if not x:return ('zero',Fraction(0),zero_sign)
 negative=x<0;x=abs(x)
 k=log2rat(x)
 if sqrt:k//=2
 e=max(k-p+1,3-16384-p)
 y=x/dyadic(1,2*e if sqrt else e)
 n,d=y.numerator,y.denominator
 if sqrt:
  q=isqrt(n//d)
  t=4*n-d*(2*q+1)**2
  q+=int(t>0 or (t==0 and q%2==1))
 else:
  q,rem=divmod(n,d)
  q+=int(2*rem>d or (2*rem==d and q%2==1))
 v=dyadic(q,e)
 if v>=dyadic(1,16384):return ('inf',None,negative)
 return ('finite' if q else 'zero',-v if negative else v,negative)

def expected(row,op):
 p,profile,am,ae,bm,be=row
 a,b=dyadic(am,ae),dyadic(bm,be)
 if op=='add':return round_nearest(a+b,p)
 if op=='sub':return round_nearest(a-b,p)
 if op=='mul':return round_nearest(a*b,p,zero_sign=(am<0)^(bm<0))
 if op=='sqrt':return round_nearest(abs(a),p,sqrt=True)
 if b==0:
  return ('nan',None,False) if a==0 else ('inf',None,am<0)
 return round_nearest(a/b,p,zero_sign=(am<0)^(bm<0))

def parse_sig(fields):
 tag,m,e,sign=fields
 return tag,dyadic(int(m),int(e)) if tag in ['finite','zero'] else None,sign=='true'

def sf_digest(fields):
 tag,m,e,negative=fields;m=int(m);e=int(e);s=0x9e3779b97f4a7c15 if negative=='true' else 0
 if tag=='nan':return 0x7ff8000000000001
 if tag=='zero':return s
 if tag=='inf':return 0x7ff0000000000000^s
 return (abs(m)&MASK)^s^((abs(e)*0x100000001b3)&MASK)^(0xd6e8feb86659fd93 if e<0 else 0)

def fl_digest(fields,p):
 tag,m,e,negative=fields;m=int(m);e=int(e);bits=int(negative=='true')<<(p+14)
 if tag=='nan':return ((32767<<(p-1))|(1<<(p-2)))&MASK
 if tag=='inf':return (bits|(32767<<(p-1)))&MASK
 if tag=='zero':return bits&MASK
 n=abs(m);k=n.bit_length()-1+e
 if k>=-16382:
  qe=k-(p-1)
  mantissa=n<<(e-qe) if e>=qe else n>>(qe-e)
  bits|=(k+16383)<<(p-1);bits|=mantissa-(1<<(p-1))
 else:
  qe=3-16384-p
  bits|=n<<(e-qe) if e>=qe else n>>(qe-e)
 return bits&MASK

def repeated_hash(digits,reps):
 # affine recurrence across a complete input batch, then binary powering
 a=1;b=0
 for d in digits:a=(a*FACTOR)&MASK;b=(b*FACTOR+d)&MASK
 value=0
 while reps:
  if reps&1:value=(a*value+b)&MASK
  b=(a*b+b)&MASK;a=a*a&MASK;reps//=2
 return value
