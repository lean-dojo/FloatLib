# FloatSpec rounded comparison: supporting evidence

The chapter's table uses unlimited-add-sub/combined-summary.json. The top-level
summary.json is the original capped run and is superseded for wider add/sub cases.
Each summary entry names its original or uncapped/retry attempt. Times are native
per-call times; by_precision contains geometric means over the three profiles.

This compact editorial archive retains frozen drivers and their five definitional
equality theorems, result receipts, recorded timing TSVs, source fingerprints,
protocols, the oracle, and the stack/memory diagnoses. No new measurements were run.
Upstream source files were fetched at the measured revision; the saved GitHub API
response records the public main revision observed on 2026-09-22. It equals the pin.

SHA256SUMS.json verifies every other entry in this ZIP. provenance.json maps copied
files to the durable experiment or the source-review workspace. Original manifests
are retained as receipts: they also name files outside this compact download.
The full experiment, input fixtures, verification streams, source rebuild archives,
and further diagnostic snapshots are not part of this download. Machine-specific
paths and host names in the records are replaced by placeholders such as
<workspace>, <floatspec-checkout>, <flocq-checkout>, <home>,
<user>, <scratch>, <host>, <host-capped>, <registry>/<image>, <nodegroup-label>,
<node-NN>, and <pod-ip-NN>. Every hash of a rewritten file, including those in the
original receipts, is updated to the rewritten content. No measurement changed.
This ZIP is supporting evidence, not a standalone rebuild or rerun package.

The original FloatSpec source remains unchanged and includes its Apache-2.0 LICENSE.
Its source credits the Flocq port. The separate Flocq header and COPYING preserve
Boldo/Melquiond attribution and the LGPL-3.0-or-later notice; neither is relabeled as
FloatLib MIT source. The benchmark drivers are the experiment's frozen adapters.
