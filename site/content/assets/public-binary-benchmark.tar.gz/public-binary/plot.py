"""Render ordinary public-call plots from the compact benchmark dataset."""
import argparse
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    with (args.dataset / "summary.csv").open() as source:
        rows = list(csv.DictReader(source))
    indexed = {(r["format"], r["operation"], r["input_class"], r["arm"]): r for r in rows}
    current_prefix = "candidate:" if any(r["arm"].startswith("candidate:") for r in rows) else ""
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 10, "axes.titlesize": 12,
        "axes.spines.top": False, "axes.spines.right": False,
        "svg.fonttype": "none", "svg.hashsalt": "floatlib-aligned-addition-final",
    })
    output = args.dataset / "plots"
    output.mkdir(exist_ok=True)
    operations = ("add", "sub", "mul", "div", "fma", "sqrt")
    configurations = [
        ("ordinary", (32, 64, 128, 256, 512, 1024, 2048, 4096),
         ((current_prefix + "binary", "FloatLib Binary", "#1768ac", "-"),
          ("mpfr", "MPFR", "#a64273", "-")),
         "Ordinary public calls: FloatLib and MPFR"),
        ("carriers", (128, 256, 512, 1024, 2048, 4096),
         ((current_prefix + "binary", "FloatLib Binary", "#1768ac", "-"),
          (current_prefix + "limbs", "FloatLib BinaryLimbs", "#d27617", "-"),
          ("mpfr", "MPFR", "#a64273", "-")),
         "Ordinary public calls: current carriers and MPFR"),
    ]
    for name, widths, series, title in configurations:
        fig, axes = plt.subplots(2, 3, figsize=(12.6, 8.0))
        fig.subplots_adjust(left=.065, right=.985, bottom=.15, top=.875,
                            hspace=.52, wspace=.30)
        for axis, operation in zip(axes.flat, operations):
            for arm, label, color, style in series:
                selected = [(w, indexed[f"binary{w}", operation, "ordinary", arm])
                            for w in widths
                            if (f"binary{w}", operation, "ordinary", arm) in indexed]
                if not selected:
                    continue
                xs = [w for w, _ in selected]
                ys = [float(r["median_ns"]) / 1000 for _, r in selected]
                lo = [float(r["min_ns"]) / 1000 for _, r in selected]
                hi = [float(r["max_ns"]) / 1000 for _, r in selected]
                axis.plot(xs, ys, color=color, linestyle=style, marker="o",
                          markersize=3.5, linewidth=1.7, label=label)
                axis.vlines(xs, lo, hi, color=color, linewidth=1, alpha=.6)
            axis.set_title(operation.upper() if operation == "fma" else operation)
            axis.set_xscale("log", base=2)
            axis.set_yscale("log")
            axis.set_xticks(widths, [str(w) for w in widths], rotation=30, ha="right")
            axis.yaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x:g}"))
            axis.grid(which="major", axis="y", alpha=.16)
            axis.set_xlabel("Encoded width (bits)")
            axis.set_ylabel("µs / operation")
        handles, labels = axes[0, 0].get_legend_handles_labels()
        fig.legend(handles, labels, loc="upper center", bbox_to_anchor=(.5, .947),
                   ncols=3, frameon=False)
        fig.suptitle(title, fontsize=15, y=.985)
        fig.supxlabel(
            "16 matching prepared inputs • three paired trials per arm • median and observed range\n"
            "MPFR matches precision/exponent bounds; versions are recorded in metadata.json. "
            "Speedup claims use within-pair ratios in paired-ratios.csv.",
            fontsize=8.5, y=.012)
        for suffix in ("svg", "png"):
            path = output / f"{name}.{suffix}"
            fig.savefig(path, dpi=150, metadata={"Date": None} if suffix == "svg" else None)
        plt.close(fig)
    print(output)


if __name__ == "__main__":
    main()
