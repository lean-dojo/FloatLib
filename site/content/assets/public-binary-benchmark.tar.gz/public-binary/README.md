# Compare FloatLib with MPFR

Build the public-call driver against your FloatLib checkout, then compare it with
MPFR. The bundle contains the Lean drivers, C reference, integer oracle, and
1,543 prepared cases across 53 formats. Supply your own FloatLib checkout.

Use Linux, Python 3.10+, a C compiler, GMP/MPFR development headers, and elan with
`leanprover/lean4:v4.34.0`. Supply the pinned dependency checkouts from FloatLib's
`lake-manifest.json`; Mathlib must be
`5ed2965256430c3649e86755f9576b54eca72435`. Matplotlib is optional for plots.

```bash
python3 build.py --source ./FloatLib --packages ./packages \
  --output ./build/current --library-build ./build/current-library
python3 run.py \
  --current ./build/current/.lake/build/bin/pairedBench \
  --mpfr ./build/current/mpfr-bench --checksum ./build/current/checksum.so \
  --output ./results/ordinary
python3 plot.py --dataset ./results/ordinary
```

The default is 48 ordinary public Binary cases: six operations at encoded widths
32, 64, 128, 256, 512, 1024, 2048, and 4096. Each arm targets **40 ms**, with
**three trials**. `--full` selects all 1,543 cases and applicable carriers.
`--format binary256 --operation add --input-class huge_gap` selects one case.
`--verify-only` checks complete encodings without calibration or timing.

The guide also reports 36 lower-precision cases, using the same executable and
three-trial protocol:

```bash
python3 run.py \
  --current ./build/current/.lake/build/bin/pairedBench \
  --mpfr ./build/current/mpfr-bench --checksum ./build/current/checksum.so \
  --format binary7e3m3 --format binary8e4m3 --format binary8e5m2 \
  --format binary9e4m4 --format binary16 --format bfloat16 \
  --output ./results/low-precision
```

The small layouts use IEEE-style encodings with infinities and NaNs. Binary16 and
bfloat16 have different significand precisions and exponent ranges despite sharing
the same encoded width.

Every build records repository-relative source hashes in `source-snapshot.json`,
plus dependency revisions, compiler information, commands, and executable hashes
in `build-receipt.json`. An existing exact library cache is allowed.
`--prepare-only` writes configuration and source receipts without compiling.

To require the source used for the guide's plot, add
`--expected-source source-receipts/current.json` to `build.py`. Omit that optional
argument to measure another checkout; its source snapshot is still recorded.
The receipt covers every library Lean file and the three build configuration
files. Dependency revisions, executable hashes, and compiler versions are recorded
separately.

FloatLib and MPFR run in alternating order: AB, BA, AB. To compare two FloatLib
checkouts as well, build each in its own output directory and pass the second
executable through `run.py --baseline`. The runner keeps baseline/current pairs
adjacent and reverses their order across trials.

The runner selects and records one idle logical CPU, or accepts `--cpu N`.
Keep other benchmarks off that physical core. Calibration fixes each arm's count,
targeting 40 ms by default and capped at 4,194,304 operations; very fast arms can
finish sooner. Warmup is at most 512 operations. Inputs are prepared outside
timing. All sixteen complete input/result encodings must match the integer oracle
before timing, and every timed/warmup output feeds a checked FNV checksum.
MPFR matches precision, exponent limits, nearest-even rounding, and subnormalization.

`measurements.csv` retains raw trials; `summary.csv` contains arm medians/ranges;
`paired-ratios.csv` contains within-trial ratios and their medians. Numerator and
denominator labels are literal: a ratio above one favors the denominator.
Use the median of within-trial ratios for comparisons. Three trials do not
establish small-effect confidence intervals.

`provenance.json` records the source and executable hashes behind the guide's
measurements. `bundle-validation.json` records the build, encoding checks, and
three-run timing checks. `fixtures.py` can regenerate the tasks and inputs;
`sha256.json` covers every bundled file except itself.
