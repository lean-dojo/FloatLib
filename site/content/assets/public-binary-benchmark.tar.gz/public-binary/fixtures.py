"""Exact encodings and independent integer oracle for the matched CPU evaluation."""
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parent
OPS = ("add", "sub", "mul", "div", "sqrt", "fma")
ROUND_CLASSES = ("guard_clear", "tie_even", "tie_odd", "sticky_even", "sticky_odd")
MASK64 = (1 << 64) - 1
SEED = 14695981039346656037
MULTIPLIER = 1099511628211
FORMATS = [
    dict(name="binary32", width=32, e=8, f=23, carrier="binary"),
    dict(name="binary64", width=64, e=11, f=52, carrier="binary"),
    *[dict(name=f"binary{w}", width=w, e=15 if w == 128 else 19,
           f=w - (15 if w == 128 else 19) - 1, carrier="binary")
      for w in (128, 256, 512, 1024, 2048, 4096)],
    dict(name="descriptor24", width=24, e=7, f=16, carrier="descriptor"),
    dict(name="descriptor48", width=48, e=7, f=40, carrier="descriptor"),
    dict(name="descriptor64", width=64, e=2, f=61, carrier="descriptor"),
    dict(name="descriptor64e19", width=64, e=19, f=44, carrier="descriptor"),
    dict(name="runtime24", width=24, e=7, f=16, carrier="descriptor", runtime=True),
    dict(name="runtime64e19", width=64, e=19, f=44, carrier="descriptor", runtime=True),
    dict(name="runtime256", width=256, e=19, f=236, carrier="descriptor", runtime=True),
]
PRIOR_FORMAT_NAMES = {fmt["name"] for fmt in FORMATS}
IRREGULAR_WIDTHS = (17, 31, 33, 63, 65, 127, 129, 255, 257, 511, 513, 1023, 1025)
PRECISION_BOUNDARIES = (17, 31, 32, 33, 63, 64, 65, 127, 128, 129,
                        255, 256, 257, 511, 512, 513, 1023, 1024, 1025)
for width in IRREGULAR_WIDTHS:
    e = 8 if width < 64 else 11 if width < 127 else 15 if width < 255 else 19
    FORMATS.append(dict(name=f"binary{width}", width=width, e=e, f=width-e-1,
                        carrier="binary", coverage="encoded-width-boundary"))
for precision in PRECISION_BOUNDARIES:
    e = 11 if precision < 64 else 15 if precision < 128 else 19
    FORMATS.append(dict(name=f"precision{precision}", width=precision+e, e=e,
                        f=precision-1, carrier="binary", coverage="precision-boundary"))
FORMATS += [
    dict(name="binary16", width=16, e=5, f=10, carrier="binary", coverage="small-regression"),
    dict(name="bfloat16", width=16, e=8, f=7, carrier="binary", coverage="small-regression"),
    dict(name="binary8e5m2", width=8, e=5, f=2, carrier="binary",
         coverage="small-regression"),
    dict(name="binary7e3m3", width=7, e=3, f=3, carrier="binary",
         coverage="small-regression"),
    dict(name="binary8e4m3", width=8, e=4, f=3, carrier="binary",
         coverage="small-regression"),
    dict(name="binary9e4m4", width=9, e=4, f=4, carrier="binary",
         coverage="small-regression"),
]
for fmt in FORMATS:
    fmt["bias"] = (1 << (fmt["e"] - 1)) - 1
    fmt["precision"] = fmt["f"] + 1
    fmt["arms"] = (["binary", "limbs"] if fmt["width"] > 128 and not fmt.get("runtime")
                   else [fmt["carrier"]])
    fmt["mpfr_emin"] = 2 - fmt["bias"] - fmt["f"]
    fmt["mpfr_emax"] = (1 << fmt["e"]) - 1 - fmt["bias"]
    fmt["minimum_normal_exponent"] = 1 - fmt["bias"]
    fmt["minimum_subnormal_exponent"] = 1 - fmt["bias"] - fmt["f"]
    fmt["maximum_normal_exponent"] = (1 << fmt["e"]) - 2 - fmt["bias"]
BY_NAME = {x["name"]: x for x in FORMATS}


def signed_zero(fmt, sign):
    return int(sign) << (fmt["width"] - 1)


def infinity(fmt, sign):
    return signed_zero(fmt, sign) | (((1 << fmt["e"]) - 1) << fmt["f"])


def decode(bits, fmt):
    f, bias = fmt["f"], fmt["bias"]
    sign = bool(bits >> (fmt["width"] - 1))
    exponent = (bits >> f) & ((1 << fmt["e"]) - 1)
    mantissa = bits & ((1 << f) - 1)
    if exponent == (1 << fmt["e"]) - 1:
        return ("nan" if mantissa else "inf", sign, 0, 0)
    if exponent:
        return "finite", sign, mantissa + (1 << f), exponent - bias - f
    return "finite", sign, mantissa, 1 - bias - f


def log2_ratio(n, d):
    k = n.bit_length() - d.bit_length()
    if (n < (d << k)) if k >= 0 else ((n << -k) < d):
        k -= 1
    return k


def pack_rounded(mantissa, scale, fmt, sign):
    """Pack an already rounded integer multiple of the selected ulp."""
    f, bias = fmt["f"], fmt["bias"]
    if not mantissa:
        return signed_zero(fmt, sign)
    leading = mantissa.bit_length() - 1
    unbiased = leading + scale
    max_unbiased = (1 << fmt["e"]) - 2 - bias
    if unbiased > max_unbiased:
        return infinity(fmt, sign)
    if unbiased < 1 - bias:
        assert scale == 1 - bias - f
        return signed_zero(fmt, sign) | mantissa
    if leading > f:
        assert mantissa & ((1 << (leading - f)) - 1) == 0
        mantissa >>= leading - f
    elif leading < f:
        mantissa <<= f - leading
    return (signed_zero(fmt, sign) | ((unbiased + bias) << f) |
            (mantissa - (1 << f)))


def round_scaled(n, d, scale, fmt, negative=False):
    """Nearest-even of |n/d|*2^scale, with an explicit zero sign."""
    assert n >= 0 and d > 0
    if not n:
        return signed_zero(fmt, negative)
    leading = log2_ratio(n, d) + scale
    if leading > (1 << fmt["e"]) - 2 - fmt["bias"]:
        return infinity(fmt, negative)
    ulp = max(1 - fmt["bias"] - fmt["f"], leading - fmt["f"])
    shift = scale - ulp
    numerator, denominator = ((n << shift, d) if shift >= 0
                              else (n, d << -shift))
    q, r = divmod(numerator, denominator)
    q += (2 * r > denominator) or (2 * r == denominator and q % 2 == 1)
    return pack_rounded(q, ulp, fmt, negative)


def exact_rational(index, salt, negative):
    result = Fraction((index * salt + salt + 1) % 113 + 7,
                      (index * 11 + salt) % 29 + 32)
    return -result if negative else result


def rational_bits(x, fmt):
    return round_scaled(abs(x.numerator), x.denominator, 0, fmt, x < 0)


def inputs(fmt, operation, kind):
    """Mirror PerformanceRegression.binaryInputs, including ordinary rationals."""
    if kind in ("dense", "sparse", "extreme_exponents", "small_boundary"):
        return boundary_inputs(fmt, operation, kind)
    if kind == "ordinary":
        xs = [rational_bits(exact_rational(i, 43 if operation == "sqrt" else 37,
                    False if operation == "sqrt" else i % 5 == 0), fmt)
              for i in range(16)]
        ys = [rational_bits(exact_rational(i, 61, i % 3 == 0), fmt)
              for i in range(16)]
        zs = [rational_bits(exact_rational(15-i, 37, (15-i) % 5 == 0), fmt)
              for i in range(16)]
        return list(zip(xs, ys, zs))
    f, bias = fmt["f"], fmt["bias"]
    unit, sign = 1 << f, 1 << (fmt["width"] - 1)
    one, two = bias * unit, (bias + 1) * unit
    half_ulp = max(0, bias - f - 1) * unit
    rows = []
    for i in range(16):
        signed = lambda bits: bits if i % 2 == 0 else bits + sign
        x = one + i
        if kind == "zero":
            row = signed(0), x, signed(one + 15 - i)
        elif kind == "subnormal":
            tiny = i + 1 if i < 8 else unit - (16 - i)
            y = unit + i if operation in ("add", "sub") else (
                two if operation == "div" else one + unit // 2)
            row = tiny, y, sign + unit + i
        elif kind == "cancel":
            nearby = x - i % 2
            row = ((x, two, sign + nearby + unit) if operation == "fma"
                   else (x, sign + nearby if operation == "add" else nearby, 0))
        elif kind == "gap":
            tiny = signed(max(0, bias - f - 4 - i) * unit)
            row = (x, two, tiny) if operation == "fma" else (x, tiny, 0)
        elif kind == "huge_gap":
            # One against a signed minimum-normal operand: the exponent gap is
            # roughly the bias, independently of the significand width. Cover
            # all four dominant/addend sign combinations within the 16 triples.
            tiny = signed(unit + i)
            dominant = x + (sign if i % 4 >= 2 else 0)
            row = ((dominant, two, tiny) if operation == "fma"
                   else (dominant, tiny, 0))
        elif kind == "tie":
            if operation == "mul":
                row = signed(one + 2*i + 1), one + unit // 2, 0
            elif operation == "div":
                row = signed(2*i + 1), two, 0
            elif operation == "fma":
                row = signed(x), one, signed(half_ulp)
            else:
                row = signed(x + (operation == "sub")), signed(half_ulp), 0
        elif kind in ROUND_CLASSES:
            odd = kind.endswith("_odd")
            if operation in ("add", "sub"):
                # A quarter, half, or three quarters of an ulp at one. Both
                # signs occur, and retained parity is fixed for the named ties.
                retained = one + 2 * (i // 2) + int(odd)
                quarters = 1 if kind == "guard_clear" else (
                    2 if kind.startswith("tie_") else 3)
                tiny = round_scaled(quarters, 1, -f-2, fmt)
                row = (signed(retained), signed(tiny) ^ (
                    sign if operation == "sub" else 0), 0)
            else:
                assert operation in ("mul", "fma")
                # Multiplication by 5/4 gives an exact discarded suffix of
                # k/4; adding 1/8 in FMA preserves that suffix and parity.
                k = dict(guard_clear=1, tie_even=2, tie_odd=6,
                         sticky_even=7, sticky_odd=3)[kind] + 8 * (i // 2)
                row = (signed(one + k), one + unit // 4,
                       signed((bias - 3) * unit) if operation == "fma" else 0)
        else:
            raise ValueError(kind)
        rows.append(row)
    assert all(0 <= b < (1 << fmt["width"]) for row in rows for b in row)
    return rows


def boundary_inputs(fmt, operation, kind):
    """Runtime bit patterns exercise full significands and both exponent endpoints."""
    f, bias = fmt["f"], fmt["bias"]
    unit = 1 << f
    max_exponent = (1 << fmt["e"]) - 2
    sign_bit = 1 << (fmt["width"] - 1)
    rng = random.Random(int.from_bytes(
        hashlib.sha256(f"floatlib-wide-v1:{fmt['e']}:{f}:{operation}:{kind}".encode()).digest(),
        "big"))

    def packed(sign, exponent, fraction):
        assert 0 <= exponent <= max_exponent and 0 <= fraction < unit
        return (sign_bit if sign else 0) | (exponent << f) | fraction

    rows = []
    for i in range(16):
        sa, sb, sc = i % 2 == 1, i % 4 >= 2, i % 8 >= 4
        if operation == "sqrt":
            sa = False
        if kind in ("dense", "sparse"):
            fractions = [rng.getrandbits(f) for _ in range(3)] if kind == "dense" else [
                (1 << ((i * 7 + j * 11) % f)) | 1 for j in range(3)]
            exponents = [max(1, min(max_exponent, bias + rng.randrange(-6, 7)))
                         for _ in range(3)]
            rows.append(tuple(packed(s, e, m) for s, e, m in
                              zip((sa, sb, sc), exponents, fractions)))
            continue
        # Finite endpoints, exact powers, and immediate neighbours. The division
        # denominator stays nonzero; signed zero outputs and overflow remain checked.
        endpoints = [(0, 1), (0, unit-1), (1, 0), (1, 1),
                     (max_exponent, unit-1), (max_exponent, unit-2),
                     (max_exponent, 0), (bias, 0)]
        if kind == "small_boundary":
            endpoints += [(0, 0), (0, 0)]
        ea, ma = endpoints[i % len(endpoints)]
        if operation == "sqrt" and ea == 0 and ma == 0:
            sa = i % 2 == 1
        if kind == "small_boundary":
            eb, mb = endpoints[(i * 3 + 1) % len(endpoints)]
            ec, mc = endpoints[(i * 5 + 2) % len(endpoints)]
        elif operation in ("add", "sub"):
            eb, mb = (ea, max(0, ma-1)) if i % 4 < 2 else (
                max_exponent if ea <= 1 else 1, unit-1)
            ec, mc = bias, 0
        elif operation in ("mul", "div"):
            eb, mb = max(1, min(max_exponent, bias + (1 if i % 4 < 2 else -1))), 0
            ec, mc = bias, 0
        else:
            eb, mb = bias, i % unit
            ec, mc = ea, ma
            if operation == "fma":
                sc = not (sa ^ sb)
        if eb == 0 and mb == 0:
            mb = 1
        rows.append((packed(sa, ea, ma), packed(sb, eb, mb), packed(sc, ec, mc)))
    assert all(0 <= bits < (1 << fmt["width"]) for row in rows for bits in row)
    return rows


def add_exact(a, b):
    sa, ma, ea = a
    sb, mb, eb = b
    e = min(ea, eb)
    m = (-1 if sa else 1) * (ma << (ea-e)) + (
        -1 if sb else 1) * (mb << (eb-e))
    sign = m < 0 if m else (sa and sb)
    return sign, abs(m), e


def expected(row, fmt, op):
    a, b, c = [decode(x, fmt) for x in row]
    assert all(x[0] == "finite" for x in (a, b, c)), (fmt, row)
    _, sa, ma, ea = a
    _, sb, mb, eb = b
    _, sc, mc, ec = c
    if op in ("add", "sub"):
        sign, n, e = add_exact((sa, ma, ea), (sb ^ (op == "sub"), mb, eb))
        return round_scaled(n, 1, e, fmt, sign)
    if op == "mul":
        return round_scaled(ma * mb, 1, ea + eb, fmt, sa ^ sb)
    if op == "fma":
        sign, n, e = add_exact((sa ^ sb, ma * mb, ea + eb), (sc, mc, ec))
        return round_scaled(n, 1, e, fmt, sign)
    if op == "div":
        assert mb != 0
        return round_scaled(ma, mb, ea - eb, fmt, sa ^ sb)
    if op == "sqrt":
        assert not sa or ma == 0
        if not ma:
            return signed_zero(fmt, sa)
        leading = (ma.bit_length() - 1 + ea) // 2
        ulp = max(1 - fmt["bias"] - fmt["f"], leading - fmt["f"])
        shift = ea - 2 * ulp
        n, d = (ma << shift, 1) if shift >= 0 else (ma, 1 << -shift)
        q = math.isqrt(n // d)
        midpoint = d * (2*q + 1)**2
        q += 4*n > midpoint or (4*n == midpoint and q % 2 == 1)
        return pack_rounded(q, ulp, fmt, False)
    raise ValueError(op)


def rounding_signature(row, fmt, op):
    """Exact final rounding bits for add/sub/mul/FMA, independent of a backend."""
    if op not in ("add", "sub", "mul", "fma"):
        return None
    a, b, c = [decode(x, fmt) for x in row]
    _, sa, ma, ea = a
    _, sb, mb, eb = b
    _, sc, mc, ec = c
    if op in ("add", "sub"):
        sign, n, e = add_exact((sa, ma, ea), (sb ^ (op == "sub"), mb, eb))
    elif op == "mul":
        sign, n, e = sa ^ sb, ma * mb, ea + eb
    else:
        sign, n, e = add_exact((sa ^ sb, ma * mb, ea + eb), (sc, mc, ec))
    if n == 0:
        return dict(kind="zero", negative=sign)
    ulp = max(1 - fmt["bias"] - fmt["f"], n.bit_length() - 1 + e - fmt["f"])
    shift = max(0, ulp - e)
    quotient = n >> shift
    guard = bool(shift and ((n >> (shift - 1)) & 1))
    sticky = bool(shift > 1 and n & ((1 << (shift - 1)) - 1))
    kind = ("guard_clear" if not guard else
            ("sticky_" if sticky else "tie_") + ("odd" if quotient & 1 else "even"))
    return dict(kind=kind, negative=sign, guard=guard, sticky=sticky,
                quotient_odd=bool(quotient & 1), shift=shift,
                exact_integer_bits=n.bit_length())


def repeated_sink(bits, iterations, seed=SEED):
    sink = seed
    for count in range(iterations - 1, -1, -1):
        sink = ((sink ^ (bits[count & 15] & MASK64)) * MULTIPLIER) & MASK64
    return sink


def classes(fmt, op):
    # Full boundary patterns at four diagnostic formats; every format gets all six
    # ordinary rows. Width is total storage width, not significand precision.
    result = ["ordinary"]
    if fmt["name"] in ("binary32", "binary256", "binary4096", "descriptor24"):
        result += ["zero", "subnormal"]
        if op in ("add", "sub", "fma"):
            result += ["cancel", "gap"]
        if op != "sqrt":
            result += ["tie"]
    if (fmt["width"] >= 128 or fmt["name"] in ("descriptor64e19", "runtime64e19")) and op in (
            "add", "sub", "fma"):
        result += ["huge_gap"]
    if fmt["name"] in ("binary64", "binary256", "binary4096", "descriptor64e19") and op in (
            "add", "sub", "mul", "fma"):
        result += ROUND_CLASSES
    if fmt.get("coverage") == "encoded-width-boundary":
        result += ["dense", "subnormal", "extreme_exponents"]
        if op in ("add", "sub", "fma"):
            result += ["cancel", "gap", "huge_gap"]
        if op in ("add", "sub", "mul", "fma"):
            result += ROUND_CLASSES
    elif fmt.get("coverage") == "precision-boundary":
        result += ["dense"]
        if fmt["precision"] in (31, 32, 33, 63, 64, 65, 127, 128, 129) and op in (
                "add", "sub", "fma"):
            result += ["cancel"]
    elif fmt.get("coverage") == "small-regression":
        result += ["dense", "small_boundary"]
        if fmt["f"] >= 7:
            result += ["zero", "subnormal"]
            if op in ("add", "sub", "fma"):
                result += ["cancel"]
            if op in ("add", "sub", "mul", "fma"):
                result += ROUND_CLASSES
    elif fmt["name"] in ("binary32", "binary64", "binary128", "binary256",
                         "binary512", "binary1024", "binary2048", "binary4096"):
        result += ["dense", "extreme_exponents"]
    result = list(dict.fromkeys(result))
    return result


def generate():
    directory = ROOT / "inputs"
    directory.mkdir(exist_ok=True)
    tasks = []
    for fmt in FORMATS:
        cases = []
        for op in OPS:
            for kind in classes(fmt, op):
                rows = inputs(fmt, op, kind)
                expected_bits = [expected(row, fmt, op) for row in rows]
                name = f"{fmt['name']}-{op}-{kind}.tsv"
                text = "".join("\t".join(map(str, row)) + "\n" for row in rows)
                (directory / name).write_text(text)
                gaps = []
                for row in rows:
                    a, b, c = [decode(x, fmt) for x in row]
                    gaps.append(abs(a[3] + b[3] - c[3]) if op == "fma"
                                else abs(a[3] - b[3]))
                signatures = [rounding_signature(row, fmt, op) for row in rows]
                if kind in ROUND_CLASSES:
                    assert all(x["kind"] == kind for x in signatures), (
                        fmt["name"], op, kind, signatures)
                cases.append(dict(operation=op, input_class=kind, input=name,
                    input_sha256=hashlib.sha256(text.encode()).hexdigest(),
                    max_dyadic_exponent_gap=max(gaps),
                    final_rounding_signatures=signatures,
                    expected=[str(x) for x in expected_bits]))
        tasks.append(dict(format=fmt, cases=cases))
    (ROOT / "tasks.json").write_text(json.dumps(tasks, indent=2) + "\n")
    (ROOT / "formats.json").write_text(json.dumps(FORMATS, indent=2) + "\n")
    prior_path = ROOT / "reused-public/tasks.json"
    if prior_path.is_file():
        by_input = {c["input"]: c for t in tasks for c in t["cases"]}
        prior = json.loads(prior_path.read_text())
        for task in prior:
            for case in task["cases"]:
                actual = by_input[case["input"]]
                assert actual["input_sha256"] == case["input_sha256"]
                assert actual["expected"] == case["expected"]
    return tasks


if __name__ == "__main__":
    tasks = generate()
    print(f"{len(tasks)} format jobs, {sum(len(t['cases']) for t in tasks)} cases")
