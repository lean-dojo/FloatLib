"""Shared full-encoding agreement checks, also usable before cluster submission."""
import argparse
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
MASK64 = (1 << 64) - 1


def command(executable, fmt, arm, case, path, mode="verify", count=16, warmup=16):
    if arm == "mpfr":
        return [str(executable), mode, str(fmt["e"]), str(fmt["f"]),
                str(fmt["bias"]), case["operation"], str(path), str(count), str(warmup)]
    format_arg = f"runtime:{fmt['e']}:{fmt['f']}" if fmt.get("runtime") else fmt["name"]
    return [str(executable), mode, format_arg, arm, case["operation"],
            str(path), str(count), str(warmup)]


def check_values(stdout, path, expected):
    rows = [list(map(int, line.split("\t"))) for line in path.read_text().splitlines()]
    actual = []
    backends = set()
    for line in stdout.splitlines():
        parts = line.split("\t")
        assert len(parts) == 8 and parts[0] == "value", line[:200]
        index, a, b, c, result, low = map(int, parts[1:7])
        assert index == len(actual), (index, len(actual))
        assert [a, b, c] == rows[index], ("input round-trip", index)
        assert low == result & MASK64, ("sink projection", index)
        actual.append(str(result))
        backends.add(parts[7])
    assert len(actual) == 16, len(actual)
    assert actual == expected, {
        "mismatches": [dict(index=i, actual=a, expected=e)
                       for i, (a, e) in enumerate(zip(actual, expected)) if a != e]}
    assert len(backends) == 1, backends
    return dict(status="pass", count=16, backend=next(iter(backends)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lean", type=Path)
    parser.add_argument("--mpfr", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--format", action="append")
    args = parser.parse_args()
    tasks = json.loads((ROOT / "tasks.json").read_text())
    results = []
    for task in tasks:
        fmt = task["format"]
        if args.format and fmt["name"] not in args.format:
            continue
        for case in task["cases"]:
            arms = fmt["arms"] if args.lean else []
            if args.mpfr:
                arms = arms + ["mpfr"]
            for arm in arms:
                path = ROOT / "inputs" / case["input"]
                cmd = command(args.mpfr if arm == "mpfr" else args.lean,
                              fmt, arm, case, path)
                result = dict(format=fmt["name"], operation=case["operation"],
                              input_class=case["input_class"], arm=arm, command=cmd)
                start = time.monotonic()
                try:
                    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
                    result.update(returncode=proc.returncode, stdout=proc.stdout,
                                  stderr=proc.stderr)
                    assert proc.returncode == 0, ("returncode", proc.returncode)
                    result.update(check_values(proc.stdout, path, case["expected"]))
                except Exception as error:
                    result.update(status="failed", error=repr(error))
                    print(fmt["name"], case["operation"], case["input_class"], arm,
                          result["error"][:240], flush=True)
                result["wall_seconds"] = time.monotonic() - start
                results.append(result)
    args.output.parent.mkdir(exist_ok=True, parents=True)
    args.output.write_text(json.dumps(results, indent=2) + "\n")
    failed = sum(r["status"] != "pass" for r in results)
    print(json.dumps(dict(checks=len(results), failed=failed, output=str(args.output))))
    raise SystemExit(bool(failed))


if __name__ == "__main__":
    main()
