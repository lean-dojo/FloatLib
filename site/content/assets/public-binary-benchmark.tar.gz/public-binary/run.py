"""Run three same-CPU trials of current FloatLib against MPFR."""
import argparse
import csv
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import tempfile

from runner import Runner, atomic_json, choose_cpu, digest, environment_snapshot, utc
from validate import check_values, command

ROOT = Path(__file__).resolve().parent
WIDTHS = (32, 64, 128, 256, 512, 1024, 2048, 4096)


def write_csv(path, rows):
    if not rows:
        return
    with path.open("w") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def selected_tasks(tasks, args):
    selected = []
    allowed = args.format or ([f"binary{w}" for w in WIDTHS] if not args.full else None)
    for task in tasks:
        fmt = dict(task["format"])
        if allowed and fmt["name"] not in allowed:
            continue
        if not args.full and "binary" in fmt["arms"]:
            fmt["arms"] = ["binary"]
        cases = [case for case in task["cases"] if
                 (not args.operation or case["operation"] in args.operation)
                 and (case["input_class"] in args.input_class if args.input_class else
                      args.full or case["input_class"] == "ordinary")]
        if cases:
            selected.append(dict(format=fmt, cases=cases))
    return selected


def verify_only(runner, fmt, case):
    key = case["input"].removesuffix(".tsv")
    result = dict(format=fmt, case=case, status="started", verification={}, trials=[])
    bench_arms = ([f"{source}:{arm}" for arm in fmt["arms"]
                   for source in ("baseline", "candidate")] if runner.reference
                  else fmt["arms"])
    arms = bench_arms + ["mpfr"]
    try:
        for arm in arms:
            path = runner.local / "inputs" / case["input"]
            receipt = runner.invoke(
                command(runner.executable(arm), fmt, runner.carrier(arm), case, path),
                "verification", key, arm)
            result["verification"][arm] = {
                **check_values(receipt["stdout"], path, case["expected"]),
                "sequence": receipt["sequence"]}
        result.update(status="pass", agreement="pass")
    except Exception as error:
        result.update(status="failed", error=repr(error))
    atomic_json(runner.output / f"{key}.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path,
                        help="Optional baseline pairedBench executable for paired reproduction")
    parser.add_argument("--current", type=Path, required=True,
                        help="Current pairedBench executable")
    parser.add_argument("--mpfr", type=Path, required=True)
    parser.add_argument("--checksum", type=Path, required=True, help="Built checksum.so")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--format", action="append")
    parser.add_argument("--operation", action="append")
    parser.add_argument("--input-class", action="append")
    parser.add_argument("--full", action="store_true",
                         help="All 1543 cases and applicable carriers; default is 48 ordinary Binary cases")
    parser.add_argument("--verify-only", action="store_true",
                        help="Check complete encodings without calibration, warmup, or timing")
    parser.add_argument("--target-ms", type=float, default=40)
    parser.add_argument("--cpu", type=int)
    args = parser.parse_args()
    assert 1 <= args.target_ms <= 1000
    tasks = selected_tasks(json.loads((ROOT / "tasks.json").read_text()), args)
    if not tasks:
        parser.error("the supplied filters select no cases")
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    pin = choose_cpu() if args.cpu is None else None
    if pin is None:
        before = sorted(os.sched_getaffinity(0))
        assert args.cpu in before
        os.sched_setaffinity(0, {args.cpu})
        pin = dict(cpu=args.cpu, allowed_before=before,
                   affinity_after=sorted(os.sched_getaffinity(0)), exclusive_cpuset=False)
    executables = [("current", args.current), ("mpfr", args.mpfr),
                   ("checksum", args.checksum)]
    if args.baseline:
        executables.append(("baseline", args.baseline))
    artifact = dict(files={n: digest(p) for n, p in executables})
    metadata = dict(utc=utc(), pin=pin, executable_sha256=artifact["files"],
                    lscpu=subprocess.check_output(["lscpu"], text=True),
                    mpfr_version=subprocess.check_output([str(args.mpfr.resolve()), "--version"],
                                                         text=True),
                    environment=environment_snapshot(pin["cpu"]),
                    protocol=dict(trials=0 if args.verify_only else 3,
                                  verify_only=args.verify_only,
                                  target_ms=args.target_ms, iteration_cap=4_194_304,
                                  input_count=16, preparation_outside_clock=True,
                                  full_encoding_agreement_before_timing=True,
                                  every_timed_output_consumed_and_checked=True,
                                  arm_order=("adjacent baseline/current pairs, reversed each trial"
                                             if args.baseline else
                                             "rotating arms; two-arm cases alternate AB, BA, AB"),
                                  decision_statistic="median within-trial numerator/denominator ratio"))
    atomic_json(output / "metadata.json", metadata)
    measurements, summaries, pairs, records = [], [], [], []
    with tempfile.TemporaryDirectory(prefix="floatlib-public-pairs-") as temporary:
        local = Path(temporary)
        (local / "inputs").mkdir()
        links = [(args.current, local / "pairedBench"),
                 (args.mpfr, local / "mpfr-bench"),
                 (args.checksum, local / "checksum.so")]
        if args.baseline:
            (local / "reference").mkdir()
            links.append((args.baseline, local / "reference/pairedBench"))
        for source, dest in links:
            dest.symlink_to(source.resolve())
        for task in tasks:
            fmt, cases = task["format"], task["cases"]
            destination = output / fmt["name"]
            destination.mkdir()
            runner = Runner(local, destination, artifact, pin["cpu"], args.target_ms,
                            "portable-public-pairs",
                            reference=artifact if args.baseline else None)
            for case in cases:
                path = local / "inputs" / case["input"]
                shutil.copy2(ROOT / "inputs" / case["input"], path)
                assert digest(path) == case["input_sha256"]
                result = (verify_only(runner, fmt, case) if args.verify_only else
                          runner.run_case(fmt, case, profiles=False))
                records.append(result)
                if result["status"] != "pass" or args.verify_only:
                    continue
                arms = list(result["trials"][0]["arms"])
                base = dict(format=fmt["name"], width=fmt["width"], precision=fmt["precision"],
                            exponent_bits=fmt["e"], operation=case["operation"],
                            input_class=case["input_class"])
                for trial in result["trials"]:
                    for arm, row in trial["arms"].items():
                        measurements.append(dict(**base, arm=arm, trial=trial["trial"],
                            order=trial["order"].index(arm), cpu=pin["cpu"],
                            **{k: row[k] for k in ("iterations", "warmup", "nanoseconds",
                                "ns_per_operation", "sink", "warmup_sink", "output_check",
                                "backend")},
                            throttled_us=row["cgroup_delta"].get("throttled_usec", 0)))
                for arm in arms:
                    times = [t["arms"][arm]["ns_per_operation"] for t in result["trials"]]
                    summaries.append(dict(**base, arm=arm, median_ns=statistics.median(times),
                                          min_ns=min(times), max_ns=max(times)))
                for carrier in fmt["arms"]:
                    current = "candidate:" + carrier if args.baseline else carrier
                    comparisons = [(current, "mpfr")]
                    if args.baseline:
                        baseline = "baseline:" + carrier
                        comparisons = [(baseline, current), (baseline, "mpfr")] + comparisons
                    for numerator, denominator in comparisons:
                        ratios = [t["arms"][numerator]["ns_per_operation"] /
                                  t["arms"][denominator]["ns_per_operation"]
                                  for t in result["trials"]]
                        pairs.append(dict(**base, numerator=numerator, denominator=denominator,
                                          median_ratio=statistics.median(ratios),
                                          **{f"trial_{i+1}": x for i, x in enumerate(ratios)}))
            runner.journal.close()
    write_csv(output / "measurements.csv", measurements)
    write_csv(output / "summary.csv", summaries)
    write_csv(output / "paired-ratios.csv", pairs)
    failed = sum(r["status"] != "pass" for r in records)
    status = dict(utc=utc(), status="failed" if failed else "pass",
                  cases=len(records), passed=len(records)-failed, failed=failed,
                  timing_rows=len(measurements), pair_rows=len(pairs),
                  verified_arms=sum(len(r["verification"]) for r in records),
                  verify_only=args.verify_only,
                  environment=environment_snapshot(pin["cpu"]))
    atomic_json(output / "validation.json", status)
    print(json.dumps(status))
    raise SystemExit(bool(failed))


if __name__ == "__main__":
    main()
