"""Measured same-CPU pairing, calibration, validation and checksum core."""
import argparse
import ctypes
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import shutil
import subprocess
import sys
import time
import traceback

from validate import check_values, command

ROOT = Path(__file__).resolve().parent
SEED = 14695981039346656037
MASK = (1 << 64) - 1


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def read(path):
    try:
        return Path(path).read_text().strip()
    except OSError:
        return None


def atomic_json(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def cpu_ticks():
    result = {}
    for line in Path("/proc/stat").read_text().splitlines():
        parts = line.split()
        if parts[0].startswith("cpu") and parts[0][3:].isdigit():
            values = list(map(int, parts[1:]))
            result[int(parts[0][3:])] = (sum(values[:8]), values[3] + values[4])
    return result


def choose_cpu():
    allowed = sorted(os.sched_getaffinity(0))
    topology = {}
    for cpu in allowed:
        root = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        topology[cpu] = dict(core=read(root / "core_id"),
                             socket=read(root / "physical_package_id"),
                             siblings=read(root / "thread_siblings_list"))
    before = cpu_ticks()
    time.sleep(0.35)
    after = cpu_ticks()
    busy = {}
    for cpu in allowed:
        total = after[cpu][0] - before[cpu][0]
        idle = after[cpu][1] - before[cpu][1]
        busy[cpu] = 1 - idle / total if total else 1.0
    # Select the least busy complete physical core. Record that this is a shared
    # scheduler CPU, not an exclusive cpuset reservation.
    scores = {}
    for cpu in allowed:
        peers = [c for c in allowed if topology[c]["socket"] == topology[cpu]["socket"]
                 and topology[c]["core"] == topology[cpu]["core"]]
        scores[cpu] = sum(busy[c] for c in peers) / len(peers)
    chosen = min(allowed, key=lambda c: (scores[c], busy[c], c))
    os.sched_setaffinity(0, {chosen})
    return dict(cpu=chosen, allowed_before=allowed, affinity_after=sorted(os.sched_getaffinity(0)),
                topology=topology[chosen], cpu_busy_at_selection=busy[chosen],
                physical_core_busy_at_selection=scores[chosen], exclusive_cpuset=False)


def environment_snapshot(cpu):
    result = dict(utc=utc(), affinity=sorted(os.sched_getaffinity(0)),
                  cpu_stat=read("/sys/fs/cgroup/cpu.stat"),
                  cpu_max=read("/sys/fs/cgroup/cpu.max"),
                  cpu_pressure=read("/sys/fs/cgroup/cpu.pressure"),
                  frequency_khz=read(f"/sys/devices/system/cpu/cpu{cpu}/cpufreq/scaling_cur_freq"),
                  cpu_ticks=cpu_ticks().get(cpu))
    if result["cpu_stat"] is None:
        result["cpu_stat"] = read("/sys/fs/cgroup/cpu/cpu.stat")
        result["cpu_max"] = dict(quota=read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us"),
                                  period=read("/sys/fs/cgroup/cpu/cpu.cfs_period_us"))
    return result


def stat_fields(text):
    return {line.split()[0]: int(line.split()[1]) for line in (text or "").splitlines()
            if len(line.split()) == 2 and line.split()[1].isdigit()}


class Runner:
    def __init__(self, local, output, artifacts, cpu, target_ms, label, reference=None):
        self.local, self.output = local, output
        self.artifacts, self.cpu = artifacts, cpu
        self.target_ns, self.label = target_ms * 1e6, label
        self.reference = reference
        library = ctypes.CDLL(str(local / "checksum.so"))
        self.sink = library.fl_expected_sink
        self.sink.argtypes = [ctypes.POINTER(ctypes.c_uint64), ctypes.c_uint64,
                              ctypes.c_uint64]
        self.sink.restype = ctypes.c_uint64
        self.sequence = 0
        self.journal = (output / "commands.jsonl").open("a", buffering=1)

    def executable(self, arm, profile=False):
        root = self.local / "reference" if arm.startswith("baseline:") else self.local
        return root / ("mpfr-bench" if arm == "mpfr" else
                       "pairedProfile" if profile else "pairedBench")

    @staticmethod
    def carrier(arm):
        return arm.split(":")[-1]

    def invoke(self, cmd, stage, case_key, arm, extra_env=None):
        self.sequence += 1
        receipt = dict(sequence=self.sequence, utc=utc(), command=list(map(str, cmd)),
                       stage=stage, case=case_key, arm=arm)
        before = environment_snapshot(self.cpu)
        usage_before = resource.getrusage(resource.RUSAGE_CHILDREN)
        start = time.monotonic()
        env = dict(os.environ)
        if extra_env:
            env.update(extra_env)
        try:
            proc = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=30)
            receipt.update(returncode=proc.returncode, stdout=proc.stdout, stderr=proc.stderr)
        except subprocess.TimeoutExpired as error:
            receipt.update(returncode=None, timeout=True,
                           stdout=(error.stdout or b"").decode() if isinstance(error.stdout, bytes)
                                  else error.stdout,
                           stderr=(error.stderr or b"").decode() if isinstance(error.stderr, bytes)
                                  else error.stderr)
        receipt["wall_seconds"] = time.monotonic() - start
        usage_after = resource.getrusage(resource.RUSAGE_CHILDREN)
        receipt["child_usage_delta"] = {
            name: getattr(usage_after, name) - getattr(usage_before, name)
            for name in ("ru_utime", "ru_stime", "ru_minflt", "ru_majflt",
                         "ru_nvcsw", "ru_nivcsw")}
        after = environment_snapshot(self.cpu)
        a, b = stat_fields(before["cpu_stat"]), stat_fields(after["cpu_stat"])
        receipt.update(environment_before=before, environment_after=after,
                       cgroup_delta={key: b[key] - a.get(key, 0) for key in b})
        self.journal.write(json.dumps(receipt) + "\n")
        if receipt["returncode"] != 0:
            raise RuntimeError(f"command {self.sequence} failed: {receipt}")
        return receipt

    def timed(self, fmt, case, arm, count, warmup, stage, profile=False):
        key = case["input"].removesuffix(".tsv")
        path = self.local / "inputs" / case["input"]
        cmd = command(self.executable(arm, profile), fmt, self.carrier(arm), case, path,
                      "profile" if profile else "time", count, warmup)
        prefix = self.output / "profiles" / f"{key}-{arm}"
        env = {"FL_PROFILE_PREFIX": str(prefix)} if profile else None
        proc = self.invoke(cmd, stage, key, arm, env)
        parts = proc["stdout"].strip().split("\t")
        assert len(parts) == 7 and parts[0] == "time", proc["stdout"][:300]
        iterations, actual_warm, nanos, sink, warm_sink = map(int, parts[1:6])
        assert iterations == count and warmup == actual_warm
        values = (ctypes.c_uint64 * 16)(*[int(x) & MASK for x in case["expected"]])
        want_warm = self.sink(values, warmup, SEED)
        want_result = self.sink(values, count, want_warm)
        assert sink == want_result and warm_sink == want_warm, (
            "consumed output mismatch", key, arm, sink, want_result, warm_sink, want_warm)
        return dict(sequence=proc["sequence"], iterations=count, warmup=warmup,
                    nanoseconds=nanos, ns_per_operation=nanos/count,
                    sink=str(sink), warmup_sink=str(warm_sink), backend=parts[6],
                    output_check="pass", cgroup_delta=proc["cgroup_delta"],
                    wall_seconds=proc["wall_seconds"],
                    child_usage_delta=proc["child_usage_delta"])

    def calibrate(self, fmt, case, arm):
        observations = []
        count = 256
        for attempt in range(3):
            row = self.timed(fmt, case, arm, count, min(count, 256), "calibration")
            observations.append(row)
            if row["nanoseconds"] >= 4_000_000:
                break
            count = min(4_194_304, max(count*2, math.ceil(
                8_000_000 / max(row["ns_per_operation"], 1) / 16) * 16))
        estimate = observations[-1]["ns_per_operation"]
        count = min(4_194_304, max(16, math.ceil(self.target_ns / estimate / 16) * 16))
        return dict(iterations=count, warmup=min(count, 512), observations=observations,
                    target_ns=self.target_ns, cap=4_194_304)

    def run_case(self, fmt, case, profiles):
        key = case["input"].removesuffix(".tsv")
        result = dict(format=fmt, case=case, label=self.label, utc=utc(),
                      status="started", verification={}, calibration={}, trials=[])
        bench_arms = ([f"{source}:{arm}" for arm in fmt["arms"]
                       for source in ("baseline", "candidate")] if self.reference
                      else fmt["arms"])
        arms = bench_arms + ["mpfr"]
        out = self.output / f"{key}.json"
        atomic_json(out, result)
        try:
            # Full encodings of all three operands and the result are checked
            # independently for every arm before any arm is timed for this case.
            for arm in arms:
                path = self.local / "inputs" / case["input"]
                proc = self.invoke(command(self.executable(arm), fmt, self.carrier(arm), case, path),
                                   "verification", key, arm)
                check = check_values(proc["stdout"], path, case["expected"])
                result["verification"][arm] = {**check, "sequence": proc["sequence"]}
            result["agreement"] = "pass"
            for arm in arms:
                result["calibration"][arm] = self.calibrate(fmt, case, arm)
            for trial in range(3):
                # A Latin rotation balances early/late placement across the three
                # arms. Two-arm cases alternate AB, BA, AB.
                if self.reference:
                    # Keep each source pair adjacent and alternate which source
                    # is first. Vary the starting direction across cases.
                    reverse = (trial + int(hashlib.sha256(key.encode()).hexdigest()[:2], 16)) % 2
                    order = list(reversed(arms)) if reverse else arms
                else:
                    order = arms[trial % len(arms):] + arms[:trial % len(arms)]
                sample = dict(trial=trial + 1, order=order, arms={})
                for arm in order:
                    config = result["calibration"][arm]
                    sample["arms"][arm] = self.timed(
                        fmt, case, arm, config["iterations"], config["warmup"], "trial")
                result["trials"].append(sample)
                atomic_json(out, result)
            result["status"] = "pass"
            if profiles and self.executable("binary", True).exists() and (
                fmt["name"] in ("binary256", "binary4096") and (
                    case["input_class"] == "ordinary" and case["operation"] != "sub"
                    or case["input_class"] in ("gap", "huge_gap")
                       and case["operation"] in ("add", "fma"))
                or fmt["name"] == "descriptor64e19"
                   and case["operation"] in ("add", "fma")
                   and case["input_class"] in ("ordinary", "huge_gap")
                or fmt["name"] == "binary32"
                   and case["operation"] == "add" and case["input_class"] == "ordinary"
                or fmt["name"] == "binary256" and case["operation"] == "mul"
                   and case["input_class"] in ("guard_clear", "tie_even", "tie_odd",
                                               "sticky_even", "sticky_odd")
                or fmt["name"] == "binary4096" and case["operation"] == "mul"
                   and case["input_class"] in ("guard_clear", "tie_even", "sticky_even")
                or fmt["name"] == "runtime256" and (
                    case["operation"] in ("add", "mul") and case["input_class"] == "ordinary"
                    or case["operation"] == "add" and case["input_class"] == "huge_gap")
            ):
                result["profiles"] = {}
                for arm in bench_arms:
                    # Profile each carrier with at least ~0.7s of uninstrumented
                    # work; instrumentation time is diagnostic, never a trial.
                    estimate = result["calibration"][arm]["observations"][-1]["ns_per_operation"]
                    count = min(16_777_216, max(16, math.ceil(700_000_000/estimate/16)*16))
                    prof = self.timed(fmt, case, arm, count, 512, "profile", True)
                    counters = self.output / "profiles" / f"{key}-{arm}.counters.json"
                    prof["counters"] = json.loads(counters.read_text())
                    prof["prefix"] = str(counters).removesuffix(".counters.json")
                    result["profiles"][arm] = prof
        except Exception as error:
            result["status"] = "failed"
            result["error"] = repr(error)
            result["traceback"] = traceback.format_exc()
        result["finished_utc"] = utc()
        atomic_json(out, result)
        print(json.dumps(dict(case=key, status=result["status"],
                              trial_count=len(result["trials"]),
                              error=result.get("error", "")[:400])), flush=True)
        return result

