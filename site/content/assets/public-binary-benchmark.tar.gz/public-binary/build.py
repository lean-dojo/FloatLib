"""Build the exact public-call driver against an explicit local FloatLib tree."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
TOOLCHAIN = "leanprover/lean4:v4.34.0"
MATHLIB = "5ed2965256430c3649e86755f9576b54eca72435"
PARTS = tuple(f"BenchPart{i:02d}" for i in range(8)) + ("BenchRuntime",)
DRIVERS = ("DriverSupport.lean", *(name + ".lean" for name in PARTS), "PairedBench.lean")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--packages", type=Path, required=True,
                        help="Lake dependency directory with the exact pinned checkouts")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--library-build", type=Path, required=True,
                        help="Isolated library build directory; an exact matching cache is allowed")
    parser.add_argument("--expected-source", type=Path,
                        help="Optional exact source receipt, such as source-receipts/current.json")
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()
    source, packages = args.source.resolve(), args.packages.resolve()
    output, library = args.output.resolve(), args.library_build.resolve()
    assert source.joinpath("lean-toolchain").read_text().strip() == TOOLCHAIN
    manifest = json.loads((source / "lake-manifest.json").read_text())
    assert next(p["rev"] for p in manifest["packages"] if p["name"] == "mathlib") == MATHLIB
    dependencies = {}
    for package in manifest["packages"]:
        if package["type"] == "git":
            revision = subprocess.check_output(
                ["git", "-C", str(packages / package["name"]), "rev-parse", "HEAD"],
                text=True).strip()
            assert revision == package["rev"], ("dependency revision", package["name"])
            dependencies[package["name"]] = revision
    source_paths = [source / name for name in
                    ("FloatLib.lean", "lean-toolchain", "lakefile.lean", "lake-manifest.json")]
    source_paths.extend((source / "FloatLib").rglob("*.lean"))
    snapshot = dict(
        schema="floatlib-local-source-snapshot-v1",
        scope="FloatLib Lean sources and the three build configuration files",
        files={p.relative_to(source).as_posix(): sha(p) for p in sorted(source_paths)})
    source_check = None
    if args.expected_source:
        expected = json.loads(args.expected_source.read_text())
        assert snapshot["files"].keys() == expected["files"].keys(), "source file set differs"
        for name, digest in expected["files"].items():
            assert snapshot["files"].get(name) == digest, ("source hash mismatch", name)
        source_check = dict(receipt_sha256=sha(args.expected_source),
                            files_checked=len(expected["files"]))
    lean = Path(subprocess.check_output(["elan", "which", "lean"], cwd=ROOT, text=True).strip())
    version = subprocess.check_output([str(lean), "--version"], text=True).strip()
    assert "4.34.0" in version and "rc" not in version, version
    prefix = lean.parent.parent
    output.mkdir(parents=True, exist_ok=False)
    snapshot_path = output / "source-snapshot.json"
    snapshot_path.write_text(json.dumps(snapshot, indent=2, sort_keys=True) + "\n")
    for name in (*DRIVERS, "profile_stub.c", "mpfr_bench.c", "checksum.c"):
        shutil.copy2(ROOT / "source" / name, output / name)
    quote = lambda p: json.dumps(str(p))
    (output / "lakefile.lean").write_text(
        "import Lake\nopen Lake DSL\n"
        "package floatlibHarness where\n"
        f"  packagesDir := {quote(packages)}\n"
        "  leanOptions := #[⟨`autoImplicit, false⟩, ⟨`relaxedAutoImplicit, false⟩]\n"
        f"require floatlib from {quote(source)}\n"
        "lean_lib HarnessSupport where\n  roots := #[`DriverSupport]\n"
        "lean_lib HarnessParts where\n"
        f"  roots := #[{', '.join('`' + name for name in PARTS)}]\n"
        "lean_exe pairedBench where\n  root := `PairedBench\n"
        f"  moreLinkArgs := #[{quote(output / 'profile_stub.o')}]\n")
    (output / "lean-toolchain").write_text(TOOLCHAIN + "\n")
    manifest["name"] = "floatlibHarness"
    manifest["packagesDir"] = str(packages)
    for package in manifest["packages"]:
        package["inherited"] = True
    manifest["packages"].append(dict(type="path", name="floatlib", scope="", dir=str(source),
        manifestFile="lake-manifest.json", inherited=False, configFile="lakefile.lean"))
    (output / "lake-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    record = dict(status="prepared", source=str(source), packages=str(packages),
                  library_build=str(library), lean=version, mathlib=MATHLIB,
                  dependencies=dependencies, source_check=source_check,
                  source_snapshot=dict(file=snapshot_path.name, sha256=sha(snapshot_path),
                                       files_recorded=len(snapshot["files"])),
                  cc_version=subprocess.check_output(["cc", "--version"], text=True),
                  lean_header_sha256=sha(prefix / "include/lean/lean.h"),
                  driver_sha256={n: sha(output / n) for n in DRIVERS},
                  commands=[])
    receipt = output / "build-receipt.json"
    receipt.write_text(json.dumps(record, indent=2) + "\n")
    if args.prepare_only:
        print(output)
        return
    env = dict(os.environ, FLOATLIB_BUILD_DIR=str(library))
    commands = [
        ["cc", "-O2", "-I" + str(prefix / "include"), "-c",
         str(output / "profile_stub.c"), "-o", str(output / "profile_stub.o")],
        [str(prefix / "bin/lake"), "build", "pairedBench"],
        ["cc", "-O3", "-g", "-Wall", "-Wextra", str(output / "mpfr_bench.c"),
         "-o", str(output / "mpfr-bench"), "-lmpfr", "-lgmp"],
        ["cc", "-O3", "-shared", "-fPIC", str(output / "checksum.c"),
         "-o", str(output / "checksum.so")]]
    try:
        for command in commands:
            start = time.monotonic()
            with (output / "build.log").open("a") as log:
                result = subprocess.run(command, cwd=output, env=env,
                                        stdout=log, stderr=subprocess.STDOUT)
            record["commands"].append(dict(argv=command, returncode=result.returncode,
                                            seconds=time.monotonic()-start))
            receipt.write_text(json.dumps(record, indent=2) + "\n")
            result.check_returncode()
        record["status"] = "pass"
        record["executables"] = {n: sha(output / n) for n in
                                (".lake/build/bin/pairedBench", "mpfr-bench", "checksum.so")}
    except Exception as error:
        record.update(status="failed", error=repr(error))
        raise
    finally:
        receipt.write_text(json.dumps(record, indent=2) + "\n")
    print(output)


if __name__ == "__main__":
    main()
