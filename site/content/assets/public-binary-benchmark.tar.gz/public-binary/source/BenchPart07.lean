module

import DriverSupport

open FloatLib.Floats
open FloatLib.Floats.Formats.BinaryInterchange
open BoundedBench

namespace BoundedBench.Driver

abbrev Fbinary4096Binary := ExecFloat.Binary.Family 19 4076
abbrev Tbinary4096Binary := ExecFloat Fbinary4096Binary
bounded_binary binary4096BinaryAdd : Tbinary4096Binary using ExecFloat.add
bounded_binary binary4096BinarySub : Tbinary4096Binary using ExecFloat.sub
bounded_binary binary4096BinaryMul : Tbinary4096Binary using ExecFloat.mul
bounded_binary binary4096BinaryDiv : Tbinary4096Binary using ExecFloat.div
bounded_unary binary4096BinarySqrt : Tbinary4096Binary using ExecFloat.sqrt
bounded_ternary binary4096BinaryFma : Tbinary4096Binary using ExecFloat.fma

@[noinline] public def runbinary4096Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary4096Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary4096Binary)).name
      (fun a b _ => ExecFloat.add a b) binary4096BinaryAdd
  | "sub" => run (F := Fbinary4096Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary4096Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary4096BinarySub
  | "mul" => run (F := Fbinary4096Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary4096Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary4096BinaryMul
  | "div" => run (F := Fbinary4096Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary4096Binary)).name
      (fun a b _ => ExecFloat.div a b) binary4096BinaryDiv
  | "sqrt" => run (F := Fbinary4096Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary4096Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary4096BinarySqrt
  | "fma" => run (F := Fbinary4096Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary4096Binary)).name
      ExecFloat.fma binary4096BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary4096Limbs := ExecFloat.Binary.LimbFamily 19 4076
abbrev Tbinary4096Limbs := ExecFloat Fbinary4096Limbs
bounded_binary binary4096LimbsAdd : Tbinary4096Limbs using ExecFloat.add
bounded_binary binary4096LimbsSub : Tbinary4096Limbs using ExecFloat.sub
bounded_binary binary4096LimbsMul : Tbinary4096Limbs using ExecFloat.mul
bounded_binary binary4096LimbsDiv : Tbinary4096Limbs using ExecFloat.div
bounded_unary binary4096LimbsSqrt : Tbinary4096Limbs using ExecFloat.sqrt
bounded_ternary binary4096LimbsFma : Tbinary4096Limbs using ExecFloat.fma

@[noinline] public def runbinary4096Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary4096Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary4096Limbs)).name
      (fun a b _ => ExecFloat.add a b) binary4096LimbsAdd
  | "sub" => run (F := Fbinary4096Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary4096Limbs)).name
      (fun a b _ => ExecFloat.sub a b) binary4096LimbsSub
  | "mul" => run (F := Fbinary4096Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary4096Limbs)).name
      (fun a b _ => ExecFloat.mul a b) binary4096LimbsMul
  | "div" => run (F := Fbinary4096Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary4096Limbs)).name
      (fun a b _ => ExecFloat.div a b) binary4096LimbsDiv
  | "sqrt" => run (F := Fbinary4096Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary4096Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) binary4096LimbsSqrt
  | "fma" => run (F := Fbinary4096Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary4096Limbs)).name
      ExecFloat.fma binary4096LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary63Binary := ExecFloat.Binary.Family 8 54
abbrev Tbinary63Binary := ExecFloat Fbinary63Binary
bounded_binary binary63BinaryAdd : Tbinary63Binary using ExecFloat.add
bounded_binary binary63BinarySub : Tbinary63Binary using ExecFloat.sub
bounded_binary binary63BinaryMul : Tbinary63Binary using ExecFloat.mul
bounded_binary binary63BinaryDiv : Tbinary63Binary using ExecFloat.div
bounded_unary binary63BinarySqrt : Tbinary63Binary using ExecFloat.sqrt
bounded_ternary binary63BinaryFma : Tbinary63Binary using ExecFloat.fma

@[noinline] public def runbinary63Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary63Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary63Binary)).name
      (fun a b _ => ExecFloat.add a b) binary63BinaryAdd
  | "sub" => run (F := Fbinary63Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary63Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary63BinarySub
  | "mul" => run (F := Fbinary63Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary63Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary63BinaryMul
  | "div" => run (F := Fbinary63Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary63Binary)).name
      (fun a b _ => ExecFloat.div a b) binary63BinaryDiv
  | "sqrt" => run (F := Fbinary63Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary63Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary63BinarySqrt
  | "fma" => run (F := Fbinary63Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary63Binary)).name
      ExecFloat.fma binary63BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary1023Binary := ExecFloat.Binary.Family 19 1003
abbrev Tbinary1023Binary := ExecFloat Fbinary1023Binary
bounded_binary binary1023BinaryAdd : Tbinary1023Binary using ExecFloat.add
bounded_binary binary1023BinarySub : Tbinary1023Binary using ExecFloat.sub
bounded_binary binary1023BinaryMul : Tbinary1023Binary using ExecFloat.mul
bounded_binary binary1023BinaryDiv : Tbinary1023Binary using ExecFloat.div
bounded_unary binary1023BinarySqrt : Tbinary1023Binary using ExecFloat.sqrt
bounded_ternary binary1023BinaryFma : Tbinary1023Binary using ExecFloat.fma

@[noinline] public def runbinary1023Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary1023Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary1023Binary)).name
      (fun a b _ => ExecFloat.add a b) binary1023BinaryAdd
  | "sub" => run (F := Fbinary1023Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary1023Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary1023BinarySub
  | "mul" => run (F := Fbinary1023Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary1023Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary1023BinaryMul
  | "div" => run (F := Fbinary1023Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary1023Binary)).name
      (fun a b _ => ExecFloat.div a b) binary1023BinaryDiv
  | "sqrt" => run (F := Fbinary1023Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary1023Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary1023BinarySqrt
  | "fma" => run (F := Fbinary1023Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary1023Binary)).name
      ExecFloat.fma binary1023BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary1023Limbs := ExecFloat.Binary.LimbFamily 19 1003
abbrev Tbinary1023Limbs := ExecFloat Fbinary1023Limbs
bounded_binary binary1023LimbsAdd : Tbinary1023Limbs using ExecFloat.add
bounded_binary binary1023LimbsSub : Tbinary1023Limbs using ExecFloat.sub
bounded_binary binary1023LimbsMul : Tbinary1023Limbs using ExecFloat.mul
bounded_binary binary1023LimbsDiv : Tbinary1023Limbs using ExecFloat.div
bounded_unary binary1023LimbsSqrt : Tbinary1023Limbs using ExecFloat.sqrt
bounded_ternary binary1023LimbsFma : Tbinary1023Limbs using ExecFloat.fma

@[noinline] public def runbinary1023Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary1023Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary1023Limbs)).name
      (fun a b _ => ExecFloat.add a b) binary1023LimbsAdd
  | "sub" => run (F := Fbinary1023Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary1023Limbs)).name
      (fun a b _ => ExecFloat.sub a b) binary1023LimbsSub
  | "mul" => run (F := Fbinary1023Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary1023Limbs)).name
      (fun a b _ => ExecFloat.mul a b) binary1023LimbsMul
  | "div" => run (F := Fbinary1023Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary1023Limbs)).name
      (fun a b _ => ExecFloat.div a b) binary1023LimbsDiv
  | "sqrt" => run (F := Fbinary1023Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary1023Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) binary1023LimbsSqrt
  | "fma" => run (F := Fbinary1023Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary1023Limbs)).name
      ExecFloat.fma binary1023LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision65Binary := ExecFloat.Binary.Family 15 64
abbrev Tprecision65Binary := ExecFloat Fprecision65Binary
bounded_binary precision65BinaryAdd : Tprecision65Binary using ExecFloat.add
bounded_binary precision65BinarySub : Tprecision65Binary using ExecFloat.sub
bounded_binary precision65BinaryMul : Tprecision65Binary using ExecFloat.mul
bounded_binary precision65BinaryDiv : Tprecision65Binary using ExecFloat.div
bounded_unary precision65BinarySqrt : Tprecision65Binary using ExecFloat.sqrt
bounded_ternary precision65BinaryFma : Tprecision65Binary using ExecFloat.fma

@[noinline] public def runprecision65Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision65Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision65Binary)).name
      (fun a b _ => ExecFloat.add a b) precision65BinaryAdd
  | "sub" => run (F := Fprecision65Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision65Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision65BinarySub
  | "mul" => run (F := Fprecision65Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision65Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision65BinaryMul
  | "div" => run (F := Fprecision65Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision65Binary)).name
      (fun a b _ => ExecFloat.div a b) precision65BinaryDiv
  | "sqrt" => run (F := Fprecision65Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision65Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision65BinarySqrt
  | "fma" => run (F := Fprecision65Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision65Binary)).name
      ExecFloat.fma precision65BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision512Binary := ExecFloat.Binary.Family 19 511
abbrev Tprecision512Binary := ExecFloat Fprecision512Binary
bounded_binary precision512BinaryAdd : Tprecision512Binary using ExecFloat.add
bounded_binary precision512BinarySub : Tprecision512Binary using ExecFloat.sub
bounded_binary precision512BinaryMul : Tprecision512Binary using ExecFloat.mul
bounded_binary precision512BinaryDiv : Tprecision512Binary using ExecFloat.div
bounded_unary precision512BinarySqrt : Tprecision512Binary using ExecFloat.sqrt
bounded_ternary precision512BinaryFma : Tprecision512Binary using ExecFloat.fma

@[noinline] public def runprecision512Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision512Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision512Binary)).name
      (fun a b _ => ExecFloat.add a b) precision512BinaryAdd
  | "sub" => run (F := Fprecision512Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision512Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision512BinarySub
  | "mul" => run (F := Fprecision512Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision512Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision512BinaryMul
  | "div" => run (F := Fprecision512Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision512Binary)).name
      (fun a b _ => ExecFloat.div a b) precision512BinaryDiv
  | "sqrt" => run (F := Fprecision512Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision512Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision512BinarySqrt
  | "fma" => run (F := Fprecision512Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision512Binary)).name
      ExecFloat.fma precision512BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision512Limbs := ExecFloat.Binary.LimbFamily 19 511
abbrev Tprecision512Limbs := ExecFloat Fprecision512Limbs
bounded_binary precision512LimbsAdd : Tprecision512Limbs using ExecFloat.add
bounded_binary precision512LimbsSub : Tprecision512Limbs using ExecFloat.sub
bounded_binary precision512LimbsMul : Tprecision512Limbs using ExecFloat.mul
bounded_binary precision512LimbsDiv : Tprecision512Limbs using ExecFloat.div
bounded_unary precision512LimbsSqrt : Tprecision512Limbs using ExecFloat.sqrt
bounded_ternary precision512LimbsFma : Tprecision512Limbs using ExecFloat.fma

@[noinline] public def runprecision512Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision512Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision512Limbs)).name
      (fun a b _ => ExecFloat.add a b) precision512LimbsAdd
  | "sub" => run (F := Fprecision512Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision512Limbs)).name
      (fun a b _ => ExecFloat.sub a b) precision512LimbsSub
  | "mul" => run (F := Fprecision512Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision512Limbs)).name
      (fun a b _ => ExecFloat.mul a b) precision512LimbsMul
  | "div" => run (F := Fprecision512Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision512Limbs)).name
      (fun a b _ => ExecFloat.div a b) precision512LimbsDiv
  | "sqrt" => run (F := Fprecision512Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision512Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) precision512LimbsSqrt
  | "fma" => run (F := Fprecision512Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision512Limbs)).name
      ExecFloat.fma precision512LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary7e3m3Binary := ExecFloat.Binary.Family 3 3
abbrev Tbinary7e3m3Binary := ExecFloat Fbinary7e3m3Binary
bounded_binary binary7e3m3BinaryAdd : Tbinary7e3m3Binary using ExecFloat.add
bounded_binary binary7e3m3BinarySub : Tbinary7e3m3Binary using ExecFloat.sub
bounded_binary binary7e3m3BinaryMul : Tbinary7e3m3Binary using ExecFloat.mul
bounded_binary binary7e3m3BinaryDiv : Tbinary7e3m3Binary using ExecFloat.div
bounded_unary binary7e3m3BinarySqrt : Tbinary7e3m3Binary using ExecFloat.sqrt
bounded_ternary binary7e3m3BinaryFma : Tbinary7e3m3Binary using ExecFloat.fma

@[noinline] public def runbinary7e3m3Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary7e3m3Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary7e3m3Binary)).name
      (fun a b _ => ExecFloat.add a b) binary7e3m3BinaryAdd
  | "sub" => run (F := Fbinary7e3m3Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary7e3m3Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary7e3m3BinarySub
  | "mul" => run (F := Fbinary7e3m3Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary7e3m3Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary7e3m3BinaryMul
  | "div" => run (F := Fbinary7e3m3Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary7e3m3Binary)).name
      (fun a b _ => ExecFloat.div a b) binary7e3m3BinaryDiv
  | "sqrt" => run (F := Fbinary7e3m3Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary7e3m3Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary7e3m3BinarySqrt
  | "fma" => run (F := Fbinary7e3m3Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary7e3m3Binary)).name
      ExecFloat.fma binary7e3m3BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

end BoundedBench.Driver
