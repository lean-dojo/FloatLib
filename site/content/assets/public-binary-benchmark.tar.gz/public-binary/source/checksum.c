#include <stdint.h>

uint64_t fl_expected_sink(const uint64_t *bits, uint64_t count, uint64_t seed) {
    while (count) {
        seed = (seed ^ bits[--count & 15]) * UINT64_C(1099511628211);
    }
    return seed;
}
