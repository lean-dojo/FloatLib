module

import DriverSupport

open FloatLib.Floats
open FloatLib.Floats.Formats.BinaryInterchange
open BoundedBench

namespace BoundedBench.Driver

abbrev Fbinary512Binary := ExecFloat.Binary.Family 19 492
abbrev Tbinary512Binary := ExecFloat Fbinary512Binary
bounded_binary binary512BinaryAdd : Tbinary512Binary using ExecFloat.add
bounded_binary binary512BinarySub : Tbinary512Binary using ExecFloat.sub
bounded_binary binary512BinaryMul : Tbinary512Binary using ExecFloat.mul
bounded_binary binary512BinaryDiv : Tbinary512Binary using ExecFloat.div
bounded_unary binary512BinarySqrt : Tbinary512Binary using ExecFloat.sqrt
bounded_ternary binary512BinaryFma : Tbinary512Binary using ExecFloat.fma

@[noinline] public def runbinary512Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary512Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary512Binary)).name
      (fun a b _ => ExecFloat.add a b) binary512BinaryAdd
  | "sub" => run (F := Fbinary512Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary512Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary512BinarySub
  | "mul" => run (F := Fbinary512Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary512Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary512BinaryMul
  | "div" => run (F := Fbinary512Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary512Binary)).name
      (fun a b _ => ExecFloat.div a b) binary512BinaryDiv
  | "sqrt" => run (F := Fbinary512Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary512Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary512BinarySqrt
  | "fma" => run (F := Fbinary512Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary512Binary)).name
      ExecFloat.fma binary512BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary512Limbs := ExecFloat.Binary.LimbFamily 19 492
abbrev Tbinary512Limbs := ExecFloat Fbinary512Limbs
bounded_binary binary512LimbsAdd : Tbinary512Limbs using ExecFloat.add
bounded_binary binary512LimbsSub : Tbinary512Limbs using ExecFloat.sub
bounded_binary binary512LimbsMul : Tbinary512Limbs using ExecFloat.mul
bounded_binary binary512LimbsDiv : Tbinary512Limbs using ExecFloat.div
bounded_unary binary512LimbsSqrt : Tbinary512Limbs using ExecFloat.sqrt
bounded_ternary binary512LimbsFma : Tbinary512Limbs using ExecFloat.fma

@[noinline] public def runbinary512Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary512Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary512Limbs)).name
      (fun a b _ => ExecFloat.add a b) binary512LimbsAdd
  | "sub" => run (F := Fbinary512Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary512Limbs)).name
      (fun a b _ => ExecFloat.sub a b) binary512LimbsSub
  | "mul" => run (F := Fbinary512Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary512Limbs)).name
      (fun a b _ => ExecFloat.mul a b) binary512LimbsMul
  | "div" => run (F := Fbinary512Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary512Limbs)).name
      (fun a b _ => ExecFloat.div a b) binary512LimbsDiv
  | "sqrt" => run (F := Fbinary512Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary512Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) binary512LimbsSqrt
  | "fma" => run (F := Fbinary512Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary512Limbs)).name
      ExecFloat.fma binary512LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary17Binary := ExecFloat.Binary.Family 8 8
abbrev Tbinary17Binary := ExecFloat Fbinary17Binary
bounded_binary binary17BinaryAdd : Tbinary17Binary using ExecFloat.add
bounded_binary binary17BinarySub : Tbinary17Binary using ExecFloat.sub
bounded_binary binary17BinaryMul : Tbinary17Binary using ExecFloat.mul
bounded_binary binary17BinaryDiv : Tbinary17Binary using ExecFloat.div
bounded_unary binary17BinarySqrt : Tbinary17Binary using ExecFloat.sqrt
bounded_ternary binary17BinaryFma : Tbinary17Binary using ExecFloat.fma

@[noinline] public def runbinary17Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary17Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary17Binary)).name
      (fun a b _ => ExecFloat.add a b) binary17BinaryAdd
  | "sub" => run (F := Fbinary17Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary17Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary17BinarySub
  | "mul" => run (F := Fbinary17Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary17Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary17BinaryMul
  | "div" => run (F := Fbinary17Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary17Binary)).name
      (fun a b _ => ExecFloat.div a b) binary17BinaryDiv
  | "sqrt" => run (F := Fbinary17Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary17Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary17BinarySqrt
  | "fma" => run (F := Fbinary17Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary17Binary)).name
      ExecFloat.fma binary17BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary257Binary := ExecFloat.Binary.Family 19 237
abbrev Tbinary257Binary := ExecFloat Fbinary257Binary
bounded_binary binary257BinaryAdd : Tbinary257Binary using ExecFloat.add
bounded_binary binary257BinarySub : Tbinary257Binary using ExecFloat.sub
bounded_binary binary257BinaryMul : Tbinary257Binary using ExecFloat.mul
bounded_binary binary257BinaryDiv : Tbinary257Binary using ExecFloat.div
bounded_unary binary257BinarySqrt : Tbinary257Binary using ExecFloat.sqrt
bounded_ternary binary257BinaryFma : Tbinary257Binary using ExecFloat.fma

@[noinline] public def runbinary257Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary257Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary257Binary)).name
      (fun a b _ => ExecFloat.add a b) binary257BinaryAdd
  | "sub" => run (F := Fbinary257Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary257Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary257BinarySub
  | "mul" => run (F := Fbinary257Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary257Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary257BinaryMul
  | "div" => run (F := Fbinary257Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary257Binary)).name
      (fun a b _ => ExecFloat.div a b) binary257BinaryDiv
  | "sqrt" => run (F := Fbinary257Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary257Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary257BinarySqrt
  | "fma" => run (F := Fbinary257Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary257Binary)).name
      ExecFloat.fma binary257BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary257Limbs := ExecFloat.Binary.LimbFamily 19 237
abbrev Tbinary257Limbs := ExecFloat Fbinary257Limbs
bounded_binary binary257LimbsAdd : Tbinary257Limbs using ExecFloat.add
bounded_binary binary257LimbsSub : Tbinary257Limbs using ExecFloat.sub
bounded_binary binary257LimbsMul : Tbinary257Limbs using ExecFloat.mul
bounded_binary binary257LimbsDiv : Tbinary257Limbs using ExecFloat.div
bounded_unary binary257LimbsSqrt : Tbinary257Limbs using ExecFloat.sqrt
bounded_ternary binary257LimbsFma : Tbinary257Limbs using ExecFloat.fma

@[noinline] public def runbinary257Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary257Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary257Limbs)).name
      (fun a b _ => ExecFloat.add a b) binary257LimbsAdd
  | "sub" => run (F := Fbinary257Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary257Limbs)).name
      (fun a b _ => ExecFloat.sub a b) binary257LimbsSub
  | "mul" => run (F := Fbinary257Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary257Limbs)).name
      (fun a b _ => ExecFloat.mul a b) binary257LimbsMul
  | "div" => run (F := Fbinary257Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary257Limbs)).name
      (fun a b _ => ExecFloat.div a b) binary257LimbsDiv
  | "sqrt" => run (F := Fbinary257Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary257Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) binary257LimbsSqrt
  | "fma" => run (F := Fbinary257Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary257Limbs)).name
      ExecFloat.fma binary257LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision33Binary := ExecFloat.Binary.Family 11 32
abbrev Tprecision33Binary := ExecFloat Fprecision33Binary
bounded_binary precision33BinaryAdd : Tprecision33Binary using ExecFloat.add
bounded_binary precision33BinarySub : Tprecision33Binary using ExecFloat.sub
bounded_binary precision33BinaryMul : Tprecision33Binary using ExecFloat.mul
bounded_binary precision33BinaryDiv : Tprecision33Binary using ExecFloat.div
bounded_unary precision33BinarySqrt : Tprecision33Binary using ExecFloat.sqrt
bounded_ternary precision33BinaryFma : Tprecision33Binary using ExecFloat.fma

@[noinline] public def runprecision33Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision33Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision33Binary)).name
      (fun a b _ => ExecFloat.add a b) precision33BinaryAdd
  | "sub" => run (F := Fprecision33Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision33Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision33BinarySub
  | "mul" => run (F := Fprecision33Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision33Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision33BinaryMul
  | "div" => run (F := Fprecision33Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision33Binary)).name
      (fun a b _ => ExecFloat.div a b) precision33BinaryDiv
  | "sqrt" => run (F := Fprecision33Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision33Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision33BinarySqrt
  | "fma" => run (F := Fprecision33Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision33Binary)).name
      ExecFloat.fma precision33BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision256Binary := ExecFloat.Binary.Family 19 255
abbrev Tprecision256Binary := ExecFloat Fprecision256Binary
bounded_binary precision256BinaryAdd : Tprecision256Binary using ExecFloat.add
bounded_binary precision256BinarySub : Tprecision256Binary using ExecFloat.sub
bounded_binary precision256BinaryMul : Tprecision256Binary using ExecFloat.mul
bounded_binary precision256BinaryDiv : Tprecision256Binary using ExecFloat.div
bounded_unary precision256BinarySqrt : Tprecision256Binary using ExecFloat.sqrt
bounded_ternary precision256BinaryFma : Tprecision256Binary using ExecFloat.fma

@[noinline] public def runprecision256Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision256Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision256Binary)).name
      (fun a b _ => ExecFloat.add a b) precision256BinaryAdd
  | "sub" => run (F := Fprecision256Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision256Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision256BinarySub
  | "mul" => run (F := Fprecision256Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision256Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision256BinaryMul
  | "div" => run (F := Fprecision256Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision256Binary)).name
      (fun a b _ => ExecFloat.div a b) precision256BinaryDiv
  | "sqrt" => run (F := Fprecision256Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision256Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision256BinarySqrt
  | "fma" => run (F := Fprecision256Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision256Binary)).name
      ExecFloat.fma precision256BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision256Limbs := ExecFloat.Binary.LimbFamily 19 255
abbrev Tprecision256Limbs := ExecFloat Fprecision256Limbs
bounded_binary precision256LimbsAdd : Tprecision256Limbs using ExecFloat.add
bounded_binary precision256LimbsSub : Tprecision256Limbs using ExecFloat.sub
bounded_binary precision256LimbsMul : Tprecision256Limbs using ExecFloat.mul
bounded_binary precision256LimbsDiv : Tprecision256Limbs using ExecFloat.div
bounded_unary precision256LimbsSqrt : Tprecision256Limbs using ExecFloat.sqrt
bounded_ternary precision256LimbsFma : Tprecision256Limbs using ExecFloat.fma

@[noinline] public def runprecision256Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision256Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision256Limbs)).name
      (fun a b _ => ExecFloat.add a b) precision256LimbsAdd
  | "sub" => run (F := Fprecision256Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision256Limbs)).name
      (fun a b _ => ExecFloat.sub a b) precision256LimbsSub
  | "mul" => run (F := Fprecision256Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision256Limbs)).name
      (fun a b _ => ExecFloat.mul a b) precision256LimbsMul
  | "div" => run (F := Fprecision256Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision256Limbs)).name
      (fun a b _ => ExecFloat.div a b) precision256LimbsDiv
  | "sqrt" => run (F := Fprecision256Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision256Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) precision256LimbsSqrt
  | "fma" => run (F := Fprecision256Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision256Limbs)).name
      ExecFloat.fma precision256LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary16Binary := ExecFloat.Binary.Family 5 10
abbrev Tbinary16Binary := ExecFloat Fbinary16Binary
bounded_binary binary16BinaryAdd : Tbinary16Binary using ExecFloat.add
bounded_binary binary16BinarySub : Tbinary16Binary using ExecFloat.sub
bounded_binary binary16BinaryMul : Tbinary16Binary using ExecFloat.mul
bounded_binary binary16BinaryDiv : Tbinary16Binary using ExecFloat.div
bounded_unary binary16BinarySqrt : Tbinary16Binary using ExecFloat.sqrt
bounded_ternary binary16BinaryFma : Tbinary16Binary using ExecFloat.fma

@[noinline] public def runbinary16Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary16Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary16Binary)).name
      (fun a b _ => ExecFloat.add a b) binary16BinaryAdd
  | "sub" => run (F := Fbinary16Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary16Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary16BinarySub
  | "mul" => run (F := Fbinary16Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary16Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary16BinaryMul
  | "div" => run (F := Fbinary16Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary16Binary)).name
      (fun a b _ => ExecFloat.div a b) binary16BinaryDiv
  | "sqrt" => run (F := Fbinary16Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary16Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary16BinarySqrt
  | "fma" => run (F := Fbinary16Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary16Binary)).name
      ExecFloat.fma binary16BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

end BoundedBench.Driver
