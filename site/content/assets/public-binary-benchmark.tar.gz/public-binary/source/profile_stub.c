#include <lean/lean.h>

lean_obj_res fl_profile_start(lean_obj_arg world) {
    (void)world;
    return lean_io_result_mk_ok(lean_box(0));
}

lean_obj_res fl_profile_stop(lean_obj_arg world) {
    (void)world;
    return lean_io_result_mk_ok(lean_box(0));
}
