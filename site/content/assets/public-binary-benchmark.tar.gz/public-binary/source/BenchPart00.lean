module

import DriverSupport

open FloatLib.Floats
open FloatLib.Floats.Formats.BinaryInterchange
open BoundedBench

namespace BoundedBench.Driver

abbrev Fbinary32Binary := ExecFloat.Binary.Family 8 23
abbrev Tbinary32Binary := ExecFloat Fbinary32Binary
bounded_binary binary32BinaryAdd : Tbinary32Binary using ExecFloat.add
bounded_binary binary32BinarySub : Tbinary32Binary using ExecFloat.sub
bounded_binary binary32BinaryMul : Tbinary32Binary using ExecFloat.mul
bounded_binary binary32BinaryDiv : Tbinary32Binary using ExecFloat.div
bounded_unary binary32BinarySqrt : Tbinary32Binary using ExecFloat.sqrt
bounded_ternary binary32BinaryFma : Tbinary32Binary using ExecFloat.fma

@[noinline] public def runbinary32Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary32Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary32Binary)).name
      (fun a b _ => ExecFloat.add a b) binary32BinaryAdd
  | "sub" => run (F := Fbinary32Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary32Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary32BinarySub
  | "mul" => run (F := Fbinary32Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary32Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary32BinaryMul
  | "div" => run (F := Fbinary32Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary32Binary)).name
      (fun a b _ => ExecFloat.div a b) binary32BinaryDiv
  | "sqrt" => run (F := Fbinary32Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary32Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary32BinarySqrt
  | "fma" => run (F := Fbinary32Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary32Binary)).name
      ExecFloat.fma binary32BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fdescriptor24Descriptor := Descriptor (FloatFormat.ieee 7 16)
abbrev Tdescriptor24Descriptor := ExecFloat Fdescriptor24Descriptor
bounded_binary descriptor24DescriptorAdd : Tdescriptor24Descriptor using ExecFloat.add
bounded_binary descriptor24DescriptorSub : Tdescriptor24Descriptor using ExecFloat.sub
bounded_binary descriptor24DescriptorMul : Tdescriptor24Descriptor using ExecFloat.mul
bounded_binary descriptor24DescriptorDiv : Tdescriptor24Descriptor using ExecFloat.div
bounded_unary descriptor24DescriptorSqrt : Tdescriptor24Descriptor using ExecFloat.sqrt
bounded_ternary descriptor24DescriptorFma : Tdescriptor24Descriptor using ExecFloat.fma

@[noinline] public def rundescriptor24Descriptor (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fdescriptor24Descriptor) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fdescriptor24Descriptor)).name
      (fun a b _ => ExecFloat.add a b) descriptor24DescriptorAdd
  | "sub" => run (F := Fdescriptor24Descriptor) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fdescriptor24Descriptor)).name
      (fun a b _ => ExecFloat.sub a b) descriptor24DescriptorSub
  | "mul" => run (F := Fdescriptor24Descriptor) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fdescriptor24Descriptor)).name
      (fun a b _ => ExecFloat.mul a b) descriptor24DescriptorMul
  | "div" => run (F := Fdescriptor24Descriptor) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fdescriptor24Descriptor)).name
      (fun a b _ => ExecFloat.div a b) descriptor24DescriptorDiv
  | "sqrt" => run (F := Fdescriptor24Descriptor) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fdescriptor24Descriptor)).name
      (fun a _ _ => ExecFloat.sqrt a) descriptor24DescriptorSqrt
  | "fma" => run (F := Fdescriptor24Descriptor) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fdescriptor24Descriptor)).name
      ExecFloat.fma descriptor24DescriptorFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary65Binary := ExecFloat.Binary.Family 11 53
abbrev Tbinary65Binary := ExecFloat Fbinary65Binary
bounded_binary binary65BinaryAdd : Tbinary65Binary using ExecFloat.add
bounded_binary binary65BinarySub : Tbinary65Binary using ExecFloat.sub
bounded_binary binary65BinaryMul : Tbinary65Binary using ExecFloat.mul
bounded_binary binary65BinaryDiv : Tbinary65Binary using ExecFloat.div
bounded_unary binary65BinarySqrt : Tbinary65Binary using ExecFloat.sqrt
bounded_ternary binary65BinaryFma : Tbinary65Binary using ExecFloat.fma

@[noinline] public def runbinary65Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary65Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary65Binary)).name
      (fun a b _ => ExecFloat.add a b) binary65BinaryAdd
  | "sub" => run (F := Fbinary65Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary65Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary65BinarySub
  | "mul" => run (F := Fbinary65Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary65Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary65BinaryMul
  | "div" => run (F := Fbinary65Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary65Binary)).name
      (fun a b _ => ExecFloat.div a b) binary65BinaryDiv
  | "sqrt" => run (F := Fbinary65Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary65Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary65BinarySqrt
  | "fma" => run (F := Fbinary65Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary65Binary)).name
      ExecFloat.fma binary65BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary1025Binary := ExecFloat.Binary.Family 19 1005
abbrev Tbinary1025Binary := ExecFloat Fbinary1025Binary
bounded_binary binary1025BinaryAdd : Tbinary1025Binary using ExecFloat.add
bounded_binary binary1025BinarySub : Tbinary1025Binary using ExecFloat.sub
bounded_binary binary1025BinaryMul : Tbinary1025Binary using ExecFloat.mul
bounded_binary binary1025BinaryDiv : Tbinary1025Binary using ExecFloat.div
bounded_unary binary1025BinarySqrt : Tbinary1025Binary using ExecFloat.sqrt
bounded_ternary binary1025BinaryFma : Tbinary1025Binary using ExecFloat.fma

@[noinline] public def runbinary1025Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary1025Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary1025Binary)).name
      (fun a b _ => ExecFloat.add a b) binary1025BinaryAdd
  | "sub" => run (F := Fbinary1025Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary1025Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary1025BinarySub
  | "mul" => run (F := Fbinary1025Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary1025Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary1025BinaryMul
  | "div" => run (F := Fbinary1025Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary1025Binary)).name
      (fun a b _ => ExecFloat.div a b) binary1025BinaryDiv
  | "sqrt" => run (F := Fbinary1025Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary1025Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary1025BinarySqrt
  | "fma" => run (F := Fbinary1025Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary1025Binary)).name
      ExecFloat.fma binary1025BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary1025Limbs := ExecFloat.Binary.LimbFamily 19 1005
abbrev Tbinary1025Limbs := ExecFloat Fbinary1025Limbs
bounded_binary binary1025LimbsAdd : Tbinary1025Limbs using ExecFloat.add
bounded_binary binary1025LimbsSub : Tbinary1025Limbs using ExecFloat.sub
bounded_binary binary1025LimbsMul : Tbinary1025Limbs using ExecFloat.mul
bounded_binary binary1025LimbsDiv : Tbinary1025Limbs using ExecFloat.div
bounded_unary binary1025LimbsSqrt : Tbinary1025Limbs using ExecFloat.sqrt
bounded_ternary binary1025LimbsFma : Tbinary1025Limbs using ExecFloat.fma

@[noinline] public def runbinary1025Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary1025Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary1025Limbs)).name
      (fun a b _ => ExecFloat.add a b) binary1025LimbsAdd
  | "sub" => run (F := Fbinary1025Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary1025Limbs)).name
      (fun a b _ => ExecFloat.sub a b) binary1025LimbsSub
  | "mul" => run (F := Fbinary1025Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary1025Limbs)).name
      (fun a b _ => ExecFloat.mul a b) binary1025LimbsMul
  | "div" => run (F := Fbinary1025Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary1025Limbs)).name
      (fun a b _ => ExecFloat.div a b) binary1025LimbsDiv
  | "sqrt" => run (F := Fbinary1025Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary1025Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) binary1025LimbsSqrt
  | "fma" => run (F := Fbinary1025Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary1025Limbs)).name
      ExecFloat.fma binary1025LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision127Binary := ExecFloat.Binary.Family 15 126
abbrev Tprecision127Binary := ExecFloat Fprecision127Binary
bounded_binary precision127BinaryAdd : Tprecision127Binary using ExecFloat.add
bounded_binary precision127BinarySub : Tprecision127Binary using ExecFloat.sub
bounded_binary precision127BinaryMul : Tprecision127Binary using ExecFloat.mul
bounded_binary precision127BinaryDiv : Tprecision127Binary using ExecFloat.div
bounded_unary precision127BinarySqrt : Tprecision127Binary using ExecFloat.sqrt
bounded_ternary precision127BinaryFma : Tprecision127Binary using ExecFloat.fma

@[noinline] public def runprecision127Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision127Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision127Binary)).name
      (fun a b _ => ExecFloat.add a b) precision127BinaryAdd
  | "sub" => run (F := Fprecision127Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision127Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision127BinarySub
  | "mul" => run (F := Fprecision127Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision127Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision127BinaryMul
  | "div" => run (F := Fprecision127Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision127Binary)).name
      (fun a b _ => ExecFloat.div a b) precision127BinaryDiv
  | "sqrt" => run (F := Fprecision127Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision127Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision127BinarySqrt
  | "fma" => run (F := Fprecision127Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision127Binary)).name
      ExecFloat.fma precision127BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision127Limbs := ExecFloat.Binary.LimbFamily 15 126
abbrev Tprecision127Limbs := ExecFloat Fprecision127Limbs
bounded_binary precision127LimbsAdd : Tprecision127Limbs using ExecFloat.add
bounded_binary precision127LimbsSub : Tprecision127Limbs using ExecFloat.sub
bounded_binary precision127LimbsMul : Tprecision127Limbs using ExecFloat.mul
bounded_binary precision127LimbsDiv : Tprecision127Limbs using ExecFloat.div
bounded_unary precision127LimbsSqrt : Tprecision127Limbs using ExecFloat.sqrt
bounded_ternary precision127LimbsFma : Tprecision127Limbs using ExecFloat.fma

@[noinline] public def runprecision127Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision127Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision127Limbs)).name
      (fun a b _ => ExecFloat.add a b) precision127LimbsAdd
  | "sub" => run (F := Fprecision127Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision127Limbs)).name
      (fun a b _ => ExecFloat.sub a b) precision127LimbsSub
  | "mul" => run (F := Fprecision127Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision127Limbs)).name
      (fun a b _ => ExecFloat.mul a b) precision127LimbsMul
  | "div" => run (F := Fprecision127Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision127Limbs)).name
      (fun a b _ => ExecFloat.div a b) precision127LimbsDiv
  | "sqrt" => run (F := Fprecision127Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision127Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) precision127LimbsSqrt
  | "fma" => run (F := Fprecision127Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision127Limbs)).name
      ExecFloat.fma precision127LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision513Binary := ExecFloat.Binary.Family 19 512
abbrev Tprecision513Binary := ExecFloat Fprecision513Binary
bounded_binary precision513BinaryAdd : Tprecision513Binary using ExecFloat.add
bounded_binary precision513BinarySub : Tprecision513Binary using ExecFloat.sub
bounded_binary precision513BinaryMul : Tprecision513Binary using ExecFloat.mul
bounded_binary precision513BinaryDiv : Tprecision513Binary using ExecFloat.div
bounded_unary precision513BinarySqrt : Tprecision513Binary using ExecFloat.sqrt
bounded_ternary precision513BinaryFma : Tprecision513Binary using ExecFloat.fma

@[noinline] public def runprecision513Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision513Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision513Binary)).name
      (fun a b _ => ExecFloat.add a b) precision513BinaryAdd
  | "sub" => run (F := Fprecision513Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision513Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision513BinarySub
  | "mul" => run (F := Fprecision513Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision513Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision513BinaryMul
  | "div" => run (F := Fprecision513Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision513Binary)).name
      (fun a b _ => ExecFloat.div a b) precision513BinaryDiv
  | "sqrt" => run (F := Fprecision513Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision513Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision513BinarySqrt
  | "fma" => run (F := Fprecision513Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision513Binary)).name
      ExecFloat.fma precision513BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision513Limbs := ExecFloat.Binary.LimbFamily 19 512
abbrev Tprecision513Limbs := ExecFloat Fprecision513Limbs
bounded_binary precision513LimbsAdd : Tprecision513Limbs using ExecFloat.add
bounded_binary precision513LimbsSub : Tprecision513Limbs using ExecFloat.sub
bounded_binary precision513LimbsMul : Tprecision513Limbs using ExecFloat.mul
bounded_binary precision513LimbsDiv : Tprecision513Limbs using ExecFloat.div
bounded_unary precision513LimbsSqrt : Tprecision513Limbs using ExecFloat.sqrt
bounded_ternary precision513LimbsFma : Tprecision513Limbs using ExecFloat.fma

@[noinline] public def runprecision513Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision513Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision513Limbs)).name
      (fun a b _ => ExecFloat.add a b) precision513LimbsAdd
  | "sub" => run (F := Fprecision513Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision513Limbs)).name
      (fun a b _ => ExecFloat.sub a b) precision513LimbsSub
  | "mul" => run (F := Fprecision513Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision513Limbs)).name
      (fun a b _ => ExecFloat.mul a b) precision513LimbsMul
  | "div" => run (F := Fprecision513Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision513Limbs)).name
      (fun a b _ => ExecFloat.div a b) precision513LimbsDiv
  | "sqrt" => run (F := Fprecision513Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision513Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) precision513LimbsSqrt
  | "fma" => run (F := Fprecision513Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision513Limbs)).name
      ExecFloat.fma precision513LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary8e4m3Binary := ExecFloat.Binary.Family 4 3
abbrev Tbinary8e4m3Binary := ExecFloat Fbinary8e4m3Binary
bounded_binary binary8e4m3BinaryAdd : Tbinary8e4m3Binary using ExecFloat.add
bounded_binary binary8e4m3BinarySub : Tbinary8e4m3Binary using ExecFloat.sub
bounded_binary binary8e4m3BinaryMul : Tbinary8e4m3Binary using ExecFloat.mul
bounded_binary binary8e4m3BinaryDiv : Tbinary8e4m3Binary using ExecFloat.div
bounded_unary binary8e4m3BinarySqrt : Tbinary8e4m3Binary using ExecFloat.sqrt
bounded_ternary binary8e4m3BinaryFma : Tbinary8e4m3Binary using ExecFloat.fma

@[noinline] public def runbinary8e4m3Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary8e4m3Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary8e4m3Binary)).name
      (fun a b _ => ExecFloat.add a b) binary8e4m3BinaryAdd
  | "sub" => run (F := Fbinary8e4m3Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary8e4m3Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary8e4m3BinarySub
  | "mul" => run (F := Fbinary8e4m3Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary8e4m3Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary8e4m3BinaryMul
  | "div" => run (F := Fbinary8e4m3Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary8e4m3Binary)).name
      (fun a b _ => ExecFloat.div a b) binary8e4m3BinaryDiv
  | "sqrt" => run (F := Fbinary8e4m3Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary8e4m3Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary8e4m3BinarySqrt
  | "fma" => run (F := Fbinary8e4m3Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary8e4m3Binary)).name
      ExecFloat.fma binary8e4m3BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

end BoundedBench.Driver
