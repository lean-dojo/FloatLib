module

import DriverSupport

open FloatLib.Floats
open FloatLib.Floats.Formats.BinaryInterchange
open BoundedBench

namespace BoundedBench.Driver

abbrev Fbinary128Binary := ExecFloat.Binary.Family 15 112
abbrev Tbinary128Binary := ExecFloat Fbinary128Binary
bounded_binary binary128BinaryAdd : Tbinary128Binary using ExecFloat.add
bounded_binary binary128BinarySub : Tbinary128Binary using ExecFloat.sub
bounded_binary binary128BinaryMul : Tbinary128Binary using ExecFloat.mul
bounded_binary binary128BinaryDiv : Tbinary128Binary using ExecFloat.div
bounded_unary binary128BinarySqrt : Tbinary128Binary using ExecFloat.sqrt
bounded_ternary binary128BinaryFma : Tbinary128Binary using ExecFloat.fma

@[noinline] public def runbinary128Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary128Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary128Binary)).name
      (fun a b _ => ExecFloat.add a b) binary128BinaryAdd
  | "sub" => run (F := Fbinary128Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary128Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary128BinarySub
  | "mul" => run (F := Fbinary128Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary128Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary128BinaryMul
  | "div" => run (F := Fbinary128Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary128Binary)).name
      (fun a b _ => ExecFloat.div a b) binary128BinaryDiv
  | "sqrt" => run (F := Fbinary128Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary128Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary128BinarySqrt
  | "fma" => run (F := Fbinary128Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary128Binary)).name
      ExecFloat.fma binary128BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fdescriptor64Descriptor := Descriptor (FloatFormat.ieee 2 61)
abbrev Tdescriptor64Descriptor := ExecFloat Fdescriptor64Descriptor
bounded_binary descriptor64DescriptorAdd : Tdescriptor64Descriptor using ExecFloat.add
bounded_binary descriptor64DescriptorSub : Tdescriptor64Descriptor using ExecFloat.sub
bounded_binary descriptor64DescriptorMul : Tdescriptor64Descriptor using ExecFloat.mul
bounded_binary descriptor64DescriptorDiv : Tdescriptor64Descriptor using ExecFloat.div
bounded_unary descriptor64DescriptorSqrt : Tdescriptor64Descriptor using ExecFloat.sqrt
bounded_ternary descriptor64DescriptorFma : Tdescriptor64Descriptor using ExecFloat.fma

@[noinline] public def rundescriptor64Descriptor (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fdescriptor64Descriptor) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fdescriptor64Descriptor)).name
      (fun a b _ => ExecFloat.add a b) descriptor64DescriptorAdd
  | "sub" => run (F := Fdescriptor64Descriptor) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fdescriptor64Descriptor)).name
      (fun a b _ => ExecFloat.sub a b) descriptor64DescriptorSub
  | "mul" => run (F := Fdescriptor64Descriptor) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fdescriptor64Descriptor)).name
      (fun a b _ => ExecFloat.mul a b) descriptor64DescriptorMul
  | "div" => run (F := Fdescriptor64Descriptor) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fdescriptor64Descriptor)).name
      (fun a b _ => ExecFloat.div a b) descriptor64DescriptorDiv
  | "sqrt" => run (F := Fdescriptor64Descriptor) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fdescriptor64Descriptor)).name
      (fun a _ _ => ExecFloat.sqrt a) descriptor64DescriptorSqrt
  | "fma" => run (F := Fdescriptor64Descriptor) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fdescriptor64Descriptor)).name
      ExecFloat.fma descriptor64DescriptorFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary129Binary := ExecFloat.Binary.Family 15 113
abbrev Tbinary129Binary := ExecFloat Fbinary129Binary
bounded_binary binary129BinaryAdd : Tbinary129Binary using ExecFloat.add
bounded_binary binary129BinarySub : Tbinary129Binary using ExecFloat.sub
bounded_binary binary129BinaryMul : Tbinary129Binary using ExecFloat.mul
bounded_binary binary129BinaryDiv : Tbinary129Binary using ExecFloat.div
bounded_unary binary129BinarySqrt : Tbinary129Binary using ExecFloat.sqrt
bounded_ternary binary129BinaryFma : Tbinary129Binary using ExecFloat.fma

@[noinline] public def runbinary129Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary129Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary129Binary)).name
      (fun a b _ => ExecFloat.add a b) binary129BinaryAdd
  | "sub" => run (F := Fbinary129Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary129Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary129BinarySub
  | "mul" => run (F := Fbinary129Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary129Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary129BinaryMul
  | "div" => run (F := Fbinary129Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary129Binary)).name
      (fun a b _ => ExecFloat.div a b) binary129BinaryDiv
  | "sqrt" => run (F := Fbinary129Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary129Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary129BinarySqrt
  | "fma" => run (F := Fbinary129Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary129Binary)).name
      ExecFloat.fma binary129BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary129Limbs := ExecFloat.Binary.LimbFamily 15 113
abbrev Tbinary129Limbs := ExecFloat Fbinary129Limbs
bounded_binary binary129LimbsAdd : Tbinary129Limbs using ExecFloat.add
bounded_binary binary129LimbsSub : Tbinary129Limbs using ExecFloat.sub
bounded_binary binary129LimbsMul : Tbinary129Limbs using ExecFloat.mul
bounded_binary binary129LimbsDiv : Tbinary129Limbs using ExecFloat.div
bounded_unary binary129LimbsSqrt : Tbinary129Limbs using ExecFloat.sqrt
bounded_ternary binary129LimbsFma : Tbinary129Limbs using ExecFloat.fma

@[noinline] public def runbinary129Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary129Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary129Limbs)).name
      (fun a b _ => ExecFloat.add a b) binary129LimbsAdd
  | "sub" => run (F := Fbinary129Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary129Limbs)).name
      (fun a b _ => ExecFloat.sub a b) binary129LimbsSub
  | "mul" => run (F := Fbinary129Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary129Limbs)).name
      (fun a b _ => ExecFloat.mul a b) binary129LimbsMul
  | "div" => run (F := Fbinary129Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary129Limbs)).name
      (fun a b _ => ExecFloat.div a b) binary129LimbsDiv
  | "sqrt" => run (F := Fbinary129Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary129Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) binary129LimbsSqrt
  | "fma" => run (F := Fbinary129Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary129Limbs)).name
      ExecFloat.fma binary129LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision31Binary := ExecFloat.Binary.Family 11 30
abbrev Tprecision31Binary := ExecFloat Fprecision31Binary
bounded_binary precision31BinaryAdd : Tprecision31Binary using ExecFloat.add
bounded_binary precision31BinarySub : Tprecision31Binary using ExecFloat.sub
bounded_binary precision31BinaryMul : Tprecision31Binary using ExecFloat.mul
bounded_binary precision31BinaryDiv : Tprecision31Binary using ExecFloat.div
bounded_unary precision31BinarySqrt : Tprecision31Binary using ExecFloat.sqrt
bounded_ternary precision31BinaryFma : Tprecision31Binary using ExecFloat.fma

@[noinline] public def runprecision31Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision31Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision31Binary)).name
      (fun a b _ => ExecFloat.add a b) precision31BinaryAdd
  | "sub" => run (F := Fprecision31Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision31Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision31BinarySub
  | "mul" => run (F := Fprecision31Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision31Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision31BinaryMul
  | "div" => run (F := Fprecision31Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision31Binary)).name
      (fun a b _ => ExecFloat.div a b) precision31BinaryDiv
  | "sqrt" => run (F := Fprecision31Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision31Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision31BinarySqrt
  | "fma" => run (F := Fprecision31Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision31Binary)).name
      ExecFloat.fma precision31BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision129Binary := ExecFloat.Binary.Family 19 128
abbrev Tprecision129Binary := ExecFloat Fprecision129Binary
bounded_binary precision129BinaryAdd : Tprecision129Binary using ExecFloat.add
bounded_binary precision129BinarySub : Tprecision129Binary using ExecFloat.sub
bounded_binary precision129BinaryMul : Tprecision129Binary using ExecFloat.mul
bounded_binary precision129BinaryDiv : Tprecision129Binary using ExecFloat.div
bounded_unary precision129BinarySqrt : Tprecision129Binary using ExecFloat.sqrt
bounded_ternary precision129BinaryFma : Tprecision129Binary using ExecFloat.fma

@[noinline] public def runprecision129Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision129Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision129Binary)).name
      (fun a b _ => ExecFloat.add a b) precision129BinaryAdd
  | "sub" => run (F := Fprecision129Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision129Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision129BinarySub
  | "mul" => run (F := Fprecision129Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision129Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision129BinaryMul
  | "div" => run (F := Fprecision129Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision129Binary)).name
      (fun a b _ => ExecFloat.div a b) precision129BinaryDiv
  | "sqrt" => run (F := Fprecision129Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision129Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision129BinarySqrt
  | "fma" => run (F := Fprecision129Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision129Binary)).name
      ExecFloat.fma precision129BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision129Limbs := ExecFloat.Binary.LimbFamily 19 128
abbrev Tprecision129Limbs := ExecFloat Fprecision129Limbs
bounded_binary precision129LimbsAdd : Tprecision129Limbs using ExecFloat.add
bounded_binary precision129LimbsSub : Tprecision129Limbs using ExecFloat.sub
bounded_binary precision129LimbsMul : Tprecision129Limbs using ExecFloat.mul
bounded_binary precision129LimbsDiv : Tprecision129Limbs using ExecFloat.div
bounded_unary precision129LimbsSqrt : Tprecision129Limbs using ExecFloat.sqrt
bounded_ternary precision129LimbsFma : Tprecision129Limbs using ExecFloat.fma

@[noinline] public def runprecision129Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision129Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision129Limbs)).name
      (fun a b _ => ExecFloat.add a b) precision129LimbsAdd
  | "sub" => run (F := Fprecision129Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision129Limbs)).name
      (fun a b _ => ExecFloat.sub a b) precision129LimbsSub
  | "mul" => run (F := Fprecision129Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision129Limbs)).name
      (fun a b _ => ExecFloat.mul a b) precision129LimbsMul
  | "div" => run (F := Fprecision129Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision129Limbs)).name
      (fun a b _ => ExecFloat.div a b) precision129LimbsDiv
  | "sqrt" => run (F := Fprecision129Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision129Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) precision129LimbsSqrt
  | "fma" => run (F := Fprecision129Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision129Limbs)).name
      ExecFloat.fma precision129LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision1024Binary := ExecFloat.Binary.Family 19 1023
abbrev Tprecision1024Binary := ExecFloat Fprecision1024Binary
bounded_binary precision1024BinaryAdd : Tprecision1024Binary using ExecFloat.add
bounded_binary precision1024BinarySub : Tprecision1024Binary using ExecFloat.sub
bounded_binary precision1024BinaryMul : Tprecision1024Binary using ExecFloat.mul
bounded_binary precision1024BinaryDiv : Tprecision1024Binary using ExecFloat.div
bounded_unary precision1024BinarySqrt : Tprecision1024Binary using ExecFloat.sqrt
bounded_ternary precision1024BinaryFma : Tprecision1024Binary using ExecFloat.fma

@[noinline] public def runprecision1024Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision1024Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision1024Binary)).name
      (fun a b _ => ExecFloat.add a b) precision1024BinaryAdd
  | "sub" => run (F := Fprecision1024Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision1024Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision1024BinarySub
  | "mul" => run (F := Fprecision1024Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision1024Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision1024BinaryMul
  | "div" => run (F := Fprecision1024Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision1024Binary)).name
      (fun a b _ => ExecFloat.div a b) precision1024BinaryDiv
  | "sqrt" => run (F := Fprecision1024Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision1024Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision1024BinarySqrt
  | "fma" => run (F := Fprecision1024Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision1024Binary)).name
      ExecFloat.fma precision1024BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision1024Limbs := ExecFloat.Binary.LimbFamily 19 1023
abbrev Tprecision1024Limbs := ExecFloat Fprecision1024Limbs
bounded_binary precision1024LimbsAdd : Tprecision1024Limbs using ExecFloat.add
bounded_binary precision1024LimbsSub : Tprecision1024Limbs using ExecFloat.sub
bounded_binary precision1024LimbsMul : Tprecision1024Limbs using ExecFloat.mul
bounded_binary precision1024LimbsDiv : Tprecision1024Limbs using ExecFloat.div
bounded_unary precision1024LimbsSqrt : Tprecision1024Limbs using ExecFloat.sqrt
bounded_ternary precision1024LimbsFma : Tprecision1024Limbs using ExecFloat.fma

@[noinline] public def runprecision1024Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision1024Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision1024Limbs)).name
      (fun a b _ => ExecFloat.add a b) precision1024LimbsAdd
  | "sub" => run (F := Fprecision1024Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision1024Limbs)).name
      (fun a b _ => ExecFloat.sub a b) precision1024LimbsSub
  | "mul" => run (F := Fprecision1024Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision1024Limbs)).name
      (fun a b _ => ExecFloat.mul a b) precision1024LimbsMul
  | "div" => run (F := Fprecision1024Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision1024Limbs)).name
      (fun a b _ => ExecFloat.div a b) precision1024LimbsDiv
  | "sqrt" => run (F := Fprecision1024Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision1024Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) precision1024LimbsSqrt
  | "fma" => run (F := Fprecision1024Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision1024Limbs)).name
      ExecFloat.fma precision1024LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

end BoundedBench.Driver
