#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <inttypes.h>
#include <mpfr.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define N 16
#define SEED UINT64_C(14695981039346656037)
#define MULT UINT64_C(1099511628211)
#define NOINLINE __attribute__((noinline))

static unsigned exponent_bits, fraction_bits, width;
static long bias;
static mpfr_prec_t precision;
static mpfr_t xs[N], ys[N], zs[N], rounded;
static volatile uint64_t observed;

static uint64_t nanos(void) {
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC, &t)) abort();
    return (uint64_t)t.tv_sec * UINT64_C(1000000000) + t.tv_nsec;
}

static uint64_t number(const char *s) {
    char *end = NULL;
    errno = 0;
    unsigned long long n = strtoull(s, &end, 10);
    if (errno || !*s || *end) {
        fprintf(stderr, "invalid integer: %s\n", s);
        exit(2);
    }
    return n;
}

/* A constant-cost projection of the low encoded word. MPFR left-aligns its
 * significand in the public limb array. No temporary mpz is constructed here.
 * Full encoding below independently checks this projection before timing.
 */
static inline uint64_t low_bits(mpfr_srcptr x) {
    uint64_t sign = (width <= 64 && mpfr_signbit(x))
                        ? UINT64_C(1) << (width - 1) : 0;
    if (mpfr_zero_p(x)) return sign;
    if (!mpfr_number_p(x)) {
        uint64_t e = fraction_bits < 64
                       ? ((UINT64_C(1) << exponent_bits) - 1) << fraction_bits : 0;
        uint64_t nan = mpfr_nan_p(x) && fraction_bits <= 64
                         ? UINT64_C(1) << (fraction_bits - 1) : 0;
        return sign | e | nan;
    }
    long e = mpfr_get_exp(x);
    unsigned padding = (GMP_NUMB_BITS - precision % GMP_NUMB_BITS) % GMP_NUMB_BITS;
    unsigned subshift = e < 2 - bias ? (unsigned)(2 - bias - e) : 0;
    unsigned shift = padding + subshift;
    unsigned limb = shift / GMP_NUMB_BITS, offset = shift % GMP_NUMB_BITS;
    unsigned count = (precision + GMP_NUMB_BITS - 1) / GMP_NUMB_BITS;
    uint64_t low = limb < count ? (uint64_t)x->_mpfr_d[limb] >> offset : 0;
    if (offset && limb + 1 < count)
        low |= (uint64_t)x->_mpfr_d[limb + 1] << (GMP_NUMB_BITS - offset);
    if (fraction_bits < 64) {
        low &= (UINT64_C(1) << fraction_bits) - 1;
        if (e >= 2 - bias) low |= (uint64_t)(e - 1 + bias) << fraction_bits;
    }
    return low | sign;
}

static void set_encoded(mpfr_ptr x, const char *text) {
    mpz_t bits, mantissa, temp;
    mpz_inits(bits, mantissa, temp, NULL);
    if (mpz_set_str(bits, text, 10) != 0 || mpz_sgn(bits) < 0 ||
        mpz_sizeinbase(bits, 2) > width) abort();
    int sign = mpz_tstbit(bits, width - 1);
    mpz_fdiv_q_2exp(temp, bits, fraction_bits);
    unsigned long exponent = mpz_get_ui(temp) & ((1UL << exponent_bits) - 1);
    mpz_fdiv_r_2exp(mantissa, bits, fraction_bits);
    if (exponent == (1UL << exponent_bits) - 1) {
        if (mpz_sgn(mantissa)) mpfr_set_nan(x);
        else mpfr_set_inf(x, sign ? -1 : 1);
    } else if (!exponent && !mpz_sgn(mantissa)) {
        mpfr_set_zero(x, sign ? -1 : 1);
    } else {
        if (exponent) mpz_setbit(mantissa, fraction_bits);
        if (sign) mpz_neg(mantissa, mantissa);
        long scale = (exponent ? (long)exponent - bias : 1 - bias) - fraction_bits;
        int ternary = mpfr_set_z_2exp(x, mantissa, scale, MPFR_RNDN);
        ternary = mpfr_subnormalize(x, ternary, MPFR_RNDN);
        if (ternary) {
            fprintf(stderr, "input conversion was not exact\n");
            abort();
        }
    }
    mpz_clears(bits, mantissa, temp, NULL);
}

static void encoded(mpz_ptr result, mpfr_srcptr x) {
    mpz_set_ui(result, 0);
    if (mpfr_nan_p(x)) {
        mpz_set_ui(result, (1UL << exponent_bits) - 1);
        mpz_mul_2exp(result, result, fraction_bits);
        mpz_setbit(result, fraction_bits - 1);
        return;
    }
    if (mpfr_inf_p(x)) {
        mpz_set_ui(result, (1UL << exponent_bits) - 1);
        mpz_mul_2exp(result, result, fraction_bits);
    } else if (!mpfr_zero_p(x)) {
        long exponent = mpfr_get_exp(x);
        long target_scale = exponent >= 2 - bias
                              ? exponent - 1 - fraction_bits
                              : 1 - bias - fraction_bits;
        long scale = mpfr_get_z_2exp(result, x);
        mpz_abs(result, result);
        if (scale >= target_scale)
            mpz_mul_2exp(result, result, scale - target_scale);
        else {
            if (!mpz_divisible_2exp_p(result, target_scale - scale)) abort();
            mpz_fdiv_q_2exp(result, result, target_scale - scale);
        }
        if (exponent >= 2 - bias) {
            mpz_clrbit(result, fraction_bits);
            mpz_t field;
            mpz_init_set_ui(field, exponent - 1 + bias);
            mpz_mul_2exp(field, field, fraction_bits);
            mpz_ior(result, result, field);
            mpz_clear(field);
        }
    }
    if (mpfr_signbit(x)) mpz_setbit(result, width - 1);
}

static void load(const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) { perror(path); exit(2); }
    char *line = NULL;
    size_t capacity = 0;
    for (size_t i = 0; i < N; ++i) {
        if (getline(&line, &capacity, f) <= 0) abort();
        char *a = strtok(line, "\t\r\n"), *b = strtok(NULL, "\t\r\n"),
             *c = strtok(NULL, "\t\r\n");
        if (!a || !b || !c || strtok(NULL, "\t\r\n")) abort();
        mpfr_init2(xs[i], precision);
        mpfr_init2(ys[i], precision);
        mpfr_init2(zs[i], precision);
        set_encoded(xs[i], a); set_encoded(ys[i], b); set_encoded(zs[i], c);
    }
    if (getline(&line, &capacity, f) > 0) abort();
    free(line);
    fclose(f);
    mpfr_init2(rounded, precision);
}

#define BINARY(NAME) \
static int op_##NAME(size_t i) { \
    return mpfr_##NAME(rounded, xs[i], ys[i], MPFR_RNDN); \
} \
static NOINLINE uint64_t run_##NAME(uint64_t count, uint64_t sink) { \
    while (count) { \
        size_t i = --count & 15; \
        int ternary = mpfr_##NAME(rounded, xs[i], ys[i], MPFR_RNDN); \
        mpfr_subnormalize(rounded, ternary, MPFR_RNDN); \
        sink = (sink ^ low_bits(rounded)) * MULT; \
    } \
    return sink; \
}
BINARY(add)
BINARY(sub)
BINARY(mul)
BINARY(div)

static int op_sqrt(size_t i) { return mpfr_sqrt(rounded, xs[i], MPFR_RNDN); }
static int op_fma(size_t i) { return mpfr_fma(rounded, xs[i], ys[i], zs[i], MPFR_RNDN); }
static NOINLINE uint64_t run_sqrt(uint64_t count, uint64_t sink) {
    while (count) {
        size_t i = --count & 15;
        int ternary = mpfr_sqrt(rounded, xs[i], MPFR_RNDN);
        mpfr_subnormalize(rounded, ternary, MPFR_RNDN);
        sink = (sink ^ low_bits(rounded)) * MULT;
    }
    return sink;
}
static NOINLINE uint64_t run_fma(uint64_t count, uint64_t sink) {
    while (count) {
        size_t i = --count & 15;
        int ternary = mpfr_fma(rounded, xs[i], ys[i], zs[i], MPFR_RNDN);
        mpfr_subnormalize(rounded, ternary, MPFR_RNDN);
        sink = (sink ^ low_bits(rounded)) * MULT;
    }
    return sink;
}

int main(int argc, char **argv) {
    if (argc == 2 && !strcmp(argv[1], "--version")) {
        printf("MPFR %s GMP %s limb_bits=%d compiler=%s\n",
               mpfr_get_version(), gmp_version, GMP_NUMB_BITS, __VERSION__);
        return 0;
    }
    if (argc != 9 || GMP_NUMB_BITS != 64) {
        fprintf(stderr, "MODE EXP_BITS FRAC_BITS BIAS OP INPUT COUNT WARMUP\n");
        return 2;
    }
    const char *mode = argv[1], *op = argv[5];
    exponent_bits = number(argv[2]); fraction_bits = number(argv[3]);
    bias = number(argv[4]); width = 1 + exponent_bits + fraction_bits;
    precision = fraction_bits + 1;
    uint64_t count = number(argv[7]), warmup = number(argv[8]);
    if (!count || !warmup) return 2;
    if (mpfr_set_emin(2 - bias - fraction_bits) ||
        mpfr_set_emax((1L << exponent_bits) - 1 - bias)) return 2;
    load(argv[6]);
    int (*evaluate)(size_t) = NULL;
    uint64_t (*run)(uint64_t, uint64_t) = NULL;
#define SELECT(NAME) if (!strcmp(op, #NAME)) { evaluate = op_##NAME; run = run_##NAME; }
    SELECT(add) SELECT(sub) SELECT(mul) SELECT(div) SELECT(sqrt) SELECT(fma)
    if (!evaluate) return 2;
    if (!strcmp(mode, "verify")) {
        mpz_t a, b, c, result;
        mpz_inits(a, b, c, result, NULL);
        for (size_t i = 0; i < N; ++i) {
            int ternary = evaluate(i);
            mpfr_subnormalize(rounded, ternary, MPFR_RNDN);
            encoded(a, xs[i]); encoded(b, ys[i]); encoded(c, zs[i]);
            encoded(result, rounded);
            uint64_t low = low_bits(rounded);
            if (low != (uint64_t)mpz_get_ui(result)) {
                fprintf(stderr, "projection mismatch at %zu\n", i); abort();
            }
            gmp_printf("value\t%zu\t%Zd\t%Zd\t%Zd\t%Zd\t%" PRIu64 "\tMPFR\n",
                       i, a, b, c, result, low);
        }
        mpz_clears(a, b, c, result, NULL);
    } else if (!strcmp(mode, "time")) {
        observed = run(warmup, SEED);
        uint64_t seed = observed;
        uint64_t start = nanos();
        observed = run(count, seed);
        uint64_t stop = nanos();
        printf("time\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64
               "\t%" PRIu64 "\tMPFR\n", count, warmup, stop-start, observed, seed);
    } else return 2;
    mpfr_clear(rounded);
    for (size_t i = 0; i < N; ++i) {
        mpfr_clear(xs[i]); mpfr_clear(ys[i]); mpfr_clear(zs[i]);
    }
    mpfr_free_cache();
    return 0;
}
