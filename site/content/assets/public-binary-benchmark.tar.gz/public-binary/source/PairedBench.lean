module

import DriverSupport
import BenchPart00
import BenchPart01
import BenchPart02
import BenchPart03
import BenchPart04
import BenchPart05
import BenchPart06
import BenchPart07
import BenchRuntime

open FloatLib.Floats
open FloatLib.Floats.Formats.BinaryInterchange
open BoundedBench

namespace BoundedBench.Driver

def main (args : List String) : IO Unit := do
  let [mode, format, arm, op, path, count, warm] := args
    | throw <| IO.userError "MODE FORMAT ARM OP INPUT COUNT WARMUP"
  let iterations ← parseNat count
  let warmup ← parseNat warm
  unless iterations > 0 && warmup > 0 do
    throw <| IO.userError "counts must be positive"
  match format, arm with
  | "binary32", "binary" => runbinary32Binary mode path op iterations warmup
  | "binary64", "binary" => runbinary64Binary mode path op iterations warmup
  | "binary128", "binary" => runbinary128Binary mode path op iterations warmup
  | "binary256", "binary" => runbinary256Binary mode path op iterations warmup
  | "binary256", "limbs" => runbinary256Limbs mode path op iterations warmup
  | "binary512", "binary" => runbinary512Binary mode path op iterations warmup
  | "binary512", "limbs" => runbinary512Limbs mode path op iterations warmup
  | "binary1024", "binary" => runbinary1024Binary mode path op iterations warmup
  | "binary1024", "limbs" => runbinary1024Limbs mode path op iterations warmup
  | "binary2048", "binary" => runbinary2048Binary mode path op iterations warmup
  | "binary2048", "limbs" => runbinary2048Limbs mode path op iterations warmup
  | "binary4096", "binary" => runbinary4096Binary mode path op iterations warmup
  | "binary4096", "limbs" => runbinary4096Limbs mode path op iterations warmup
  | "descriptor24", "descriptor" => rundescriptor24Descriptor mode path op iterations warmup
  | "descriptor48", "descriptor" => rundescriptor48Descriptor mode path op iterations warmup
  | "descriptor64", "descriptor" => rundescriptor64Descriptor mode path op iterations warmup
  | "descriptor64e19", "descriptor" => rundescriptor64e19Descriptor mode path op iterations warmup
  | "binary17", "binary" => runbinary17Binary mode path op iterations warmup
  | "binary31", "binary" => runbinary31Binary mode path op iterations warmup
  | "binary33", "binary" => runbinary33Binary mode path op iterations warmup
  | "binary63", "binary" => runbinary63Binary mode path op iterations warmup
  | "binary65", "binary" => runbinary65Binary mode path op iterations warmup
  | "binary127", "binary" => runbinary127Binary mode path op iterations warmup
  | "binary129", "binary" => runbinary129Binary mode path op iterations warmup
  | "binary129", "limbs" => runbinary129Limbs mode path op iterations warmup
  | "binary255", "binary" => runbinary255Binary mode path op iterations warmup
  | "binary255", "limbs" => runbinary255Limbs mode path op iterations warmup
  | "binary257", "binary" => runbinary257Binary mode path op iterations warmup
  | "binary257", "limbs" => runbinary257Limbs mode path op iterations warmup
  | "binary511", "binary" => runbinary511Binary mode path op iterations warmup
  | "binary511", "limbs" => runbinary511Limbs mode path op iterations warmup
  | "binary513", "binary" => runbinary513Binary mode path op iterations warmup
  | "binary513", "limbs" => runbinary513Limbs mode path op iterations warmup
  | "binary1023", "binary" => runbinary1023Binary mode path op iterations warmup
  | "binary1023", "limbs" => runbinary1023Limbs mode path op iterations warmup
  | "binary1025", "binary" => runbinary1025Binary mode path op iterations warmup
  | "binary1025", "limbs" => runbinary1025Limbs mode path op iterations warmup
  | "precision17", "binary" => runprecision17Binary mode path op iterations warmup
  | "precision31", "binary" => runprecision31Binary mode path op iterations warmup
  | "precision32", "binary" => runprecision32Binary mode path op iterations warmup
  | "precision33", "binary" => runprecision33Binary mode path op iterations warmup
  | "precision63", "binary" => runprecision63Binary mode path op iterations warmup
  | "precision64", "binary" => runprecision64Binary mode path op iterations warmup
  | "precision65", "binary" => runprecision65Binary mode path op iterations warmup
  | "precision127", "binary" => runprecision127Binary mode path op iterations warmup
  | "precision127", "limbs" => runprecision127Limbs mode path op iterations warmup
  | "precision128", "binary" => runprecision128Binary mode path op iterations warmup
  | "precision128", "limbs" => runprecision128Limbs mode path op iterations warmup
  | "precision129", "binary" => runprecision129Binary mode path op iterations warmup
  | "precision129", "limbs" => runprecision129Limbs mode path op iterations warmup
  | "precision255", "binary" => runprecision255Binary mode path op iterations warmup
  | "precision255", "limbs" => runprecision255Limbs mode path op iterations warmup
  | "precision256", "binary" => runprecision256Binary mode path op iterations warmup
  | "precision256", "limbs" => runprecision256Limbs mode path op iterations warmup
  | "precision257", "binary" => runprecision257Binary mode path op iterations warmup
  | "precision257", "limbs" => runprecision257Limbs mode path op iterations warmup
  | "precision511", "binary" => runprecision511Binary mode path op iterations warmup
  | "precision511", "limbs" => runprecision511Limbs mode path op iterations warmup
  | "precision512", "binary" => runprecision512Binary mode path op iterations warmup
  | "precision512", "limbs" => runprecision512Limbs mode path op iterations warmup
  | "precision513", "binary" => runprecision513Binary mode path op iterations warmup
  | "precision513", "limbs" => runprecision513Limbs mode path op iterations warmup
  | "precision1023", "binary" => runprecision1023Binary mode path op iterations warmup
  | "precision1023", "limbs" => runprecision1023Limbs mode path op iterations warmup
  | "precision1024", "binary" => runprecision1024Binary mode path op iterations warmup
  | "precision1024", "limbs" => runprecision1024Limbs mode path op iterations warmup
  | "precision1025", "binary" => runprecision1025Binary mode path op iterations warmup
  | "precision1025", "limbs" => runprecision1025Limbs mode path op iterations warmup
  | "binary16", "binary" => runbinary16Binary mode path op iterations warmup
  | "bfloat16", "binary" => runbfloat16Binary mode path op iterations warmup
  | "binary8e5m2", "binary" => runbinary8e5m2Binary mode path op iterations warmup
  | "binary7e3m3", "binary" => runbinary7e3m3Binary mode path op iterations warmup
  | "binary8e4m3", "binary" => runbinary8e4m3Binary mode path op iterations warmup
  | "binary9e4m4", "binary" => runbinary9e4m4Binary mode path op iterations warmup
  | format, "descriptor" => do
    let ["runtime", expText, fracText] := format.splitOn ":"
      | throw <| IO.userError s!"unknown runtime descriptor: {format}"
    let expWidth ← parseNat expText
    let fracWidth ← parseNat fracText
    if he : 2 ≤ expWidth then
      if hf : 0 < fracWidth then
        runRuntime (FloatFormat.ieee expWidth fracWidth he hf)
          mode path op iterations warmup
      else throw <| IO.userError "fraction width must be positive"
    else throw <| IO.userError "exponent width must be at least two"

  | _, _ => throw <| IO.userError s!"unsupported carrier: {format}/{arm}"

end BoundedBench.Driver

public def main : List String → IO Unit := BoundedBench.Driver.main
