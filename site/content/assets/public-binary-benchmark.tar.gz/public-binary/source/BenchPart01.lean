module

import DriverSupport

open FloatLib.Floats
open FloatLib.Floats.Formats.BinaryInterchange
open BoundedBench

namespace BoundedBench.Driver

abbrev Fbinary64Binary := ExecFloat.Binary.Family 11 52
abbrev Tbinary64Binary := ExecFloat Fbinary64Binary
bounded_binary binary64BinaryAdd : Tbinary64Binary using ExecFloat.add
bounded_binary binary64BinarySub : Tbinary64Binary using ExecFloat.sub
bounded_binary binary64BinaryMul : Tbinary64Binary using ExecFloat.mul
bounded_binary binary64BinaryDiv : Tbinary64Binary using ExecFloat.div
bounded_unary binary64BinarySqrt : Tbinary64Binary using ExecFloat.sqrt
bounded_ternary binary64BinaryFma : Tbinary64Binary using ExecFloat.fma

@[noinline] public def runbinary64Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary64Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary64Binary)).name
      (fun a b _ => ExecFloat.add a b) binary64BinaryAdd
  | "sub" => run (F := Fbinary64Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary64Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary64BinarySub
  | "mul" => run (F := Fbinary64Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary64Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary64BinaryMul
  | "div" => run (F := Fbinary64Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary64Binary)).name
      (fun a b _ => ExecFloat.div a b) binary64BinaryDiv
  | "sqrt" => run (F := Fbinary64Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary64Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary64BinarySqrt
  | "fma" => run (F := Fbinary64Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary64Binary)).name
      ExecFloat.fma binary64BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fdescriptor48Descriptor := Descriptor (FloatFormat.ieee 7 40)
abbrev Tdescriptor48Descriptor := ExecFloat Fdescriptor48Descriptor
bounded_binary descriptor48DescriptorAdd : Tdescriptor48Descriptor using ExecFloat.add
bounded_binary descriptor48DescriptorSub : Tdescriptor48Descriptor using ExecFloat.sub
bounded_binary descriptor48DescriptorMul : Tdescriptor48Descriptor using ExecFloat.mul
bounded_binary descriptor48DescriptorDiv : Tdescriptor48Descriptor using ExecFloat.div
bounded_unary descriptor48DescriptorSqrt : Tdescriptor48Descriptor using ExecFloat.sqrt
bounded_ternary descriptor48DescriptorFma : Tdescriptor48Descriptor using ExecFloat.fma

@[noinline] public def rundescriptor48Descriptor (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fdescriptor48Descriptor) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fdescriptor48Descriptor)).name
      (fun a b _ => ExecFloat.add a b) descriptor48DescriptorAdd
  | "sub" => run (F := Fdescriptor48Descriptor) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fdescriptor48Descriptor)).name
      (fun a b _ => ExecFloat.sub a b) descriptor48DescriptorSub
  | "mul" => run (F := Fdescriptor48Descriptor) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fdescriptor48Descriptor)).name
      (fun a b _ => ExecFloat.mul a b) descriptor48DescriptorMul
  | "div" => run (F := Fdescriptor48Descriptor) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fdescriptor48Descriptor)).name
      (fun a b _ => ExecFloat.div a b) descriptor48DescriptorDiv
  | "sqrt" => run (F := Fdescriptor48Descriptor) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fdescriptor48Descriptor)).name
      (fun a _ _ => ExecFloat.sqrt a) descriptor48DescriptorSqrt
  | "fma" => run (F := Fdescriptor48Descriptor) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fdescriptor48Descriptor)).name
      ExecFloat.fma descriptor48DescriptorFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary127Binary := ExecFloat.Binary.Family 15 111
abbrev Tbinary127Binary := ExecFloat Fbinary127Binary
bounded_binary binary127BinaryAdd : Tbinary127Binary using ExecFloat.add
bounded_binary binary127BinarySub : Tbinary127Binary using ExecFloat.sub
bounded_binary binary127BinaryMul : Tbinary127Binary using ExecFloat.mul
bounded_binary binary127BinaryDiv : Tbinary127Binary using ExecFloat.div
bounded_unary binary127BinarySqrt : Tbinary127Binary using ExecFloat.sqrt
bounded_ternary binary127BinaryFma : Tbinary127Binary using ExecFloat.fma

@[noinline] public def runbinary127Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary127Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary127Binary)).name
      (fun a b _ => ExecFloat.add a b) binary127BinaryAdd
  | "sub" => run (F := Fbinary127Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary127Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary127BinarySub
  | "mul" => run (F := Fbinary127Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary127Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary127BinaryMul
  | "div" => run (F := Fbinary127Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary127Binary)).name
      (fun a b _ => ExecFloat.div a b) binary127BinaryDiv
  | "sqrt" => run (F := Fbinary127Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary127Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary127BinarySqrt
  | "fma" => run (F := Fbinary127Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary127Binary)).name
      ExecFloat.fma binary127BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision17Binary := ExecFloat.Binary.Family 11 16
abbrev Tprecision17Binary := ExecFloat Fprecision17Binary
bounded_binary precision17BinaryAdd : Tprecision17Binary using ExecFloat.add
bounded_binary precision17BinarySub : Tprecision17Binary using ExecFloat.sub
bounded_binary precision17BinaryMul : Tprecision17Binary using ExecFloat.mul
bounded_binary precision17BinaryDiv : Tprecision17Binary using ExecFloat.div
bounded_unary precision17BinarySqrt : Tprecision17Binary using ExecFloat.sqrt
bounded_ternary precision17BinaryFma : Tprecision17Binary using ExecFloat.fma

@[noinline] public def runprecision17Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision17Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision17Binary)).name
      (fun a b _ => ExecFloat.add a b) precision17BinaryAdd
  | "sub" => run (F := Fprecision17Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision17Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision17BinarySub
  | "mul" => run (F := Fprecision17Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision17Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision17BinaryMul
  | "div" => run (F := Fprecision17Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision17Binary)).name
      (fun a b _ => ExecFloat.div a b) precision17BinaryDiv
  | "sqrt" => run (F := Fprecision17Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision17Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision17BinarySqrt
  | "fma" => run (F := Fprecision17Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision17Binary)).name
      ExecFloat.fma precision17BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision128Binary := ExecFloat.Binary.Family 19 127
abbrev Tprecision128Binary := ExecFloat Fprecision128Binary
bounded_binary precision128BinaryAdd : Tprecision128Binary using ExecFloat.add
bounded_binary precision128BinarySub : Tprecision128Binary using ExecFloat.sub
bounded_binary precision128BinaryMul : Tprecision128Binary using ExecFloat.mul
bounded_binary precision128BinaryDiv : Tprecision128Binary using ExecFloat.div
bounded_unary precision128BinarySqrt : Tprecision128Binary using ExecFloat.sqrt
bounded_ternary precision128BinaryFma : Tprecision128Binary using ExecFloat.fma

@[noinline] public def runprecision128Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision128Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision128Binary)).name
      (fun a b _ => ExecFloat.add a b) precision128BinaryAdd
  | "sub" => run (F := Fprecision128Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision128Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision128BinarySub
  | "mul" => run (F := Fprecision128Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision128Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision128BinaryMul
  | "div" => run (F := Fprecision128Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision128Binary)).name
      (fun a b _ => ExecFloat.div a b) precision128BinaryDiv
  | "sqrt" => run (F := Fprecision128Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision128Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision128BinarySqrt
  | "fma" => run (F := Fprecision128Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision128Binary)).name
      ExecFloat.fma precision128BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision128Limbs := ExecFloat.Binary.LimbFamily 19 127
abbrev Tprecision128Limbs := ExecFloat Fprecision128Limbs
bounded_binary precision128LimbsAdd : Tprecision128Limbs using ExecFloat.add
bounded_binary precision128LimbsSub : Tprecision128Limbs using ExecFloat.sub
bounded_binary precision128LimbsMul : Tprecision128Limbs using ExecFloat.mul
bounded_binary precision128LimbsDiv : Tprecision128Limbs using ExecFloat.div
bounded_unary precision128LimbsSqrt : Tprecision128Limbs using ExecFloat.sqrt
bounded_ternary precision128LimbsFma : Tprecision128Limbs using ExecFloat.fma

@[noinline] public def runprecision128Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision128Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision128Limbs)).name
      (fun a b _ => ExecFloat.add a b) precision128LimbsAdd
  | "sub" => run (F := Fprecision128Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision128Limbs)).name
      (fun a b _ => ExecFloat.sub a b) precision128LimbsSub
  | "mul" => run (F := Fprecision128Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision128Limbs)).name
      (fun a b _ => ExecFloat.mul a b) precision128LimbsMul
  | "div" => run (F := Fprecision128Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision128Limbs)).name
      (fun a b _ => ExecFloat.div a b) precision128LimbsDiv
  | "sqrt" => run (F := Fprecision128Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision128Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) precision128LimbsSqrt
  | "fma" => run (F := Fprecision128Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision128Limbs)).name
      ExecFloat.fma precision128LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision1023Binary := ExecFloat.Binary.Family 19 1022
abbrev Tprecision1023Binary := ExecFloat Fprecision1023Binary
bounded_binary precision1023BinaryAdd : Tprecision1023Binary using ExecFloat.add
bounded_binary precision1023BinarySub : Tprecision1023Binary using ExecFloat.sub
bounded_binary precision1023BinaryMul : Tprecision1023Binary using ExecFloat.mul
bounded_binary precision1023BinaryDiv : Tprecision1023Binary using ExecFloat.div
bounded_unary precision1023BinarySqrt : Tprecision1023Binary using ExecFloat.sqrt
bounded_ternary precision1023BinaryFma : Tprecision1023Binary using ExecFloat.fma

@[noinline] public def runprecision1023Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision1023Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision1023Binary)).name
      (fun a b _ => ExecFloat.add a b) precision1023BinaryAdd
  | "sub" => run (F := Fprecision1023Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision1023Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision1023BinarySub
  | "mul" => run (F := Fprecision1023Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision1023Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision1023BinaryMul
  | "div" => run (F := Fprecision1023Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision1023Binary)).name
      (fun a b _ => ExecFloat.div a b) precision1023BinaryDiv
  | "sqrt" => run (F := Fprecision1023Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision1023Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision1023BinarySqrt
  | "fma" => run (F := Fprecision1023Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision1023Binary)).name
      ExecFloat.fma precision1023BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision1023Limbs := ExecFloat.Binary.LimbFamily 19 1022
abbrev Tprecision1023Limbs := ExecFloat Fprecision1023Limbs
bounded_binary precision1023LimbsAdd : Tprecision1023Limbs using ExecFloat.add
bounded_binary precision1023LimbsSub : Tprecision1023Limbs using ExecFloat.sub
bounded_binary precision1023LimbsMul : Tprecision1023Limbs using ExecFloat.mul
bounded_binary precision1023LimbsDiv : Tprecision1023Limbs using ExecFloat.div
bounded_unary precision1023LimbsSqrt : Tprecision1023Limbs using ExecFloat.sqrt
bounded_ternary precision1023LimbsFma : Tprecision1023Limbs using ExecFloat.fma

@[noinline] public def runprecision1023Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision1023Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision1023Limbs)).name
      (fun a b _ => ExecFloat.add a b) precision1023LimbsAdd
  | "sub" => run (F := Fprecision1023Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision1023Limbs)).name
      (fun a b _ => ExecFloat.sub a b) precision1023LimbsSub
  | "mul" => run (F := Fprecision1023Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision1023Limbs)).name
      (fun a b _ => ExecFloat.mul a b) precision1023LimbsMul
  | "div" => run (F := Fprecision1023Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision1023Limbs)).name
      (fun a b _ => ExecFloat.div a b) precision1023LimbsDiv
  | "sqrt" => run (F := Fprecision1023Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision1023Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) precision1023LimbsSqrt
  | "fma" => run (F := Fprecision1023Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision1023Limbs)).name
      ExecFloat.fma precision1023LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary9e4m4Binary := ExecFloat.Binary.Family 4 4
abbrev Tbinary9e4m4Binary := ExecFloat Fbinary9e4m4Binary
bounded_binary binary9e4m4BinaryAdd : Tbinary9e4m4Binary using ExecFloat.add
bounded_binary binary9e4m4BinarySub : Tbinary9e4m4Binary using ExecFloat.sub
bounded_binary binary9e4m4BinaryMul : Tbinary9e4m4Binary using ExecFloat.mul
bounded_binary binary9e4m4BinaryDiv : Tbinary9e4m4Binary using ExecFloat.div
bounded_unary binary9e4m4BinarySqrt : Tbinary9e4m4Binary using ExecFloat.sqrt
bounded_ternary binary9e4m4BinaryFma : Tbinary9e4m4Binary using ExecFloat.fma

@[noinline] public def runbinary9e4m4Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary9e4m4Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary9e4m4Binary)).name
      (fun a b _ => ExecFloat.add a b) binary9e4m4BinaryAdd
  | "sub" => run (F := Fbinary9e4m4Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary9e4m4Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary9e4m4BinarySub
  | "mul" => run (F := Fbinary9e4m4Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary9e4m4Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary9e4m4BinaryMul
  | "div" => run (F := Fbinary9e4m4Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary9e4m4Binary)).name
      (fun a b _ => ExecFloat.div a b) binary9e4m4BinaryDiv
  | "sqrt" => run (F := Fbinary9e4m4Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary9e4m4Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary9e4m4BinarySqrt
  | "fma" => run (F := Fbinary9e4m4Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary9e4m4Binary)).name
      ExecFloat.fma binary9e4m4BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

end BoundedBench.Driver
