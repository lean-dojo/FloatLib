module

import DriverSupport

open FloatLib.Floats
open FloatLib.Floats.Formats.BinaryInterchange
open BoundedBench

namespace BoundedBench.Driver

abbrev Fbinary256Binary := ExecFloat.Binary.Family 19 236
abbrev Tbinary256Binary := ExecFloat Fbinary256Binary
bounded_binary binary256BinaryAdd : Tbinary256Binary using ExecFloat.add
bounded_binary binary256BinarySub : Tbinary256Binary using ExecFloat.sub
bounded_binary binary256BinaryMul : Tbinary256Binary using ExecFloat.mul
bounded_binary binary256BinaryDiv : Tbinary256Binary using ExecFloat.div
bounded_unary binary256BinarySqrt : Tbinary256Binary using ExecFloat.sqrt
bounded_ternary binary256BinaryFma : Tbinary256Binary using ExecFloat.fma

@[noinline] public def runbinary256Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary256Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary256Binary)).name
      (fun a b _ => ExecFloat.add a b) binary256BinaryAdd
  | "sub" => run (F := Fbinary256Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary256Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary256BinarySub
  | "mul" => run (F := Fbinary256Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary256Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary256BinaryMul
  | "div" => run (F := Fbinary256Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary256Binary)).name
      (fun a b _ => ExecFloat.div a b) binary256BinaryDiv
  | "sqrt" => run (F := Fbinary256Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary256Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary256BinarySqrt
  | "fma" => run (F := Fbinary256Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary256Binary)).name
      ExecFloat.fma binary256BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary256Limbs := ExecFloat.Binary.LimbFamily 19 236
abbrev Tbinary256Limbs := ExecFloat Fbinary256Limbs
bounded_binary binary256LimbsAdd : Tbinary256Limbs using ExecFloat.add
bounded_binary binary256LimbsSub : Tbinary256Limbs using ExecFloat.sub
bounded_binary binary256LimbsMul : Tbinary256Limbs using ExecFloat.mul
bounded_binary binary256LimbsDiv : Tbinary256Limbs using ExecFloat.div
bounded_unary binary256LimbsSqrt : Tbinary256Limbs using ExecFloat.sqrt
bounded_ternary binary256LimbsFma : Tbinary256Limbs using ExecFloat.fma

@[noinline] public def runbinary256Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary256Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary256Limbs)).name
      (fun a b _ => ExecFloat.add a b) binary256LimbsAdd
  | "sub" => run (F := Fbinary256Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary256Limbs)).name
      (fun a b _ => ExecFloat.sub a b) binary256LimbsSub
  | "mul" => run (F := Fbinary256Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary256Limbs)).name
      (fun a b _ => ExecFloat.mul a b) binary256LimbsMul
  | "div" => run (F := Fbinary256Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary256Limbs)).name
      (fun a b _ => ExecFloat.div a b) binary256LimbsDiv
  | "sqrt" => run (F := Fbinary256Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary256Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) binary256LimbsSqrt
  | "fma" => run (F := Fbinary256Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary256Limbs)).name
      ExecFloat.fma binary256LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fdescriptor64e19Descriptor := Descriptor (FloatFormat.ieee 19 44)
abbrev Tdescriptor64e19Descriptor := ExecFloat Fdescriptor64e19Descriptor
bounded_binary descriptor64e19DescriptorAdd : Tdescriptor64e19Descriptor using ExecFloat.add
bounded_binary descriptor64e19DescriptorSub : Tdescriptor64e19Descriptor using ExecFloat.sub
bounded_binary descriptor64e19DescriptorMul : Tdescriptor64e19Descriptor using ExecFloat.mul
bounded_binary descriptor64e19DescriptorDiv : Tdescriptor64e19Descriptor using ExecFloat.div
bounded_unary descriptor64e19DescriptorSqrt : Tdescriptor64e19Descriptor using ExecFloat.sqrt
bounded_ternary descriptor64e19DescriptorFma : Tdescriptor64e19Descriptor using ExecFloat.fma

@[noinline] public def rundescriptor64e19Descriptor (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fdescriptor64e19Descriptor) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fdescriptor64e19Descriptor)).name
      (fun a b _ => ExecFloat.add a b) descriptor64e19DescriptorAdd
  | "sub" => run (F := Fdescriptor64e19Descriptor) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fdescriptor64e19Descriptor)).name
      (fun a b _ => ExecFloat.sub a b) descriptor64e19DescriptorSub
  | "mul" => run (F := Fdescriptor64e19Descriptor) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fdescriptor64e19Descriptor)).name
      (fun a b _ => ExecFloat.mul a b) descriptor64e19DescriptorMul
  | "div" => run (F := Fdescriptor64e19Descriptor) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fdescriptor64e19Descriptor)).name
      (fun a b _ => ExecFloat.div a b) descriptor64e19DescriptorDiv
  | "sqrt" => run (F := Fdescriptor64e19Descriptor) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fdescriptor64e19Descriptor)).name
      (fun a _ _ => ExecFloat.sqrt a) descriptor64e19DescriptorSqrt
  | "fma" => run (F := Fdescriptor64e19Descriptor) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fdescriptor64e19Descriptor)).name
      ExecFloat.fma descriptor64e19DescriptorFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary255Binary := ExecFloat.Binary.Family 19 235
abbrev Tbinary255Binary := ExecFloat Fbinary255Binary
bounded_binary binary255BinaryAdd : Tbinary255Binary using ExecFloat.add
bounded_binary binary255BinarySub : Tbinary255Binary using ExecFloat.sub
bounded_binary binary255BinaryMul : Tbinary255Binary using ExecFloat.mul
bounded_binary binary255BinaryDiv : Tbinary255Binary using ExecFloat.div
bounded_unary binary255BinarySqrt : Tbinary255Binary using ExecFloat.sqrt
bounded_ternary binary255BinaryFma : Tbinary255Binary using ExecFloat.fma

@[noinline] public def runbinary255Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary255Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary255Binary)).name
      (fun a b _ => ExecFloat.add a b) binary255BinaryAdd
  | "sub" => run (F := Fbinary255Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary255Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary255BinarySub
  | "mul" => run (F := Fbinary255Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary255Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary255BinaryMul
  | "div" => run (F := Fbinary255Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary255Binary)).name
      (fun a b _ => ExecFloat.div a b) binary255BinaryDiv
  | "sqrt" => run (F := Fbinary255Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary255Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary255BinarySqrt
  | "fma" => run (F := Fbinary255Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary255Binary)).name
      ExecFloat.fma binary255BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary255Limbs := ExecFloat.Binary.LimbFamily 19 235
abbrev Tbinary255Limbs := ExecFloat Fbinary255Limbs
bounded_binary binary255LimbsAdd : Tbinary255Limbs using ExecFloat.add
bounded_binary binary255LimbsSub : Tbinary255Limbs using ExecFloat.sub
bounded_binary binary255LimbsMul : Tbinary255Limbs using ExecFloat.mul
bounded_binary binary255LimbsDiv : Tbinary255Limbs using ExecFloat.div
bounded_unary binary255LimbsSqrt : Tbinary255Limbs using ExecFloat.sqrt
bounded_ternary binary255LimbsFma : Tbinary255Limbs using ExecFloat.fma

@[noinline] public def runbinary255Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary255Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary255Limbs)).name
      (fun a b _ => ExecFloat.add a b) binary255LimbsAdd
  | "sub" => run (F := Fbinary255Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary255Limbs)).name
      (fun a b _ => ExecFloat.sub a b) binary255LimbsSub
  | "mul" => run (F := Fbinary255Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary255Limbs)).name
      (fun a b _ => ExecFloat.mul a b) binary255LimbsMul
  | "div" => run (F := Fbinary255Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary255Limbs)).name
      (fun a b _ => ExecFloat.div a b) binary255LimbsDiv
  | "sqrt" => run (F := Fbinary255Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary255Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) binary255LimbsSqrt
  | "fma" => run (F := Fbinary255Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary255Limbs)).name
      ExecFloat.fma binary255LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision32Binary := ExecFloat.Binary.Family 11 31
abbrev Tprecision32Binary := ExecFloat Fprecision32Binary
bounded_binary precision32BinaryAdd : Tprecision32Binary using ExecFloat.add
bounded_binary precision32BinarySub : Tprecision32Binary using ExecFloat.sub
bounded_binary precision32BinaryMul : Tprecision32Binary using ExecFloat.mul
bounded_binary precision32BinaryDiv : Tprecision32Binary using ExecFloat.div
bounded_unary precision32BinarySqrt : Tprecision32Binary using ExecFloat.sqrt
bounded_ternary precision32BinaryFma : Tprecision32Binary using ExecFloat.fma

@[noinline] public def runprecision32Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision32Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision32Binary)).name
      (fun a b _ => ExecFloat.add a b) precision32BinaryAdd
  | "sub" => run (F := Fprecision32Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision32Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision32BinarySub
  | "mul" => run (F := Fprecision32Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision32Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision32BinaryMul
  | "div" => run (F := Fprecision32Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision32Binary)).name
      (fun a b _ => ExecFloat.div a b) precision32BinaryDiv
  | "sqrt" => run (F := Fprecision32Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision32Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision32BinarySqrt
  | "fma" => run (F := Fprecision32Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision32Binary)).name
      ExecFloat.fma precision32BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision255Binary := ExecFloat.Binary.Family 19 254
abbrev Tprecision255Binary := ExecFloat Fprecision255Binary
bounded_binary precision255BinaryAdd : Tprecision255Binary using ExecFloat.add
bounded_binary precision255BinarySub : Tprecision255Binary using ExecFloat.sub
bounded_binary precision255BinaryMul : Tprecision255Binary using ExecFloat.mul
bounded_binary precision255BinaryDiv : Tprecision255Binary using ExecFloat.div
bounded_unary precision255BinarySqrt : Tprecision255Binary using ExecFloat.sqrt
bounded_ternary precision255BinaryFma : Tprecision255Binary using ExecFloat.fma

@[noinline] public def runprecision255Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision255Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision255Binary)).name
      (fun a b _ => ExecFloat.add a b) precision255BinaryAdd
  | "sub" => run (F := Fprecision255Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision255Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision255BinarySub
  | "mul" => run (F := Fprecision255Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision255Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision255BinaryMul
  | "div" => run (F := Fprecision255Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision255Binary)).name
      (fun a b _ => ExecFloat.div a b) precision255BinaryDiv
  | "sqrt" => run (F := Fprecision255Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision255Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision255BinarySqrt
  | "fma" => run (F := Fprecision255Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision255Binary)).name
      ExecFloat.fma precision255BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision255Limbs := ExecFloat.Binary.LimbFamily 19 254
abbrev Tprecision255Limbs := ExecFloat Fprecision255Limbs
bounded_binary precision255LimbsAdd : Tprecision255Limbs using ExecFloat.add
bounded_binary precision255LimbsSub : Tprecision255Limbs using ExecFloat.sub
bounded_binary precision255LimbsMul : Tprecision255Limbs using ExecFloat.mul
bounded_binary precision255LimbsDiv : Tprecision255Limbs using ExecFloat.div
bounded_unary precision255LimbsSqrt : Tprecision255Limbs using ExecFloat.sqrt
bounded_ternary precision255LimbsFma : Tprecision255Limbs using ExecFloat.fma

@[noinline] public def runprecision255Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision255Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision255Limbs)).name
      (fun a b _ => ExecFloat.add a b) precision255LimbsAdd
  | "sub" => run (F := Fprecision255Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision255Limbs)).name
      (fun a b _ => ExecFloat.sub a b) precision255LimbsSub
  | "mul" => run (F := Fprecision255Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision255Limbs)).name
      (fun a b _ => ExecFloat.mul a b) precision255LimbsMul
  | "div" => run (F := Fprecision255Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision255Limbs)).name
      (fun a b _ => ExecFloat.div a b) precision255LimbsDiv
  | "sqrt" => run (F := Fprecision255Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision255Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) precision255LimbsSqrt
  | "fma" => run (F := Fprecision255Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision255Limbs)).name
      ExecFloat.fma precision255LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision1025Binary := ExecFloat.Binary.Family 19 1024
abbrev Tprecision1025Binary := ExecFloat Fprecision1025Binary
bounded_binary precision1025BinaryAdd : Tprecision1025Binary using ExecFloat.add
bounded_binary precision1025BinarySub : Tprecision1025Binary using ExecFloat.sub
bounded_binary precision1025BinaryMul : Tprecision1025Binary using ExecFloat.mul
bounded_binary precision1025BinaryDiv : Tprecision1025Binary using ExecFloat.div
bounded_unary precision1025BinarySqrt : Tprecision1025Binary using ExecFloat.sqrt
bounded_ternary precision1025BinaryFma : Tprecision1025Binary using ExecFloat.fma

@[noinline] public def runprecision1025Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision1025Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision1025Binary)).name
      (fun a b _ => ExecFloat.add a b) precision1025BinaryAdd
  | "sub" => run (F := Fprecision1025Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision1025Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision1025BinarySub
  | "mul" => run (F := Fprecision1025Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision1025Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision1025BinaryMul
  | "div" => run (F := Fprecision1025Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision1025Binary)).name
      (fun a b _ => ExecFloat.div a b) precision1025BinaryDiv
  | "sqrt" => run (F := Fprecision1025Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision1025Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision1025BinarySqrt
  | "fma" => run (F := Fprecision1025Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision1025Binary)).name
      ExecFloat.fma precision1025BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision1025Limbs := ExecFloat.Binary.LimbFamily 19 1024
abbrev Tprecision1025Limbs := ExecFloat Fprecision1025Limbs
bounded_binary precision1025LimbsAdd : Tprecision1025Limbs using ExecFloat.add
bounded_binary precision1025LimbsSub : Tprecision1025Limbs using ExecFloat.sub
bounded_binary precision1025LimbsMul : Tprecision1025Limbs using ExecFloat.mul
bounded_binary precision1025LimbsDiv : Tprecision1025Limbs using ExecFloat.div
bounded_unary precision1025LimbsSqrt : Tprecision1025Limbs using ExecFloat.sqrt
bounded_ternary precision1025LimbsFma : Tprecision1025Limbs using ExecFloat.fma

@[noinline] public def runprecision1025Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision1025Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision1025Limbs)).name
      (fun a b _ => ExecFloat.add a b) precision1025LimbsAdd
  | "sub" => run (F := Fprecision1025Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision1025Limbs)).name
      (fun a b _ => ExecFloat.sub a b) precision1025LimbsSub
  | "mul" => run (F := Fprecision1025Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision1025Limbs)).name
      (fun a b _ => ExecFloat.mul a b) precision1025LimbsMul
  | "div" => run (F := Fprecision1025Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision1025Limbs)).name
      (fun a b _ => ExecFloat.div a b) precision1025LimbsDiv
  | "sqrt" => run (F := Fprecision1025Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision1025Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) precision1025LimbsSqrt
  | "fma" => run (F := Fprecision1025Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision1025Limbs)).name
      ExecFloat.fma precision1025LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

end BoundedBench.Driver
