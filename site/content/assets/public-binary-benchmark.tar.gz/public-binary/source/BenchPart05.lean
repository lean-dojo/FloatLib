module

import DriverSupport

open FloatLib.Floats
open FloatLib.Floats.Formats.BinaryInterchange
open BoundedBench

namespace BoundedBench.Driver

abbrev Fbinary1024Binary := ExecFloat.Binary.Family 19 1004
abbrev Tbinary1024Binary := ExecFloat Fbinary1024Binary
bounded_binary binary1024BinaryAdd : Tbinary1024Binary using ExecFloat.add
bounded_binary binary1024BinarySub : Tbinary1024Binary using ExecFloat.sub
bounded_binary binary1024BinaryMul : Tbinary1024Binary using ExecFloat.mul
bounded_binary binary1024BinaryDiv : Tbinary1024Binary using ExecFloat.div
bounded_unary binary1024BinarySqrt : Tbinary1024Binary using ExecFloat.sqrt
bounded_ternary binary1024BinaryFma : Tbinary1024Binary using ExecFloat.fma

@[noinline] public def runbinary1024Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary1024Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary1024Binary)).name
      (fun a b _ => ExecFloat.add a b) binary1024BinaryAdd
  | "sub" => run (F := Fbinary1024Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary1024Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary1024BinarySub
  | "mul" => run (F := Fbinary1024Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary1024Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary1024BinaryMul
  | "div" => run (F := Fbinary1024Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary1024Binary)).name
      (fun a b _ => ExecFloat.div a b) binary1024BinaryDiv
  | "sqrt" => run (F := Fbinary1024Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary1024Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary1024BinarySqrt
  | "fma" => run (F := Fbinary1024Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary1024Binary)).name
      ExecFloat.fma binary1024BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary1024Limbs := ExecFloat.Binary.LimbFamily 19 1004
abbrev Tbinary1024Limbs := ExecFloat Fbinary1024Limbs
bounded_binary binary1024LimbsAdd : Tbinary1024Limbs using ExecFloat.add
bounded_binary binary1024LimbsSub : Tbinary1024Limbs using ExecFloat.sub
bounded_binary binary1024LimbsMul : Tbinary1024Limbs using ExecFloat.mul
bounded_binary binary1024LimbsDiv : Tbinary1024Limbs using ExecFloat.div
bounded_unary binary1024LimbsSqrt : Tbinary1024Limbs using ExecFloat.sqrt
bounded_ternary binary1024LimbsFma : Tbinary1024Limbs using ExecFloat.fma

@[noinline] public def runbinary1024Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary1024Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary1024Limbs)).name
      (fun a b _ => ExecFloat.add a b) binary1024LimbsAdd
  | "sub" => run (F := Fbinary1024Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary1024Limbs)).name
      (fun a b _ => ExecFloat.sub a b) binary1024LimbsSub
  | "mul" => run (F := Fbinary1024Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary1024Limbs)).name
      (fun a b _ => ExecFloat.mul a b) binary1024LimbsMul
  | "div" => run (F := Fbinary1024Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary1024Limbs)).name
      (fun a b _ => ExecFloat.div a b) binary1024LimbsDiv
  | "sqrt" => run (F := Fbinary1024Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary1024Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) binary1024LimbsSqrt
  | "fma" => run (F := Fbinary1024Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary1024Limbs)).name
      ExecFloat.fma binary1024LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary31Binary := ExecFloat.Binary.Family 8 22
abbrev Tbinary31Binary := ExecFloat Fbinary31Binary
bounded_binary binary31BinaryAdd : Tbinary31Binary using ExecFloat.add
bounded_binary binary31BinarySub : Tbinary31Binary using ExecFloat.sub
bounded_binary binary31BinaryMul : Tbinary31Binary using ExecFloat.mul
bounded_binary binary31BinaryDiv : Tbinary31Binary using ExecFloat.div
bounded_unary binary31BinarySqrt : Tbinary31Binary using ExecFloat.sqrt
bounded_ternary binary31BinaryFma : Tbinary31Binary using ExecFloat.fma

@[noinline] public def runbinary31Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary31Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary31Binary)).name
      (fun a b _ => ExecFloat.add a b) binary31BinaryAdd
  | "sub" => run (F := Fbinary31Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary31Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary31BinarySub
  | "mul" => run (F := Fbinary31Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary31Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary31BinaryMul
  | "div" => run (F := Fbinary31Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary31Binary)).name
      (fun a b _ => ExecFloat.div a b) binary31BinaryDiv
  | "sqrt" => run (F := Fbinary31Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary31Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary31BinarySqrt
  | "fma" => run (F := Fbinary31Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary31Binary)).name
      ExecFloat.fma binary31BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary511Binary := ExecFloat.Binary.Family 19 491
abbrev Tbinary511Binary := ExecFloat Fbinary511Binary
bounded_binary binary511BinaryAdd : Tbinary511Binary using ExecFloat.add
bounded_binary binary511BinarySub : Tbinary511Binary using ExecFloat.sub
bounded_binary binary511BinaryMul : Tbinary511Binary using ExecFloat.mul
bounded_binary binary511BinaryDiv : Tbinary511Binary using ExecFloat.div
bounded_unary binary511BinarySqrt : Tbinary511Binary using ExecFloat.sqrt
bounded_ternary binary511BinaryFma : Tbinary511Binary using ExecFloat.fma

@[noinline] public def runbinary511Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary511Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary511Binary)).name
      (fun a b _ => ExecFloat.add a b) binary511BinaryAdd
  | "sub" => run (F := Fbinary511Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary511Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary511BinarySub
  | "mul" => run (F := Fbinary511Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary511Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary511BinaryMul
  | "div" => run (F := Fbinary511Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary511Binary)).name
      (fun a b _ => ExecFloat.div a b) binary511BinaryDiv
  | "sqrt" => run (F := Fbinary511Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary511Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary511BinarySqrt
  | "fma" => run (F := Fbinary511Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary511Binary)).name
      ExecFloat.fma binary511BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary511Limbs := ExecFloat.Binary.LimbFamily 19 491
abbrev Tbinary511Limbs := ExecFloat Fbinary511Limbs
bounded_binary binary511LimbsAdd : Tbinary511Limbs using ExecFloat.add
bounded_binary binary511LimbsSub : Tbinary511Limbs using ExecFloat.sub
bounded_binary binary511LimbsMul : Tbinary511Limbs using ExecFloat.mul
bounded_binary binary511LimbsDiv : Tbinary511Limbs using ExecFloat.div
bounded_unary binary511LimbsSqrt : Tbinary511Limbs using ExecFloat.sqrt
bounded_ternary binary511LimbsFma : Tbinary511Limbs using ExecFloat.fma

@[noinline] public def runbinary511Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary511Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary511Limbs)).name
      (fun a b _ => ExecFloat.add a b) binary511LimbsAdd
  | "sub" => run (F := Fbinary511Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary511Limbs)).name
      (fun a b _ => ExecFloat.sub a b) binary511LimbsSub
  | "mul" => run (F := Fbinary511Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary511Limbs)).name
      (fun a b _ => ExecFloat.mul a b) binary511LimbsMul
  | "div" => run (F := Fbinary511Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary511Limbs)).name
      (fun a b _ => ExecFloat.div a b) binary511LimbsDiv
  | "sqrt" => run (F := Fbinary511Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary511Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) binary511LimbsSqrt
  | "fma" => run (F := Fbinary511Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary511Limbs)).name
      ExecFloat.fma binary511LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision63Binary := ExecFloat.Binary.Family 11 62
abbrev Tprecision63Binary := ExecFloat Fprecision63Binary
bounded_binary precision63BinaryAdd : Tprecision63Binary using ExecFloat.add
bounded_binary precision63BinarySub : Tprecision63Binary using ExecFloat.sub
bounded_binary precision63BinaryMul : Tprecision63Binary using ExecFloat.mul
bounded_binary precision63BinaryDiv : Tprecision63Binary using ExecFloat.div
bounded_unary precision63BinarySqrt : Tprecision63Binary using ExecFloat.sqrt
bounded_ternary precision63BinaryFma : Tprecision63Binary using ExecFloat.fma

@[noinline] public def runprecision63Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision63Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision63Binary)).name
      (fun a b _ => ExecFloat.add a b) precision63BinaryAdd
  | "sub" => run (F := Fprecision63Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision63Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision63BinarySub
  | "mul" => run (F := Fprecision63Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision63Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision63BinaryMul
  | "div" => run (F := Fprecision63Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision63Binary)).name
      (fun a b _ => ExecFloat.div a b) precision63BinaryDiv
  | "sqrt" => run (F := Fprecision63Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision63Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision63BinarySqrt
  | "fma" => run (F := Fprecision63Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision63Binary)).name
      ExecFloat.fma precision63BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision257Binary := ExecFloat.Binary.Family 19 256
abbrev Tprecision257Binary := ExecFloat Fprecision257Binary
bounded_binary precision257BinaryAdd : Tprecision257Binary using ExecFloat.add
bounded_binary precision257BinarySub : Tprecision257Binary using ExecFloat.sub
bounded_binary precision257BinaryMul : Tprecision257Binary using ExecFloat.mul
bounded_binary precision257BinaryDiv : Tprecision257Binary using ExecFloat.div
bounded_unary precision257BinarySqrt : Tprecision257Binary using ExecFloat.sqrt
bounded_ternary precision257BinaryFma : Tprecision257Binary using ExecFloat.fma

@[noinline] public def runprecision257Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision257Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision257Binary)).name
      (fun a b _ => ExecFloat.add a b) precision257BinaryAdd
  | "sub" => run (F := Fprecision257Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision257Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision257BinarySub
  | "mul" => run (F := Fprecision257Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision257Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision257BinaryMul
  | "div" => run (F := Fprecision257Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision257Binary)).name
      (fun a b _ => ExecFloat.div a b) precision257BinaryDiv
  | "sqrt" => run (F := Fprecision257Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision257Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision257BinarySqrt
  | "fma" => run (F := Fprecision257Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision257Binary)).name
      ExecFloat.fma precision257BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision257Limbs := ExecFloat.Binary.LimbFamily 19 256
abbrev Tprecision257Limbs := ExecFloat Fprecision257Limbs
bounded_binary precision257LimbsAdd : Tprecision257Limbs using ExecFloat.add
bounded_binary precision257LimbsSub : Tprecision257Limbs using ExecFloat.sub
bounded_binary precision257LimbsMul : Tprecision257Limbs using ExecFloat.mul
bounded_binary precision257LimbsDiv : Tprecision257Limbs using ExecFloat.div
bounded_unary precision257LimbsSqrt : Tprecision257Limbs using ExecFloat.sqrt
bounded_ternary precision257LimbsFma : Tprecision257Limbs using ExecFloat.fma

@[noinline] public def runprecision257Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision257Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision257Limbs)).name
      (fun a b _ => ExecFloat.add a b) precision257LimbsAdd
  | "sub" => run (F := Fprecision257Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision257Limbs)).name
      (fun a b _ => ExecFloat.sub a b) precision257LimbsSub
  | "mul" => run (F := Fprecision257Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision257Limbs)).name
      (fun a b _ => ExecFloat.mul a b) precision257LimbsMul
  | "div" => run (F := Fprecision257Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision257Limbs)).name
      (fun a b _ => ExecFloat.div a b) precision257LimbsDiv
  | "sqrt" => run (F := Fprecision257Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision257Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) precision257LimbsSqrt
  | "fma" => run (F := Fprecision257Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision257Limbs)).name
      ExecFloat.fma precision257LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbfloat16Binary := ExecFloat.Binary.Family 8 7
abbrev Tbfloat16Binary := ExecFloat Fbfloat16Binary
bounded_binary bfloat16BinaryAdd : Tbfloat16Binary using ExecFloat.add
bounded_binary bfloat16BinarySub : Tbfloat16Binary using ExecFloat.sub
bounded_binary bfloat16BinaryMul : Tbfloat16Binary using ExecFloat.mul
bounded_binary bfloat16BinaryDiv : Tbfloat16Binary using ExecFloat.div
bounded_unary bfloat16BinarySqrt : Tbfloat16Binary using ExecFloat.sqrt
bounded_ternary bfloat16BinaryFma : Tbfloat16Binary using ExecFloat.fma

@[noinline] public def runbfloat16Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbfloat16Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbfloat16Binary)).name
      (fun a b _ => ExecFloat.add a b) bfloat16BinaryAdd
  | "sub" => run (F := Fbfloat16Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbfloat16Binary)).name
      (fun a b _ => ExecFloat.sub a b) bfloat16BinarySub
  | "mul" => run (F := Fbfloat16Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbfloat16Binary)).name
      (fun a b _ => ExecFloat.mul a b) bfloat16BinaryMul
  | "div" => run (F := Fbfloat16Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbfloat16Binary)).name
      (fun a b _ => ExecFloat.div a b) bfloat16BinaryDiv
  | "sqrt" => run (F := Fbfloat16Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbfloat16Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) bfloat16BinarySqrt
  | "fma" => run (F := Fbfloat16Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbfloat16Binary)).name
      ExecFloat.fma bfloat16BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

end BoundedBench.Driver
