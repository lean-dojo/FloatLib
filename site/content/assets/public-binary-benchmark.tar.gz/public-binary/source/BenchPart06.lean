module

import DriverSupport

open FloatLib.Floats
open FloatLib.Floats.Formats.BinaryInterchange
open BoundedBench

namespace BoundedBench.Driver

abbrev Fbinary2048Binary := ExecFloat.Binary.Family 19 2028
abbrev Tbinary2048Binary := ExecFloat Fbinary2048Binary
bounded_binary binary2048BinaryAdd : Tbinary2048Binary using ExecFloat.add
bounded_binary binary2048BinarySub : Tbinary2048Binary using ExecFloat.sub
bounded_binary binary2048BinaryMul : Tbinary2048Binary using ExecFloat.mul
bounded_binary binary2048BinaryDiv : Tbinary2048Binary using ExecFloat.div
bounded_unary binary2048BinarySqrt : Tbinary2048Binary using ExecFloat.sqrt
bounded_ternary binary2048BinaryFma : Tbinary2048Binary using ExecFloat.fma

@[noinline] public def runbinary2048Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary2048Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary2048Binary)).name
      (fun a b _ => ExecFloat.add a b) binary2048BinaryAdd
  | "sub" => run (F := Fbinary2048Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary2048Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary2048BinarySub
  | "mul" => run (F := Fbinary2048Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary2048Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary2048BinaryMul
  | "div" => run (F := Fbinary2048Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary2048Binary)).name
      (fun a b _ => ExecFloat.div a b) binary2048BinaryDiv
  | "sqrt" => run (F := Fbinary2048Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary2048Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary2048BinarySqrt
  | "fma" => run (F := Fbinary2048Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary2048Binary)).name
      ExecFloat.fma binary2048BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary2048Limbs := ExecFloat.Binary.LimbFamily 19 2028
abbrev Tbinary2048Limbs := ExecFloat Fbinary2048Limbs
bounded_binary binary2048LimbsAdd : Tbinary2048Limbs using ExecFloat.add
bounded_binary binary2048LimbsSub : Tbinary2048Limbs using ExecFloat.sub
bounded_binary binary2048LimbsMul : Tbinary2048Limbs using ExecFloat.mul
bounded_binary binary2048LimbsDiv : Tbinary2048Limbs using ExecFloat.div
bounded_unary binary2048LimbsSqrt : Tbinary2048Limbs using ExecFloat.sqrt
bounded_ternary binary2048LimbsFma : Tbinary2048Limbs using ExecFloat.fma

@[noinline] public def runbinary2048Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary2048Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary2048Limbs)).name
      (fun a b _ => ExecFloat.add a b) binary2048LimbsAdd
  | "sub" => run (F := Fbinary2048Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary2048Limbs)).name
      (fun a b _ => ExecFloat.sub a b) binary2048LimbsSub
  | "mul" => run (F := Fbinary2048Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary2048Limbs)).name
      (fun a b _ => ExecFloat.mul a b) binary2048LimbsMul
  | "div" => run (F := Fbinary2048Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary2048Limbs)).name
      (fun a b _ => ExecFloat.div a b) binary2048LimbsDiv
  | "sqrt" => run (F := Fbinary2048Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary2048Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) binary2048LimbsSqrt
  | "fma" => run (F := Fbinary2048Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary2048Limbs)).name
      ExecFloat.fma binary2048LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary33Binary := ExecFloat.Binary.Family 8 24
abbrev Tbinary33Binary := ExecFloat Fbinary33Binary
bounded_binary binary33BinaryAdd : Tbinary33Binary using ExecFloat.add
bounded_binary binary33BinarySub : Tbinary33Binary using ExecFloat.sub
bounded_binary binary33BinaryMul : Tbinary33Binary using ExecFloat.mul
bounded_binary binary33BinaryDiv : Tbinary33Binary using ExecFloat.div
bounded_unary binary33BinarySqrt : Tbinary33Binary using ExecFloat.sqrt
bounded_ternary binary33BinaryFma : Tbinary33Binary using ExecFloat.fma

@[noinline] public def runbinary33Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary33Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary33Binary)).name
      (fun a b _ => ExecFloat.add a b) binary33BinaryAdd
  | "sub" => run (F := Fbinary33Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary33Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary33BinarySub
  | "mul" => run (F := Fbinary33Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary33Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary33BinaryMul
  | "div" => run (F := Fbinary33Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary33Binary)).name
      (fun a b _ => ExecFloat.div a b) binary33BinaryDiv
  | "sqrt" => run (F := Fbinary33Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary33Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary33BinarySqrt
  | "fma" => run (F := Fbinary33Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary33Binary)).name
      ExecFloat.fma binary33BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary513Binary := ExecFloat.Binary.Family 19 493
abbrev Tbinary513Binary := ExecFloat Fbinary513Binary
bounded_binary binary513BinaryAdd : Tbinary513Binary using ExecFloat.add
bounded_binary binary513BinarySub : Tbinary513Binary using ExecFloat.sub
bounded_binary binary513BinaryMul : Tbinary513Binary using ExecFloat.mul
bounded_binary binary513BinaryDiv : Tbinary513Binary using ExecFloat.div
bounded_unary binary513BinarySqrt : Tbinary513Binary using ExecFloat.sqrt
bounded_ternary binary513BinaryFma : Tbinary513Binary using ExecFloat.fma

@[noinline] public def runbinary513Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary513Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary513Binary)).name
      (fun a b _ => ExecFloat.add a b) binary513BinaryAdd
  | "sub" => run (F := Fbinary513Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary513Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary513BinarySub
  | "mul" => run (F := Fbinary513Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary513Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary513BinaryMul
  | "div" => run (F := Fbinary513Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary513Binary)).name
      (fun a b _ => ExecFloat.div a b) binary513BinaryDiv
  | "sqrt" => run (F := Fbinary513Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary513Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary513BinarySqrt
  | "fma" => run (F := Fbinary513Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary513Binary)).name
      ExecFloat.fma binary513BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary513Limbs := ExecFloat.Binary.LimbFamily 19 493
abbrev Tbinary513Limbs := ExecFloat Fbinary513Limbs
bounded_binary binary513LimbsAdd : Tbinary513Limbs using ExecFloat.add
bounded_binary binary513LimbsSub : Tbinary513Limbs using ExecFloat.sub
bounded_binary binary513LimbsMul : Tbinary513Limbs using ExecFloat.mul
bounded_binary binary513LimbsDiv : Tbinary513Limbs using ExecFloat.div
bounded_unary binary513LimbsSqrt : Tbinary513Limbs using ExecFloat.sqrt
bounded_ternary binary513LimbsFma : Tbinary513Limbs using ExecFloat.fma

@[noinline] public def runbinary513Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary513Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary513Limbs)).name
      (fun a b _ => ExecFloat.add a b) binary513LimbsAdd
  | "sub" => run (F := Fbinary513Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary513Limbs)).name
      (fun a b _ => ExecFloat.sub a b) binary513LimbsSub
  | "mul" => run (F := Fbinary513Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary513Limbs)).name
      (fun a b _ => ExecFloat.mul a b) binary513LimbsMul
  | "div" => run (F := Fbinary513Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary513Limbs)).name
      (fun a b _ => ExecFloat.div a b) binary513LimbsDiv
  | "sqrt" => run (F := Fbinary513Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary513Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) binary513LimbsSqrt
  | "fma" => run (F := Fbinary513Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary513Limbs)).name
      ExecFloat.fma binary513LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision64Binary := ExecFloat.Binary.Family 15 63
abbrev Tprecision64Binary := ExecFloat Fprecision64Binary
bounded_binary precision64BinaryAdd : Tprecision64Binary using ExecFloat.add
bounded_binary precision64BinarySub : Tprecision64Binary using ExecFloat.sub
bounded_binary precision64BinaryMul : Tprecision64Binary using ExecFloat.mul
bounded_binary precision64BinaryDiv : Tprecision64Binary using ExecFloat.div
bounded_unary precision64BinarySqrt : Tprecision64Binary using ExecFloat.sqrt
bounded_ternary precision64BinaryFma : Tprecision64Binary using ExecFloat.fma

@[noinline] public def runprecision64Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision64Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision64Binary)).name
      (fun a b _ => ExecFloat.add a b) precision64BinaryAdd
  | "sub" => run (F := Fprecision64Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision64Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision64BinarySub
  | "mul" => run (F := Fprecision64Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision64Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision64BinaryMul
  | "div" => run (F := Fprecision64Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision64Binary)).name
      (fun a b _ => ExecFloat.div a b) precision64BinaryDiv
  | "sqrt" => run (F := Fprecision64Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision64Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision64BinarySqrt
  | "fma" => run (F := Fprecision64Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision64Binary)).name
      ExecFloat.fma precision64BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision511Binary := ExecFloat.Binary.Family 19 510
abbrev Tprecision511Binary := ExecFloat Fprecision511Binary
bounded_binary precision511BinaryAdd : Tprecision511Binary using ExecFloat.add
bounded_binary precision511BinarySub : Tprecision511Binary using ExecFloat.sub
bounded_binary precision511BinaryMul : Tprecision511Binary using ExecFloat.mul
bounded_binary precision511BinaryDiv : Tprecision511Binary using ExecFloat.div
bounded_unary precision511BinarySqrt : Tprecision511Binary using ExecFloat.sqrt
bounded_ternary precision511BinaryFma : Tprecision511Binary using ExecFloat.fma

@[noinline] public def runprecision511Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision511Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision511Binary)).name
      (fun a b _ => ExecFloat.add a b) precision511BinaryAdd
  | "sub" => run (F := Fprecision511Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision511Binary)).name
      (fun a b _ => ExecFloat.sub a b) precision511BinarySub
  | "mul" => run (F := Fprecision511Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision511Binary)).name
      (fun a b _ => ExecFloat.mul a b) precision511BinaryMul
  | "div" => run (F := Fprecision511Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision511Binary)).name
      (fun a b _ => ExecFloat.div a b) precision511BinaryDiv
  | "sqrt" => run (F := Fprecision511Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision511Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) precision511BinarySqrt
  | "fma" => run (F := Fprecision511Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision511Binary)).name
      ExecFloat.fma precision511BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fprecision511Limbs := ExecFloat.Binary.LimbFamily 19 510
abbrev Tprecision511Limbs := ExecFloat Fprecision511Limbs
bounded_binary precision511LimbsAdd : Tprecision511Limbs using ExecFloat.add
bounded_binary precision511LimbsSub : Tprecision511Limbs using ExecFloat.sub
bounded_binary precision511LimbsMul : Tprecision511Limbs using ExecFloat.mul
bounded_binary precision511LimbsDiv : Tprecision511Limbs using ExecFloat.div
bounded_unary precision511LimbsSqrt : Tprecision511Limbs using ExecFloat.sqrt
bounded_ternary precision511LimbsFma : Tprecision511Limbs using ExecFloat.fma

@[noinline] public def runprecision511Limbs (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fprecision511Limbs) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fprecision511Limbs)).name
      (fun a b _ => ExecFloat.add a b) precision511LimbsAdd
  | "sub" => run (F := Fprecision511Limbs) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fprecision511Limbs)).name
      (fun a b _ => ExecFloat.sub a b) precision511LimbsSub
  | "mul" => run (F := Fprecision511Limbs) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fprecision511Limbs)).name
      (fun a b _ => ExecFloat.mul a b) precision511LimbsMul
  | "div" => run (F := Fprecision511Limbs) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fprecision511Limbs)).name
      (fun a b _ => ExecFloat.div a b) precision511LimbsDiv
  | "sqrt" => run (F := Fprecision511Limbs) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fprecision511Limbs)).name
      (fun a _ _ => ExecFloat.sqrt a) precision511LimbsSqrt
  | "fma" => run (F := Fprecision511Limbs) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fprecision511Limbs)).name
      ExecFloat.fma precision511LimbsFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

abbrev Fbinary8e5m2Binary := ExecFloat.Binary.Family 5 2
abbrev Tbinary8e5m2Binary := ExecFloat Fbinary8e5m2Binary
bounded_binary binary8e5m2BinaryAdd : Tbinary8e5m2Binary using ExecFloat.add
bounded_binary binary8e5m2BinarySub : Tbinary8e5m2Binary using ExecFloat.sub
bounded_binary binary8e5m2BinaryMul : Tbinary8e5m2Binary using ExecFloat.mul
bounded_binary binary8e5m2BinaryDiv : Tbinary8e5m2Binary using ExecFloat.div
bounded_unary binary8e5m2BinarySqrt : Tbinary8e5m2Binary using ExecFloat.sqrt
bounded_ternary binary8e5m2BinaryFma : Tbinary8e5m2Binary using ExecFloat.fma

@[noinline] public def runbinary8e5m2Binary (mode path op : String) (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Fbinary8e5m2Binary) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Fbinary8e5m2Binary)).name
      (fun a b _ => ExecFloat.add a b) binary8e5m2BinaryAdd
  | "sub" => run (F := Fbinary8e5m2Binary) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Fbinary8e5m2Binary)).name
      (fun a b _ => ExecFloat.sub a b) binary8e5m2BinarySub
  | "mul" => run (F := Fbinary8e5m2Binary) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Fbinary8e5m2Binary)).name
      (fun a b _ => ExecFloat.mul a b) binary8e5m2BinaryMul
  | "div" => run (F := Fbinary8e5m2Binary) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Fbinary8e5m2Binary)).name
      (fun a b _ => ExecFloat.div a b) binary8e5m2BinaryDiv
  | "sqrt" => run (F := Fbinary8e5m2Binary) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Fbinary8e5m2Binary)).name
      (fun a _ _ => ExecFloat.sqrt a) binary8e5m2BinarySqrt
  | "fma" => run (F := Fbinary8e5m2Binary) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Fbinary8e5m2Binary)).name
      ExecFloat.fma binary8e5m2BinaryFma
  | _ => throw <| IO.userError s!"unknown operation: {op}"

end BoundedBench.Driver
