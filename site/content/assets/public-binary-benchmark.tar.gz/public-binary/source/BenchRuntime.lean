module

public import DriverSupport

open FloatLib.Floats
open FloatLib.Floats.Formats.BinaryInterchange
open BoundedBench

namespace BoundedBench.Driver

@[noinline] def runtimeAdd (fmt : FloatFormat) : Workload (ExecFloat (Descriptor fmt))
  | 0, _, _, _, sink => sink
  | count + 1, xs, ys, zs, sink =>
    let index := count &&& 15
    let result := ExecFloat.add xs[index]! ys[index]!
    runtimeAdd fmt count xs ys zs (mix sink (lowBits result))

@[noinline] def runtimeSub (fmt : FloatFormat) : Workload (ExecFloat (Descriptor fmt))
  | 0, _, _, _, sink => sink
  | count + 1, xs, ys, zs, sink =>
    let index := count &&& 15
    let result := ExecFloat.sub xs[index]! ys[index]!
    runtimeSub fmt count xs ys zs (mix sink (lowBits result))

@[noinline] def runtimeMul (fmt : FloatFormat) : Workload (ExecFloat (Descriptor fmt))
  | 0, _, _, _, sink => sink
  | count + 1, xs, ys, zs, sink =>
    let index := count &&& 15
    let result := ExecFloat.mul xs[index]! ys[index]!
    runtimeMul fmt count xs ys zs (mix sink (lowBits result))

@[noinline] def runtimeDiv (fmt : FloatFormat) : Workload (ExecFloat (Descriptor fmt))
  | 0, _, _, _, sink => sink
  | count + 1, xs, ys, zs, sink =>
    let index := count &&& 15
    let result := ExecFloat.div xs[index]! ys[index]!
    runtimeDiv fmt count xs ys zs (mix sink (lowBits result))

@[noinline] def runtimeSqrt (fmt : FloatFormat) : Workload (ExecFloat (Descriptor fmt))
  | 0, _, _, _, sink => sink
  | count + 1, xs, ys, zs, sink =>
    let index := count &&& 15
    let result := ExecFloat.sqrt xs[index]!
    runtimeSqrt fmt count xs ys zs (mix sink (lowBits result))

@[noinline] def runtimeFma (fmt : FloatFormat) : Workload (ExecFloat (Descriptor fmt))
  | 0, _, _, _, sink => sink
  | count + 1, xs, ys, zs, sink =>
    let index := count &&& 15
    let result := ExecFloat.fma xs[index]! ys[index]! zs[index]!
    runtimeFma fmt count xs ys zs (mix sink (lowBits result))

@[noinline] public def runRuntime (fmt : FloatFormat) (mode path op : String)
    (iterations warmup : Nat) : IO Unit :=
  match op with
  | "add" => run (F := Descriptor fmt) mode path iterations warmup
      (ExecFloat.Add.selectedCandidate (F := Descriptor fmt)).name
      (fun a b _ => ExecFloat.add a b) (runtimeAdd fmt)
  | "sub" => run (F := Descriptor fmt) mode path iterations warmup
      (ExecFloat.Sub.selectedCandidate (F := Descriptor fmt)).name
      (fun a b _ => ExecFloat.sub a b) (runtimeSub fmt)
  | "mul" => run (F := Descriptor fmt) mode path iterations warmup
      (ExecFloat.Mul.selectedCandidate (F := Descriptor fmt)).name
      (fun a b _ => ExecFloat.mul a b) (runtimeMul fmt)
  | "div" => run (F := Descriptor fmt) mode path iterations warmup
      (ExecFloat.Div.selectedCandidate (F := Descriptor fmt)).name
      (fun a b _ => ExecFloat.div a b) (runtimeDiv fmt)
  | "sqrt" => run (F := Descriptor fmt) mode path iterations warmup
      (ExecFloat.Sqrt.selectedCandidate (F := Descriptor fmt)).name
      (fun a _ _ => ExecFloat.sqrt a) (runtimeSqrt fmt)
  | "fma" => run (F := Descriptor fmt) mode path iterations warmup
      (ExecFloat.Fma.selectedCandidate (F := Descriptor fmt)).name
      ExecFloat.fma (runtimeFma fmt)
  | _ => throw <| IO.userError s!"unknown operation: {op}"

end BoundedBench.Driver
