module

public import FloatLib.Floats.ExecFloat.Runtime
public import FloatLib.Floats.Formats.BinaryInterchange.Configured.NativeDispatch
public import FloatLib.Floats.Formats.BinaryInterchange.Configured.Plan.Instances
public import FloatLib.Floats.Formats.BinaryInterchange.Descriptor.Backends
public import FloatLib.Floats.Formats.BinaryInterchange.Descriptor.Plan.Instances

/-!
Shared I/O for the bounded carrier comparison. Timed workloads are generated as
monomorphic functions in `PairedBench`; file parsing and full encoding checks occur here.
-/

@[expose] public section

open FloatLib.Floats
open FloatLib.Floats.Formats.BinaryInterchange
open FloatLib.Numerics

namespace BoundedBench

class Carrier (F : Type) [EncodedFormat F] where
  format : FloatFormat
  ofBits : Nat → ExecFloat F
  toBits : ExecFloat F → Nat
  lowBits : ExecFloat F → UInt64

instance (format : FloatFormat) :
    Carrier (Descriptor format) where
  format := format
  ofBits := fun bits => Descriptor.pack (Model.ofNatBits bits)
  toBits := fun value => (Descriptor.unpack value).toNatBits
  lowBits := fun value => UInt64.ofNat (Descriptor.unpack value).toNatBits

instance configuredCarrier (format : FloatFormat) (plan : Configured.StoragePlan format)
    [ExecFloat.ModelCodec plan (Model format) (Configured.Code plan)] :
    Carrier (Configured.Family format (Configured.Code plan) plan) where
  format := format
  ofBits := fun bits => Configured.Family.ofModel (Model.ofNatBits bits)
  toBits := fun value => (Configured.Family.toModel value).toNatBits
  lowBits :=
    match plan with
    | .byte _ => fun value => UInt64.ofNat value.raw.1.toNat
    | .word16 _ => fun value => UInt64.ofNat value.raw.1.toNat
    | .word32 _ => fun value => UInt64.ofNat value.raw.1.toNat
    | .word64 _ => fun value => value.raw.1
    | .wide => fun value => UInt64.ofNat value.raw.toNatBits
    | .limbs _ => fun value =>
        (value.raw.1.limb 0).toUInt64 ||| ((value.raw.1.limb 1).toUInt64 <<< 32)

instance limbCarrier (format : FloatFormat) (width_gt : 128 < format.bitWidth) :
    Carrier (Configured.Family format (Model.WideLimb.Value format)
      (.limbs width_gt)) :=
  configuredCarrier format (.limbs width_gt)

instance (F : Type) [EncodedFormat F] [Carrier F] : Inhabited (ExecFloat F) where
  default := Carrier.ofBits 0

@[inline] def mix (sink bits : UInt64) : UInt64 :=
  (sink ^^^ bits) * 1099511628211

@[inline] def lowBits {F : Type} [EncodedFormat F] [Carrier F]
    (value : ExecFloat F) : UInt64 :=
  Carrier.lowBits value

structure Inputs (α : Type) where
  xs : Array α
  ys : Array α
  zs : Array α

abbrev Workload (α : Type) :=
  Nat → Array α → Array α → Array α → UInt64 → UInt64

@[extern "fl_profile_start"] opaque profileStart : IO Unit
@[extern "fl_profile_stop"] opaque profileStop : IO Unit

def parseNat (text : String) : IO Nat := do
  let some n := text.toNat? | throw <| IO.userError s!"invalid natural: {text}"
  return n

def load {F : Type} [EncodedFormat F] [Carrier F]
    (path : System.FilePath) : IO (Inputs (ExecFloat F)) := do
  let mut xs := #[]
  let mut ys := #[]
  let mut zs := #[]
  let text ← IO.FS.readFile path
  for line in text.splitOn "\n" do
    if line.isEmpty then continue
    let [a, b, c] := line.splitOn "\t"
      | throw <| IO.userError "expected three encoded operands"
    xs := xs.push (Carrier.ofBits (← parseNat a))
    ys := ys.push (Carrier.ofBits (← parseNat b))
    zs := zs.push (Carrier.ofBits (← parseNat c))
  unless xs.size == 16 do
    throw <| IO.userError "expected sixteen fixture triples"
  return ⟨xs, ys, zs⟩

def run {F : Type} [EncodedFormat F] [Carrier F]
    (mode path : String) (iterations warmup : Nat) (backend : String)
    (operation : ExecFloat F → ExecFloat F → ExecFloat F → ExecFloat F)
    (workload : Workload (ExecFloat F)) : IO Unit := do
  let inputs ← load path
  if mode == "verify" then
    for i in [:16] do
      let a := inputs.xs[i]!
      let b := inputs.ys[i]!
      let c := inputs.zs[i]!
      let value := operation a b c
      IO.println s!"value\t{i}\t{Carrier.toBits a}\t{Carrier.toBits b}\t{Carrier.toBits c}\t{Carrier.toBits value}\t{(lowBits value).toNat}\t{backend}"
  else if mode == "time" || mode == "profile" then
    let warm ← IO.mkRef (0 : UInt64)
    warm.set (workload warmup inputs.xs inputs.ys inputs.zs 14695981039346656037)
    let seed ← warm.get
    let result ← IO.mkRef (0 : UInt64)
    if mode == "profile" then profileStart
    let start ← IO.monoNanosNow
    result.set (workload iterations inputs.xs inputs.ys inputs.zs seed)
    let stop ← IO.monoNanosNow
    if mode == "profile" then profileStop
    IO.println s!"time\t{iterations}\t{warmup}\t{stop - start}\t{(← result.get).toNat}\t{seed.toNat}\t{backend}"
  else
    throw <| IO.userError s!"unknown mode: {mode}"

syntax "bounded_binary " ident " : " term " using " term : command
syntax "bounded_unary " ident " : " term " using " term : command
syntax "bounded_ternary " ident " : " term " using " term : command

macro_rules
  | `(bounded_binary $name:ident : $type:term using $operation:term) =>
    `(@[noinline] def $name : Workload $type
      | 0, _, _, _, sink => sink
      | count + 1, xs, ys, zs, sink =>
        let index := count &&& 15
        let result := $operation xs[index]! ys[index]!
        $name count xs ys zs (mix sink (lowBits result)))
  | `(bounded_unary $name:ident : $type:term using $operation:term) =>
    `(@[noinline] def $name : Workload $type
      | 0, _, _, _, sink => sink
      | count + 1, xs, ys, zs, sink =>
        let index := count &&& 15
        let result := $operation xs[index]!
        $name count xs ys zs (mix sink (lowBits result)))
  | `(bounded_ternary $name:ident : $type:term using $operation:term) =>
    `(@[noinline] def $name : Workload $type
      | 0, _, _, _, sink => sink
      | count + 1, xs, ys, zs, sink =>
        let index := count &&& 15
        let result := $operation xs[index]! ys[index]! zs[index]!
        $name count xs ys zs (mix sink (lowBits result)))

end BoundedBench
