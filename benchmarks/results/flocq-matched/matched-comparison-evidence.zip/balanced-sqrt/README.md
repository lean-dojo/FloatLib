Completed: **9 cells, one trial each, PASS**, for sqrt at 1024/2048/4096 bits across FloatLib, MPFR and extracted Flocq. CPU39 timing exited 0; compilation and untimed validation used CPU41. No repository or slide files changed.

Every timed block evaluates all sixteen original fixtures once. The previous result checksum selects an unused fixture by cyclic probing; checksum and trace carry across block boundaries. Calibration targets 200ms, with a 50ms minimum and one complete warmup block outside the timer. The shortest accepted interval was **198.356ms**. Flocq uses one complete block even when it exceeds the target.

- [summary.csv](results-one-trial/summary.csv): nine replacement cells, exact main summary column layout and series names.
- [raw.csv](results-one-trial/raw.csv), [campaign.json](results-one-trial/campaign.json), and its `logs/`: all accepted observations and 26 calibration attempts.
- [codegen-audit.json](codegen-audit.json) and `codegen/`: generated C and native code retain sqrt calls inside both loop levels; FloatLib calls the same cached sqrt entries as the original executable.
- [validation.json](validation.json): 144 complete values and nine block checksum/trace checks agree with the retained full-value audit. [two-block-validation.json](two-block-validation.json) checks state carry in all lanes at width1024.
- [manifest.json](manifest.json), [compile-commands.json](compile-commands.json), [archive-files.json](archive-files.json), and [Replay.md](Replay.md): exact sources, hashes, commands and archive inventory.
- [Report.md](Report.md) and [Final.json](Final.json): results and limitations.

One trial supplies no variability estimate: p05, median and p95 coincide; standard deviation is zero by convention. The raw method tag is `result-dependent-complete-16-fixture-blocks`; parent integration must preserve that distinction.

The one-trial Python change left all numerical binaries byte-identical; the previous manifest and validation binding are preserved. Synthetic harness-check data was deleted. Compiled outputs remain pending the parent's hash/archive confirmation. Existing source/dependency license notices apply; the existing FloatLib license is included in `replay-support/FloatLib/LICENSE`.
