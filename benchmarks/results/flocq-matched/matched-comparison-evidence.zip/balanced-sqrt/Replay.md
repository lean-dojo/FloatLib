This is a scratch benchmark supplement. Preserve the evidence directory before replaying; use a fresh copy named `balanced-sqrt-replay` to keep the completed one-trial records intact.

The required layout is:

```text
/mnt/build/floatlib-general-kernels-pyj2n43w/
  FloatLib/                     frozen full candidate source and dependencies
  integration-build/            original cached Lean objects and executable .rsp
  flocq-matched/
    build/                      retained extracted Flocq kernel and clock objects
    audit/                      retained full-value records and lean-path.txt
    floatlib-preflight.csv       original metadata receipt
    mpfr-preflight.csv           original metadata receipt
    flocq-preflight.csv          original metadata receipt
    balanced-sqrt-replay/        fresh copy of this archive
```

The frozen cache must include **all paths referenced by** `integration-build/bin/execFloatFormatComparison.rsp` and `audit/lean-path.txt`, including dependency objects outside `integration-build`. Lean is `/home/ec2-user/.elan/toolchains/leanprover--lean4---v4.34.0`. Host GCC/MPFR/GMP and Docker access are required. The image tag is `leanfloat-flocq-bench:4.2.2`, pinned to image ID `sha256:80d13ef0e8c4dbcab28b3812192071b8c0c1644b074d58ae2f03a9d9e1aea7b6`. Flocq executes inside that image with networking disabled.

```bash
cd /mnt/build/floatlib-general-kernels-pyj2n43w/flocq-matched/balanced-sqrt-replay
taskset -c 41 python3 prepare.py
taskset -c 41 python3 run.py validate
# Run only when CPU39 is available:
taskset -c 41 python3 run.py run --cpu 39 --trials 1 --output results-replay
```

For a later nine-trial update, use `--trials 9` and a new output directory. `prepare.py` compiles only the three scratch drivers on CPU41. It replaces only the original root benchmark object in the cached Lean linker response file, and links the retained Flocq kernel unchanged. No Lake build runs. Input construction, process/module initialization and one full warmup block precede the internal clocks.

Keep these driver sources: `BalancedSqrt.lean`, `balanced_mpfr.c`, `balanced_flocq_suffix.ml`, the exact generated `balanced_flocq.ml`, `prepare.py`, and `run.py`. Also retain generated `BalancedSqrt.c`, the linker response file, compile commands/logs, both source manifests, all validation and codegen records, and the completed campaign/raw logs. `archive-files.json` enumerates every evidence file with its SHA-256. `replay-support/` snapshots the original benchmark adapters, headers, extracted kernel sources, metadata and full-value audit inputs; `replay-support-manifest.json` maps them to original paths.

This small source snapshot is not a standalone distribution of FloatLib and its dependencies. Rebuilding a removed native cache requires the parent's complete frozen source/dependency snapshot and a new compilation/validation receipt. Keep the currently compiled scratch outputs until the parent has recorded their hashes and archived the evidence. The inventory separately identifies these outputs and excludes them from the source/evidence zip.
