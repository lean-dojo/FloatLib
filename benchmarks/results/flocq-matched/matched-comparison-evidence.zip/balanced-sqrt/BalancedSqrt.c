// Lean compiler output
// Module: BalancedSqrt
// Imports: public import Init public meta import Init public import FloatLibBenchmarks.Public.Sweep
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Code_ofModel___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Code_toModel___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lp_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep_configuredBenchmarkCarrier(lean_object*, uint8_t, lean_object*);
lean_object* lp_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep_benchmarkExecFloatInhabited___redArg(lean_object*);
uint64_t lean_uint64_shift_right(uint64_t, uint64_t);
uint64_t lean_uint64_xor(uint64_t, uint64_t);
uint64_t lean_uint64_land(uint64_t, uint64_t);
lean_object* lean_uint64_to_nat(uint64_t);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
uint64_t lean_uint64_shift_left(uint64_t, uint64_t);
uint8_t lean_uint64_dec_eq(uint64_t, uint64_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lean_nat_mod(lean_object*, lean_object*);
lean_object* lean_nat_pow(lean_object*, lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
lean_object* l_BitVec_ofNat(lean_object*, lean_object*);
lean_object* lean_st_mk_ref(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
lean_object* lean_st_ref_swap(lean_object*, lean_object*);
lean_object* lean_st_ref_get(lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(lean_object*);
lean_object* lean_io_mono_nanos_now();
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Plan_automaticSqrtCandidates(lean_object*, uint8_t);
extern lean_object* lp_floatlib_FloatLib_Floats_ExecFloat_Backend_Policy_throughput;
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_div(lean_object*, lean_object*);
lean_object* lean_mk_thunk(lean_object*);
lean_object* lean_thunk_get_own(lean_object*);
lean_object* l_Float_Model_UnpackedFloat_pack(lean_object*, lean_object*);
lean_object* l_Float_Model_UnpackedFloat_ExtendedMantissa_roundedMantissa(lean_object*);
lean_object* lean_int_add(lean_object*, lean_object*);
lean_object* l_Float_Model_UnpackedFloat_shiftToTargetExponent(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Float_Model_UnpackedFloat_ExtendedMantissa_ofMantissaAndAccuracy(lean_object*, lean_object*);
lean_object* lean_nat_shiftr(lean_object*, lean_object*);
uint64_t lp_floatlib_FloatLib_Numerics_FixedWord_IntegerSquareRoot_sqrtIter(uint64_t, uint64_t);
uint64_t lean_uint64_add(uint64_t, uint64_t);
lean_object* lean_nat_shiftl(lean_object*, lean_object*);
lean_object* lean_int_mul(lean_object*, lean_object*);
lean_object* lean_int_sub(lean_object*, lean_object*);
lean_object* l_Int_toNat(lean_object*);
lean_object* lean_nat_log2(lean_object*);
lean_object* l_Float_Model_Format_targetExponent(lean_object*, lean_object*);
lean_object* lp_floatlib_FloatLib_Numerics_FixedWord_IntegerSquareRoot_sqrtRem(lean_object*);
uint8_t lean_uint64_dec_le(uint64_t, uint64_t);
uint8_t lean_uint64_dec_lt(uint64_t, uint64_t);
lean_object* lean_int_ediv(lean_object*, lean_object*);
lean_object* l_Float_Model_totalExponent(lean_object*, lean_object*);
uint8_t lean_int_dec_le(lean_object*, lean_object*);
uint8_t l_Nat_testBit(lean_object*, lean_object*);
lean_object* lean_nat_land(lean_object*, lean_object*);
lean_object* lean_nat_lor(lean_object*, lean_object*);
uint8_t l_Option_decidableEqNone___redArg(lean_object*);
extern lean_object* lp_floatlibBenchmarks_FloatLibBenchmarks_Support_ExactWorkload_sqrtXs;
size_t lean_array_size(lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
uint8_t lean_int_dec_lt(lean_object*, lean_object*);
lean_object* lean_nat_abs(lean_object*);
lean_object* lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Model_Internal_Directed_roundRat(lean_object*, uint8_t, uint8_t, lean_object*, lean_object*);
size_t lean_usize_add(size_t, size_t);
lean_object* lean_array_get_borrowed(lean_object*, lean_object*, lean_object*);
uint8_t lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Plan_firstOrderSelected(lean_object*, lean_object*, uint8_t, uint8_t);
uint8_t lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Plan_firstOrderGenericSelected(lean_object*, lean_object*, uint8_t, uint8_t);
lean_object* lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Descriptor_Plan_structuralRoute_x3f(lean_object*, uint8_t);
uint64_t lean_uint64_lor(uint64_t, uint64_t);
uint64_t lean_uint64_mul(uint64_t, uint64_t);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x3f(lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___redArg(uint64_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object l_BalancedSqrt_nextUnused___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*3 + 0, .m_other = 3, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(16) << 1) | 1)),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_BalancedSqrt_nextUnused___closed__0 = (const lean_object*)&l_BalancedSqrt_nextUnused___closed__0_value;
LEAN_EXPORT lean_object* l_BalancedSqrt_nextUnused(uint64_t, uint64_t);
LEAN_EXPORT lean_object* l_BalancedSqrt_nextUnused___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_advance(lean_object*, lean_object*, uint64_t);
LEAN_EXPORT lean_object* l_BalancedSqrt_advance___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block1024_spec__3___redArg();
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block1024_spec__3___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block1024_spec__3(lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block1024_spec__3___boxed(lean_object*);
LEAN_EXPORT lean_object* l_List_foldl___at___00BalancedSqrt_block1024_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_block1024___lam__0(lean_object*, uint8_t, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_block1024___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint64_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(uint64_t);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0___boxed(lean_object*);
static const lean_ctor_object l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1004) << 1) | 1)),((lean_object*)(((size_t)(19) << 1) | 1))}};
static const lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__0 = (const lean_object*)&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__0_value;
static const lean_ctor_object l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 1}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(2, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__1 = (const lean_object*)&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__1_value;
static const lean_ctor_object l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 1}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__2 = (const lean_object*)&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__2_value;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__5;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__6;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__7;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__8;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__9;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__10;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__11;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__12;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__13_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__13;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__14_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__14;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__15_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__15;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__16_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__16;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__17_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__17;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__18_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__18;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__19_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__19;
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2(lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1(lean_object*);
static const lean_ctor_object l_BalancedSqrt_block1024___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*3 + 8, .m_other = 3, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(19) << 1) | 1)),((lean_object*)(((size_t)(1004) << 1) | 1)),((lean_object*)(((size_t)(262143) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_BalancedSqrt_block1024___closed__0 = (const lean_object*)&l_BalancedSqrt_block1024___closed__0_value;
static const lean_closure_object l_BalancedSqrt_block1024___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Code_toModel___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_BalancedSqrt_block1024___closed__0_value),((lean_object*)(((size_t)(5) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block1024___closed__1 = (const lean_object*)&l_BalancedSqrt_block1024___closed__1_value;
static const lean_closure_object l_BalancedSqrt_block1024___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Code_ofModel___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_BalancedSqrt_block1024___closed__0_value),((lean_object*)(((size_t)(5) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block1024___closed__2 = (const lean_object*)&l_BalancedSqrt_block1024___closed__2_value;
static const lean_ctor_object l_BalancedSqrt_block1024___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l_BalancedSqrt_block1024___closed__1_value),((lean_object*)&l_BalancedSqrt_block1024___closed__2_value)}};
static const lean_object* l_BalancedSqrt_block1024___closed__3 = (const lean_object*)&l_BalancedSqrt_block1024___closed__3_value;
static lean_once_cell_t l_BalancedSqrt_block1024___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block1024___closed__4;
static lean_once_cell_t l_BalancedSqrt_block1024___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block1024___closed__5;
static lean_once_cell_t l_BalancedSqrt_block1024___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static uint8_t l_BalancedSqrt_block1024___closed__6;
static lean_once_cell_t l_BalancedSqrt_block1024___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static uint8_t l_BalancedSqrt_block1024___closed__7;
static const lean_closure_object l_BalancedSqrt_block1024___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_BalancedSqrt_block1024___lam__0___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_BalancedSqrt_block1024___closed__0_value),((lean_object*)(((size_t)(5) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block1024___closed__8 = (const lean_object*)&l_BalancedSqrt_block1024___closed__8_value;
static lean_once_cell_t l_BalancedSqrt_block1024___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block1024___closed__9;
static lean_once_cell_t l_BalancedSqrt_block1024___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block1024___closed__10;
static lean_once_cell_t l_BalancedSqrt_block1024___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block1024___closed__11;
LEAN_EXPORT lean_object* l_BalancedSqrt_block1024(lean_object*, uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_block1024___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block2048_spec__2___redArg();
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block2048_spec__2___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block2048_spec__2(lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block2048_spec__2___boxed(lean_object*);
static const lean_ctor_object l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(2028) << 1) | 1)),((lean_object*)(((size_t)(19) << 1) | 1))}};
static const lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__0 = (const lean_object*)&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__0_value;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__1;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__2;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__3;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__4;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__5;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__6;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__7;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__8;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__9;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__10;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__11;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__12;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__13_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__13;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__14_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__14;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__15_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__15;
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1(lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0(lean_object*);
static const lean_ctor_object l_BalancedSqrt_block2048___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*3 + 8, .m_other = 3, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(19) << 1) | 1)),((lean_object*)(((size_t)(2028) << 1) | 1)),((lean_object*)(((size_t)(262143) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_BalancedSqrt_block2048___closed__0 = (const lean_object*)&l_BalancedSqrt_block2048___closed__0_value;
static const lean_closure_object l_BalancedSqrt_block2048___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Code_toModel___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_BalancedSqrt_block2048___closed__0_value),((lean_object*)(((size_t)(5) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block2048___closed__1 = (const lean_object*)&l_BalancedSqrt_block2048___closed__1_value;
static const lean_closure_object l_BalancedSqrt_block2048___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Code_ofModel___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_BalancedSqrt_block2048___closed__0_value),((lean_object*)(((size_t)(5) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block2048___closed__2 = (const lean_object*)&l_BalancedSqrt_block2048___closed__2_value;
static const lean_ctor_object l_BalancedSqrt_block2048___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l_BalancedSqrt_block2048___closed__1_value),((lean_object*)&l_BalancedSqrt_block2048___closed__2_value)}};
static const lean_object* l_BalancedSqrt_block2048___closed__3 = (const lean_object*)&l_BalancedSqrt_block2048___closed__3_value;
static lean_once_cell_t l_BalancedSqrt_block2048___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block2048___closed__4;
static lean_once_cell_t l_BalancedSqrt_block2048___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block2048___closed__5;
static lean_once_cell_t l_BalancedSqrt_block2048___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static uint8_t l_BalancedSqrt_block2048___closed__6;
static lean_once_cell_t l_BalancedSqrt_block2048___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static uint8_t l_BalancedSqrt_block2048___closed__7;
static const lean_closure_object l_BalancedSqrt_block2048___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_BalancedSqrt_block1024___lam__0___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_BalancedSqrt_block2048___closed__0_value),((lean_object*)(((size_t)(5) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block2048___closed__8 = (const lean_object*)&l_BalancedSqrt_block2048___closed__8_value;
static lean_once_cell_t l_BalancedSqrt_block2048___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block2048___closed__9;
static lean_once_cell_t l_BalancedSqrt_block2048___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block2048___closed__10;
static lean_once_cell_t l_BalancedSqrt_block2048___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block2048___closed__11;
LEAN_EXPORT lean_object* l_BalancedSqrt_block2048(lean_object*, uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_block2048___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block4096_spec__2___redArg();
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block4096_spec__2___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block4096_spec__2(lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block4096_spec__2___boxed(lean_object*);
static const lean_ctor_object l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(4076) << 1) | 1)),((lean_object*)(((size_t)(19) << 1) | 1))}};
static const lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__0 = (const lean_object*)&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__0_value;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__1;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__2;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__3;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__4;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__5;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__6;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__7;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__8;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__9;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__10;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__11;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__12;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__13_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__13;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__14_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__14;
static lean_once_cell_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__15_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__15;
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1(lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0(lean_object*);
static const lean_ctor_object l_BalancedSqrt_block4096___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*3 + 8, .m_other = 3, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(19) << 1) | 1)),((lean_object*)(((size_t)(4076) << 1) | 1)),((lean_object*)(((size_t)(262143) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_BalancedSqrt_block4096___closed__0 = (const lean_object*)&l_BalancedSqrt_block4096___closed__0_value;
static const lean_closure_object l_BalancedSqrt_block4096___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Code_toModel___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_BalancedSqrt_block4096___closed__0_value),((lean_object*)(((size_t)(5) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block4096___closed__1 = (const lean_object*)&l_BalancedSqrt_block4096___closed__1_value;
static const lean_closure_object l_BalancedSqrt_block4096___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Code_ofModel___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_BalancedSqrt_block4096___closed__0_value),((lean_object*)(((size_t)(5) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block4096___closed__2 = (const lean_object*)&l_BalancedSqrt_block4096___closed__2_value;
static const lean_ctor_object l_BalancedSqrt_block4096___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l_BalancedSqrt_block4096___closed__1_value),((lean_object*)&l_BalancedSqrt_block4096___closed__2_value)}};
static const lean_object* l_BalancedSqrt_block4096___closed__3 = (const lean_object*)&l_BalancedSqrt_block4096___closed__3_value;
static lean_once_cell_t l_BalancedSqrt_block4096___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block4096___closed__4;
static lean_once_cell_t l_BalancedSqrt_block4096___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block4096___closed__5;
static lean_once_cell_t l_BalancedSqrt_block4096___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static uint8_t l_BalancedSqrt_block4096___closed__6;
static lean_once_cell_t l_BalancedSqrt_block4096___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static uint8_t l_BalancedSqrt_block4096___closed__7;
static const lean_closure_object l_BalancedSqrt_block4096___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_BalancedSqrt_block1024___lam__0___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_BalancedSqrt_block4096___closed__0_value),((lean_object*)(((size_t)(5) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block4096___closed__8 = (const lean_object*)&l_BalancedSqrt_block4096___closed__8_value;
static lean_once_cell_t l_BalancedSqrt_block4096___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block4096___closed__9;
static lean_once_cell_t l_BalancedSqrt_block4096___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block4096___closed__10;
static lean_once_cell_t l_BalancedSqrt_block4096___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block4096___closed__11;
LEAN_EXPORT lean_object* l_BalancedSqrt_block4096(lean_object*, uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_block4096___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks1024(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks1024___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks2048(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks2048___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks4096(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks4096___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object l_BalancedSqrt_output___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 16, .m_capacity = 16, .m_length = 15, .m_data = "block|floatlib|"};
static const lean_object* l_BalancedSqrt_output___closed__0 = (const lean_object*)&l_BalancedSqrt_output___closed__0_value;
static const lean_string_object l_BalancedSqrt_output___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "|"};
static const lean_object* l_BalancedSqrt_output___closed__1 = (const lean_object*)&l_BalancedSqrt_output___closed__1_value;
LEAN_EXPORT lean_object* l_BalancedSqrt_output(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_output___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object l_BalancedSqrt_execute___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 16, .m_other = 0, .m_tag = 0}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(37, 35, 34, 132, 228, 156, 242, 203),LEAN_SCALAR_PTR_LITERAL(37, 35, 34, 132, 228, 156, 242, 203)}};
static const lean_object* l_BalancedSqrt_execute___closed__0 = (const lean_object*)&l_BalancedSqrt_execute___closed__0_value;
static const lean_string_object l_BalancedSqrt_execute___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "validate"};
static const lean_object* l_BalancedSqrt_execute___closed__1 = (const lean_object*)&l_BalancedSqrt_execute___closed__1_value;
static const lean_string_object l_BalancedSqrt_execute___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "warmup|floatlib|"};
static const lean_object* l_BalancedSqrt_execute___closed__2 = (const lean_object*)&l_BalancedSqrt_execute___closed__2_value;
static const lean_string_object l_BalancedSqrt_execute___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "|1|"};
static const lean_object* l_BalancedSqrt_execute___closed__3 = (const lean_object*)&l_BalancedSqrt_execute___closed__3_value;
LEAN_EXPORT lean_object* l_BalancedSqrt_execute(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_execute___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0___closed__0;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static size_t l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0;
static lean_once_cell_t l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__1;
LEAN_EXPORT lean_object* l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0;
static const lean_string_object l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "value|1024|"};
static const lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__0 = (const lean_object*)&l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__0_value;
static const lean_string_object l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "|raw|"};
static const lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1 = (const lean_object*)&l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run1024___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run1024___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_BalancedSqrt_run1024___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_run1024___closed__0;
static const lean_closure_object l_BalancedSqrt_run1024___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*3, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_BalancedSqrt_run1024___lam__0___boxed, .m_arity = 4, .m_num_fixed = 3, .m_objs = {((lean_object*)&l_BalancedSqrt_nextUnused___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_run1024___closed__1 = (const lean_object*)&l_BalancedSqrt_run1024___closed__1_value;
LEAN_EXPORT lean_object* l_BalancedSqrt_run1024(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run1024___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0_spec__0(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0___closed__0;
LEAN_EXPORT lean_object* l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0;
static const lean_string_object l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "value|2048|"};
static const lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg___closed__0 = (const lean_object*)&l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg___closed__0_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run2048___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run2048___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_BalancedSqrt_run2048___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_run2048___closed__0;
static const lean_closure_object l_BalancedSqrt_run2048___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*3, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_BalancedSqrt_run2048___lam__0___boxed, .m_arity = 4, .m_num_fixed = 3, .m_objs = {((lean_object*)&l_BalancedSqrt_nextUnused___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_run2048___closed__1 = (const lean_object*)&l_BalancedSqrt_run2048___closed__1_value;
LEAN_EXPORT lean_object* l_BalancedSqrt_run2048(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run2048___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0_spec__0(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0___closed__0;
LEAN_EXPORT lean_object* l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0;
static const lean_string_object l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "value|4096|"};
static const lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg___closed__0 = (const lean_object*)&l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg___closed__0_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run4096___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run4096___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_BalancedSqrt_run4096___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_run4096___closed__0;
static const lean_closure_object l_BalancedSqrt_run4096___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*3, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_BalancedSqrt_run4096___lam__0___boxed, .m_arity = 4, .m_num_fixed = 3, .m_objs = {((lean_object*)&l_BalancedSqrt_nextUnused___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_run4096___closed__1 = (const lean_object*)&l_BalancedSqrt_run4096___closed__1_value;
LEAN_EXPORT lean_object* l_BalancedSqrt_run4096(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run4096___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 54, .m_capacity = 54, .m_length = 53, .m_data = "usage: balanced-floatlib (validate|time) WIDTH BLOCKS"};
static const lean_object* l_main___closed__0 = (const lean_object*)&l_main___closed__0_value;
static const lean_ctor_object l_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_main___closed__0_value)}};
static const lean_object* l_main___closed__1 = (const lean_object*)&l_main___closed__1_value;
static const lean_string_object l_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 29, .m_capacity = 29, .m_length = 28, .m_data = "block count must be positive"};
static const lean_object* l_main___closed__2 = (const lean_object*)&l_main___closed__2_value;
static const lean_ctor_object l_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_main___closed__2_value)}};
static const lean_object* l_main___closed__3 = (const lean_object*)&l_main___closed__3_value;
static const lean_string_object l_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "1024"};
static const lean_object* l_main___closed__4 = (const lean_object*)&l_main___closed__4_value;
static const lean_string_object l_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "2048"};
static const lean_object* l_main___closed__5 = (const lean_object*)&l_main___closed__5_value;
static const lean_string_object l_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "4096"};
static const lean_object* l_main___closed__6 = (const lean_object*)&l_main___closed__6_value;
static const lean_string_object l_main___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 34, .m_capacity = 34, .m_length = 33, .m_data = "width must be 1024, 2048, or 4096"};
static const lean_object* l_main___closed__7 = (const lean_object*)&l_main___closed__7_value;
static const lean_ctor_object l_main___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_main___closed__7_value)}};
static const lean_object* l_main___closed__8 = (const lean_object*)&l_main___closed__8_value;
static const lean_string_object l_main___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 20, .m_capacity = 20, .m_length = 19, .m_data = "invalid block count"};
static const lean_object* l_main___closed__9 = (const lean_object*)&l_main___closed__9_value;
static const lean_ctor_object l_main___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_main___closed__9_value)}};
static const lean_object* l_main___closed__10 = (const lean_object*)&l_main___closed__10_value;
static const lean_string_object l_main___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "time"};
static const lean_object* l_main___closed__11 = (const lean_object*)&l_main___closed__11_value;
static const lean_string_object l_main___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 30, .m_capacity = 30, .m_length = 29, .m_data = "mode must be validate or time"};
static const lean_object* l_main___closed__12 = (const lean_object*)&l_main___closed__12_value;
static const lean_ctor_object l_main___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_main___closed__12_value)}};
static const lean_object* l_main___closed__13 = (const lean_object*)&l_main___closed__13_value;
LEAN_EXPORT lean_object* l_main___boxed__const__1;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* l_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___redArg(uint64_t v_used_1_, lean_object* v_range_2_, lean_object* v_b_3_, lean_object* v_i_4_){
_start:
{
lean_object* v_stop_5_; lean_object* v_step_6_; uint8_t v___x_7_; 
v_stop_5_ = lean_ctor_get(v_range_2_, 1);
v_step_6_ = lean_ctor_get(v_range_2_, 2);
v___x_7_ = lean_nat_dec_lt(v_i_4_, v_stop_5_);
if (v___x_7_ == 0)
{
lean_dec(v_i_4_);
return v_b_3_;
}
else
{
lean_object* v_snd_8_; lean_object* v___x_10_; uint8_t v_isShared_11_; uint8_t v_isSharedCheck_32_; 
v_snd_8_ = lean_ctor_get(v_b_3_, 1);
v_isSharedCheck_32_ = !lean_is_exclusive(v_b_3_);
if (v_isSharedCheck_32_ == 0)
{
lean_object* v_unused_33_; 
v_unused_33_ = lean_ctor_get(v_b_3_, 0);
lean_dec(v_unused_33_);
v___x_10_ = v_b_3_;
v_isShared_11_ = v_isSharedCheck_32_;
goto v_resetjp_9_;
}
else
{
lean_inc(v_snd_8_);
lean_dec(v_b_3_);
v___x_10_ = lean_box(0);
v_isShared_11_ = v_isSharedCheck_32_;
goto v_resetjp_9_;
}
v_resetjp_9_:
{
uint64_t v___x_12_; uint64_t v___x_13_; uint64_t v___x_14_; uint64_t v___x_15_; uint64_t v___x_16_; uint8_t v___x_17_; 
v___x_12_ = 1ULL;
v___x_13_ = lean_uint64_of_nat(v_snd_8_);
v___x_14_ = lean_uint64_shift_left(v___x_12_, v___x_13_);
v___x_15_ = lean_uint64_land(v_used_1_, v___x_14_);
v___x_16_ = 0ULL;
v___x_17_ = lean_uint64_dec_eq(v___x_15_, v___x_16_);
if (v___x_17_ == 0)
{
lean_object* v___x_18_; lean_object* v___x_19_; lean_object* v___x_20_; lean_object* v___x_21_; lean_object* v___x_22_; lean_object* v___x_24_; 
v___x_18_ = lean_unsigned_to_nat(1u);
v___x_19_ = lean_unsigned_to_nat(16u);
v___x_20_ = lean_box(0);
v___x_21_ = lean_nat_add(v_snd_8_, v___x_18_);
lean_dec(v_snd_8_);
v___x_22_ = lean_nat_mod(v___x_21_, v___x_19_);
lean_dec(v___x_21_);
if (v_isShared_11_ == 0)
{
lean_ctor_set(v___x_10_, 1, v___x_22_);
lean_ctor_set(v___x_10_, 0, v___x_20_);
v___x_24_ = v___x_10_;
goto v_reusejp_23_;
}
else
{
lean_object* v_reuseFailAlloc_27_; 
v_reuseFailAlloc_27_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_27_, 0, v___x_20_);
lean_ctor_set(v_reuseFailAlloc_27_, 1, v___x_22_);
v___x_24_ = v_reuseFailAlloc_27_;
goto v_reusejp_23_;
}
v_reusejp_23_:
{
lean_object* v___x_25_; 
v___x_25_ = lean_nat_add(v_i_4_, v_step_6_);
lean_dec(v_i_4_);
v_b_3_ = v___x_24_;
v_i_4_ = v___x_25_;
goto _start;
}
}
else
{
lean_object* v___x_28_; lean_object* v___x_30_; 
lean_dec(v_i_4_);
lean_inc(v_snd_8_);
v___x_28_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_28_, 0, v_snd_8_);
if (v_isShared_11_ == 0)
{
lean_ctor_set(v___x_10_, 0, v___x_28_);
v___x_30_ = v___x_10_;
goto v_reusejp_29_;
}
else
{
lean_object* v_reuseFailAlloc_31_; 
v_reuseFailAlloc_31_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_31_, 0, v___x_28_);
lean_ctor_set(v_reuseFailAlloc_31_, 1, v_snd_8_);
v___x_30_ = v_reuseFailAlloc_31_;
goto v_reusejp_29_;
}
v_reusejp_29_:
{
return v___x_30_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___redArg___boxed(lean_object* v_used_34_, lean_object* v_range_35_, lean_object* v_b_36_, lean_object* v_i_37_){
_start:
{
uint64_t v_used_boxed_38_; lean_object* v_res_39_; 
v_used_boxed_38_ = lean_unbox_uint64(v_used_34_);
lean_dec_ref(v_used_34_);
v_res_39_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___redArg(v_used_boxed_38_, v_range_35_, v_b_36_, v_i_37_);
lean_dec_ref(v_range_35_);
return v_res_39_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_nextUnused(uint64_t v_used_44_, uint64_t v_sink_45_){
_start:
{
uint64_t v___x_46_; uint64_t v___x_47_; uint64_t v___x_48_; uint64_t v___x_49_; uint64_t v___x_50_; uint64_t v_folded_51_; uint64_t v___x_52_; uint64_t v___x_53_; lean_object* v_index_54_; lean_object* v___x_55_; lean_object* v___x_56_; lean_object* v___x_57_; lean_object* v___x_58_; lean_object* v___x_59_; lean_object* v_fst_60_; 
v___x_46_ = 32ULL;
v___x_47_ = lean_uint64_shift_right(v_sink_45_, v___x_46_);
v___x_48_ = lean_uint64_xor(v_sink_45_, v___x_47_);
v___x_49_ = 16ULL;
v___x_50_ = lean_uint64_shift_right(v___x_48_, v___x_49_);
v_folded_51_ = lean_uint64_xor(v___x_48_, v___x_50_);
v___x_52_ = 15ULL;
v___x_53_ = lean_uint64_land(v_folded_51_, v___x_52_);
v_index_54_ = lean_uint64_to_nat(v___x_53_);
v___x_55_ = lean_unsigned_to_nat(0u);
v___x_56_ = ((lean_object*)(l_BalancedSqrt_nextUnused___closed__0));
v___x_57_ = lean_box(0);
v___x_58_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_58_, 0, v___x_57_);
lean_ctor_set(v___x_58_, 1, v_index_54_);
v___x_59_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___redArg(v_used_44_, v___x_56_, v___x_58_, v___x_55_);
v_fst_60_ = lean_ctor_get(v___x_59_, 0);
lean_inc(v_fst_60_);
if (lean_obj_tag(v_fst_60_) == 0)
{
lean_object* v_snd_61_; 
v_snd_61_ = lean_ctor_get(v___x_59_, 1);
lean_inc(v_snd_61_);
lean_dec_ref(v___x_59_);
return v_snd_61_;
}
else
{
lean_object* v_val_62_; 
lean_dec_ref(v___x_59_);
v_val_62_ = lean_ctor_get(v_fst_60_, 0);
lean_inc(v_val_62_);
lean_dec_ref_known(v_fst_60_, 1);
return v_val_62_;
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_nextUnused___boxed(lean_object* v_used_63_, lean_object* v_sink_64_){
_start:
{
uint64_t v_used_boxed_65_; uint64_t v_sink_boxed_66_; lean_object* v_res_67_; 
v_used_boxed_65_ = lean_unbox_uint64(v_used_63_);
lean_dec_ref(v_used_63_);
v_sink_boxed_66_ = lean_unbox_uint64(v_sink_64_);
lean_dec_ref(v_sink_64_);
v_res_67_ = l_BalancedSqrt_nextUnused(v_used_boxed_65_, v_sink_boxed_66_);
return v_res_67_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0(uint64_t v_used_68_, lean_object* v_range_69_, lean_object* v_b_70_, lean_object* v_i_71_, lean_object* v_hs_72_, lean_object* v_hl_73_){
_start:
{
lean_object* v___x_74_; 
v___x_74_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___redArg(v_used_68_, v_range_69_, v_b_70_, v_i_71_);
return v___x_74_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___boxed(lean_object* v_used_75_, lean_object* v_range_76_, lean_object* v_b_77_, lean_object* v_i_78_, lean_object* v_hs_79_, lean_object* v_hl_80_){
_start:
{
uint64_t v_used_boxed_81_; lean_object* v_res_82_; 
v_used_boxed_81_ = lean_unbox_uint64(v_used_75_);
lean_dec_ref(v_used_75_);
v_res_82_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0(v_used_boxed_81_, v_range_76_, v_b_77_, v_i_78_, v_hs_79_, v_hl_80_);
lean_dec_ref(v_range_76_);
return v_res_82_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_advance(lean_object* v_s_83_, lean_object* v_index_84_, uint64_t v_bits_85_){
_start:
{
uint64_t v_sink_86_; uint64_t v_trace_87_; lean_object* v___x_89_; uint8_t v_isShared_90_; uint8_t v_isSharedCheck_100_; 
v_sink_86_ = lean_ctor_get_uint64(v_s_83_, 0);
v_trace_87_ = lean_ctor_get_uint64(v_s_83_, 8);
v_isSharedCheck_100_ = !lean_is_exclusive(v_s_83_);
if (v_isSharedCheck_100_ == 0)
{
v___x_89_ = v_s_83_;
v_isShared_90_ = v_isSharedCheck_100_;
goto v_resetjp_88_;
}
else
{
lean_dec(v_s_83_);
v___x_89_ = lean_box(0);
v_isShared_90_ = v_isSharedCheck_100_;
goto v_resetjp_88_;
}
v_resetjp_88_:
{
uint64_t v___x_91_; uint64_t v___x_92_; uint64_t v___x_93_; uint64_t v___x_94_; uint64_t v___x_95_; uint64_t v___x_96_; lean_object* v___x_98_; 
v___x_91_ = lean_uint64_xor(v_sink_86_, v_bits_85_);
v___x_92_ = 1099511628211ULL;
v___x_93_ = lean_uint64_mul(v___x_91_, v___x_92_);
v___x_94_ = lean_uint64_of_nat(v_index_84_);
v___x_95_ = lean_uint64_xor(v_trace_87_, v___x_94_);
v___x_96_ = lean_uint64_mul(v___x_95_, v___x_92_);
if (v_isShared_90_ == 0)
{
v___x_98_ = v___x_89_;
goto v_reusejp_97_;
}
else
{
lean_object* v_reuseFailAlloc_99_; 
v_reuseFailAlloc_99_ = lean_alloc_ctor(0, 0, 16);
v___x_98_ = v_reuseFailAlloc_99_;
goto v_reusejp_97_;
}
v_reusejp_97_:
{
lean_ctor_set_uint64(v___x_98_, 0, v___x_93_);
lean_ctor_set_uint64(v___x_98_, 8, v___x_96_);
return v___x_98_;
}
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_advance___boxed(lean_object* v_s_101_, lean_object* v_index_102_, lean_object* v_bits_103_){
_start:
{
uint64_t v_bits_boxed_104_; lean_object* v_res_105_; 
v_bits_boxed_104_ = lean_unbox_uint64(v_bits_103_);
lean_dec_ref(v_bits_103_);
v_res_105_ = l_BalancedSqrt_advance(v_s_101_, v_index_102_, v_bits_boxed_104_);
lean_dec(v_index_102_);
return v_res_105_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block1024_spec__3___redArg(){
_start:
{
lean_object* v___x_107_; 
v___x_107_ = lean_box(0);
return v___x_107_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block1024_spec__3___redArg___boxed(lean_object* v___dummy_108_){
_start:
{
lean_object* v_res_109_; 
v_res_109_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block1024_spec__3___redArg();
return v_res_109_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block1024_spec__3(lean_object* v_x_110_){
_start:
{
lean_object* v___x_111_; 
v___x_111_ = lean_box(0);
return v___x_111_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block1024_spec__3___boxed(lean_object* v_x_112_){
_start:
{
lean_object* v_res_113_; 
v_res_113_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block1024_spec__3(v_x_112_);
lean_dec(v_x_112_);
return v_res_113_;
}
}
LEAN_EXPORT lean_object* l_List_foldl___at___00BalancedSqrt_block1024_spec__0(lean_object* v_x_114_, lean_object* v_x_115_){
_start:
{
if (lean_obj_tag(v_x_115_) == 0)
{
return v_x_114_;
}
else
{
lean_object* v_head_116_; lean_object* v_tail_117_; lean_object* v___y_119_; lean_object* v___y_120_; lean_object* v_estimate_124_; lean_object* v_kind_125_; lean_object* v_steadyCost_126_; lean_object* v_marshallingCost_127_; lean_object* v_setupCost_128_; lean_object* v_setupAllocations_129_; lean_object* v_residentBytes_130_; lean_object* v_temporaryBytes_131_; lean_object* v_allocations_132_; lean_object* v___x_133_; lean_object* v_expectedCalls_134_; lean_object* v_allocationPenalty_135_; lean_object* v_memoryBlockBytes_136_; lean_object* v_temporaryBlockPenalty_137_; lean_object* v_residentBlockPenalty_138_; lean_object* v_maxTemporaryBytes_139_; lean_object* v_maxResidentBytes_140_; uint8_t v___x_141_; 
v_head_116_ = lean_ctor_get(v_x_115_, 0);
lean_inc(v_head_116_);
v_tail_117_ = lean_ctor_get(v_x_115_, 1);
lean_inc(v_tail_117_);
lean_dec_ref_known(v_x_115_, 2);
v_estimate_124_ = lean_ctor_get(v_head_116_, 0);
v_kind_125_ = lean_ctor_get(v_estimate_124_, 1);
v_steadyCost_126_ = lean_ctor_get(v_estimate_124_, 3);
v_marshallingCost_127_ = lean_ctor_get(v_estimate_124_, 4);
v_setupCost_128_ = lean_ctor_get(v_estimate_124_, 5);
v_setupAllocations_129_ = lean_ctor_get(v_estimate_124_, 6);
v_residentBytes_130_ = lean_ctor_get(v_estimate_124_, 7);
v_temporaryBytes_131_ = lean_ctor_get(v_estimate_124_, 8);
v_allocations_132_ = lean_ctor_get(v_estimate_124_, 9);
v___x_133_ = lp_floatlib_FloatLib_Floats_ExecFloat_Backend_Policy_throughput;
v_expectedCalls_134_ = lean_ctor_get(v___x_133_, 0);
v_allocationPenalty_135_ = lean_ctor_get(v___x_133_, 1);
v_memoryBlockBytes_136_ = lean_ctor_get(v___x_133_, 2);
v_temporaryBlockPenalty_137_ = lean_ctor_get(v___x_133_, 3);
v_residentBlockPenalty_138_ = lean_ctor_get(v___x_133_, 4);
v_maxTemporaryBytes_139_ = lean_ctor_get(v___x_133_, 5);
v_maxResidentBytes_140_ = lean_ctor_get(v___x_133_, 6);
v___x_141_ = lean_nat_dec_le(v_residentBytes_130_, v_maxResidentBytes_140_);
if (v___x_141_ == 0)
{
lean_dec(v_head_116_);
v_x_115_ = v_tail_117_;
goto _start;
}
else
{
uint8_t v___x_143_; 
v___x_143_ = lean_nat_dec_le(v_temporaryBytes_131_, v_maxTemporaryBytes_139_);
if (v___x_143_ == 0)
{
lean_dec(v_head_116_);
v_x_115_ = v_tail_117_;
goto _start;
}
else
{
lean_object* v_estimate_145_; lean_object* v___y_147_; lean_object* v___y_159_; lean_object* v___y_160_; lean_object* v___y_161_; lean_object* v___y_178_; lean_object* v___y_179_; lean_object* v___y_180_; lean_object* v___y_181_; lean_object* v___y_191_; lean_object* v___y_192_; lean_object* v___y_193_; lean_object* v___y_194_; lean_object* v___y_195_; lean_object* v___y_196_; lean_object* v___y_197_; lean_object* v___y_198_; lean_object* v___y_199_; lean_object* v___x_228_; lean_object* v___x_229_; lean_object* v___x_230_; lean_object* v___y_232_; lean_object* v___y_233_; lean_object* v___y_234_; lean_object* v___y_235_; lean_object* v___y_236_; lean_object* v___y_237_; lean_object* v___y_238_; lean_object* v___y_239_; lean_object* v___y_249_; lean_object* v___y_250_; lean_object* v___y_251_; lean_object* v___y_252_; lean_object* v___y_253_; lean_object* v___y_254_; lean_object* v___y_255_; lean_object* v___y_256_; lean_object* v___y_257_; lean_object* v___y_258_; lean_object* v___y_271_; lean_object* v___y_272_; lean_object* v___y_273_; lean_object* v___y_274_; lean_object* v___y_275_; lean_object* v___y_276_; lean_object* v___y_277_; lean_object* v___y_278_; lean_object* v___y_279_; lean_object* v___y_290_; lean_object* v___y_291_; lean_object* v___y_292_; lean_object* v___y_293_; lean_object* v___y_294_; lean_object* v___y_295_; lean_object* v___y_296_; lean_object* v___y_297_; lean_object* v___y_298_; lean_object* v___y_309_; lean_object* v___y_310_; lean_object* v___y_311_; lean_object* v___y_312_; lean_object* v___y_313_; lean_object* v___y_314_; lean_object* v___y_315_; lean_object* v___y_316_; lean_object* v___y_327_; lean_object* v___y_328_; lean_object* v___y_329_; lean_object* v___y_330_; lean_object* v___y_331_; lean_object* v___y_332_; lean_object* v___y_333_; lean_object* v___y_334_; lean_object* v___y_335_; lean_object* v___y_336_; lean_object* v___y_349_; lean_object* v___y_350_; lean_object* v___y_351_; lean_object* v___y_352_; lean_object* v___y_353_; lean_object* v___y_354_; lean_object* v___y_355_; lean_object* v___y_356_; lean_object* v___y_357_; lean_object* v___y_358_; lean_object* v___y_371_; lean_object* v___y_372_; lean_object* v___y_373_; lean_object* v___y_394_; lean_object* v___x_406_; uint8_t v___x_407_; 
v_estimate_145_ = lean_ctor_get(v_x_114_, 0);
v___x_228_ = lean_nat_add(v_steadyCost_126_, v_marshallingCost_127_);
v___x_229_ = lean_nat_mul(v_allocationPenalty_135_, v_allocations_132_);
v___x_230_ = lean_nat_add(v___x_228_, v___x_229_);
lean_dec(v___x_229_);
lean_dec(v___x_228_);
v___x_406_ = lean_unsigned_to_nat(0u);
v___x_407_ = lean_nat_dec_eq(v_memoryBlockBytes_136_, v___x_406_);
if (v___x_407_ == 0)
{
lean_object* v___x_408_; lean_object* v___x_409_; lean_object* v___x_410_; lean_object* v___x_411_; 
v___x_408_ = lean_nat_add(v_temporaryBytes_131_, v_memoryBlockBytes_136_);
v___x_409_ = lean_unsigned_to_nat(1u);
v___x_410_ = lean_nat_sub(v___x_408_, v___x_409_);
lean_dec(v___x_408_);
v___x_411_ = lean_nat_div(v___x_410_, v_memoryBlockBytes_136_);
lean_dec(v___x_410_);
v___y_394_ = v___x_411_;
goto v___jp_393_;
}
else
{
lean_inc(v_temporaryBytes_131_);
v___y_394_ = v_temporaryBytes_131_;
goto v___jp_393_;
}
v___jp_146_:
{
lean_object* v_kind_148_; 
v_kind_148_ = lean_ctor_get(v_estimate_145_, 1);
switch(lean_obj_tag(v_kind_148_))
{
case 0:
{
lean_object* v___x_149_; 
v___x_149_ = lean_unsigned_to_nat(0u);
v___y_119_ = v___y_147_;
v___y_120_ = v___x_149_;
goto v___jp_118_;
}
case 1:
{
lean_object* v___x_150_; 
v___x_150_ = lean_unsigned_to_nat(2u);
v___y_119_ = v___y_147_;
v___y_120_ = v___x_150_;
goto v___jp_118_;
}
case 2:
{
lean_object* v___x_151_; 
v___x_151_ = lean_unsigned_to_nat(3u);
v___y_119_ = v___y_147_;
v___y_120_ = v___x_151_;
goto v___jp_118_;
}
case 3:
{
lean_object* v___x_152_; 
v___x_152_ = lean_unsigned_to_nat(4u);
v___y_119_ = v___y_147_;
v___y_120_ = v___x_152_;
goto v___jp_118_;
}
case 4:
{
lean_object* v___x_153_; 
v___x_153_ = lean_unsigned_to_nat(5u);
v___y_119_ = v___y_147_;
v___y_120_ = v___x_153_;
goto v___jp_118_;
}
case 5:
{
lean_object* v___x_154_; 
v___x_154_ = lean_unsigned_to_nat(6u);
v___y_119_ = v___y_147_;
v___y_120_ = v___x_154_;
goto v___jp_118_;
}
default: 
{
lean_object* v_tieRank_155_; lean_object* v___x_156_; lean_object* v___x_157_; 
v_tieRank_155_ = lean_ctor_get(v_kind_148_, 1);
v___x_156_ = lean_unsigned_to_nat(7u);
v___x_157_ = lean_nat_add(v___x_156_, v_tieRank_155_);
v___y_119_ = v___y_147_;
v___y_120_ = v___x_157_;
goto v___jp_118_;
}
}
}
v___jp_158_:
{
lean_object* v___x_162_; lean_object* v___x_163_; uint8_t v___x_164_; 
v___x_162_ = lean_nat_mul(v_residentBlockPenalty_138_, v___y_161_);
lean_dec(v___y_161_);
v___x_163_ = lean_nat_add(v___y_159_, v___x_162_);
lean_dec(v___x_162_);
lean_dec(v___y_159_);
v___x_164_ = lean_nat_dec_eq(v___y_160_, v___x_163_);
if (v___x_164_ == 0)
{
uint8_t v___x_165_; 
v___x_165_ = lean_nat_dec_lt(v___y_160_, v___x_163_);
lean_dec(v___x_163_);
lean_dec(v___y_160_);
if (v___x_165_ == 0)
{
lean_dec(v_head_116_);
v_x_115_ = v_tail_117_;
goto _start;
}
else
{
lean_dec_ref(v_x_114_);
v_x_114_ = v_head_116_;
v_x_115_ = v_tail_117_;
goto _start;
}
}
else
{
lean_dec(v___x_163_);
lean_dec(v___y_160_);
switch(lean_obj_tag(v_kind_125_))
{
case 0:
{
lean_object* v___x_168_; 
v___x_168_ = lean_unsigned_to_nat(0u);
v___y_147_ = v___x_168_;
goto v___jp_146_;
}
case 1:
{
lean_object* v___x_169_; 
v___x_169_ = lean_unsigned_to_nat(2u);
v___y_147_ = v___x_169_;
goto v___jp_146_;
}
case 2:
{
lean_object* v___x_170_; 
v___x_170_ = lean_unsigned_to_nat(3u);
v___y_147_ = v___x_170_;
goto v___jp_146_;
}
case 3:
{
lean_object* v___x_171_; 
v___x_171_ = lean_unsigned_to_nat(4u);
v___y_147_ = v___x_171_;
goto v___jp_146_;
}
case 4:
{
lean_object* v___x_172_; 
v___x_172_ = lean_unsigned_to_nat(5u);
v___y_147_ = v___x_172_;
goto v___jp_146_;
}
case 5:
{
lean_object* v___x_173_; 
v___x_173_ = lean_unsigned_to_nat(6u);
v___y_147_ = v___x_173_;
goto v___jp_146_;
}
default: 
{
lean_object* v_tieRank_174_; lean_object* v___x_175_; lean_object* v___x_176_; 
v_tieRank_174_ = lean_ctor_get(v_kind_125_, 1);
v___x_175_ = lean_unsigned_to_nat(7u);
v___x_176_ = lean_nat_add(v___x_175_, v_tieRank_174_);
v___y_147_ = v___x_176_;
goto v___jp_146_;
}
}
}
}
v___jp_177_:
{
lean_object* v___x_182_; lean_object* v___x_183_; lean_object* v___x_184_; uint8_t v___x_185_; 
v___x_182_ = lean_nat_mul(v_residentBlockPenalty_138_, v___y_181_);
lean_dec(v___y_181_);
v___x_183_ = lean_nat_add(v___y_179_, v___x_182_);
lean_dec(v___x_182_);
lean_dec(v___y_179_);
v___x_184_ = lean_unsigned_to_nat(0u);
v___x_185_ = lean_nat_dec_eq(v_memoryBlockBytes_136_, v___x_184_);
if (v___x_185_ == 0)
{
lean_object* v___x_186_; lean_object* v___x_187_; lean_object* v___x_188_; lean_object* v___x_189_; 
v___x_186_ = lean_nat_add(v___y_180_, v_memoryBlockBytes_136_);
lean_dec(v___y_180_);
v___x_187_ = lean_unsigned_to_nat(1u);
v___x_188_ = lean_nat_sub(v___x_186_, v___x_187_);
lean_dec(v___x_186_);
v___x_189_ = lean_nat_div(v___x_188_, v_memoryBlockBytes_136_);
lean_dec(v___x_188_);
v___y_159_ = v___y_178_;
v___y_160_ = v___x_183_;
v___y_161_ = v___x_189_;
goto v___jp_158_;
}
else
{
v___y_159_ = v___y_178_;
v___y_160_ = v___x_183_;
v___y_161_ = v___y_180_;
goto v___jp_158_;
}
}
v___jp_190_:
{
lean_object* v___x_200_; lean_object* v___x_201_; uint8_t v___x_202_; 
v___x_200_ = lean_nat_mul(v_temporaryBlockPenalty_137_, v___y_199_);
lean_dec(v___y_199_);
v___x_201_ = lean_nat_add(v___y_194_, v___x_200_);
lean_dec(v___x_200_);
lean_dec(v___y_194_);
v___x_202_ = lean_nat_dec_eq(v___y_197_, v___x_201_);
if (v___x_202_ == 0)
{
uint8_t v___x_203_; 
lean_dec(v___y_198_);
lean_dec(v___y_196_);
lean_dec(v___y_195_);
lean_dec(v___y_193_);
lean_dec(v___y_192_);
lean_dec(v___y_191_);
v___x_203_ = lean_nat_dec_lt(v___y_197_, v___x_201_);
lean_dec(v___x_201_);
lean_dec(v___y_197_);
if (v___x_203_ == 0)
{
lean_dec(v_head_116_);
v_x_115_ = v_tail_117_;
goto _start;
}
else
{
lean_dec_ref(v_x_114_);
v_x_114_ = v_head_116_;
v_x_115_ = v_tail_117_;
goto _start;
}
}
else
{
uint8_t v___x_206_; 
lean_dec(v___x_201_);
lean_dec(v___y_197_);
v___x_206_ = lean_nat_dec_eq(v_marshallingCost_127_, v___y_196_);
if (v___x_206_ == 0)
{
uint8_t v___x_207_; 
lean_dec(v___y_198_);
lean_dec(v___y_195_);
lean_dec(v___y_193_);
lean_dec(v___y_192_);
lean_dec(v___y_191_);
v___x_207_ = lean_nat_dec_lt(v_marshallingCost_127_, v___y_196_);
lean_dec(v___y_196_);
if (v___x_207_ == 0)
{
lean_dec(v_head_116_);
v_x_115_ = v_tail_117_;
goto _start;
}
else
{
lean_dec_ref(v_x_114_);
v_x_114_ = v_head_116_;
v_x_115_ = v_tail_117_;
goto _start;
}
}
else
{
uint8_t v___x_210_; 
lean_dec(v___y_196_);
v___x_210_ = lean_nat_dec_eq(v_allocations_132_, v___y_198_);
if (v___x_210_ == 0)
{
uint8_t v___x_211_; 
lean_dec(v___y_195_);
lean_dec(v___y_193_);
lean_dec(v___y_192_);
lean_dec(v___y_191_);
v___x_211_ = lean_nat_dec_lt(v_allocations_132_, v___y_198_);
lean_dec(v___y_198_);
if (v___x_211_ == 0)
{
lean_dec(v_head_116_);
v_x_115_ = v_tail_117_;
goto _start;
}
else
{
lean_dec_ref(v_x_114_);
v_x_114_ = v_head_116_;
v_x_115_ = v_tail_117_;
goto _start;
}
}
else
{
uint8_t v___x_214_; 
lean_dec(v___y_198_);
v___x_214_ = lean_nat_dec_eq(v_temporaryBytes_131_, v___y_193_);
if (v___x_214_ == 0)
{
uint8_t v___x_215_; 
lean_dec(v___y_195_);
lean_dec(v___y_192_);
lean_dec(v___y_191_);
v___x_215_ = lean_nat_dec_lt(v_temporaryBytes_131_, v___y_193_);
lean_dec(v___y_193_);
if (v___x_215_ == 0)
{
lean_dec(v_head_116_);
v_x_115_ = v_tail_117_;
goto _start;
}
else
{
lean_dec_ref(v_x_114_);
v_x_114_ = v_head_116_;
v_x_115_ = v_tail_117_;
goto _start;
}
}
else
{
uint8_t v___x_218_; 
lean_dec(v___y_193_);
v___x_218_ = lean_nat_dec_eq(v_residentBytes_130_, v___y_195_);
if (v___x_218_ == 0)
{
uint8_t v___x_219_; 
lean_dec(v___y_192_);
lean_dec(v___y_191_);
v___x_219_ = lean_nat_dec_lt(v_residentBytes_130_, v___y_195_);
lean_dec(v___y_195_);
if (v___x_219_ == 0)
{
lean_dec(v_head_116_);
v_x_115_ = v_tail_117_;
goto _start;
}
else
{
lean_dec_ref(v_x_114_);
v_x_114_ = v_head_116_;
v_x_115_ = v_tail_117_;
goto _start;
}
}
else
{
lean_object* v___x_222_; uint8_t v___x_223_; 
v___x_222_ = lean_unsigned_to_nat(0u);
v___x_223_ = lean_nat_dec_eq(v_memoryBlockBytes_136_, v___x_222_);
if (v___x_223_ == 0)
{
lean_object* v___x_224_; lean_object* v___x_225_; lean_object* v___x_226_; lean_object* v___x_227_; 
v___x_224_ = lean_nat_add(v_residentBytes_130_, v_memoryBlockBytes_136_);
v___x_225_ = lean_unsigned_to_nat(1u);
v___x_226_ = lean_nat_sub(v___x_224_, v___x_225_);
lean_dec(v___x_224_);
v___x_227_ = lean_nat_div(v___x_226_, v_memoryBlockBytes_136_);
lean_dec(v___x_226_);
v___y_178_ = v___y_191_;
v___y_179_ = v___y_192_;
v___y_180_ = v___y_195_;
v___y_181_ = v___x_227_;
goto v___jp_177_;
}
else
{
lean_inc(v_residentBytes_130_);
v___y_178_ = v___y_191_;
v___y_179_ = v___y_192_;
v___y_180_ = v___y_195_;
v___y_181_ = v_residentBytes_130_;
goto v___jp_177_;
}
}
}
}
}
}
}
v___jp_231_:
{
lean_object* v___x_240_; lean_object* v___x_241_; lean_object* v___x_242_; uint8_t v___x_243_; 
v___x_240_ = lean_nat_mul(v_temporaryBlockPenalty_137_, v___y_239_);
lean_dec(v___y_239_);
v___x_241_ = lean_nat_add(v___x_230_, v___x_240_);
lean_dec(v___x_240_);
lean_dec(v___x_230_);
v___x_242_ = lean_unsigned_to_nat(0u);
v___x_243_ = lean_nat_dec_eq(v_memoryBlockBytes_136_, v___x_242_);
if (v___x_243_ == 0)
{
lean_object* v___x_244_; lean_object* v___x_245_; lean_object* v___x_246_; lean_object* v___x_247_; 
v___x_244_ = lean_nat_add(v___y_235_, v_memoryBlockBytes_136_);
v___x_245_ = lean_unsigned_to_nat(1u);
v___x_246_ = lean_nat_sub(v___x_244_, v___x_245_);
lean_dec(v___x_244_);
v___x_247_ = lean_nat_div(v___x_246_, v_memoryBlockBytes_136_);
lean_dec(v___x_246_);
v___y_191_ = v___y_232_;
v___y_192_ = v___y_233_;
v___y_193_ = v___y_235_;
v___y_194_ = v___y_234_;
v___y_195_ = v___y_236_;
v___y_196_ = v___y_237_;
v___y_197_ = v___x_241_;
v___y_198_ = v___y_238_;
v___y_199_ = v___x_247_;
goto v___jp_190_;
}
else
{
lean_inc(v___y_235_);
v___y_191_ = v___y_232_;
v___y_192_ = v___y_233_;
v___y_193_ = v___y_235_;
v___y_194_ = v___y_234_;
v___y_195_ = v___y_236_;
v___y_196_ = v___y_237_;
v___y_197_ = v___x_241_;
v___y_198_ = v___y_238_;
v___y_199_ = v___y_235_;
goto v___jp_190_;
}
}
v___jp_248_:
{
lean_object* v___x_259_; lean_object* v___x_260_; lean_object* v___x_261_; uint8_t v___x_262_; 
v___x_259_ = lean_nat_mul(v_residentBlockPenalty_138_, v___y_258_);
lean_dec(v___y_258_);
v___x_260_ = lean_nat_add(v___y_249_, v___x_259_);
lean_dec(v___x_259_);
v___x_261_ = lean_nat_add(v___y_256_, v___x_260_);
lean_dec(v___x_260_);
lean_dec(v___y_256_);
v___x_262_ = lean_nat_dec_eq(v___y_253_, v___x_261_);
lean_dec(v___x_261_);
lean_dec(v___y_253_);
if (v___x_262_ == 0)
{
lean_dec(v___y_257_);
lean_dec(v___y_255_);
lean_dec(v___y_254_);
lean_dec(v___y_252_);
lean_dec(v___y_251_);
lean_dec(v___y_250_);
lean_dec(v___y_249_);
lean_dec(v___x_230_);
lean_dec(v_head_116_);
v_x_115_ = v_tail_117_;
goto _start;
}
else
{
lean_object* v___x_264_; uint8_t v___x_265_; 
v___x_264_ = lean_unsigned_to_nat(0u);
v___x_265_ = lean_nat_dec_eq(v_memoryBlockBytes_136_, v___x_264_);
if (v___x_265_ == 0)
{
lean_object* v___x_266_; lean_object* v___x_267_; lean_object* v___x_268_; lean_object* v___x_269_; 
v___x_266_ = lean_nat_add(v_temporaryBytes_131_, v_memoryBlockBytes_136_);
v___x_267_ = lean_unsigned_to_nat(1u);
v___x_268_ = lean_nat_sub(v___x_266_, v___x_267_);
lean_dec(v___x_266_);
v___x_269_ = lean_nat_div(v___x_268_, v_memoryBlockBytes_136_);
lean_dec(v___x_268_);
v___y_232_ = v___y_249_;
v___y_233_ = v___y_250_;
v___y_234_ = v___y_252_;
v___y_235_ = v___y_251_;
v___y_236_ = v___y_254_;
v___y_237_ = v___y_255_;
v___y_238_ = v___y_257_;
v___y_239_ = v___x_269_;
goto v___jp_231_;
}
else
{
lean_inc(v_temporaryBytes_131_);
v___y_232_ = v___y_249_;
v___y_233_ = v___y_250_;
v___y_234_ = v___y_252_;
v___y_235_ = v___y_251_;
v___y_236_ = v___y_254_;
v___y_237_ = v___y_255_;
v___y_238_ = v___y_257_;
v___y_239_ = v_temporaryBytes_131_;
goto v___jp_231_;
}
}
}
v___jp_270_:
{
lean_object* v___x_280_; lean_object* v___x_281_; lean_object* v___x_282_; lean_object* v___x_283_; uint8_t v___x_284_; 
v___x_280_ = lean_nat_mul(v_temporaryBlockPenalty_137_, v___y_279_);
lean_dec(v___y_279_);
v___x_281_ = lean_nat_add(v___y_275_, v___x_280_);
lean_dec(v___x_280_);
v___x_282_ = lean_nat_mul(v_expectedCalls_134_, v___x_281_);
lean_dec(v___x_281_);
v___x_283_ = lean_unsigned_to_nat(0u);
v___x_284_ = lean_nat_dec_eq(v_memoryBlockBytes_136_, v___x_283_);
if (v___x_284_ == 0)
{
lean_object* v___x_285_; lean_object* v___x_286_; lean_object* v___x_287_; lean_object* v___x_288_; 
v___x_285_ = lean_nat_add(v___y_276_, v_memoryBlockBytes_136_);
v___x_286_ = lean_unsigned_to_nat(1u);
v___x_287_ = lean_nat_sub(v___x_285_, v___x_286_);
lean_dec(v___x_285_);
v___x_288_ = lean_nat_div(v___x_287_, v_memoryBlockBytes_136_);
lean_dec(v___x_287_);
v___y_249_ = v___y_271_;
v___y_250_ = v___y_272_;
v___y_251_ = v___y_274_;
v___y_252_ = v___y_275_;
v___y_253_ = v___y_273_;
v___y_254_ = v___y_276_;
v___y_255_ = v___y_277_;
v___y_256_ = v___x_282_;
v___y_257_ = v___y_278_;
v___y_258_ = v___x_288_;
goto v___jp_248_;
}
else
{
lean_inc(v___y_276_);
v___y_249_ = v___y_271_;
v___y_250_ = v___y_272_;
v___y_251_ = v___y_274_;
v___y_252_ = v___y_275_;
v___y_253_ = v___y_273_;
v___y_254_ = v___y_276_;
v___y_255_ = v___y_277_;
v___y_256_ = v___x_282_;
v___y_257_ = v___y_278_;
v___y_258_ = v___y_276_;
goto v___jp_248_;
}
}
v___jp_289_:
{
lean_object* v___x_299_; lean_object* v___x_300_; lean_object* v___x_301_; lean_object* v___x_302_; uint8_t v___x_303_; 
v___x_299_ = lean_nat_mul(v_residentBlockPenalty_138_, v___y_298_);
lean_dec(v___y_298_);
v___x_300_ = lean_nat_add(v___y_291_, v___x_299_);
lean_dec(v___x_299_);
v___x_301_ = lean_nat_add(v___y_295_, v___x_300_);
lean_dec(v___x_300_);
lean_dec(v___y_295_);
v___x_302_ = lean_unsigned_to_nat(0u);
v___x_303_ = lean_nat_dec_eq(v_memoryBlockBytes_136_, v___x_302_);
if (v___x_303_ == 0)
{
lean_object* v___x_304_; lean_object* v___x_305_; lean_object* v___x_306_; lean_object* v___x_307_; 
v___x_304_ = lean_nat_add(v___y_293_, v_memoryBlockBytes_136_);
v___x_305_ = lean_unsigned_to_nat(1u);
v___x_306_ = lean_nat_sub(v___x_304_, v___x_305_);
lean_dec(v___x_304_);
v___x_307_ = lean_nat_div(v___x_306_, v_memoryBlockBytes_136_);
lean_dec(v___x_306_);
v___y_271_ = v___y_290_;
v___y_272_ = v___y_291_;
v___y_273_ = v___x_301_;
v___y_274_ = v___y_293_;
v___y_275_ = v___y_292_;
v___y_276_ = v___y_294_;
v___y_277_ = v___y_296_;
v___y_278_ = v___y_297_;
v___y_279_ = v___x_307_;
goto v___jp_270_;
}
else
{
lean_inc(v___y_293_);
v___y_271_ = v___y_290_;
v___y_272_ = v___y_291_;
v___y_273_ = v___x_301_;
v___y_274_ = v___y_293_;
v___y_275_ = v___y_292_;
v___y_276_ = v___y_294_;
v___y_277_ = v___y_296_;
v___y_278_ = v___y_297_;
v___y_279_ = v___y_293_;
goto v___jp_270_;
}
}
v___jp_308_:
{
lean_object* v___x_317_; lean_object* v___x_318_; lean_object* v___x_319_; lean_object* v___x_320_; uint8_t v___x_321_; 
v___x_317_ = lean_nat_mul(v_temporaryBlockPenalty_137_, v___y_316_);
lean_dec(v___y_316_);
v___x_318_ = lean_nat_add(v___x_230_, v___x_317_);
lean_dec(v___x_317_);
v___x_319_ = lean_nat_mul(v_expectedCalls_134_, v___x_318_);
lean_dec(v___x_318_);
v___x_320_ = lean_unsigned_to_nat(0u);
v___x_321_ = lean_nat_dec_eq(v_memoryBlockBytes_136_, v___x_320_);
if (v___x_321_ == 0)
{
lean_object* v___x_322_; lean_object* v___x_323_; lean_object* v___x_324_; lean_object* v___x_325_; 
v___x_322_ = lean_nat_add(v_residentBytes_130_, v_memoryBlockBytes_136_);
v___x_323_ = lean_unsigned_to_nat(1u);
v___x_324_ = lean_nat_sub(v___x_322_, v___x_323_);
lean_dec(v___x_322_);
v___x_325_ = lean_nat_div(v___x_324_, v_memoryBlockBytes_136_);
lean_dec(v___x_324_);
v___y_290_ = v___y_309_;
v___y_291_ = v___y_310_;
v___y_292_ = v___y_312_;
v___y_293_ = v___y_311_;
v___y_294_ = v___y_313_;
v___y_295_ = v___x_319_;
v___y_296_ = v___y_314_;
v___y_297_ = v___y_315_;
v___y_298_ = v___x_325_;
goto v___jp_289_;
}
else
{
lean_inc(v_residentBytes_130_);
v___y_290_ = v___y_309_;
v___y_291_ = v___y_310_;
v___y_292_ = v___y_312_;
v___y_293_ = v___y_311_;
v___y_294_ = v___y_313_;
v___y_295_ = v___x_319_;
v___y_296_ = v___y_314_;
v___y_297_ = v___y_315_;
v___y_298_ = v_residentBytes_130_;
goto v___jp_289_;
}
}
v___jp_326_:
{
lean_object* v___x_337_; lean_object* v___x_338_; lean_object* v___x_339_; uint8_t v___x_340_; 
v___x_337_ = lean_nat_mul(v_residentBlockPenalty_138_, v___y_336_);
lean_dec(v___y_336_);
v___x_338_ = lean_nat_add(v___y_327_, v___x_337_);
lean_dec(v___x_337_);
v___x_339_ = lean_nat_add(v___y_331_, v___x_338_);
lean_dec(v___x_338_);
lean_dec(v___y_331_);
v___x_340_ = lean_nat_dec_lt(v___y_335_, v___x_339_);
lean_dec(v___x_339_);
lean_dec(v___y_335_);
if (v___x_340_ == 0)
{
lean_object* v___x_341_; uint8_t v___x_342_; 
v___x_341_ = lean_unsigned_to_nat(0u);
v___x_342_ = lean_nat_dec_eq(v_memoryBlockBytes_136_, v___x_341_);
if (v___x_342_ == 0)
{
lean_object* v___x_343_; lean_object* v___x_344_; lean_object* v___x_345_; lean_object* v___x_346_; 
v___x_343_ = lean_nat_add(v_temporaryBytes_131_, v_memoryBlockBytes_136_);
v___x_344_ = lean_unsigned_to_nat(1u);
v___x_345_ = lean_nat_sub(v___x_343_, v___x_344_);
lean_dec(v___x_343_);
v___x_346_ = lean_nat_div(v___x_345_, v_memoryBlockBytes_136_);
lean_dec(v___x_345_);
v___y_309_ = v___y_327_;
v___y_310_ = v___y_328_;
v___y_311_ = v___y_330_;
v___y_312_ = v___y_329_;
v___y_313_ = v___y_332_;
v___y_314_ = v___y_333_;
v___y_315_ = v___y_334_;
v___y_316_ = v___x_346_;
goto v___jp_308_;
}
else
{
lean_inc(v_temporaryBytes_131_);
v___y_309_ = v___y_327_;
v___y_310_ = v___y_328_;
v___y_311_ = v___y_330_;
v___y_312_ = v___y_329_;
v___y_313_ = v___y_332_;
v___y_314_ = v___y_333_;
v___y_315_ = v___y_334_;
v___y_316_ = v_temporaryBytes_131_;
goto v___jp_308_;
}
}
else
{
lean_dec(v___y_334_);
lean_dec(v___y_333_);
lean_dec(v___y_332_);
lean_dec(v___y_330_);
lean_dec(v___y_329_);
lean_dec(v___y_328_);
lean_dec(v___y_327_);
lean_dec(v___x_230_);
lean_dec_ref(v_x_114_);
v_x_114_ = v_head_116_;
v_x_115_ = v_tail_117_;
goto _start;
}
}
v___jp_348_:
{
lean_object* v___x_359_; lean_object* v___x_360_; lean_object* v___x_361_; lean_object* v___x_362_; lean_object* v___x_363_; lean_object* v___x_364_; uint8_t v___x_365_; 
v___x_359_ = lean_nat_mul(v_temporaryBlockPenalty_137_, v___y_358_);
lean_dec(v___y_358_);
v___x_360_ = lean_nat_add(v___y_351_, v___x_359_);
lean_dec(v___x_359_);
v___x_361_ = lean_nat_mul(v_expectedCalls_134_, v___x_360_);
lean_dec(v___x_360_);
v___x_362_ = lean_nat_mul(v_allocationPenalty_135_, v___y_354_);
lean_dec(v___y_354_);
v___x_363_ = lean_nat_add(v___y_353_, v___x_362_);
lean_dec(v___x_362_);
lean_dec(v___y_353_);
v___x_364_ = lean_unsigned_to_nat(0u);
v___x_365_ = lean_nat_dec_eq(v_memoryBlockBytes_136_, v___x_364_);
if (v___x_365_ == 0)
{
lean_object* v___x_366_; lean_object* v___x_367_; lean_object* v___x_368_; lean_object* v___x_369_; 
v___x_366_ = lean_nat_add(v___y_352_, v_memoryBlockBytes_136_);
v___x_367_ = lean_unsigned_to_nat(1u);
v___x_368_ = lean_nat_sub(v___x_366_, v___x_367_);
lean_dec(v___x_366_);
v___x_369_ = lean_nat_div(v___x_368_, v_memoryBlockBytes_136_);
lean_dec(v___x_368_);
v___y_327_ = v___x_363_;
v___y_328_ = v___y_349_;
v___y_329_ = v___y_351_;
v___y_330_ = v___y_350_;
v___y_331_ = v___x_361_;
v___y_332_ = v___y_352_;
v___y_333_ = v___y_355_;
v___y_334_ = v___y_356_;
v___y_335_ = v___y_357_;
v___y_336_ = v___x_369_;
goto v___jp_326_;
}
else
{
lean_inc(v___y_352_);
v___y_327_ = v___x_363_;
v___y_328_ = v___y_349_;
v___y_329_ = v___y_351_;
v___y_330_ = v___y_350_;
v___y_331_ = v___x_361_;
v___y_332_ = v___y_352_;
v___y_333_ = v___y_355_;
v___y_334_ = v___y_356_;
v___y_335_ = v___y_357_;
v___y_336_ = v___y_352_;
goto v___jp_326_;
}
}
v___jp_370_:
{
lean_object* v_steadyCost_374_; lean_object* v_marshallingCost_375_; lean_object* v_setupCost_376_; lean_object* v_setupAllocations_377_; lean_object* v_residentBytes_378_; lean_object* v_temporaryBytes_379_; lean_object* v_allocations_380_; lean_object* v___x_381_; lean_object* v___x_382_; lean_object* v___x_383_; lean_object* v___x_384_; lean_object* v___x_385_; lean_object* v___x_386_; lean_object* v___x_387_; uint8_t v___x_388_; 
v_steadyCost_374_ = lean_ctor_get(v_estimate_145_, 3);
v_marshallingCost_375_ = lean_ctor_get(v_estimate_145_, 4);
v_setupCost_376_ = lean_ctor_get(v_estimate_145_, 5);
v_setupAllocations_377_ = lean_ctor_get(v_estimate_145_, 6);
v_residentBytes_378_ = lean_ctor_get(v_estimate_145_, 7);
v_temporaryBytes_379_ = lean_ctor_get(v_estimate_145_, 8);
v_allocations_380_ = lean_ctor_get(v_estimate_145_, 9);
v___x_381_ = lean_nat_mul(v_residentBlockPenalty_138_, v___y_373_);
lean_dec(v___y_373_);
v___x_382_ = lean_nat_add(v___y_371_, v___x_381_);
lean_dec(v___x_381_);
v___x_383_ = lean_nat_add(v___y_372_, v___x_382_);
lean_dec(v___x_382_);
lean_dec(v___y_372_);
v___x_384_ = lean_nat_add(v_steadyCost_374_, v_marshallingCost_375_);
v___x_385_ = lean_nat_mul(v_allocationPenalty_135_, v_allocations_380_);
v___x_386_ = lean_nat_add(v___x_384_, v___x_385_);
lean_dec(v___x_385_);
lean_dec(v___x_384_);
v___x_387_ = lean_unsigned_to_nat(0u);
v___x_388_ = lean_nat_dec_eq(v_memoryBlockBytes_136_, v___x_387_);
if (v___x_388_ == 0)
{
lean_object* v___x_389_; lean_object* v___x_390_; lean_object* v___x_391_; lean_object* v___x_392_; 
v___x_389_ = lean_nat_add(v_temporaryBytes_379_, v_memoryBlockBytes_136_);
v___x_390_ = lean_unsigned_to_nat(1u);
v___x_391_ = lean_nat_sub(v___x_389_, v___x_390_);
lean_dec(v___x_389_);
v___x_392_ = lean_nat_div(v___x_391_, v_memoryBlockBytes_136_);
lean_dec(v___x_391_);
lean_inc(v_allocations_380_);
lean_inc(v_marshallingCost_375_);
lean_inc(v_setupAllocations_377_);
lean_inc(v_setupCost_376_);
lean_inc(v_residentBytes_378_);
lean_inc(v_temporaryBytes_379_);
v___y_349_ = v___y_371_;
v___y_350_ = v_temporaryBytes_379_;
v___y_351_ = v___x_386_;
v___y_352_ = v_residentBytes_378_;
v___y_353_ = v_setupCost_376_;
v___y_354_ = v_setupAllocations_377_;
v___y_355_ = v_marshallingCost_375_;
v___y_356_ = v_allocations_380_;
v___y_357_ = v___x_383_;
v___y_358_ = v___x_392_;
goto v___jp_348_;
}
else
{
lean_inc(v_allocations_380_);
lean_inc(v_marshallingCost_375_);
lean_inc(v_setupAllocations_377_);
lean_inc(v_setupCost_376_);
lean_inc(v_residentBytes_378_);
lean_inc_n(v_temporaryBytes_379_, 2);
v___y_349_ = v___y_371_;
v___y_350_ = v_temporaryBytes_379_;
v___y_351_ = v___x_386_;
v___y_352_ = v_residentBytes_378_;
v___y_353_ = v_setupCost_376_;
v___y_354_ = v_setupAllocations_377_;
v___y_355_ = v_marshallingCost_375_;
v___y_356_ = v_allocations_380_;
v___y_357_ = v___x_383_;
v___y_358_ = v_temporaryBytes_379_;
goto v___jp_348_;
}
}
v___jp_393_:
{
lean_object* v___x_395_; lean_object* v___x_396_; lean_object* v___x_397_; lean_object* v___x_398_; lean_object* v___x_399_; lean_object* v___x_400_; uint8_t v___x_401_; 
v___x_395_ = lean_nat_mul(v_temporaryBlockPenalty_137_, v___y_394_);
lean_dec(v___y_394_);
v___x_396_ = lean_nat_add(v___x_230_, v___x_395_);
lean_dec(v___x_395_);
v___x_397_ = lean_nat_mul(v_expectedCalls_134_, v___x_396_);
lean_dec(v___x_396_);
v___x_398_ = lean_nat_mul(v_allocationPenalty_135_, v_setupAllocations_129_);
v___x_399_ = lean_nat_add(v_setupCost_128_, v___x_398_);
lean_dec(v___x_398_);
v___x_400_ = lean_unsigned_to_nat(0u);
v___x_401_ = lean_nat_dec_eq(v_memoryBlockBytes_136_, v___x_400_);
if (v___x_401_ == 0)
{
lean_object* v___x_402_; lean_object* v___x_403_; lean_object* v___x_404_; lean_object* v___x_405_; 
v___x_402_ = lean_nat_add(v_residentBytes_130_, v_memoryBlockBytes_136_);
v___x_403_ = lean_unsigned_to_nat(1u);
v___x_404_ = lean_nat_sub(v___x_402_, v___x_403_);
lean_dec(v___x_402_);
v___x_405_ = lean_nat_div(v___x_404_, v_memoryBlockBytes_136_);
lean_dec(v___x_404_);
v___y_371_ = v___x_399_;
v___y_372_ = v___x_397_;
v___y_373_ = v___x_405_;
goto v___jp_370_;
}
else
{
lean_inc(v_residentBytes_130_);
v___y_371_ = v___x_399_;
v___y_372_ = v___x_397_;
v___y_373_ = v_residentBytes_130_;
goto v___jp_370_;
}
}
}
}
v___jp_118_:
{
uint8_t v___x_121_; 
v___x_121_ = lean_nat_dec_lt(v___y_119_, v___y_120_);
lean_dec(v___y_120_);
lean_dec(v___y_119_);
if (v___x_121_ == 0)
{
lean_dec(v_head_116_);
v_x_115_ = v_tail_117_;
goto _start;
}
else
{
lean_dec_ref(v_x_114_);
v_x_114_ = v_head_116_;
v_x_115_ = v_tail_117_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_block1024___lam__0(lean_object* v___x_412_, uint8_t v___x_413_, lean_object* v_x_414_){
_start:
{
lean_object* v___x_415_; lean_object* v_alternatives_416_; lean_object* v_baseline_417_; lean_object* v___x_418_; 
v___x_415_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Plan_automaticSqrtCandidates(v___x_412_, v___x_413_);
v_alternatives_416_ = lean_ctor_get(v___x_415_, 0);
lean_inc(v_alternatives_416_);
v_baseline_417_ = lean_ctor_get(v___x_415_, 1);
lean_inc(v_baseline_417_);
lean_dec_ref(v___x_415_);
v___x_418_ = l_List_foldl___at___00BalancedSqrt_block1024_spec__0(v_baseline_417_, v_alternatives_416_);
return v___x_418_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_block1024___lam__0___boxed(lean_object* v___x_419_, lean_object* v___x_420_, lean_object* v_x_421_){
_start:
{
uint8_t v___x_25649__boxed_422_; lean_object* v_res_423_; 
v___x_25649__boxed_422_ = lean_unbox(v___x_420_);
v_res_423_ = l_BalancedSqrt_block1024___lam__0(v___x_419_, v___x_25649__boxed_422_, v_x_421_);
return v_res_423_;
}
}
LEAN_EXPORT uint64_t l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(uint64_t v_rest_424_){
_start:
{
uint64_t v___x_425_; uint64_t v___x_426_; uint64_t v___x_427_; uint64_t v___x_428_; uint64_t v___x_429_; uint64_t v___x_430_; 
v___x_425_ = 4294945360ULL;
v___x_426_ = 1ULL;
v___x_427_ = lean_uint64_shift_left(v_rest_424_, v___x_426_);
v___x_428_ = lean_uint64_shift_right(v___x_425_, v___x_427_);
v___x_429_ = 3ULL;
v___x_430_ = lean_uint64_land(v___x_428_, v___x_429_);
return v___x_430_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0___boxed(lean_object* v_rest_431_){
_start:
{
uint64_t v_rest_boxed_432_; uint64_t v_res_433_; lean_object* v_r_434_; 
v_rest_boxed_432_ = lean_unbox_uint64(v_rest_431_);
lean_dec_ref(v_rest_431_);
v_res_433_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v_rest_boxed_432_);
v_r_434_ = lean_box_uint64(v_res_433_);
return v_r_434_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3(void){
_start:
{
lean_object* v___x_442_; 
v___x_442_ = lean_cstr_to_nat("18446744073709551616");
return v___x_442_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4(void){
_start:
{
lean_object* v___x_443_; lean_object* v___x_444_; 
v___x_443_ = lean_unsigned_to_nat(262143u);
v___x_444_ = lean_nat_to_int(v___x_443_);
return v___x_444_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__5(void){
_start:
{
lean_object* v___x_445_; lean_object* v___x_446_; 
v___x_445_ = lean_unsigned_to_nat(1004u);
v___x_446_ = lean_nat_to_int(v___x_445_);
return v___x_446_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__6(void){
_start:
{
lean_object* v___x_447_; 
v___x_447_ = lean_cstr_to_nat("171441377149802771351748007849600289689824769872885377191000062139256168179989779598911740610511337300415147666808503492029943245710770246975753241195177196862953084397187695766737193680997938270047266914448743599737311060278380280946648703137233006633139143642984674682566877306441990189395290689110015");
return v___x_447_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__7(void){
_start:
{
lean_object* v___x_448_; 
v___x_448_ = lean_cstr_to_nat("171441377149802771351748007849600289689824769872885377191000062139256168179989779598911740610511337300415147666808503492029943245710770246975753241195177196862953084397187695766737193680997938270047266914448743599737311060278380280946648703137233006633139143642984674682566877306441990189395290689110016");
return v___x_448_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__8(void){
_start:
{
lean_object* v___x_449_; lean_object* v___x_450_; lean_object* v___x_451_; 
v___x_449_ = lean_unsigned_to_nat(1004u);
v___x_450_ = lean_unsigned_to_nat(2u);
v___x_451_ = lean_nat_pow(v___x_450_, v___x_449_);
return v___x_451_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__9(void){
_start:
{
lean_object* v___x_452_; lean_object* v___x_453_; lean_object* v___x_454_; 
v___x_452_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__8, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__8_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__8);
v___x_453_ = lean_unsigned_to_nat(524287u);
v___x_454_ = lean_nat_mul(v___x_453_, v___x_452_);
return v___x_454_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__10(void){
_start:
{
lean_object* v___x_455_; lean_object* v___x_456_; lean_object* v___x_457_; 
v___x_455_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__9, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__9_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__9);
v___x_456_ = lean_unsigned_to_nat(1024u);
v___x_457_ = l_BitVec_ofNat(v___x_456_, v___x_455_);
return v___x_457_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__11(void){
_start:
{
lean_object* v___x_458_; lean_object* v___x_459_; lean_object* v___x_460_; 
v___x_458_ = lean_unsigned_to_nat(1003u);
v___x_459_ = lean_unsigned_to_nat(2u);
v___x_460_ = lean_nat_pow(v___x_459_, v___x_458_);
return v___x_460_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__12(void){
_start:
{
lean_object* v___x_461_; lean_object* v___x_462_; lean_object* v___x_463_; 
v___x_461_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__11, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__11_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__11);
v___x_462_ = lean_unsigned_to_nat(1024u);
v___x_463_ = l_BitVec_ofNat(v___x_462_, v___x_461_);
return v___x_463_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__13(void){
_start:
{
lean_object* v___x_464_; lean_object* v___x_465_; lean_object* v___x_466_; 
v___x_464_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__12, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__12_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__12);
v___x_465_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__10, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__10_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__10);
v___x_466_ = lean_nat_lor(v___x_465_, v___x_464_);
return v___x_466_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__14(void){
_start:
{
lean_object* v___x_467_; lean_object* v___x_468_; lean_object* v___x_469_; 
v___x_467_ = lean_unsigned_to_nat(524287u);
v___x_468_ = lean_unsigned_to_nat(1024u);
v___x_469_ = l_BitVec_ofNat(v___x_468_, v___x_467_);
return v___x_469_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__15(void){
_start:
{
lean_object* v___x_470_; lean_object* v___x_471_; lean_object* v___x_472_; 
v___x_470_ = lean_unsigned_to_nat(1u);
v___x_471_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__8, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__8_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__8);
v___x_472_ = lean_nat_sub(v___x_471_, v___x_470_);
return v___x_472_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__16(void){
_start:
{
lean_object* v___x_473_; lean_object* v___x_474_; lean_object* v___x_475_; 
v___x_473_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__15, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__15_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__15);
v___x_474_ = lean_unsigned_to_nat(1024u);
v___x_475_ = l_BitVec_ofNat(v___x_474_, v___x_473_);
return v___x_475_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__17(void){
_start:
{
lean_object* v___x_476_; lean_object* v___x_477_; lean_object* v___x_478_; 
v___x_476_ = lean_unsigned_to_nat(1023u);
v___x_477_ = lean_unsigned_to_nat(2u);
v___x_478_ = lean_nat_pow(v___x_477_, v___x_476_);
return v___x_478_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__18(void){
_start:
{
lean_object* v___x_479_; lean_object* v___x_480_; lean_object* v___x_481_; 
v___x_479_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__17, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__17_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__17);
v___x_480_ = lean_unsigned_to_nat(1024u);
v___x_481_ = l_BitVec_ofNat(v___x_480_, v___x_479_);
return v___x_481_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__19(void){
_start:
{
lean_object* v___x_482_; lean_object* v___x_483_; lean_object* v___x_484_; 
v___x_482_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__10, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__10_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__10);
v___x_483_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__18, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__18_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__18);
v___x_484_ = lean_nat_lor(v___x_483_, v___x_482_);
return v___x_484_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2(lean_object* v_x_485_){
_start:
{
lean_object* v___x_486_; lean_object* v___y_488_; uint8_t v___y_492_; lean_object* v___y_493_; lean_object* v___y_494_; lean_object* v___y_495_; lean_object* v___y_496_; lean_object* v___y_497_; uint8_t v___y_510_; lean_object* v___y_511_; lean_object* v___y_512_; lean_object* v___y_513_; lean_object* v___y_514_; lean_object* v___y_515_; lean_object* v___y_516_; lean_object* v___y_528_; uint64_t v___y_529_; uint8_t v___y_530_; lean_object* v___y_531_; lean_object* v___y_532_; lean_object* v___y_533_; lean_object* v___y_534_; uint64_t v___y_535_; lean_object* v___y_536_; uint64_t v___y_537_; uint64_t v___y_546_; lean_object* v___y_547_; uint64_t v___y_548_; uint8_t v___y_549_; lean_object* v___y_550_; lean_object* v___y_551_; lean_object* v___y_552_; lean_object* v___y_553_; uint64_t v___y_554_; lean_object* v___y_555_; uint64_t v___y_556_; lean_object* v___y_560_; uint64_t v___y_561_; uint64_t v___y_562_; uint8_t v___y_563_; lean_object* v___y_564_; lean_object* v___y_565_; lean_object* v___y_566_; lean_object* v___y_567_; uint64_t v___y_568_; uint8_t v___y_569_; lean_object* v___y_570_; uint64_t v___y_571_; lean_object* v___y_573_; uint64_t v___y_574_; uint64_t v___y_575_; uint64_t v___y_576_; lean_object* v___y_577_; lean_object* v___y_578_; uint64_t v___y_579_; lean_object* v___y_580_; uint64_t v___y_581_; uint64_t v___y_582_; uint8_t v___y_583_; lean_object* v___y_584_; lean_object* v___y_585_; uint64_t v___y_586_; lean_object* v___y_593_; uint64_t v___y_594_; uint8_t v___y_595_; uint64_t v___y_596_; lean_object* v___y_597_; lean_object* v___y_598_; uint64_t v___y_599_; lean_object* v___y_600_; uint64_t v___y_601_; uint64_t v___y_602_; uint64_t v___y_603_; uint8_t v___y_604_; lean_object* v___y_605_; lean_object* v___y_606_; uint64_t v___y_607_; uint64_t v___y_608_; lean_object* v___y_610_; uint64_t v___y_611_; uint64_t v___y_612_; uint64_t v___y_613_; lean_object* v___y_614_; lean_object* v___y_615_; uint64_t v___y_616_; lean_object* v___y_617_; uint64_t v___y_618_; uint64_t v___y_619_; uint64_t v___y_620_; uint8_t v___y_621_; lean_object* v___y_622_; lean_object* v___y_623_; uint64_t v___y_624_; lean_object* v___y_628_; uint64_t v___y_629_; uint64_t v___y_630_; lean_object* v___y_631_; lean_object* v___y_632_; uint64_t v___y_633_; lean_object* v___y_634_; uint64_t v___y_635_; uint64_t v___y_636_; uint64_t v___y_637_; uint64_t v___y_638_; uint8_t v___y_639_; uint8_t v___y_640_; lean_object* v___y_641_; lean_object* v___y_642_; uint64_t v___y_643_; uint64_t v___y_644_; lean_object* v___y_646_; uint64_t v___y_647_; uint64_t v___y_648_; lean_object* v___y_649_; lean_object* v___y_650_; uint64_t v___y_651_; lean_object* v___y_652_; uint64_t v___y_653_; uint64_t v___y_654_; uint64_t v___y_655_; uint64_t v___y_656_; uint8_t v___y_657_; lean_object* v___y_658_; lean_object* v___y_659_; uint64_t v___y_660_; lean_object* v___y_664_; uint64_t v___y_665_; uint64_t v___y_666_; lean_object* v___y_667_; lean_object* v___y_668_; uint64_t v___y_669_; lean_object* v___y_670_; uint64_t v___y_671_; uint64_t v___y_672_; uint8_t v___y_673_; uint64_t v___y_674_; uint64_t v___y_675_; uint64_t v___y_676_; uint8_t v___y_677_; lean_object* v___y_678_; lean_object* v___y_679_; uint64_t v___y_680_; uint64_t v___y_682_; lean_object* v___y_683_; uint64_t v___y_684_; uint64_t v___y_685_; lean_object* v___y_686_; lean_object* v___y_687_; uint64_t v___y_688_; lean_object* v___y_689_; uint64_t v___y_690_; uint64_t v___y_691_; uint64_t v___y_692_; uint8_t v___y_693_; lean_object* v___y_694_; lean_object* v___y_695_; uint64_t v___y_696_; uint64_t v___y_700_; lean_object* v___y_701_; uint64_t v___y_702_; lean_object* v___y_703_; lean_object* v___y_704_; uint64_t v___y_705_; uint64_t v___y_706_; lean_object* v___y_707_; uint64_t v___y_708_; uint64_t v___y_709_; uint64_t v___y_710_; uint8_t v___y_711_; uint8_t v___y_712_; lean_object* v___y_713_; lean_object* v___y_714_; uint64_t v___y_715_; lean_object* v___y_717_; uint8_t v___y_718_; lean_object* v___y_719_; lean_object* v___y_720_; lean_object* v___y_721_; lean_object* v___y_722_; lean_object* v___y_723_; uint8_t v___y_724_; lean_object* v___y_725_; lean_object* v___y_726_; uint8_t v___y_727_; uint8_t v___y_728_; lean_object* v___y_735_; lean_object* v___y_736_; uint8_t v___y_737_; lean_object* v___y_738_; lean_object* v___y_739_; lean_object* v___y_740_; lean_object* v___y_741_; lean_object* v___y_742_; uint8_t v___y_743_; uint8_t v___y_744_; lean_object* v___y_745_; lean_object* v___y_746_; lean_object* v___y_751_; uint64_t v___y_752_; lean_object* v___y_753_; lean_object* v___y_754_; lean_object* v___y_755_; uint8_t v___y_756_; lean_object* v___y_757_; lean_object* v___y_758_; uint8_t v___y_759_; lean_object* v___y_760_; uint64_t v___y_761_; lean_object* v___y_762_; uint8_t v___y_763_; uint64_t v___y_764_; lean_object* v___y_773_; uint64_t v___y_774_; uint64_t v___y_775_; lean_object* v___y_776_; lean_object* v___y_777_; lean_object* v___y_778_; uint64_t v___y_779_; uint8_t v___y_780_; lean_object* v___y_781_; lean_object* v___y_782_; uint64_t v___y_783_; uint8_t v___y_784_; lean_object* v___y_785_; lean_object* v___y_786_; uint64_t v___y_787_; uint64_t v___y_788_; uint8_t v___y_789_; uint64_t v___y_790_; lean_object* v___y_797_; uint64_t v___y_798_; uint64_t v___y_799_; lean_object* v___y_800_; lean_object* v___y_801_; lean_object* v___y_802_; uint64_t v___y_803_; uint64_t v___y_804_; uint8_t v___y_805_; lean_object* v___y_806_; lean_object* v___y_807_; uint64_t v___y_808_; uint8_t v___y_809_; uint8_t v___y_810_; lean_object* v___y_811_; uint64_t v___y_812_; uint64_t v___y_813_; lean_object* v___y_814_; uint8_t v___y_815_; uint64_t v___y_816_; lean_object* v___y_818_; uint64_t v___y_819_; uint64_t v___y_820_; uint64_t v___y_821_; lean_object* v___y_822_; lean_object* v___y_823_; lean_object* v___y_824_; uint8_t v___y_825_; lean_object* v___y_826_; lean_object* v___y_827_; uint64_t v___y_828_; uint8_t v___y_829_; lean_object* v___y_830_; lean_object* v___y_831_; uint64_t v___y_832_; uint64_t v___y_833_; uint64_t v___y_834_; uint8_t v___y_835_; uint64_t v___y_836_; lean_object* v___y_840_; uint64_t v___y_841_; uint64_t v___y_842_; uint64_t v___y_843_; lean_object* v___y_844_; lean_object* v___y_845_; lean_object* v___y_846_; uint8_t v___y_847_; lean_object* v___y_848_; lean_object* v___y_849_; uint64_t v___y_850_; uint8_t v___y_851_; uint64_t v___y_852_; uint8_t v___y_853_; lean_object* v___y_854_; uint64_t v___y_855_; uint64_t v___y_856_; lean_object* v___y_857_; uint64_t v___y_858_; uint8_t v___y_859_; uint64_t v___y_860_; lean_object* v___y_862_; uint64_t v___y_863_; uint64_t v___y_864_; lean_object* v___y_865_; lean_object* v___y_866_; lean_object* v___y_867_; uint8_t v___y_868_; lean_object* v___y_869_; lean_object* v___y_870_; uint64_t v___y_871_; uint64_t v___y_872_; uint8_t v___y_873_; lean_object* v___y_874_; lean_object* v___y_875_; uint64_t v___y_876_; uint64_t v___y_877_; uint64_t v___y_878_; uint8_t v___y_879_; uint64_t v___y_880_; uint8_t v___y_884_; lean_object* v___y_885_; uint64_t v___y_886_; uint64_t v___y_887_; lean_object* v___y_888_; lean_object* v___y_889_; lean_object* v___y_890_; uint64_t v___y_891_; uint8_t v___y_892_; lean_object* v___y_893_; uint64_t v___y_894_; lean_object* v___y_895_; uint64_t v___y_896_; uint64_t v___y_897_; uint8_t v___y_898_; lean_object* v___y_899_; uint64_t v___y_900_; lean_object* v___y_901_; uint64_t v___y_902_; uint8_t v___y_903_; uint64_t v___y_904_; lean_object* v___y_906_; uint64_t v___y_907_; uint64_t v___y_908_; lean_object* v___y_909_; lean_object* v___y_910_; lean_object* v___y_911_; uint8_t v___y_912_; lean_object* v___y_913_; lean_object* v___y_914_; uint64_t v___y_915_; uint64_t v___y_916_; uint8_t v___y_917_; lean_object* v___y_918_; uint64_t v___y_919_; lean_object* v___y_920_; uint64_t v___y_921_; uint64_t v___y_922_; uint8_t v___y_923_; uint64_t v___y_924_; uint64_t v___y_928_; uint8_t v___y_929_; lean_object* v___y_930_; uint64_t v___y_931_; uint64_t v___y_932_; lean_object* v___y_933_; lean_object* v___y_934_; lean_object* v___y_935_; uint8_t v___y_936_; lean_object* v___y_937_; lean_object* v___y_938_; uint64_t v___y_939_; uint8_t v___y_940_; lean_object* v___y_941_; uint64_t v___y_942_; uint64_t v___y_943_; lean_object* v___y_944_; uint64_t v___y_945_; uint8_t v___y_946_; uint64_t v___y_947_; lean_object* v___y_949_; uint64_t v___y_950_; lean_object* v___y_951_; lean_object* v___y_952_; lean_object* v___y_953_; uint8_t v___y_954_; lean_object* v___y_955_; lean_object* v___y_956_; uint64_t v___y_957_; uint8_t v___y_958_; lean_object* v___y_959_; uint64_t v___y_960_; lean_object* v___y_961_; uint8_t v___y_962_; uint64_t v___y_963_; lean_object* v___y_967_; uint64_t v___y_968_; uint8_t v___y_969_; lean_object* v___y_970_; lean_object* v___y_971_; lean_object* v___y_972_; uint8_t v___y_973_; lean_object* v___y_974_; lean_object* v___y_975_; uint64_t v___y_976_; uint8_t v___y_977_; lean_object* v___y_978_; uint64_t v___y_979_; lean_object* v___y_980_; uint8_t v___y_981_; uint64_t v___y_982_; lean_object* v___y_984_; lean_object* v___y_985_; lean_object* v___y_986_; lean_object* v___y_987_; uint8_t v___y_988_; lean_object* v___y_989_; lean_object* v___y_990_; uint8_t v___y_991_; uint8_t v___y_992_; lean_object* v___y_993_; lean_object* v___y_994_; lean_object* v___y_1065_; lean_object* v___y_1066_; lean_object* v___y_1067_; lean_object* v___y_1068_; uint8_t v___y_1069_; lean_object* v___y_1070_; lean_object* v___y_1085_; lean_object* v___y_1086_; lean_object* v___y_1087_; lean_object* v___y_1088_; uint8_t v___y_1089_; lean_object* v___y_1090_; lean_object* v___y_1130_; lean_object* v___x_1147_; lean_object* v___x_1148_; lean_object* v___x_1149_; lean_object* v___x_1150_; uint8_t v___x_1151_; 
v___x_486_ = lean_unsigned_to_nat(1004u);
v___x_1147_ = lean_nat_shiftr(v_x_485_, v___x_486_);
v___x_1148_ = lean_unsigned_to_nat(524287u);
v___x_1149_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__14, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__14_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__14);
v___x_1150_ = lean_nat_land(v___x_1147_, v___x_1149_);
lean_dec(v___x_1147_);
v___x_1151_ = lean_nat_dec_eq(v___x_1150_, v___x_1148_);
lean_dec(v___x_1150_);
if (v___x_1151_ == 0)
{
lean_object* v___x_1152_; 
v___x_1152_ = lean_box(0);
v___y_1130_ = v___x_1152_;
goto v___jp_1129_;
}
else
{
lean_object* v___x_1153_; lean_object* v___x_1154_; lean_object* v___x_1155_; uint8_t v___x_1156_; 
v___x_1153_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__16, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__16_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__16);
v___x_1154_ = lean_nat_land(v_x_485_, v___x_1153_);
v___x_1155_ = lean_unsigned_to_nat(0u);
v___x_1156_ = lean_nat_dec_eq(v___x_1154_, v___x_1155_);
lean_dec(v___x_1154_);
if (v___x_1156_ == 0)
{
if (v___x_1151_ == 0)
{
lean_object* v___x_1157_; 
lean_inc(v_x_485_);
v___x_1157_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1157_, 0, v_x_485_);
v___y_1130_ = v___x_1157_;
goto v___jp_1129_;
}
else
{
if (v___x_1156_ == 0)
{
lean_object* v___x_1158_; lean_object* v___x_1159_; lean_object* v___x_1160_; 
v___x_1158_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__12, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__12_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__12);
v___x_1159_ = lean_nat_lor(v_x_485_, v___x_1158_);
v___x_1160_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1160_, 0, v___x_1159_);
v___y_1130_ = v___x_1160_;
goto v___jp_1129_;
}
else
{
lean_object* v___x_1161_; 
lean_inc(v_x_485_);
v___x_1161_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1161_, 0, v_x_485_);
v___y_1130_ = v___x_1161_;
goto v___jp_1129_;
}
}
}
else
{
lean_object* v___x_1162_; 
v___x_1162_ = lean_box(0);
v___y_1130_ = v___x_1162_;
goto v___jp_1129_;
}
}
v___jp_487_:
{
lean_object* v___x_489_; lean_object* v___x_490_; 
v___x_489_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__0));
v___x_490_ = l_Float_Model_UnpackedFloat_pack(v___x_489_, v___y_488_);
lean_dec(v___y_488_);
return v___x_490_;
}
v___jp_491_:
{
lean_object* v_rounded_498_; lean_object* v___x_499_; lean_object* v___x_500_; lean_object* v___x_501_; lean_object* v___x_502_; lean_object* v_fst_503_; lean_object* v_snd_504_; lean_object* v_mantissa_505_; uint8_t v___x_506_; 
v_rounded_498_ = l_Float_Model_UnpackedFloat_ExtendedMantissa_roundedMantissa(v___y_497_);
lean_dec_ref(v___y_497_);
v___x_499_ = lean_nat_to_int(v___y_496_);
v___x_500_ = lean_int_add(v___y_495_, v___x_499_);
lean_dec(v___x_499_);
lean_dec(v___y_495_);
v___x_501_ = lean_box(0);
v___x_502_ = l_Float_Model_UnpackedFloat_shiftToTargetExponent(v___y_494_, v_rounded_498_, v___x_500_, v___x_501_);
lean_dec(v___x_500_);
v_fst_503_ = lean_ctor_get(v___x_502_, 0);
lean_inc(v_fst_503_);
v_snd_504_ = lean_ctor_get(v___x_502_, 1);
lean_inc(v_snd_504_);
lean_dec_ref(v___x_502_);
v_mantissa_505_ = lean_ctor_get(v_fst_503_, 0);
lean_inc(v_mantissa_505_);
lean_dec(v_fst_503_);
v___x_506_ = lean_nat_dec_eq(v_mantissa_505_, v___y_493_);
if (v___x_506_ == 0)
{
lean_object* v___x_507_; 
v___x_507_ = lean_alloc_ctor(3, 2, 1);
lean_ctor_set(v___x_507_, 0, v_mantissa_505_);
lean_ctor_set(v___x_507_, 1, v_snd_504_);
lean_ctor_set_uint8(v___x_507_, sizeof(void*)*2, v___y_492_);
v___y_488_ = v___x_507_;
goto v___jp_487_;
}
else
{
lean_object* v___x_508_; 
lean_dec(v_mantissa_505_);
lean_dec(v_snd_504_);
v___x_508_ = lean_alloc_ctor(2, 0, 1);
lean_ctor_set_uint8(v___x_508_, 0, v___y_492_);
v___y_488_ = v___x_508_;
goto v___jp_487_;
}
}
v___jp_509_:
{
lean_object* v___x_517_; lean_object* v_remainder_518_; uint8_t v___x_519_; 
v___x_517_ = lean_nat_mul(v___y_516_, v___y_516_);
v_remainder_518_ = lean_nat_sub(v___y_513_, v___x_517_);
lean_dec(v___x_517_);
lean_dec(v___y_513_);
v___x_519_ = lean_nat_dec_eq(v_remainder_518_, v___y_512_);
if (v___x_519_ == 0)
{
uint8_t v___x_520_; 
v___x_520_ = lean_nat_dec_le(v_remainder_518_, v___y_516_);
lean_dec(v_remainder_518_);
if (v___x_520_ == 0)
{
lean_object* v___x_521_; lean_object* v___x_522_; 
v___x_521_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__1));
v___x_522_ = l_Float_Model_UnpackedFloat_ExtendedMantissa_ofMantissaAndAccuracy(v___y_516_, v___x_521_);
v___y_492_ = v___y_510_;
v___y_493_ = v___y_512_;
v___y_494_ = v___y_511_;
v___y_495_ = v___y_514_;
v___y_496_ = v___y_515_;
v___y_497_ = v___x_522_;
goto v___jp_491_;
}
else
{
lean_object* v___x_523_; lean_object* v___x_524_; 
v___x_523_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__2));
v___x_524_ = l_Float_Model_UnpackedFloat_ExtendedMantissa_ofMantissaAndAccuracy(v___y_516_, v___x_523_);
v___y_492_ = v___y_510_;
v___y_493_ = v___y_512_;
v___y_494_ = v___y_511_;
v___y_495_ = v___y_514_;
v___y_496_ = v___y_515_;
v___y_497_ = v___x_524_;
goto v___jp_491_;
}
}
else
{
lean_object* v___x_525_; lean_object* v___x_526_; 
lean_dec(v_remainder_518_);
v___x_525_ = lean_box(0);
v___x_526_ = l_Float_Model_UnpackedFloat_ExtendedMantissa_ofMantissaAndAccuracy(v___y_516_, v___x_525_);
v___y_492_ = v___y_510_;
v___y_493_ = v___y_512_;
v___y_494_ = v___y_511_;
v___y_495_ = v___y_514_;
v___y_496_ = v___y_515_;
v___y_497_ = v___x_526_;
goto v___jp_491_;
}
}
v___jp_527_:
{
lean_object* v___x_538_; lean_object* v___x_539_; lean_object* v_shift_540_; uint64_t v___x_541_; uint64_t v___x_542_; uint64_t v___x_543_; lean_object* v___x_544_; 
v___x_538_ = lean_uint64_to_nat(v___y_537_);
v___x_539_ = lean_nat_shiftr(v___x_538_, v___y_528_);
lean_dec(v___x_538_);
v_shift_540_ = lean_nat_add(v___x_539_, v___y_528_);
lean_dec(v___y_528_);
lean_dec(v___x_539_);
v___x_541_ = lean_uint64_of_nat(v_shift_540_);
lean_dec(v_shift_540_);
v___x_542_ = lean_uint64_shift_left(v___y_529_, v___x_541_);
v___x_543_ = lp_floatlib_FloatLib_Numerics_FixedWord_IntegerSquareRoot_sqrtIter(v___y_535_, v___x_542_);
v___x_544_ = lean_uint64_to_nat(v___x_543_);
v___y_510_ = v___y_530_;
v___y_511_ = v___y_533_;
v___y_512_ = v___y_532_;
v___y_513_ = v___y_531_;
v___y_514_ = v___y_534_;
v___y_515_ = v___y_536_;
v___y_516_ = v___x_544_;
goto v___jp_509_;
}
v___jp_545_:
{
uint64_t v___x_557_; uint64_t v___x_558_; 
v___x_557_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___y_556_);
v___x_558_ = lean_uint64_add(v___y_546_, v___x_557_);
v___y_528_ = v___y_547_;
v___y_529_ = v___y_548_;
v___y_530_ = v___y_549_;
v___y_531_ = v___y_552_;
v___y_532_ = v___y_551_;
v___y_533_ = v___y_550_;
v___y_534_ = v___y_553_;
v___y_535_ = v___y_554_;
v___y_536_ = v___y_555_;
v___y_537_ = v___x_558_;
goto v___jp_527_;
}
v___jp_559_:
{
if (v___y_569_ == 0)
{
v___y_546_ = v___y_571_;
v___y_547_ = v___y_560_;
v___y_548_ = v___y_562_;
v___y_549_ = v___y_563_;
v___y_550_ = v___y_566_;
v___y_551_ = v___y_565_;
v___y_552_ = v___y_564_;
v___y_553_ = v___y_567_;
v___y_554_ = v___y_568_;
v___y_555_ = v___y_570_;
v___y_556_ = v___y_561_;
goto v___jp_545_;
}
else
{
v___y_546_ = v___y_571_;
v___y_547_ = v___y_560_;
v___y_548_ = v___y_562_;
v___y_549_ = v___y_563_;
v___y_550_ = v___y_566_;
v___y_551_ = v___y_565_;
v___y_552_ = v___y_564_;
v___y_553_ = v___y_567_;
v___y_554_ = v___y_568_;
v___y_555_ = v___y_570_;
v___y_556_ = v___y_568_;
goto v___jp_545_;
}
}
v___jp_572_:
{
uint64_t v___x_587_; uint64_t v___x_588_; uint64_t v___x_589_; uint64_t v___x_590_; uint64_t v___x_591_; 
v___x_587_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___y_586_);
v___x_588_ = lean_uint64_add(v___y_574_, v___x_587_);
v___x_589_ = lean_uint64_add(v___y_575_, v___x_588_);
v___x_590_ = lean_uint64_add(v___y_581_, v___x_589_);
v___x_591_ = lean_uint64_add(v___y_576_, v___x_590_);
v___y_528_ = v___y_573_;
v___y_529_ = v___y_582_;
v___y_530_ = v___y_583_;
v___y_531_ = v___y_577_;
v___y_532_ = v___y_578_;
v___y_533_ = v___y_584_;
v___y_534_ = v___y_585_;
v___y_535_ = v___y_579_;
v___y_536_ = v___y_580_;
v___y_537_ = v___x_591_;
goto v___jp_527_;
}
v___jp_592_:
{
if (v___y_595_ == 0)
{
v___y_573_ = v___y_593_;
v___y_574_ = v___y_608_;
v___y_575_ = v___y_594_;
v___y_576_ = v___y_596_;
v___y_577_ = v___y_597_;
v___y_578_ = v___y_598_;
v___y_579_ = v___y_599_;
v___y_580_ = v___y_600_;
v___y_581_ = v___y_601_;
v___y_582_ = v___y_603_;
v___y_583_ = v___y_604_;
v___y_584_ = v___y_605_;
v___y_585_ = v___y_606_;
v___y_586_ = v___y_602_;
goto v___jp_572_;
}
else
{
v___y_573_ = v___y_593_;
v___y_574_ = v___y_608_;
v___y_575_ = v___y_594_;
v___y_576_ = v___y_596_;
v___y_577_ = v___y_597_;
v___y_578_ = v___y_598_;
v___y_579_ = v___y_599_;
v___y_580_ = v___y_600_;
v___y_581_ = v___y_601_;
v___y_582_ = v___y_603_;
v___y_583_ = v___y_604_;
v___y_584_ = v___y_605_;
v___y_585_ = v___y_606_;
v___y_586_ = v___y_607_;
goto v___jp_572_;
}
}
v___jp_609_:
{
uint64_t v_high_625_; uint8_t v___x_626_; 
v_high_625_ = lean_uint64_shift_right(v___y_624_, v___y_611_);
v___x_626_ = lean_uint64_dec_eq(v_high_625_, v___y_618_);
if (v___x_626_ == 0)
{
v___y_593_ = v___y_610_;
v___y_594_ = v___y_612_;
v___y_595_ = v___x_626_;
v___y_596_ = v___y_613_;
v___y_597_ = v___y_614_;
v___y_598_ = v___y_615_;
v___y_599_ = v___y_616_;
v___y_600_ = v___y_617_;
v___y_601_ = v___y_619_;
v___y_602_ = v_high_625_;
v___y_603_ = v___y_620_;
v___y_604_ = v___y_621_;
v___y_605_ = v___y_622_;
v___y_606_ = v___y_623_;
v___y_607_ = v___y_624_;
v___y_608_ = v___y_611_;
goto v___jp_592_;
}
else
{
v___y_593_ = v___y_610_;
v___y_594_ = v___y_612_;
v___y_595_ = v___x_626_;
v___y_596_ = v___y_613_;
v___y_597_ = v___y_614_;
v___y_598_ = v___y_615_;
v___y_599_ = v___y_616_;
v___y_600_ = v___y_617_;
v___y_601_ = v___y_619_;
v___y_602_ = v_high_625_;
v___y_603_ = v___y_620_;
v___y_604_ = v___y_621_;
v___y_605_ = v___y_622_;
v___y_606_ = v___y_623_;
v___y_607_ = v___y_624_;
v___y_608_ = v___y_618_;
goto v___jp_592_;
}
}
v___jp_627_:
{
if (v___y_639_ == 0)
{
v___y_610_ = v___y_628_;
v___y_611_ = v___y_629_;
v___y_612_ = v___y_644_;
v___y_613_ = v___y_630_;
v___y_614_ = v___y_631_;
v___y_615_ = v___y_632_;
v___y_616_ = v___y_633_;
v___y_617_ = v___y_634_;
v___y_618_ = v___y_635_;
v___y_619_ = v___y_636_;
v___y_620_ = v___y_638_;
v___y_621_ = v___y_640_;
v___y_622_ = v___y_641_;
v___y_623_ = v___y_642_;
v___y_624_ = v___y_643_;
goto v___jp_609_;
}
else
{
v___y_610_ = v___y_628_;
v___y_611_ = v___y_629_;
v___y_612_ = v___y_644_;
v___y_613_ = v___y_630_;
v___y_614_ = v___y_631_;
v___y_615_ = v___y_632_;
v___y_616_ = v___y_633_;
v___y_617_ = v___y_634_;
v___y_618_ = v___y_635_;
v___y_619_ = v___y_636_;
v___y_620_ = v___y_638_;
v___y_621_ = v___y_640_;
v___y_622_ = v___y_641_;
v___y_623_ = v___y_642_;
v___y_624_ = v___y_637_;
goto v___jp_609_;
}
}
v___jp_645_:
{
uint64_t v_high_661_; uint8_t v___x_662_; 
v_high_661_ = lean_uint64_shift_right(v___y_660_, v___y_655_);
v___x_662_ = lean_uint64_dec_eq(v_high_661_, v___y_653_);
if (v___x_662_ == 0)
{
v___y_628_ = v___y_646_;
v___y_629_ = v___y_647_;
v___y_630_ = v___y_648_;
v___y_631_ = v___y_649_;
v___y_632_ = v___y_650_;
v___y_633_ = v___y_651_;
v___y_634_ = v___y_652_;
v___y_635_ = v___y_653_;
v___y_636_ = v___y_654_;
v___y_637_ = v___y_660_;
v___y_638_ = v___y_656_;
v___y_639_ = v___x_662_;
v___y_640_ = v___y_657_;
v___y_641_ = v___y_658_;
v___y_642_ = v___y_659_;
v___y_643_ = v_high_661_;
v___y_644_ = v___y_655_;
goto v___jp_627_;
}
else
{
v___y_628_ = v___y_646_;
v___y_629_ = v___y_647_;
v___y_630_ = v___y_648_;
v___y_631_ = v___y_649_;
v___y_632_ = v___y_650_;
v___y_633_ = v___y_651_;
v___y_634_ = v___y_652_;
v___y_635_ = v___y_653_;
v___y_636_ = v___y_654_;
v___y_637_ = v___y_660_;
v___y_638_ = v___y_656_;
v___y_639_ = v___x_662_;
v___y_640_ = v___y_657_;
v___y_641_ = v___y_658_;
v___y_642_ = v___y_659_;
v___y_643_ = v_high_661_;
v___y_644_ = v___y_653_;
goto v___jp_627_;
}
}
v___jp_663_:
{
if (v___y_673_ == 0)
{
v___y_646_ = v___y_664_;
v___y_647_ = v___y_665_;
v___y_648_ = v___y_666_;
v___y_649_ = v___y_667_;
v___y_650_ = v___y_668_;
v___y_651_ = v___y_669_;
v___y_652_ = v___y_670_;
v___y_653_ = v___y_671_;
v___y_654_ = v___y_680_;
v___y_655_ = v___y_674_;
v___y_656_ = v___y_676_;
v___y_657_ = v___y_677_;
v___y_658_ = v___y_678_;
v___y_659_ = v___y_679_;
v___y_660_ = v___y_675_;
goto v___jp_645_;
}
else
{
v___y_646_ = v___y_664_;
v___y_647_ = v___y_665_;
v___y_648_ = v___y_666_;
v___y_649_ = v___y_667_;
v___y_650_ = v___y_668_;
v___y_651_ = v___y_669_;
v___y_652_ = v___y_670_;
v___y_653_ = v___y_671_;
v___y_654_ = v___y_680_;
v___y_655_ = v___y_674_;
v___y_656_ = v___y_676_;
v___y_657_ = v___y_677_;
v___y_658_ = v___y_678_;
v___y_659_ = v___y_679_;
v___y_660_ = v___y_672_;
goto v___jp_645_;
}
}
v___jp_681_:
{
uint64_t v_high_697_; uint8_t v___x_698_; 
v_high_697_ = lean_uint64_shift_right(v___y_696_, v___y_682_);
v___x_698_ = lean_uint64_dec_eq(v_high_697_, v___y_690_);
if (v___x_698_ == 0)
{
v___y_664_ = v___y_683_;
v___y_665_ = v___y_684_;
v___y_666_ = v___y_685_;
v___y_667_ = v___y_686_;
v___y_668_ = v___y_687_;
v___y_669_ = v___y_688_;
v___y_670_ = v___y_689_;
v___y_671_ = v___y_690_;
v___y_672_ = v___y_696_;
v___y_673_ = v___x_698_;
v___y_674_ = v___y_691_;
v___y_675_ = v_high_697_;
v___y_676_ = v___y_692_;
v___y_677_ = v___y_693_;
v___y_678_ = v___y_694_;
v___y_679_ = v___y_695_;
v___y_680_ = v___y_682_;
goto v___jp_663_;
}
else
{
v___y_664_ = v___y_683_;
v___y_665_ = v___y_684_;
v___y_666_ = v___y_685_;
v___y_667_ = v___y_686_;
v___y_668_ = v___y_687_;
v___y_669_ = v___y_688_;
v___y_670_ = v___y_689_;
v___y_671_ = v___y_690_;
v___y_672_ = v___y_696_;
v___y_673_ = v___x_698_;
v___y_674_ = v___y_691_;
v___y_675_ = v_high_697_;
v___y_676_ = v___y_692_;
v___y_677_ = v___y_693_;
v___y_678_ = v___y_694_;
v___y_679_ = v___y_695_;
v___y_680_ = v___y_690_;
goto v___jp_663_;
}
}
v___jp_699_:
{
if (v___y_712_ == 0)
{
v___y_682_ = v___y_700_;
v___y_683_ = v___y_701_;
v___y_684_ = v___y_702_;
v___y_685_ = v___y_715_;
v___y_686_ = v___y_703_;
v___y_687_ = v___y_704_;
v___y_688_ = v___y_706_;
v___y_689_ = v___y_707_;
v___y_690_ = v___y_708_;
v___y_691_ = v___y_709_;
v___y_692_ = v___y_710_;
v___y_693_ = v___y_711_;
v___y_694_ = v___y_713_;
v___y_695_ = v___y_714_;
v___y_696_ = v___y_705_;
goto v___jp_681_;
}
else
{
v___y_682_ = v___y_700_;
v___y_683_ = v___y_701_;
v___y_684_ = v___y_702_;
v___y_685_ = v___y_715_;
v___y_686_ = v___y_703_;
v___y_687_ = v___y_704_;
v___y_688_ = v___y_706_;
v___y_689_ = v___y_707_;
v___y_690_ = v___y_708_;
v___y_691_ = v___y_709_;
v___y_692_ = v___y_710_;
v___y_693_ = v___y_711_;
v___y_694_ = v___y_713_;
v___y_695_ = v___y_714_;
v___y_696_ = v___y_706_;
goto v___jp_681_;
}
}
v___jp_716_:
{
lean_object* v___x_729_; lean_object* v___x_730_; uint8_t v___x_731_; 
v___x_729_ = lean_nat_mul(v___y_717_, v___y_717_);
lean_dec(v___y_717_);
v___x_730_ = lean_nat_shiftl(v___x_729_, v___y_722_);
lean_dec(v___y_722_);
lean_dec(v___x_729_);
v___x_731_ = lean_nat_dec_eq(v___y_721_, v___x_730_);
lean_dec(v___x_730_);
lean_dec(v___y_721_);
if (v___x_731_ == 0)
{
lean_object* v___x_732_; 
v___x_732_ = lean_alloc_ctor(0, 1, 2);
lean_ctor_set(v___x_732_, 0, v___y_725_);
lean_ctor_set_uint8(v___x_732_, sizeof(void*)*1, v___y_728_);
lean_ctor_set_uint8(v___x_732_, sizeof(void*)*1 + 1, v___y_727_);
v___y_492_ = v___y_718_;
v___y_493_ = v___y_720_;
v___y_494_ = v___y_719_;
v___y_495_ = v___y_723_;
v___y_496_ = v___y_726_;
v___y_497_ = v___x_732_;
goto v___jp_491_;
}
else
{
lean_object* v___x_733_; 
v___x_733_ = lean_alloc_ctor(0, 1, 2);
lean_ctor_set(v___x_733_, 0, v___y_725_);
lean_ctor_set_uint8(v___x_733_, sizeof(void*)*1, v___y_728_);
lean_ctor_set_uint8(v___x_733_, sizeof(void*)*1 + 1, v___y_724_);
v___y_492_ = v___y_718_;
v___y_493_ = v___y_720_;
v___y_494_ = v___y_719_;
v___y_495_ = v___y_723_;
v___y_496_ = v___y_726_;
v___y_497_ = v___x_733_;
goto v___jp_491_;
}
}
v___jp_734_:
{
lean_object* v___x_747_; lean_object* v___x_748_; uint8_t v___x_749_; 
v___x_747_ = lean_nat_shiftr(v___y_746_, v___y_736_);
lean_dec(v___y_736_);
v___x_748_ = lean_nat_mod(v___y_746_, v___y_735_);
lean_dec(v___y_735_);
v___x_749_ = lean_nat_dec_eq(v___x_748_, v___y_740_);
lean_dec(v___x_748_);
if (v___x_749_ == 0)
{
v___y_717_ = v___y_746_;
v___y_718_ = v___y_737_;
v___y_719_ = v___y_741_;
v___y_720_ = v___y_740_;
v___y_721_ = v___y_739_;
v___y_722_ = v___y_738_;
v___y_723_ = v___y_742_;
v___y_724_ = v___y_743_;
v___y_725_ = v___x_747_;
v___y_726_ = v___y_745_;
v___y_727_ = v___y_744_;
v___y_728_ = v___y_744_;
goto v___jp_716_;
}
else
{
v___y_717_ = v___y_746_;
v___y_718_ = v___y_737_;
v___y_719_ = v___y_741_;
v___y_720_ = v___y_740_;
v___y_721_ = v___y_739_;
v___y_722_ = v___y_738_;
v___y_723_ = v___y_742_;
v___y_724_ = v___y_743_;
v___y_725_ = v___x_747_;
v___y_726_ = v___y_745_;
v___y_727_ = v___y_744_;
v___y_728_ = v___y_743_;
goto v___jp_716_;
}
}
v___jp_750_:
{
lean_object* v___x_765_; lean_object* v___x_766_; lean_object* v_shift_767_; uint64_t v___x_768_; uint64_t v___x_769_; uint64_t v___x_770_; lean_object* v___x_771_; 
v___x_765_ = lean_uint64_to_nat(v___y_764_);
v___x_766_ = lean_nat_shiftr(v___x_765_, v___y_751_);
lean_dec(v___x_765_);
v_shift_767_ = lean_nat_add(v___x_766_, v___y_751_);
lean_dec(v___x_766_);
v___x_768_ = lean_uint64_of_nat(v_shift_767_);
lean_dec(v_shift_767_);
v___x_769_ = lean_uint64_shift_left(v___y_761_, v___x_768_);
v___x_770_ = lp_floatlib_FloatLib_Numerics_FixedWord_IntegerSquareRoot_sqrtIter(v___y_752_, v___x_769_);
v___x_771_ = lean_uint64_to_nat(v___x_770_);
v___y_735_ = v___y_758_;
v___y_736_ = v___y_751_;
v___y_737_ = v___y_759_;
v___y_738_ = v___y_753_;
v___y_739_ = v___y_754_;
v___y_740_ = v___y_755_;
v___y_741_ = v___y_760_;
v___y_742_ = v___y_762_;
v___y_743_ = v___y_763_;
v___y_744_ = v___y_756_;
v___y_745_ = v___y_757_;
v___y_746_ = v___x_771_;
goto v___jp_734_;
}
v___jp_772_:
{
uint64_t v___x_791_; uint64_t v___x_792_; uint64_t v___x_793_; uint64_t v___x_794_; uint64_t v___x_795_; 
v___x_791_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___y_790_);
v___x_792_ = lean_uint64_add(v___y_779_, v___x_791_);
v___x_793_ = lean_uint64_add(v___y_774_, v___x_792_);
v___x_794_ = lean_uint64_add(v___y_788_, v___x_793_);
v___x_795_ = lean_uint64_add(v___y_783_, v___x_794_);
v___y_751_ = v___y_773_;
v___y_752_ = v___y_775_;
v___y_753_ = v___y_776_;
v___y_754_ = v___y_777_;
v___y_755_ = v___y_778_;
v___y_756_ = v___y_780_;
v___y_757_ = v___y_781_;
v___y_758_ = v___y_782_;
v___y_759_ = v___y_784_;
v___y_760_ = v___y_785_;
v___y_761_ = v___y_787_;
v___y_762_ = v___y_786_;
v___y_763_ = v___y_789_;
v___y_764_ = v___x_795_;
goto v___jp_750_;
}
v___jp_796_:
{
if (v___y_809_ == 0)
{
v___y_773_ = v___y_797_;
v___y_774_ = v___y_798_;
v___y_775_ = v___y_799_;
v___y_776_ = v___y_800_;
v___y_777_ = v___y_801_;
v___y_778_ = v___y_802_;
v___y_779_ = v___y_816_;
v___y_780_ = v___y_805_;
v___y_781_ = v___y_806_;
v___y_782_ = v___y_807_;
v___y_783_ = v___y_808_;
v___y_784_ = v___y_810_;
v___y_785_ = v___y_811_;
v___y_786_ = v___y_814_;
v___y_787_ = v___y_813_;
v___y_788_ = v___y_812_;
v___y_789_ = v___y_815_;
v___y_790_ = v___y_804_;
goto v___jp_772_;
}
else
{
v___y_773_ = v___y_797_;
v___y_774_ = v___y_798_;
v___y_775_ = v___y_799_;
v___y_776_ = v___y_800_;
v___y_777_ = v___y_801_;
v___y_778_ = v___y_802_;
v___y_779_ = v___y_816_;
v___y_780_ = v___y_805_;
v___y_781_ = v___y_806_;
v___y_782_ = v___y_807_;
v___y_783_ = v___y_808_;
v___y_784_ = v___y_810_;
v___y_785_ = v___y_811_;
v___y_786_ = v___y_814_;
v___y_787_ = v___y_813_;
v___y_788_ = v___y_812_;
v___y_789_ = v___y_815_;
v___y_790_ = v___y_803_;
goto v___jp_772_;
}
}
v___jp_817_:
{
uint64_t v_high_837_; uint8_t v___x_838_; 
v_high_837_ = lean_uint64_shift_right(v___y_836_, v___y_819_);
v___x_838_ = lean_uint64_dec_eq(v_high_837_, v___y_834_);
if (v___x_838_ == 0)
{
v___y_797_ = v___y_818_;
v___y_798_ = v___y_820_;
v___y_799_ = v___y_821_;
v___y_800_ = v___y_822_;
v___y_801_ = v___y_823_;
v___y_802_ = v___y_824_;
v___y_803_ = v___y_836_;
v___y_804_ = v_high_837_;
v___y_805_ = v___y_825_;
v___y_806_ = v___y_826_;
v___y_807_ = v___y_827_;
v___y_808_ = v___y_828_;
v___y_809_ = v___x_838_;
v___y_810_ = v___y_829_;
v___y_811_ = v___y_830_;
v___y_812_ = v___y_833_;
v___y_813_ = v___y_832_;
v___y_814_ = v___y_831_;
v___y_815_ = v___y_835_;
v___y_816_ = v___y_819_;
goto v___jp_796_;
}
else
{
v___y_797_ = v___y_818_;
v___y_798_ = v___y_820_;
v___y_799_ = v___y_821_;
v___y_800_ = v___y_822_;
v___y_801_ = v___y_823_;
v___y_802_ = v___y_824_;
v___y_803_ = v___y_836_;
v___y_804_ = v_high_837_;
v___y_805_ = v___y_825_;
v___y_806_ = v___y_826_;
v___y_807_ = v___y_827_;
v___y_808_ = v___y_828_;
v___y_809_ = v___x_838_;
v___y_810_ = v___y_829_;
v___y_811_ = v___y_830_;
v___y_812_ = v___y_833_;
v___y_813_ = v___y_832_;
v___y_814_ = v___y_831_;
v___y_815_ = v___y_835_;
v___y_816_ = v___y_834_;
goto v___jp_796_;
}
}
v___jp_839_:
{
if (v___y_851_ == 0)
{
v___y_818_ = v___y_840_;
v___y_819_ = v___y_841_;
v___y_820_ = v___y_860_;
v___y_821_ = v___y_843_;
v___y_822_ = v___y_844_;
v___y_823_ = v___y_845_;
v___y_824_ = v___y_846_;
v___y_825_ = v___y_847_;
v___y_826_ = v___y_848_;
v___y_827_ = v___y_849_;
v___y_828_ = v___y_850_;
v___y_829_ = v___y_853_;
v___y_830_ = v___y_854_;
v___y_831_ = v___y_857_;
v___y_832_ = v___y_856_;
v___y_833_ = v___y_855_;
v___y_834_ = v___y_858_;
v___y_835_ = v___y_859_;
v___y_836_ = v___y_852_;
goto v___jp_817_;
}
else
{
v___y_818_ = v___y_840_;
v___y_819_ = v___y_841_;
v___y_820_ = v___y_860_;
v___y_821_ = v___y_843_;
v___y_822_ = v___y_844_;
v___y_823_ = v___y_845_;
v___y_824_ = v___y_846_;
v___y_825_ = v___y_847_;
v___y_826_ = v___y_848_;
v___y_827_ = v___y_849_;
v___y_828_ = v___y_850_;
v___y_829_ = v___y_853_;
v___y_830_ = v___y_854_;
v___y_831_ = v___y_857_;
v___y_832_ = v___y_856_;
v___y_833_ = v___y_855_;
v___y_834_ = v___y_858_;
v___y_835_ = v___y_859_;
v___y_836_ = v___y_842_;
goto v___jp_817_;
}
}
v___jp_861_:
{
uint64_t v_high_881_; uint8_t v___x_882_; 
v_high_881_ = lean_uint64_shift_right(v___y_880_, v___y_871_);
v___x_882_ = lean_uint64_dec_eq(v_high_881_, v___y_878_);
if (v___x_882_ == 0)
{
v___y_840_ = v___y_862_;
v___y_841_ = v___y_863_;
v___y_842_ = v___y_880_;
v___y_843_ = v___y_864_;
v___y_844_ = v___y_865_;
v___y_845_ = v___y_866_;
v___y_846_ = v___y_867_;
v___y_847_ = v___y_868_;
v___y_848_ = v___y_869_;
v___y_849_ = v___y_870_;
v___y_850_ = v___y_872_;
v___y_851_ = v___x_882_;
v___y_852_ = v_high_881_;
v___y_853_ = v___y_873_;
v___y_854_ = v___y_874_;
v___y_855_ = v___y_877_;
v___y_856_ = v___y_876_;
v___y_857_ = v___y_875_;
v___y_858_ = v___y_878_;
v___y_859_ = v___y_879_;
v___y_860_ = v___y_871_;
goto v___jp_839_;
}
else
{
v___y_840_ = v___y_862_;
v___y_841_ = v___y_863_;
v___y_842_ = v___y_880_;
v___y_843_ = v___y_864_;
v___y_844_ = v___y_865_;
v___y_845_ = v___y_866_;
v___y_846_ = v___y_867_;
v___y_847_ = v___y_868_;
v___y_848_ = v___y_869_;
v___y_849_ = v___y_870_;
v___y_850_ = v___y_872_;
v___y_851_ = v___x_882_;
v___y_852_ = v_high_881_;
v___y_853_ = v___y_873_;
v___y_854_ = v___y_874_;
v___y_855_ = v___y_877_;
v___y_856_ = v___y_876_;
v___y_857_ = v___y_875_;
v___y_858_ = v___y_878_;
v___y_859_ = v___y_879_;
v___y_860_ = v___y_878_;
goto v___jp_839_;
}
}
v___jp_883_:
{
if (v___y_884_ == 0)
{
v___y_862_ = v___y_885_;
v___y_863_ = v___y_886_;
v___y_864_ = v___y_887_;
v___y_865_ = v___y_888_;
v___y_866_ = v___y_889_;
v___y_867_ = v___y_890_;
v___y_868_ = v___y_892_;
v___y_869_ = v___y_893_;
v___y_870_ = v___y_895_;
v___y_871_ = v___y_896_;
v___y_872_ = v___y_897_;
v___y_873_ = v___y_898_;
v___y_874_ = v___y_899_;
v___y_875_ = v___y_901_;
v___y_876_ = v___y_900_;
v___y_877_ = v___y_904_;
v___y_878_ = v___y_902_;
v___y_879_ = v___y_903_;
v___y_880_ = v___y_894_;
goto v___jp_861_;
}
else
{
v___y_862_ = v___y_885_;
v___y_863_ = v___y_886_;
v___y_864_ = v___y_887_;
v___y_865_ = v___y_888_;
v___y_866_ = v___y_889_;
v___y_867_ = v___y_890_;
v___y_868_ = v___y_892_;
v___y_869_ = v___y_893_;
v___y_870_ = v___y_895_;
v___y_871_ = v___y_896_;
v___y_872_ = v___y_897_;
v___y_873_ = v___y_898_;
v___y_874_ = v___y_899_;
v___y_875_ = v___y_901_;
v___y_876_ = v___y_900_;
v___y_877_ = v___y_904_;
v___y_878_ = v___y_902_;
v___y_879_ = v___y_903_;
v___y_880_ = v___y_891_;
goto v___jp_861_;
}
}
v___jp_905_:
{
uint64_t v_high_925_; uint8_t v___x_926_; 
v_high_925_ = lean_uint64_shift_right(v___y_924_, v___y_919_);
v___x_926_ = lean_uint64_dec_eq(v_high_925_, v___y_922_);
if (v___x_926_ == 0)
{
v___y_884_ = v___x_926_;
v___y_885_ = v___y_906_;
v___y_886_ = v___y_907_;
v___y_887_ = v___y_908_;
v___y_888_ = v___y_909_;
v___y_889_ = v___y_910_;
v___y_890_ = v___y_911_;
v___y_891_ = v___y_924_;
v___y_892_ = v___y_912_;
v___y_893_ = v___y_913_;
v___y_894_ = v_high_925_;
v___y_895_ = v___y_914_;
v___y_896_ = v___y_915_;
v___y_897_ = v___y_916_;
v___y_898_ = v___y_917_;
v___y_899_ = v___y_918_;
v___y_900_ = v___y_921_;
v___y_901_ = v___y_920_;
v___y_902_ = v___y_922_;
v___y_903_ = v___y_923_;
v___y_904_ = v___y_919_;
goto v___jp_883_;
}
else
{
v___y_884_ = v___x_926_;
v___y_885_ = v___y_906_;
v___y_886_ = v___y_907_;
v___y_887_ = v___y_908_;
v___y_888_ = v___y_909_;
v___y_889_ = v___y_910_;
v___y_890_ = v___y_911_;
v___y_891_ = v___y_924_;
v___y_892_ = v___y_912_;
v___y_893_ = v___y_913_;
v___y_894_ = v_high_925_;
v___y_895_ = v___y_914_;
v___y_896_ = v___y_915_;
v___y_897_ = v___y_916_;
v___y_898_ = v___y_917_;
v___y_899_ = v___y_918_;
v___y_900_ = v___y_921_;
v___y_901_ = v___y_920_;
v___y_902_ = v___y_922_;
v___y_903_ = v___y_923_;
v___y_904_ = v___y_922_;
goto v___jp_883_;
}
}
v___jp_927_:
{
if (v___y_929_ == 0)
{
v___y_906_ = v___y_930_;
v___y_907_ = v___y_931_;
v___y_908_ = v___y_932_;
v___y_909_ = v___y_933_;
v___y_910_ = v___y_934_;
v___y_911_ = v___y_935_;
v___y_912_ = v___y_936_;
v___y_913_ = v___y_937_;
v___y_914_ = v___y_938_;
v___y_915_ = v___y_939_;
v___y_916_ = v___y_947_;
v___y_917_ = v___y_940_;
v___y_918_ = v___y_941_;
v___y_919_ = v___y_942_;
v___y_920_ = v___y_944_;
v___y_921_ = v___y_943_;
v___y_922_ = v___y_945_;
v___y_923_ = v___y_946_;
v___y_924_ = v___y_928_;
goto v___jp_905_;
}
else
{
v___y_906_ = v___y_930_;
v___y_907_ = v___y_931_;
v___y_908_ = v___y_932_;
v___y_909_ = v___y_933_;
v___y_910_ = v___y_934_;
v___y_911_ = v___y_935_;
v___y_912_ = v___y_936_;
v___y_913_ = v___y_937_;
v___y_914_ = v___y_938_;
v___y_915_ = v___y_939_;
v___y_916_ = v___y_947_;
v___y_917_ = v___y_940_;
v___y_918_ = v___y_941_;
v___y_919_ = v___y_942_;
v___y_920_ = v___y_944_;
v___y_921_ = v___y_943_;
v___y_922_ = v___y_945_;
v___y_923_ = v___y_946_;
v___y_924_ = v___y_932_;
goto v___jp_905_;
}
}
v___jp_948_:
{
uint64_t v___x_964_; uint64_t v___x_965_; 
v___x_964_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___y_963_);
v___x_965_ = lean_uint64_add(v___y_957_, v___x_964_);
v___y_751_ = v___y_949_;
v___y_752_ = v___y_950_;
v___y_753_ = v___y_951_;
v___y_754_ = v___y_952_;
v___y_755_ = v___y_953_;
v___y_756_ = v___y_954_;
v___y_757_ = v___y_955_;
v___y_758_ = v___y_956_;
v___y_759_ = v___y_958_;
v___y_760_ = v___y_959_;
v___y_761_ = v___y_960_;
v___y_762_ = v___y_961_;
v___y_763_ = v___y_962_;
v___y_764_ = v___x_965_;
goto v___jp_750_;
}
v___jp_966_:
{
if (v___y_969_ == 0)
{
v___y_949_ = v___y_967_;
v___y_950_ = v___y_968_;
v___y_951_ = v___y_970_;
v___y_952_ = v___y_971_;
v___y_953_ = v___y_972_;
v___y_954_ = v___y_973_;
v___y_955_ = v___y_974_;
v___y_956_ = v___y_975_;
v___y_957_ = v___y_982_;
v___y_958_ = v___y_977_;
v___y_959_ = v___y_978_;
v___y_960_ = v___y_979_;
v___y_961_ = v___y_980_;
v___y_962_ = v___y_981_;
v___y_963_ = v___y_976_;
goto v___jp_948_;
}
else
{
v___y_949_ = v___y_967_;
v___y_950_ = v___y_968_;
v___y_951_ = v___y_970_;
v___y_952_ = v___y_971_;
v___y_953_ = v___y_972_;
v___y_954_ = v___y_973_;
v___y_955_ = v___y_974_;
v___y_956_ = v___y_975_;
v___y_957_ = v___y_982_;
v___y_958_ = v___y_977_;
v___y_959_ = v___y_978_;
v___y_960_ = v___y_979_;
v___y_961_ = v___y_980_;
v___y_962_ = v___y_981_;
v___y_963_ = v___y_968_;
goto v___jp_948_;
}
}
v___jp_983_:
{
lean_object* v___x_995_; lean_object* v___x_996_; lean_object* v_shiftAmount_997_; lean_object* v___x_998_; lean_object* v___x_999_; lean_object* v___x_1000_; lean_object* v___x_1001_; lean_object* v___x_1002_; lean_object* v___x_1003_; lean_object* v_totalExponent_1004_; lean_object* v___x_1005_; lean_object* v___x_1006_; lean_object* v_shift_1007_; lean_object* v_zero_1008_; uint8_t v_isZero_1009_; 
v___x_995_ = lean_int_mul(v___y_985_, v___y_994_);
lean_dec(v___y_985_);
v___x_996_ = lean_int_sub(v___y_993_, v___x_995_);
lean_dec(v___x_995_);
lean_dec(v___y_993_);
v_shiftAmount_997_ = l_Int_toNat(v___x_996_);
lean_dec(v___x_996_);
v___x_998_ = lean_nat_shiftl(v___y_987_, v_shiftAmount_997_);
lean_dec(v_shiftAmount_997_);
lean_dec(v___y_987_);
v___x_999_ = lean_nat_log2(v___x_998_);
v___x_1000_ = lean_nat_shiftr(v___x_999_, v___y_986_);
lean_dec(v___x_999_);
v___x_1001_ = lean_nat_to_int(v___x_1000_);
lean_inc(v___y_986_);
v___x_1002_ = lean_nat_to_int(v___y_986_);
v___x_1003_ = lean_int_add(v___x_1001_, v___x_1002_);
lean_dec(v___x_1002_);
lean_dec(v___x_1001_);
v_totalExponent_1004_ = lean_int_add(v___x_1003_, v___y_994_);
lean_dec(v___x_1003_);
v___x_1005_ = l_Float_Model_Format_targetExponent(v___y_990_, v_totalExponent_1004_);
lean_dec(v_totalExponent_1004_);
v___x_1006_ = lean_int_sub(v___x_1005_, v___y_994_);
lean_dec(v___x_1005_);
v_shift_1007_ = l_Int_toNat(v___x_1006_);
lean_dec(v___x_1006_);
v_zero_1008_ = lean_unsigned_to_nat(0u);
v_isZero_1009_ = lean_nat_dec_eq(v_shift_1007_, v_zero_1008_);
if (v_isZero_1009_ == 1)
{
lean_object* v___x_1010_; uint8_t v___x_1011_; 
lean_dec(v___y_984_);
v___x_1010_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3);
v___x_1011_ = lean_nat_dec_lt(v___x_998_, v___x_1010_);
if (v___x_1011_ == 0)
{
lean_object* v___x_1012_; lean_object* v_fst_1013_; 
lean_dec(v___y_986_);
lean_inc(v___x_998_);
v___x_1012_ = lp_floatlib_FloatLib_Numerics_FixedWord_IntegerSquareRoot_sqrtRem(v___x_998_);
v_fst_1013_ = lean_ctor_get(v___x_1012_, 0);
lean_inc(v_fst_1013_);
lean_dec_ref(v___x_1012_);
v___y_510_ = v___y_988_;
v___y_511_ = v___y_990_;
v___y_512_ = v___y_989_;
v___y_513_ = v___x_998_;
v___y_514_ = v___y_994_;
v___y_515_ = v_shift_1007_;
v___y_516_ = v_fst_1013_;
goto v___jp_509_;
}
else
{
uint64_t v___x_1014_; uint64_t v___x_1015_; uint8_t v___x_1016_; 
v___x_1014_ = lean_uint64_of_nat(v___x_998_);
v___x_1015_ = 1ULL;
v___x_1016_ = lean_uint64_dec_le(v___x_1014_, v___x_1015_);
if (v___x_1016_ == 0)
{
uint64_t v___x_1017_; uint8_t v___x_1018_; 
v___x_1017_ = 2ULL;
v___x_1018_ = lean_uint64_dec_lt(v___x_1014_, v___x_1017_);
if (v___x_1018_ == 0)
{
uint64_t v___x_1019_; uint8_t v___x_1020_; 
v___x_1019_ = 16ULL;
v___x_1020_ = lean_uint64_dec_lt(v___x_1014_, v___x_1019_);
if (v___x_1020_ == 0)
{
uint64_t v___x_1021_; uint64_t v___x_1022_; uint8_t v___x_1023_; 
v___x_1021_ = 4ULL;
v___x_1022_ = 256ULL;
v___x_1023_ = lean_uint64_dec_lt(v___x_1014_, v___x_1022_);
if (v___x_1023_ == 0)
{
uint64_t v___x_1024_; uint64_t v___x_1025_; uint64_t v_high_1026_; uint64_t v___x_1027_; uint8_t v___x_1028_; 
v___x_1024_ = 32ULL;
v___x_1025_ = 8ULL;
v_high_1026_ = lean_uint64_shift_right(v___x_1014_, v___x_1024_);
v___x_1027_ = 0ULL;
v___x_1028_ = lean_uint64_dec_eq(v_high_1026_, v___x_1027_);
if (v___x_1028_ == 0)
{
v___y_700_ = v___x_1019_;
v___y_701_ = v___y_986_;
v___y_702_ = v___x_1021_;
v___y_703_ = v___x_998_;
v___y_704_ = v___y_989_;
v___y_705_ = v_high_1026_;
v___y_706_ = v___x_1014_;
v___y_707_ = v_shift_1007_;
v___y_708_ = v___x_1027_;
v___y_709_ = v___x_1025_;
v___y_710_ = v___x_1015_;
v___y_711_ = v___y_988_;
v___y_712_ = v___x_1028_;
v___y_713_ = v___y_990_;
v___y_714_ = v___y_994_;
v___y_715_ = v___x_1024_;
goto v___jp_699_;
}
else
{
v___y_700_ = v___x_1019_;
v___y_701_ = v___y_986_;
v___y_702_ = v___x_1021_;
v___y_703_ = v___x_998_;
v___y_704_ = v___y_989_;
v___y_705_ = v_high_1026_;
v___y_706_ = v___x_1014_;
v___y_707_ = v_shift_1007_;
v___y_708_ = v___x_1027_;
v___y_709_ = v___x_1025_;
v___y_710_ = v___x_1015_;
v___y_711_ = v___y_988_;
v___y_712_ = v___x_1028_;
v___y_713_ = v___y_990_;
v___y_714_ = v___y_994_;
v___y_715_ = v___x_1027_;
goto v___jp_699_;
}
}
else
{
uint64_t v_high_1029_; uint64_t v___x_1030_; uint8_t v___x_1031_; 
v_high_1029_ = lean_uint64_shift_right(v___x_1014_, v___x_1021_);
v___x_1030_ = 0ULL;
v___x_1031_ = lean_uint64_dec_eq(v_high_1029_, v___x_1030_);
if (v___x_1031_ == 0)
{
v___y_560_ = v___y_986_;
v___y_561_ = v_high_1029_;
v___y_562_ = v___x_1015_;
v___y_563_ = v___y_988_;
v___y_564_ = v___x_998_;
v___y_565_ = v___y_989_;
v___y_566_ = v___y_990_;
v___y_567_ = v___y_994_;
v___y_568_ = v___x_1014_;
v___y_569_ = v___x_1031_;
v___y_570_ = v_shift_1007_;
v___y_571_ = v___x_1021_;
goto v___jp_559_;
}
else
{
v___y_560_ = v___y_986_;
v___y_561_ = v_high_1029_;
v___y_562_ = v___x_1015_;
v___y_563_ = v___y_988_;
v___y_564_ = v___x_998_;
v___y_565_ = v___y_989_;
v___y_566_ = v___y_990_;
v___y_567_ = v___y_994_;
v___y_568_ = v___x_1014_;
v___y_569_ = v___x_1031_;
v___y_570_ = v_shift_1007_;
v___y_571_ = v___x_1030_;
goto v___jp_559_;
}
}
}
else
{
uint64_t v___x_1032_; 
v___x_1032_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___x_1014_);
v___y_528_ = v___y_986_;
v___y_529_ = v___x_1015_;
v___y_530_ = v___y_988_;
v___y_531_ = v___x_998_;
v___y_532_ = v___y_989_;
v___y_533_ = v___y_990_;
v___y_534_ = v___y_994_;
v___y_535_ = v___x_1014_;
v___y_536_ = v_shift_1007_;
v___y_537_ = v___x_1032_;
goto v___jp_527_;
}
}
else
{
uint64_t v___x_1033_; 
v___x_1033_ = 0ULL;
v___y_528_ = v___y_986_;
v___y_529_ = v___x_1015_;
v___y_530_ = v___y_988_;
v___y_531_ = v___x_998_;
v___y_532_ = v___y_989_;
v___y_533_ = v___y_990_;
v___y_534_ = v___y_994_;
v___y_535_ = v___x_1014_;
v___y_536_ = v_shift_1007_;
v___y_537_ = v___x_1033_;
goto v___jp_527_;
}
}
else
{
lean_object* v___x_1034_; 
lean_dec(v___y_986_);
v___x_1034_ = lean_uint64_to_nat(v___x_1014_);
v___y_510_ = v___y_988_;
v___y_511_ = v___y_990_;
v___y_512_ = v___y_989_;
v___y_513_ = v___x_998_;
v___y_514_ = v___y_994_;
v___y_515_ = v_shift_1007_;
v___y_516_ = v___x_1034_;
goto v___jp_509_;
}
}
}
else
{
lean_object* v_one_1035_; lean_object* v_n_1036_; lean_object* v_radicandShift_1037_; lean_object* v___x_1038_; lean_object* v___x_1039_; uint8_t v___x_1040_; 
v_one_1035_ = lean_unsigned_to_nat(1u);
v_n_1036_ = lean_nat_sub(v_shift_1007_, v_one_1035_);
v_radicandShift_1037_ = lean_nat_mul(v___y_984_, v_n_1036_);
lean_dec(v_n_1036_);
v___x_1038_ = lean_nat_shiftr(v___x_998_, v_radicandShift_1037_);
v___x_1039_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3);
v___x_1040_ = lean_nat_dec_lt(v___x_1038_, v___x_1039_);
if (v___x_1040_ == 0)
{
lean_object* v___x_1041_; lean_object* v_fst_1042_; 
v___x_1041_ = lp_floatlib_FloatLib_Numerics_FixedWord_IntegerSquareRoot_sqrtRem(v___x_1038_);
v_fst_1042_ = lean_ctor_get(v___x_1041_, 0);
lean_inc(v_fst_1042_);
lean_dec_ref(v___x_1041_);
v___y_735_ = v___y_984_;
v___y_736_ = v___y_986_;
v___y_737_ = v___y_988_;
v___y_738_ = v_radicandShift_1037_;
v___y_739_ = v___x_998_;
v___y_740_ = v___y_989_;
v___y_741_ = v___y_990_;
v___y_742_ = v___y_994_;
v___y_743_ = v___y_991_;
v___y_744_ = v___y_992_;
v___y_745_ = v_shift_1007_;
v___y_746_ = v_fst_1042_;
goto v___jp_734_;
}
else
{
uint64_t v___x_1043_; uint64_t v___x_1044_; uint8_t v___x_1045_; 
v___x_1043_ = lean_uint64_of_nat(v___x_1038_);
lean_dec(v___x_1038_);
v___x_1044_ = 1ULL;
v___x_1045_ = lean_uint64_dec_le(v___x_1043_, v___x_1044_);
if (v___x_1045_ == 0)
{
uint64_t v___x_1046_; uint8_t v___x_1047_; 
v___x_1046_ = 2ULL;
v___x_1047_ = lean_uint64_dec_lt(v___x_1043_, v___x_1046_);
if (v___x_1047_ == 0)
{
uint64_t v___x_1048_; uint8_t v___x_1049_; 
v___x_1048_ = 16ULL;
v___x_1049_ = lean_uint64_dec_lt(v___x_1043_, v___x_1048_);
if (v___x_1049_ == 0)
{
uint64_t v___x_1050_; uint64_t v___x_1051_; uint8_t v___x_1052_; 
v___x_1050_ = 4ULL;
v___x_1051_ = 256ULL;
v___x_1052_ = lean_uint64_dec_lt(v___x_1043_, v___x_1051_);
if (v___x_1052_ == 0)
{
uint64_t v___x_1053_; uint64_t v___x_1054_; uint64_t v_high_1055_; uint64_t v___x_1056_; uint8_t v___x_1057_; 
v___x_1053_ = 32ULL;
v___x_1054_ = 8ULL;
v_high_1055_ = lean_uint64_shift_right(v___x_1043_, v___x_1053_);
v___x_1056_ = 0ULL;
v___x_1057_ = lean_uint64_dec_eq(v_high_1055_, v___x_1056_);
if (v___x_1057_ == 0)
{
v___y_928_ = v_high_1055_;
v___y_929_ = v___x_1057_;
v___y_930_ = v___y_986_;
v___y_931_ = v___x_1050_;
v___y_932_ = v___x_1043_;
v___y_933_ = v_radicandShift_1037_;
v___y_934_ = v___x_998_;
v___y_935_ = v___y_989_;
v___y_936_ = v___y_992_;
v___y_937_ = v_shift_1007_;
v___y_938_ = v___y_984_;
v___y_939_ = v___x_1054_;
v___y_940_ = v___y_988_;
v___y_941_ = v___y_990_;
v___y_942_ = v___x_1048_;
v___y_943_ = v___x_1044_;
v___y_944_ = v___y_994_;
v___y_945_ = v___x_1056_;
v___y_946_ = v___y_991_;
v___y_947_ = v___x_1053_;
goto v___jp_927_;
}
else
{
v___y_928_ = v_high_1055_;
v___y_929_ = v___x_1057_;
v___y_930_ = v___y_986_;
v___y_931_ = v___x_1050_;
v___y_932_ = v___x_1043_;
v___y_933_ = v_radicandShift_1037_;
v___y_934_ = v___x_998_;
v___y_935_ = v___y_989_;
v___y_936_ = v___y_992_;
v___y_937_ = v_shift_1007_;
v___y_938_ = v___y_984_;
v___y_939_ = v___x_1054_;
v___y_940_ = v___y_988_;
v___y_941_ = v___y_990_;
v___y_942_ = v___x_1048_;
v___y_943_ = v___x_1044_;
v___y_944_ = v___y_994_;
v___y_945_ = v___x_1056_;
v___y_946_ = v___y_991_;
v___y_947_ = v___x_1056_;
goto v___jp_927_;
}
}
else
{
uint64_t v_high_1058_; uint64_t v___x_1059_; uint8_t v___x_1060_; 
v_high_1058_ = lean_uint64_shift_right(v___x_1043_, v___x_1050_);
v___x_1059_ = 0ULL;
v___x_1060_ = lean_uint64_dec_eq(v_high_1058_, v___x_1059_);
if (v___x_1060_ == 0)
{
v___y_967_ = v___y_986_;
v___y_968_ = v___x_1043_;
v___y_969_ = v___x_1060_;
v___y_970_ = v_radicandShift_1037_;
v___y_971_ = v___x_998_;
v___y_972_ = v___y_989_;
v___y_973_ = v___y_992_;
v___y_974_ = v_shift_1007_;
v___y_975_ = v___y_984_;
v___y_976_ = v_high_1058_;
v___y_977_ = v___y_988_;
v___y_978_ = v___y_990_;
v___y_979_ = v___x_1044_;
v___y_980_ = v___y_994_;
v___y_981_ = v___y_991_;
v___y_982_ = v___x_1050_;
goto v___jp_966_;
}
else
{
v___y_967_ = v___y_986_;
v___y_968_ = v___x_1043_;
v___y_969_ = v___x_1060_;
v___y_970_ = v_radicandShift_1037_;
v___y_971_ = v___x_998_;
v___y_972_ = v___y_989_;
v___y_973_ = v___y_992_;
v___y_974_ = v_shift_1007_;
v___y_975_ = v___y_984_;
v___y_976_ = v_high_1058_;
v___y_977_ = v___y_988_;
v___y_978_ = v___y_990_;
v___y_979_ = v___x_1044_;
v___y_980_ = v___y_994_;
v___y_981_ = v___y_991_;
v___y_982_ = v___x_1059_;
goto v___jp_966_;
}
}
}
else
{
uint64_t v___x_1061_; 
v___x_1061_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___x_1043_);
v___y_751_ = v___y_986_;
v___y_752_ = v___x_1043_;
v___y_753_ = v_radicandShift_1037_;
v___y_754_ = v___x_998_;
v___y_755_ = v___y_989_;
v___y_756_ = v___y_992_;
v___y_757_ = v_shift_1007_;
v___y_758_ = v___y_984_;
v___y_759_ = v___y_988_;
v___y_760_ = v___y_990_;
v___y_761_ = v___x_1044_;
v___y_762_ = v___y_994_;
v___y_763_ = v___y_991_;
v___y_764_ = v___x_1061_;
goto v___jp_750_;
}
}
else
{
uint64_t v___x_1062_; 
v___x_1062_ = 0ULL;
v___y_751_ = v___y_986_;
v___y_752_ = v___x_1043_;
v___y_753_ = v_radicandShift_1037_;
v___y_754_ = v___x_998_;
v___y_755_ = v___y_989_;
v___y_756_ = v___y_992_;
v___y_757_ = v_shift_1007_;
v___y_758_ = v___y_984_;
v___y_759_ = v___y_988_;
v___y_760_ = v___y_990_;
v___y_761_ = v___x_1044_;
v___y_762_ = v___y_994_;
v___y_763_ = v___y_991_;
v___y_764_ = v___x_1062_;
goto v___jp_750_;
}
}
else
{
lean_object* v___x_1063_; 
v___x_1063_ = lean_uint64_to_nat(v___x_1043_);
v___y_735_ = v___y_984_;
v___y_736_ = v___y_986_;
v___y_737_ = v___y_988_;
v___y_738_ = v_radicandShift_1037_;
v___y_739_ = v___x_998_;
v___y_740_ = v___y_989_;
v___y_741_ = v___y_990_;
v___y_742_ = v___y_994_;
v___y_743_ = v___y_991_;
v___y_744_ = v___y_992_;
v___y_745_ = v_shift_1007_;
v___y_746_ = v___x_1063_;
goto v___jp_734_;
}
}
}
}
v___jp_1064_:
{
lean_object* v___x_1071_; uint8_t v___x_1072_; 
v___x_1071_ = lean_unsigned_to_nat(0u);
v___x_1072_ = lean_nat_dec_eq(v___y_1068_, v___x_1071_);
if (v___x_1072_ == 0)
{
lean_object* v___x_1073_; uint8_t v___x_1074_; lean_object* v___x_1075_; lean_object* v___x_1076_; lean_object* v___x_1077_; lean_object* v___x_1078_; lean_object* v___x_1079_; lean_object* v___x_1080_; lean_object* v___x_1081_; uint8_t v___x_1082_; 
v___x_1073_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__0));
v___x_1074_ = 1;
lean_inc(v___y_1065_);
v___x_1075_ = lean_nat_to_int(v___y_1065_);
v___x_1076_ = lean_int_ediv(v___y_1070_, v___x_1075_);
v___x_1077_ = l_Float_Model_totalExponent(v___y_1068_, v___y_1070_);
lean_inc(v___y_1067_);
v___x_1078_ = lean_nat_to_int(v___y_1067_);
v___x_1079_ = lean_int_add(v___x_1077_, v___x_1078_);
lean_dec(v___x_1078_);
lean_dec(v___x_1077_);
v___x_1080_ = lean_int_ediv(v___x_1079_, v___x_1075_);
lean_dec(v___x_1079_);
v___x_1081_ = l_Float_Model_Format_targetExponent(v___x_1073_, v___x_1080_);
lean_dec(v___x_1080_);
v___x_1082_ = lean_int_dec_le(v___x_1076_, v___x_1081_);
if (v___x_1082_ == 0)
{
lean_dec(v___x_1076_);
v___y_984_ = v___y_1065_;
v___y_985_ = v___x_1075_;
v___y_986_ = v___y_1067_;
v___y_987_ = v___y_1068_;
v___y_988_ = v___x_1074_;
v___y_989_ = v___x_1071_;
v___y_990_ = v___x_1073_;
v___y_991_ = v___x_1072_;
v___y_992_ = v___y_1069_;
v___y_993_ = v___y_1070_;
v___y_994_ = v___x_1081_;
goto v___jp_983_;
}
else
{
lean_dec(v___x_1081_);
v___y_984_ = v___y_1065_;
v___y_985_ = v___x_1075_;
v___y_986_ = v___y_1067_;
v___y_987_ = v___y_1068_;
v___y_988_ = v___x_1074_;
v___y_989_ = v___x_1071_;
v___y_990_ = v___x_1073_;
v___y_991_ = v___x_1072_;
v___y_992_ = v___y_1069_;
v___y_993_ = v___y_1070_;
v___y_994_ = v___x_1076_;
goto v___jp_983_;
}
}
else
{
lean_object* v___x_1083_; 
lean_dec(v___y_1070_);
lean_dec(v___y_1068_);
lean_dec(v___y_1067_);
lean_dec(v___y_1065_);
v___x_1083_ = l_BitVec_ofNat(v___y_1066_, v___x_1071_);
return v___x_1083_;
}
}
v___jp_1084_:
{
lean_object* v___x_1091_; uint8_t v___x_1092_; 
v___x_1091_ = lean_unsigned_to_nat(0u);
v___x_1092_ = lean_nat_dec_eq(v___y_1087_, v___x_1091_);
if (v___x_1092_ == 0)
{
lean_object* v___x_1093_; lean_object* v___x_1094_; lean_object* v___x_1095_; lean_object* v___x_1096_; lean_object* v___x_1097_; 
v___x_1093_ = lean_nat_to_int(v___y_1087_);
v___x_1094_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4);
v___x_1095_ = lean_int_sub(v___x_1093_, v___x_1094_);
lean_dec(v___x_1093_);
v___x_1096_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__5, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__5_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__5);
v___x_1097_ = lean_int_sub(v___x_1095_, v___x_1096_);
lean_dec(v___x_1095_);
v___y_1065_ = v___y_1085_;
v___y_1066_ = v___y_1086_;
v___y_1067_ = v___y_1088_;
v___y_1068_ = v___y_1090_;
v___y_1069_ = v___y_1089_;
v___y_1070_ = v___x_1097_;
goto v___jp_1064_;
}
else
{
lean_object* v___x_1098_; lean_object* v___x_1099_; lean_object* v___x_1100_; lean_object* v___x_1101_; lean_object* v___x_1102_; 
lean_dec(v___y_1087_);
lean_inc(v___y_1088_);
v___x_1098_ = lean_nat_to_int(v___y_1088_);
v___x_1099_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4);
v___x_1100_ = lean_int_sub(v___x_1098_, v___x_1099_);
lean_dec(v___x_1098_);
v___x_1101_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__5, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__5_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__5);
v___x_1102_ = lean_int_sub(v___x_1100_, v___x_1101_);
lean_dec(v___x_1100_);
v___y_1065_ = v___y_1085_;
v___y_1066_ = v___y_1086_;
v___y_1067_ = v___y_1088_;
v___y_1068_ = v___y_1090_;
v___y_1069_ = v___y_1089_;
v___y_1070_ = v___x_1102_;
goto v___jp_1064_;
}
}
v___jp_1103_:
{
lean_object* v___x_1104_; lean_object* v___x_1105_; uint8_t v___x_1106_; 
v___x_1104_ = lean_unsigned_to_nat(1024u);
v___x_1105_ = lean_unsigned_to_nat(1023u);
v___x_1106_ = l_Nat_testBit(v_x_485_, v___x_1105_);
if (v___x_1106_ == 0)
{
lean_object* v___x_1107_; lean_object* v___x_1108_; uint8_t v___x_1109_; lean_object* v___x_1110_; lean_object* v___x_1111_; lean_object* v_exponent_1112_; lean_object* v___x_1113_; lean_object* v_fraction_1114_; lean_object* v___x_1115_; uint8_t v___x_1116_; 
v___x_1107_ = lean_unsigned_to_nat(1u);
v___x_1108_ = lean_unsigned_to_nat(2u);
v___x_1109_ = 1;
v___x_1110_ = lean_nat_shiftr(v_x_485_, v___x_486_);
v___x_1111_ = lean_unsigned_to_nat(524287u);
v_exponent_1112_ = lean_nat_land(v___x_1110_, v___x_1111_);
lean_dec(v___x_1110_);
v___x_1113_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__6, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__6_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__6);
v_fraction_1114_ = lean_nat_land(v_x_485_, v___x_1113_);
lean_dec(v_x_485_);
v___x_1115_ = lean_unsigned_to_nat(0u);
v___x_1116_ = lean_nat_dec_eq(v_exponent_1112_, v___x_1115_);
if (v___x_1116_ == 0)
{
lean_object* v___x_1117_; lean_object* v___x_1118_; 
v___x_1117_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__7, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__7_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__7);
v___x_1118_ = lean_nat_add(v___x_1117_, v_fraction_1114_);
lean_dec(v_fraction_1114_);
v___y_1085_ = v___x_1108_;
v___y_1086_ = v___x_1104_;
v___y_1087_ = v_exponent_1112_;
v___y_1088_ = v___x_1107_;
v___y_1089_ = v___x_1109_;
v___y_1090_ = v___x_1118_;
goto v___jp_1084_;
}
else
{
v___y_1085_ = v___x_1108_;
v___y_1086_ = v___x_1104_;
v___y_1087_ = v_exponent_1112_;
v___y_1088_ = v___x_1107_;
v___y_1089_ = v___x_1109_;
v___y_1090_ = v_fraction_1114_;
goto v___jp_1084_;
}
}
else
{
lean_object* v___x_1119_; 
lean_dec(v_x_485_);
v___x_1119_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__13, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__13_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__13);
return v___x_1119_;
}
}
v___jp_1120_:
{
lean_object* v___x_1121_; lean_object* v___x_1122_; lean_object* v___x_1123_; lean_object* v___x_1124_; uint8_t v___x_1125_; 
v___x_1121_ = lean_nat_shiftr(v_x_485_, v___x_486_);
v___x_1122_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__14, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__14_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__14);
v___x_1123_ = lean_nat_land(v___x_1121_, v___x_1122_);
lean_dec(v___x_1121_);
v___x_1124_ = lean_unsigned_to_nat(0u);
v___x_1125_ = lean_nat_dec_eq(v___x_1123_, v___x_1124_);
lean_dec(v___x_1123_);
if (v___x_1125_ == 0)
{
goto v___jp_1103_;
}
else
{
lean_object* v___x_1126_; lean_object* v___x_1127_; uint8_t v___x_1128_; 
v___x_1126_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__16, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__16_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__16);
v___x_1127_ = lean_nat_land(v_x_485_, v___x_1126_);
v___x_1128_ = lean_nat_dec_eq(v___x_1127_, v___x_1124_);
lean_dec(v___x_1127_);
if (v___x_1128_ == 0)
{
goto v___jp_1103_;
}
else
{
return v_x_485_;
}
}
}
v___jp_1129_:
{
uint8_t v___x_1131_; 
v___x_1131_ = l_Option_decidableEqNone___redArg(v___y_1130_);
if (v___x_1131_ == 0)
{
lean_object* v_val_1132_; 
lean_dec(v_x_485_);
v_val_1132_ = lean_ctor_get(v___y_1130_, 0);
lean_inc(v_val_1132_);
lean_dec(v___y_1130_);
return v_val_1132_;
}
else
{
lean_object* v___x_1133_; lean_object* v___x_1134_; lean_object* v___x_1135_; lean_object* v___x_1136_; uint8_t v___x_1137_; 
lean_dec(v___y_1130_);
v___x_1133_ = lean_nat_shiftr(v_x_485_, v___x_486_);
v___x_1134_ = lean_unsigned_to_nat(524287u);
v___x_1135_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__14, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__14_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__14);
v___x_1136_ = lean_nat_land(v___x_1133_, v___x_1135_);
lean_dec(v___x_1133_);
v___x_1137_ = lean_nat_dec_eq(v___x_1136_, v___x_1134_);
lean_dec(v___x_1136_);
if (v___x_1137_ == 0)
{
goto v___jp_1120_;
}
else
{
lean_object* v___x_1138_; lean_object* v___x_1139_; lean_object* v___x_1140_; uint8_t v___x_1141_; 
v___x_1138_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__16, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__16_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__16);
v___x_1139_ = lean_nat_land(v_x_485_, v___x_1138_);
v___x_1140_ = lean_unsigned_to_nat(0u);
v___x_1141_ = lean_nat_dec_eq(v___x_1139_, v___x_1140_);
lean_dec(v___x_1139_);
if (v___x_1141_ == 0)
{
goto v___jp_1120_;
}
else
{
lean_object* v___x_1142_; uint8_t v___x_1143_; 
v___x_1142_ = lean_unsigned_to_nat(1023u);
v___x_1143_ = l_Nat_testBit(v_x_485_, v___x_1142_);
lean_dec(v_x_485_);
if (v___x_1143_ == 0)
{
if (v___x_1143_ == 0)
{
lean_object* v___x_1144_; 
v___x_1144_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__10, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__10_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__10);
return v___x_1144_;
}
else
{
lean_object* v___x_1145_; 
v___x_1145_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__19, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__19_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__19);
return v___x_1145_;
}
}
else
{
lean_object* v___x_1146_; 
v___x_1146_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__13, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__13_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__13);
return v___x_1146_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1(lean_object* v_x_1163_){
_start:
{
lean_object* v___x_1164_; 
v___x_1164_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2(v_x_1163_);
return v___x_1164_;
}
}
static lean_object* _init_l_BalancedSqrt_block1024___closed__4(void){
_start:
{
lean_object* v___x_1181_; uint8_t v___x_1182_; lean_object* v___x_1183_; lean_object* v___x_1184_; 
v___x_1181_ = ((lean_object*)(l_BalancedSqrt_block1024___closed__3));
v___x_1182_ = 5;
v___x_1183_ = ((lean_object*)(l_BalancedSqrt_block1024___closed__0));
v___x_1184_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep_configuredBenchmarkCarrier(v___x_1183_, v___x_1182_, v___x_1181_);
return v___x_1184_;
}
}
static lean_object* _init_l_BalancedSqrt_block1024___closed__5(void){
_start:
{
lean_object* v___x_1185_; lean_object* v___x_1186_; 
v___x_1185_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__4, &l_BalancedSqrt_block1024___closed__4_once, _init_l_BalancedSqrt_block1024___closed__4);
v___x_1186_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep_benchmarkExecFloatInhabited___redArg(v___x_1185_);
return v___x_1186_;
}
}
static uint8_t _init_l_BalancedSqrt_block1024___closed__6(void){
_start:
{
uint8_t v___x_1187_; uint8_t v___x_1188_; lean_object* v___x_1189_; lean_object* v___x_1190_; uint8_t v___x_1191_; 
v___x_1187_ = 4;
v___x_1188_ = 5;
v___x_1189_ = lp_floatlib_FloatLib_Floats_ExecFloat_Backend_Policy_throughput;
v___x_1190_ = ((lean_object*)(l_BalancedSqrt_block1024___closed__0));
v___x_1191_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Plan_firstOrderSelected(v___x_1190_, v___x_1189_, v___x_1188_, v___x_1187_);
return v___x_1191_;
}
}
static uint8_t _init_l_BalancedSqrt_block1024___closed__7(void){
_start:
{
uint8_t v___x_1192_; uint8_t v___x_1193_; lean_object* v___x_1194_; lean_object* v___x_1195_; uint8_t v___x_1196_; 
v___x_1192_ = 4;
v___x_1193_ = 5;
v___x_1194_ = lp_floatlib_FloatLib_Floats_ExecFloat_Backend_Policy_throughput;
v___x_1195_ = ((lean_object*)(l_BalancedSqrt_block1024___closed__0));
v___x_1196_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Plan_firstOrderGenericSelected(v___x_1195_, v___x_1194_, v___x_1193_, v___x_1192_);
return v___x_1196_;
}
}
static lean_object* _init_l_BalancedSqrt_block1024___closed__9(void){
_start:
{
lean_object* v___f_1201_; lean_object* v_selection_1202_; 
v___f_1201_ = ((lean_object*)(l_BalancedSqrt_block1024___closed__8));
v_selection_1202_ = lean_mk_thunk(v___f_1201_);
return v_selection_1202_;
}
}
static lean_object* _init_l_BalancedSqrt_block1024___closed__10(void){
_start:
{
lean_object* v_selection_1203_; lean_object* v___x_1204_; 
v_selection_1203_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__9, &l_BalancedSqrt_block1024___closed__9_once, _init_l_BalancedSqrt_block1024___closed__9);
v___x_1204_ = lean_thunk_get_own(v_selection_1203_);
return v___x_1204_;
}
}
static lean_object* _init_l_BalancedSqrt_block1024___closed__11(void){
_start:
{
uint8_t v___x_1205_; lean_object* v___x_1206_; lean_object* v___x_1207_; 
v___x_1205_ = 4;
v___x_1206_ = ((lean_object*)(l_BalancedSqrt_block1024___closed__0));
v___x_1207_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Descriptor_Plan_structuralRoute_x3f(v___x_1206_, v___x_1205_);
return v___x_1207_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_block1024(lean_object* v_x_1208_, uint64_t v_x_1209_, lean_object* v_x_1210_, lean_object* v_x_1211_){
_start:
{
lean_object* v_zero_1212_; uint8_t v_isZero_1213_; 
v_zero_1212_ = lean_unsigned_to_nat(0u);
v_isZero_1213_ = lean_nat_dec_eq(v_x_1208_, v_zero_1212_);
if (v_isZero_1213_ == 1)
{
lean_dec(v_x_1208_);
return v_x_1211_;
}
else
{
uint64_t v_sink_1214_; uint64_t v_trace_1215_; lean_object* v___x_1217_; uint8_t v_isShared_1218_; uint8_t v_isSharedCheck_1253_; 
v_sink_1214_ = lean_ctor_get_uint64(v_x_1211_, 0);
v_trace_1215_ = lean_ctor_get_uint64(v_x_1211_, 8);
v_isSharedCheck_1253_ = !lean_is_exclusive(v_x_1211_);
if (v_isSharedCheck_1253_ == 0)
{
v___x_1217_ = v_x_1211_;
v_isShared_1218_ = v_isSharedCheck_1253_;
goto v_resetjp_1216_;
}
else
{
lean_dec(v_x_1211_);
v___x_1217_ = lean_box(0);
v_isShared_1218_ = v_isSharedCheck_1253_;
goto v_resetjp_1216_;
}
v_resetjp_1216_:
{
lean_object* v_one_1219_; lean_object* v_n_1220_; lean_object* v_index_1221_; lean_object* v___y_1223_; lean_object* v___y_1239_; lean_object* v___x_1241_; lean_object* v___x_1242_; uint8_t v___x_1243_; 
v_one_1219_ = lean_unsigned_to_nat(1u);
v_n_1220_ = lean_nat_sub(v_x_1208_, v_one_1219_);
lean_dec(v_x_1208_);
v_index_1221_ = l_BalancedSqrt_nextUnused(v_x_1209_, v_sink_1214_);
v___x_1241_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__5, &l_BalancedSqrt_block1024___closed__5_once, _init_l_BalancedSqrt_block1024___closed__5);
v___x_1242_ = lean_array_get_borrowed(v___x_1241_, v_x_1210_, v_index_1221_);
v___x_1243_ = lean_uint8_once(&l_BalancedSqrt_block1024___closed__6, &l_BalancedSqrt_block1024___closed__6_once, _init_l_BalancedSqrt_block1024___closed__6);
if (v___x_1243_ == 0)
{
uint8_t v___x_1244_; 
v___x_1244_ = lean_uint8_once(&l_BalancedSqrt_block1024___closed__7, &l_BalancedSqrt_block1024___closed__7_once, _init_l_BalancedSqrt_block1024___closed__7);
if (v___x_1244_ == 0)
{
lean_object* v___x_1245_; lean_object* v_run_1246_; lean_object* v___x_1247_; 
v___x_1245_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__10, &l_BalancedSqrt_block1024___closed__10_once, _init_l_BalancedSqrt_block1024___closed__10);
v_run_1246_ = lean_ctor_get(v___x_1245_, 1);
lean_inc(v_run_1246_);
lean_inc(v___x_1242_);
v___x_1247_ = lean_apply_1(v_run_1246_, v___x_1242_);
v___y_1223_ = v___x_1247_;
goto v___jp_1222_;
}
else
{
lean_object* v___x_1248_; 
lean_inc(v___x_1242_);
v___x_1248_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2(v___x_1242_);
v___y_1223_ = v___x_1248_;
goto v___jp_1222_;
}
}
else
{
lean_object* v___x_1249_; 
v___x_1249_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__11, &l_BalancedSqrt_block1024___closed__11_once, _init_l_BalancedSqrt_block1024___closed__11);
if (lean_obj_tag(v___x_1249_) == 1)
{
lean_object* v_val_1250_; uint8_t v___x_1251_; 
v_val_1250_ = lean_ctor_get(v___x_1249_, 0);
v___x_1251_ = lean_unbox(v_val_1250_);
if (v___x_1251_ == 2)
{
lean_object* v___x_1252_; 
lean_inc(v___x_1242_);
v___x_1252_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2(v___x_1242_);
v___y_1223_ = v___x_1252_;
goto v___jp_1222_;
}
else
{
lean_inc(v___x_1242_);
v___y_1239_ = v___x_1242_;
goto v___jp_1238_;
}
}
else
{
lean_inc(v___x_1242_);
v___y_1239_ = v___x_1242_;
goto v___jp_1238_;
}
}
v___jp_1222_:
{
uint64_t v___x_1224_; uint64_t v___x_1225_; uint64_t v___x_1226_; uint64_t v___x_1227_; uint64_t v___x_1228_; uint64_t v___x_1229_; uint64_t v___x_1230_; uint64_t v___x_1231_; uint64_t v___x_1232_; uint64_t v___x_1233_; lean_object* v___x_1235_; 
v___x_1224_ = 1ULL;
v___x_1225_ = lean_uint64_of_nat(v_index_1221_);
lean_dec(v_index_1221_);
v___x_1226_ = lean_uint64_shift_left(v___x_1224_, v___x_1225_);
v___x_1227_ = lean_uint64_lor(v_x_1209_, v___x_1226_);
v___x_1228_ = lean_uint64_of_nat(v___y_1223_);
lean_dec(v___y_1223_);
v___x_1229_ = lean_uint64_xor(v_sink_1214_, v___x_1228_);
v___x_1230_ = 1099511628211ULL;
v___x_1231_ = lean_uint64_mul(v___x_1229_, v___x_1230_);
v___x_1232_ = lean_uint64_xor(v_trace_1215_, v___x_1225_);
v___x_1233_ = lean_uint64_mul(v___x_1232_, v___x_1230_);
if (v_isShared_1218_ == 0)
{
v___x_1235_ = v___x_1217_;
goto v_reusejp_1234_;
}
else
{
lean_object* v_reuseFailAlloc_1237_; 
v_reuseFailAlloc_1237_ = lean_alloc_ctor(0, 0, 16);
v___x_1235_ = v_reuseFailAlloc_1237_;
goto v_reusejp_1234_;
}
v_reusejp_1234_:
{
lean_ctor_set_uint64(v___x_1235_, 0, v___x_1231_);
lean_ctor_set_uint64(v___x_1235_, 8, v___x_1233_);
v_x_1208_ = v_n_1220_;
v_x_1209_ = v___x_1227_;
v_x_1211_ = v___x_1235_;
goto _start;
}
}
v___jp_1238_:
{
lean_object* v___x_1240_; 
v___x_1240_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2(v___y_1239_);
v___y_1223_ = v___x_1240_;
goto v___jp_1222_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_block1024___boxed(lean_object* v_x_1254_, lean_object* v_x_1255_, lean_object* v_x_1256_, lean_object* v_x_1257_){
_start:
{
uint64_t v_x_27274__boxed_1258_; lean_object* v_res_1259_; 
v_x_27274__boxed_1258_ = lean_unbox_uint64(v_x_1255_);
lean_dec_ref(v_x_1255_);
v_res_1259_ = l_BalancedSqrt_block1024(v_x_1254_, v_x_27274__boxed_1258_, v_x_1256_, v_x_1257_);
lean_dec_ref(v_x_1256_);
return v_res_1259_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block2048_spec__2___redArg(){
_start:
{
lean_object* v___x_1261_; 
v___x_1261_ = lean_box(0);
return v___x_1261_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block2048_spec__2___redArg___boxed(lean_object* v___dummy_1262_){
_start:
{
lean_object* v_res_1263_; 
v_res_1263_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block2048_spec__2___redArg();
return v_res_1263_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block2048_spec__2(lean_object* v_x_1264_){
_start:
{
lean_object* v___x_1265_; 
v___x_1265_ = lean_box(0);
return v___x_1265_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block2048_spec__2___boxed(lean_object* v_x_1266_){
_start:
{
lean_object* v_res_1267_; 
v_res_1267_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block2048_spec__2(v_x_1266_);
lean_dec(v_x_1266_);
return v_res_1267_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__1(void){
_start:
{
lean_object* v___x_1271_; lean_object* v___x_1272_; 
v___x_1271_ = lean_unsigned_to_nat(2028u);
v___x_1272_ = lean_nat_to_int(v___x_1271_);
return v___x_1272_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__2(void){
_start:
{
lean_object* v___x_1273_; 
v___x_1273_ = lean_cstr_to_nat("30819898673354155827250363053007080040401556653705104858522744586491255892627612012097550784609712089241712532922647494787330207014552041144455101381729395981436612479496952144384572744741108042522485388168399399067680567400569683229292005861736460180837293483768754046332908526936593826873352431415491471788324674024265615864453291689457482809883285556150743539884381923037553971012554468298204987396409146047538379400693757398222304489423414139178941357835089904048085865698642930722386457182818721265486280995041559157415387409546850813117528120412289939445116172250012974400824049572899006074481824503955455");
return v___x_1273_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__3(void){
_start:
{
lean_object* v___x_1274_; 
v___x_1274_ = lean_cstr_to_nat("30819898673354155827250363053007080040401556653705104858522744586491255892627612012097550784609712089241712532922647494787330207014552041144455101381729395981436612479496952144384572744741108042522485388168399399067680567400569683229292005861736460180837293483768754046332908526936593826873352431415491471788324674024265615864453291689457482809883285556150743539884381923037553971012554468298204987396409146047538379400693757398222304489423414139178941357835089904048085865698642930722386457182818721265486280995041559157415387409546850813117528120412289939445116172250012974400824049572899006074481824503955456");
return v___x_1274_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__4(void){
_start:
{
lean_object* v___x_1275_; lean_object* v___x_1276_; lean_object* v___x_1277_; 
v___x_1275_ = lean_unsigned_to_nat(2028u);
v___x_1276_ = lean_unsigned_to_nat(2u);
v___x_1277_ = lean_nat_pow(v___x_1276_, v___x_1275_);
return v___x_1277_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__5(void){
_start:
{
lean_object* v___x_1278_; lean_object* v___x_1279_; lean_object* v___x_1280_; 
v___x_1278_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__4, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__4_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__4);
v___x_1279_ = lean_unsigned_to_nat(524287u);
v___x_1280_ = lean_nat_mul(v___x_1279_, v___x_1278_);
return v___x_1280_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__6(void){
_start:
{
lean_object* v___x_1281_; lean_object* v___x_1282_; lean_object* v___x_1283_; 
v___x_1281_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__5, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__5_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__5);
v___x_1282_ = lean_unsigned_to_nat(2048u);
v___x_1283_ = l_BitVec_ofNat(v___x_1282_, v___x_1281_);
return v___x_1283_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__7(void){
_start:
{
lean_object* v___x_1284_; lean_object* v___x_1285_; lean_object* v___x_1286_; 
v___x_1284_ = lean_unsigned_to_nat(2027u);
v___x_1285_ = lean_unsigned_to_nat(2u);
v___x_1286_ = lean_nat_pow(v___x_1285_, v___x_1284_);
return v___x_1286_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__8(void){
_start:
{
lean_object* v___x_1287_; lean_object* v___x_1288_; lean_object* v___x_1289_; 
v___x_1287_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__7, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__7_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__7);
v___x_1288_ = lean_unsigned_to_nat(2048u);
v___x_1289_ = l_BitVec_ofNat(v___x_1288_, v___x_1287_);
return v___x_1289_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__9(void){
_start:
{
lean_object* v___x_1290_; lean_object* v___x_1291_; lean_object* v___x_1292_; 
v___x_1290_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__8, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__8_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__8);
v___x_1291_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__6, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__6_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__6);
v___x_1292_ = lean_nat_lor(v___x_1291_, v___x_1290_);
return v___x_1292_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__10(void){
_start:
{
lean_object* v___x_1293_; lean_object* v___x_1294_; lean_object* v___x_1295_; 
v___x_1293_ = lean_unsigned_to_nat(524287u);
v___x_1294_ = lean_unsigned_to_nat(2048u);
v___x_1295_ = l_BitVec_ofNat(v___x_1294_, v___x_1293_);
return v___x_1295_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__11(void){
_start:
{
lean_object* v___x_1296_; lean_object* v___x_1297_; lean_object* v___x_1298_; 
v___x_1296_ = lean_unsigned_to_nat(1u);
v___x_1297_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__4, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__4_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__4);
v___x_1298_ = lean_nat_sub(v___x_1297_, v___x_1296_);
return v___x_1298_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__12(void){
_start:
{
lean_object* v___x_1299_; lean_object* v___x_1300_; lean_object* v___x_1301_; 
v___x_1299_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__11, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__11_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__11);
v___x_1300_ = lean_unsigned_to_nat(2048u);
v___x_1301_ = l_BitVec_ofNat(v___x_1300_, v___x_1299_);
return v___x_1301_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__13(void){
_start:
{
lean_object* v___x_1302_; lean_object* v___x_1303_; lean_object* v___x_1304_; 
v___x_1302_ = lean_unsigned_to_nat(2047u);
v___x_1303_ = lean_unsigned_to_nat(2u);
v___x_1304_ = lean_nat_pow(v___x_1303_, v___x_1302_);
return v___x_1304_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__14(void){
_start:
{
lean_object* v___x_1305_; lean_object* v___x_1306_; lean_object* v___x_1307_; 
v___x_1305_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__13, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__13_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__13);
v___x_1306_ = lean_unsigned_to_nat(2048u);
v___x_1307_ = l_BitVec_ofNat(v___x_1306_, v___x_1305_);
return v___x_1307_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__15(void){
_start:
{
lean_object* v___x_1308_; lean_object* v___x_1309_; lean_object* v___x_1310_; 
v___x_1308_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__6, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__6_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__6);
v___x_1309_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__14, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__14_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__14);
v___x_1310_ = lean_nat_lor(v___x_1309_, v___x_1308_);
return v___x_1310_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1(lean_object* v_x_1311_){
_start:
{
lean_object* v___x_1312_; lean_object* v___y_1314_; lean_object* v___y_1318_; lean_object* v___y_1319_; lean_object* v___y_1320_; lean_object* v___y_1321_; uint8_t v___y_1322_; lean_object* v___y_1323_; lean_object* v___y_1336_; lean_object* v___y_1337_; lean_object* v___y_1338_; lean_object* v___y_1339_; uint8_t v___y_1340_; lean_object* v___y_1341_; lean_object* v___y_1342_; uint64_t v___y_1354_; lean_object* v___y_1355_; lean_object* v___y_1356_; lean_object* v___y_1357_; lean_object* v___y_1358_; lean_object* v___y_1359_; uint8_t v___y_1360_; lean_object* v___y_1361_; uint64_t v___y_1362_; uint64_t v___y_1363_; uint64_t v___y_1372_; uint64_t v___y_1373_; lean_object* v___y_1374_; lean_object* v___y_1375_; lean_object* v___y_1376_; lean_object* v___y_1377_; lean_object* v___y_1378_; uint8_t v___y_1379_; lean_object* v___y_1380_; uint64_t v___y_1381_; uint64_t v___y_1382_; uint64_t v___y_1386_; lean_object* v___y_1387_; uint64_t v___y_1388_; lean_object* v___y_1389_; lean_object* v___y_1390_; lean_object* v___y_1391_; lean_object* v___y_1392_; uint8_t v___y_1393_; lean_object* v___y_1394_; uint64_t v___y_1395_; uint8_t v___y_1396_; uint64_t v___y_1397_; uint64_t v___y_1399_; lean_object* v___y_1400_; lean_object* v___y_1401_; uint8_t v___y_1402_; lean_object* v___y_1403_; uint64_t v___y_1404_; uint64_t v___y_1405_; uint64_t v___y_1406_; uint64_t v___y_1407_; lean_object* v___y_1408_; lean_object* v___y_1409_; lean_object* v___y_1410_; uint64_t v___y_1411_; uint64_t v___y_1412_; uint64_t v___y_1419_; lean_object* v___y_1420_; lean_object* v___y_1421_; uint8_t v___y_1422_; lean_object* v___y_1423_; uint64_t v___y_1424_; uint64_t v___y_1425_; uint64_t v___y_1426_; lean_object* v___y_1427_; uint64_t v___y_1428_; lean_object* v___y_1429_; lean_object* v___y_1430_; uint8_t v___y_1431_; uint64_t v___y_1432_; uint64_t v___y_1433_; uint64_t v___y_1434_; uint64_t v___y_1436_; lean_object* v___y_1437_; lean_object* v___y_1438_; uint8_t v___y_1439_; lean_object* v___y_1440_; uint64_t v___y_1441_; uint64_t v___y_1442_; uint64_t v___y_1443_; uint64_t v___y_1444_; lean_object* v___y_1445_; uint64_t v___y_1446_; lean_object* v___y_1447_; lean_object* v___y_1448_; uint64_t v___y_1449_; uint64_t v___y_1450_; uint64_t v___y_1454_; lean_object* v___y_1455_; lean_object* v___y_1456_; uint8_t v___y_1457_; lean_object* v___y_1458_; uint64_t v___y_1459_; uint64_t v___y_1460_; uint64_t v___y_1461_; uint64_t v___y_1462_; lean_object* v___y_1463_; uint64_t v___y_1464_; uint64_t v___y_1465_; lean_object* v___y_1466_; lean_object* v___y_1467_; uint8_t v___y_1468_; uint64_t v___y_1469_; uint64_t v___y_1470_; uint64_t v___y_1472_; lean_object* v___y_1473_; lean_object* v___y_1474_; uint8_t v___y_1475_; lean_object* v___y_1476_; uint64_t v___y_1477_; uint64_t v___y_1478_; uint64_t v___y_1479_; lean_object* v___y_1480_; uint64_t v___y_1481_; lean_object* v___y_1482_; lean_object* v___y_1483_; uint64_t v___y_1484_; uint64_t v___y_1485_; uint64_t v___y_1486_; uint64_t v___y_1490_; lean_object* v___y_1491_; lean_object* v___y_1492_; uint8_t v___y_1493_; lean_object* v___y_1494_; uint8_t v___y_1495_; uint64_t v___y_1496_; uint64_t v___y_1497_; uint64_t v___y_1498_; uint64_t v___y_1499_; uint64_t v___y_1500_; lean_object* v___y_1501_; uint64_t v___y_1502_; lean_object* v___y_1503_; lean_object* v___y_1504_; uint64_t v___y_1505_; uint64_t v___y_1506_; uint64_t v___y_1508_; lean_object* v___y_1509_; lean_object* v___y_1510_; uint8_t v___y_1511_; lean_object* v___y_1512_; uint64_t v___y_1513_; uint64_t v___y_1514_; uint64_t v___y_1515_; lean_object* v___y_1516_; uint64_t v___y_1517_; lean_object* v___y_1518_; lean_object* v___y_1519_; uint64_t v___y_1520_; uint64_t v___y_1521_; uint64_t v___y_1522_; uint64_t v___y_1526_; uint8_t v___y_1527_; lean_object* v___y_1528_; lean_object* v___y_1529_; uint8_t v___y_1530_; uint64_t v___y_1531_; lean_object* v___y_1532_; uint64_t v___y_1533_; uint64_t v___y_1534_; lean_object* v___y_1535_; uint64_t v___y_1536_; lean_object* v___y_1537_; lean_object* v___y_1538_; uint64_t v___y_1539_; uint64_t v___y_1540_; uint64_t v___y_1541_; lean_object* v___y_1543_; lean_object* v___y_1544_; lean_object* v___y_1545_; lean_object* v___y_1546_; uint8_t v___y_1547_; lean_object* v___y_1548_; lean_object* v___y_1549_; lean_object* v___y_1550_; uint8_t v___y_1551_; lean_object* v___y_1552_; uint8_t v___y_1553_; uint8_t v___y_1554_; lean_object* v___y_1561_; lean_object* v___y_1562_; lean_object* v___y_1563_; lean_object* v___y_1564_; lean_object* v___y_1565_; lean_object* v___y_1566_; uint8_t v___y_1567_; lean_object* v___y_1568_; lean_object* v___y_1569_; uint8_t v___y_1570_; uint8_t v___y_1571_; lean_object* v___y_1572_; uint64_t v___y_1577_; lean_object* v___y_1578_; lean_object* v___y_1579_; uint8_t v___y_1580_; lean_object* v___y_1581_; uint64_t v___y_1582_; lean_object* v___y_1583_; lean_object* v___y_1584_; lean_object* v___y_1585_; lean_object* v___y_1586_; lean_object* v___y_1587_; uint8_t v___y_1588_; uint8_t v___y_1589_; uint64_t v___y_1590_; uint64_t v___y_1599_; uint64_t v___y_1600_; lean_object* v___y_1601_; lean_object* v___y_1602_; uint8_t v___y_1603_; lean_object* v___y_1604_; uint64_t v___y_1605_; uint64_t v___y_1606_; lean_object* v___y_1607_; lean_object* v___y_1608_; lean_object* v___y_1609_; lean_object* v___y_1610_; uint64_t v___y_1611_; uint64_t v___y_1612_; lean_object* v___y_1613_; uint8_t v___y_1614_; uint8_t v___y_1615_; uint64_t v___y_1616_; uint64_t v___y_1623_; lean_object* v___y_1624_; lean_object* v___y_1625_; uint8_t v___y_1626_; lean_object* v___y_1627_; uint64_t v___y_1628_; uint8_t v___y_1629_; uint64_t v___y_1630_; uint64_t v___y_1631_; lean_object* v___y_1632_; lean_object* v___y_1633_; lean_object* v___y_1634_; lean_object* v___y_1635_; uint64_t v___y_1636_; uint64_t v___y_1637_; uint64_t v___y_1638_; lean_object* v___y_1639_; uint8_t v___y_1640_; uint8_t v___y_1641_; uint64_t v___y_1642_; uint64_t v___y_1644_; uint64_t v___y_1645_; lean_object* v___y_1646_; lean_object* v___y_1647_; uint8_t v___y_1648_; lean_object* v___y_1649_; uint64_t v___y_1650_; uint64_t v___y_1651_; lean_object* v___y_1652_; lean_object* v___y_1653_; uint64_t v___y_1654_; lean_object* v___y_1655_; lean_object* v___y_1656_; uint64_t v___y_1657_; uint64_t v___y_1658_; lean_object* v___y_1659_; uint8_t v___y_1660_; uint8_t v___y_1661_; uint64_t v___y_1662_; uint64_t v___y_1666_; uint64_t v___y_1667_; uint64_t v___y_1668_; uint8_t v___y_1669_; lean_object* v___y_1670_; lean_object* v___y_1671_; uint8_t v___y_1672_; lean_object* v___y_1673_; uint64_t v___y_1674_; uint64_t v___y_1675_; uint64_t v___y_1676_; lean_object* v___y_1677_; lean_object* v___y_1678_; uint64_t v___y_1679_; lean_object* v___y_1680_; lean_object* v___y_1681_; uint64_t v___y_1682_; lean_object* v___y_1683_; uint8_t v___y_1684_; uint8_t v___y_1685_; uint64_t v___y_1686_; uint64_t v___y_1688_; uint64_t v___y_1689_; uint64_t v___y_1690_; lean_object* v___y_1691_; lean_object* v___y_1692_; uint8_t v___y_1693_; lean_object* v___y_1694_; uint64_t v___y_1695_; uint64_t v___y_1696_; lean_object* v___y_1697_; lean_object* v___y_1698_; lean_object* v___y_1699_; uint64_t v___y_1700_; lean_object* v___y_1701_; uint64_t v___y_1702_; lean_object* v___y_1703_; uint8_t v___y_1704_; uint8_t v___y_1705_; uint64_t v___y_1706_; uint64_t v___y_1710_; uint64_t v___y_1711_; uint64_t v___y_1712_; uint64_t v___y_1713_; lean_object* v___y_1714_; lean_object* v___y_1715_; uint8_t v___y_1716_; lean_object* v___y_1717_; uint64_t v___y_1718_; uint64_t v___y_1719_; uint64_t v___y_1720_; lean_object* v___y_1721_; lean_object* v___y_1722_; uint8_t v___y_1723_; lean_object* v___y_1724_; lean_object* v___y_1725_; uint64_t v___y_1726_; lean_object* v___y_1727_; uint8_t v___y_1728_; uint8_t v___y_1729_; uint64_t v___y_1730_; uint64_t v___y_1732_; uint64_t v___y_1733_; uint64_t v___y_1734_; lean_object* v___y_1735_; lean_object* v___y_1736_; uint8_t v___y_1737_; lean_object* v___y_1738_; uint64_t v___y_1739_; uint64_t v___y_1740_; lean_object* v___y_1741_; lean_object* v___y_1742_; lean_object* v___y_1743_; lean_object* v___y_1744_; uint64_t v___y_1745_; lean_object* v___y_1746_; uint8_t v___y_1747_; uint8_t v___y_1748_; uint64_t v___y_1749_; uint64_t v___y_1750_; uint64_t v___y_1754_; uint8_t v___y_1755_; uint64_t v___y_1756_; uint64_t v___y_1757_; lean_object* v___y_1758_; lean_object* v___y_1759_; uint8_t v___y_1760_; lean_object* v___y_1761_; uint64_t v___y_1762_; lean_object* v___y_1763_; lean_object* v___y_1764_; lean_object* v___y_1765_; lean_object* v___y_1766_; uint64_t v___y_1767_; lean_object* v___y_1768_; uint8_t v___y_1769_; uint64_t v___y_1770_; uint64_t v___y_1771_; uint8_t v___y_1772_; uint64_t v___y_1773_; uint64_t v___y_1775_; lean_object* v___y_1776_; lean_object* v___y_1777_; uint8_t v___y_1778_; lean_object* v___y_1779_; uint64_t v___y_1780_; uint64_t v___y_1781_; lean_object* v___y_1782_; lean_object* v___y_1783_; lean_object* v___y_1784_; lean_object* v___y_1785_; lean_object* v___y_1786_; uint8_t v___y_1787_; uint8_t v___y_1788_; uint64_t v___y_1789_; uint64_t v___y_1793_; lean_object* v___y_1794_; lean_object* v___y_1795_; uint8_t v___y_1796_; lean_object* v___y_1797_; uint64_t v___y_1798_; uint64_t v___y_1799_; lean_object* v___y_1800_; lean_object* v___y_1801_; lean_object* v___y_1802_; lean_object* v___y_1803_; lean_object* v___y_1804_; uint8_t v___y_1805_; uint8_t v___y_1806_; uint8_t v___y_1807_; uint64_t v___y_1808_; lean_object* v___y_1810_; lean_object* v___y_1811_; lean_object* v___y_1812_; lean_object* v___y_1813_; uint8_t v___y_1814_; lean_object* v___y_1815_; lean_object* v___y_1816_; lean_object* v___y_1817_; uint8_t v___y_1818_; uint8_t v___y_1819_; lean_object* v___y_1820_; lean_object* v___y_1891_; lean_object* v___y_1892_; lean_object* v___y_1893_; lean_object* v___y_1894_; uint8_t v___y_1895_; lean_object* v___y_1896_; lean_object* v___y_1911_; lean_object* v___y_1912_; lean_object* v___y_1913_; lean_object* v___y_1914_; uint8_t v___y_1915_; lean_object* v___y_1916_; lean_object* v___y_1956_; lean_object* v___x_1973_; lean_object* v___x_1974_; lean_object* v___x_1975_; lean_object* v___x_1976_; uint8_t v___x_1977_; 
v___x_1312_ = lean_unsigned_to_nat(2028u);
v___x_1973_ = lean_nat_shiftr(v_x_1311_, v___x_1312_);
v___x_1974_ = lean_unsigned_to_nat(524287u);
v___x_1975_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__10, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__10_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__10);
v___x_1976_ = lean_nat_land(v___x_1973_, v___x_1975_);
lean_dec(v___x_1973_);
v___x_1977_ = lean_nat_dec_eq(v___x_1976_, v___x_1974_);
lean_dec(v___x_1976_);
if (v___x_1977_ == 0)
{
lean_object* v___x_1978_; 
v___x_1978_ = lean_box(0);
v___y_1956_ = v___x_1978_;
goto v___jp_1955_;
}
else
{
lean_object* v___x_1979_; lean_object* v___x_1980_; lean_object* v___x_1981_; uint8_t v___x_1982_; 
v___x_1979_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__12, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__12_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__12);
v___x_1980_ = lean_nat_land(v_x_1311_, v___x_1979_);
v___x_1981_ = lean_unsigned_to_nat(0u);
v___x_1982_ = lean_nat_dec_eq(v___x_1980_, v___x_1981_);
lean_dec(v___x_1980_);
if (v___x_1982_ == 0)
{
if (v___x_1977_ == 0)
{
lean_object* v___x_1983_; 
lean_inc(v_x_1311_);
v___x_1983_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1983_, 0, v_x_1311_);
v___y_1956_ = v___x_1983_;
goto v___jp_1955_;
}
else
{
if (v___x_1982_ == 0)
{
lean_object* v___x_1984_; lean_object* v___x_1985_; lean_object* v___x_1986_; 
v___x_1984_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__8, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__8_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__8);
v___x_1985_ = lean_nat_lor(v_x_1311_, v___x_1984_);
v___x_1986_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1986_, 0, v___x_1985_);
v___y_1956_ = v___x_1986_;
goto v___jp_1955_;
}
else
{
lean_object* v___x_1987_; 
lean_inc(v_x_1311_);
v___x_1987_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1987_, 0, v_x_1311_);
v___y_1956_ = v___x_1987_;
goto v___jp_1955_;
}
}
}
else
{
lean_object* v___x_1988_; 
v___x_1988_ = lean_box(0);
v___y_1956_ = v___x_1988_;
goto v___jp_1955_;
}
}
v___jp_1313_:
{
lean_object* v___x_1315_; lean_object* v___x_1316_; 
v___x_1315_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__0));
v___x_1316_ = l_Float_Model_UnpackedFloat_pack(v___x_1315_, v___y_1314_);
lean_dec(v___y_1314_);
return v___x_1316_;
}
v___jp_1317_:
{
lean_object* v_rounded_1324_; lean_object* v___x_1325_; lean_object* v___x_1326_; lean_object* v___x_1327_; lean_object* v___x_1328_; lean_object* v_fst_1329_; lean_object* v_snd_1330_; lean_object* v_mantissa_1331_; uint8_t v___x_1332_; 
v_rounded_1324_ = l_Float_Model_UnpackedFloat_ExtendedMantissa_roundedMantissa(v___y_1323_);
lean_dec_ref(v___y_1323_);
v___x_1325_ = lean_nat_to_int(v___y_1318_);
v___x_1326_ = lean_int_add(v___y_1320_, v___x_1325_);
lean_dec(v___x_1325_);
lean_dec(v___y_1320_);
v___x_1327_ = lean_box(0);
v___x_1328_ = l_Float_Model_UnpackedFloat_shiftToTargetExponent(v___y_1319_, v_rounded_1324_, v___x_1326_, v___x_1327_);
lean_dec(v___x_1326_);
v_fst_1329_ = lean_ctor_get(v___x_1328_, 0);
lean_inc(v_fst_1329_);
v_snd_1330_ = lean_ctor_get(v___x_1328_, 1);
lean_inc(v_snd_1330_);
lean_dec_ref(v___x_1328_);
v_mantissa_1331_ = lean_ctor_get(v_fst_1329_, 0);
lean_inc(v_mantissa_1331_);
lean_dec(v_fst_1329_);
v___x_1332_ = lean_nat_dec_eq(v_mantissa_1331_, v___y_1321_);
if (v___x_1332_ == 0)
{
lean_object* v___x_1333_; 
v___x_1333_ = lean_alloc_ctor(3, 2, 1);
lean_ctor_set(v___x_1333_, 0, v_mantissa_1331_);
lean_ctor_set(v___x_1333_, 1, v_snd_1330_);
lean_ctor_set_uint8(v___x_1333_, sizeof(void*)*2, v___y_1322_);
v___y_1314_ = v___x_1333_;
goto v___jp_1313_;
}
else
{
lean_object* v___x_1334_; 
lean_dec(v_mantissa_1331_);
lean_dec(v_snd_1330_);
v___x_1334_ = lean_alloc_ctor(2, 0, 1);
lean_ctor_set_uint8(v___x_1334_, 0, v___y_1322_);
v___y_1314_ = v___x_1334_;
goto v___jp_1313_;
}
}
v___jp_1335_:
{
lean_object* v___x_1343_; lean_object* v_remainder_1344_; uint8_t v___x_1345_; 
v___x_1343_ = lean_nat_mul(v___y_1342_, v___y_1342_);
v_remainder_1344_ = lean_nat_sub(v___y_1341_, v___x_1343_);
lean_dec(v___x_1343_);
lean_dec(v___y_1341_);
v___x_1345_ = lean_nat_dec_eq(v_remainder_1344_, v___y_1339_);
if (v___x_1345_ == 0)
{
uint8_t v___x_1346_; 
v___x_1346_ = lean_nat_dec_le(v_remainder_1344_, v___y_1342_);
lean_dec(v_remainder_1344_);
if (v___x_1346_ == 0)
{
lean_object* v___x_1347_; lean_object* v___x_1348_; 
v___x_1347_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__1));
v___x_1348_ = l_Float_Model_UnpackedFloat_ExtendedMantissa_ofMantissaAndAccuracy(v___y_1342_, v___x_1347_);
v___y_1318_ = v___y_1336_;
v___y_1319_ = v___y_1338_;
v___y_1320_ = v___y_1337_;
v___y_1321_ = v___y_1339_;
v___y_1322_ = v___y_1340_;
v___y_1323_ = v___x_1348_;
goto v___jp_1317_;
}
else
{
lean_object* v___x_1349_; lean_object* v___x_1350_; 
v___x_1349_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__2));
v___x_1350_ = l_Float_Model_UnpackedFloat_ExtendedMantissa_ofMantissaAndAccuracy(v___y_1342_, v___x_1349_);
v___y_1318_ = v___y_1336_;
v___y_1319_ = v___y_1338_;
v___y_1320_ = v___y_1337_;
v___y_1321_ = v___y_1339_;
v___y_1322_ = v___y_1340_;
v___y_1323_ = v___x_1350_;
goto v___jp_1317_;
}
}
else
{
lean_object* v___x_1351_; lean_object* v___x_1352_; 
lean_dec(v_remainder_1344_);
v___x_1351_ = lean_box(0);
v___x_1352_ = l_Float_Model_UnpackedFloat_ExtendedMantissa_ofMantissaAndAccuracy(v___y_1342_, v___x_1351_);
v___y_1318_ = v___y_1336_;
v___y_1319_ = v___y_1338_;
v___y_1320_ = v___y_1337_;
v___y_1321_ = v___y_1339_;
v___y_1322_ = v___y_1340_;
v___y_1323_ = v___x_1352_;
goto v___jp_1317_;
}
}
v___jp_1353_:
{
lean_object* v___x_1364_; lean_object* v___x_1365_; lean_object* v_shift_1366_; uint64_t v___x_1367_; uint64_t v___x_1368_; uint64_t v___x_1369_; lean_object* v___x_1370_; 
v___x_1364_ = lean_uint64_to_nat(v___y_1363_);
v___x_1365_ = lean_nat_shiftr(v___x_1364_, v___y_1359_);
lean_dec(v___x_1364_);
v_shift_1366_ = lean_nat_add(v___x_1365_, v___y_1359_);
lean_dec(v___y_1359_);
lean_dec(v___x_1365_);
v___x_1367_ = lean_uint64_of_nat(v_shift_1366_);
lean_dec(v_shift_1366_);
v___x_1368_ = lean_uint64_shift_left(v___y_1354_, v___x_1367_);
v___x_1369_ = lp_floatlib_FloatLib_Numerics_FixedWord_IntegerSquareRoot_sqrtIter(v___y_1362_, v___x_1368_);
v___x_1370_ = lean_uint64_to_nat(v___x_1369_);
v___y_1336_ = v___y_1355_;
v___y_1337_ = v___y_1357_;
v___y_1338_ = v___y_1356_;
v___y_1339_ = v___y_1358_;
v___y_1340_ = v___y_1360_;
v___y_1341_ = v___y_1361_;
v___y_1342_ = v___x_1370_;
goto v___jp_1335_;
}
v___jp_1371_:
{
uint64_t v___x_1383_; uint64_t v___x_1384_; 
v___x_1383_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___y_1382_);
v___x_1384_ = lean_uint64_add(v___y_1373_, v___x_1383_);
v___y_1354_ = v___y_1372_;
v___y_1355_ = v___y_1374_;
v___y_1356_ = v___y_1376_;
v___y_1357_ = v___y_1375_;
v___y_1358_ = v___y_1378_;
v___y_1359_ = v___y_1377_;
v___y_1360_ = v___y_1379_;
v___y_1361_ = v___y_1380_;
v___y_1362_ = v___y_1381_;
v___y_1363_ = v___x_1384_;
goto v___jp_1353_;
}
v___jp_1385_:
{
if (v___y_1396_ == 0)
{
v___y_1372_ = v___y_1386_;
v___y_1373_ = v___y_1397_;
v___y_1374_ = v___y_1387_;
v___y_1375_ = v___y_1390_;
v___y_1376_ = v___y_1389_;
v___y_1377_ = v___y_1392_;
v___y_1378_ = v___y_1391_;
v___y_1379_ = v___y_1393_;
v___y_1380_ = v___y_1394_;
v___y_1381_ = v___y_1395_;
v___y_1382_ = v___y_1388_;
goto v___jp_1371_;
}
else
{
v___y_1372_ = v___y_1386_;
v___y_1373_ = v___y_1397_;
v___y_1374_ = v___y_1387_;
v___y_1375_ = v___y_1390_;
v___y_1376_ = v___y_1389_;
v___y_1377_ = v___y_1392_;
v___y_1378_ = v___y_1391_;
v___y_1379_ = v___y_1393_;
v___y_1380_ = v___y_1394_;
v___y_1381_ = v___y_1395_;
v___y_1382_ = v___y_1395_;
goto v___jp_1371_;
}
}
v___jp_1398_:
{
uint64_t v___x_1413_; uint64_t v___x_1414_; uint64_t v___x_1415_; uint64_t v___x_1416_; uint64_t v___x_1417_; 
v___x_1413_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___y_1412_);
v___x_1414_ = lean_uint64_add(v___y_1406_, v___x_1413_);
v___x_1415_ = lean_uint64_add(v___y_1405_, v___x_1414_);
v___x_1416_ = lean_uint64_add(v___y_1411_, v___x_1415_);
v___x_1417_ = lean_uint64_add(v___y_1407_, v___x_1416_);
v___y_1354_ = v___y_1399_;
v___y_1355_ = v___y_1408_;
v___y_1356_ = v___y_1400_;
v___y_1357_ = v___y_1401_;
v___y_1358_ = v___y_1409_;
v___y_1359_ = v___y_1410_;
v___y_1360_ = v___y_1402_;
v___y_1361_ = v___y_1403_;
v___y_1362_ = v___y_1404_;
v___y_1363_ = v___x_1417_;
goto v___jp_1353_;
}
v___jp_1418_:
{
if (v___y_1431_ == 0)
{
v___y_1399_ = v___y_1419_;
v___y_1400_ = v___y_1420_;
v___y_1401_ = v___y_1421_;
v___y_1402_ = v___y_1422_;
v___y_1403_ = v___y_1423_;
v___y_1404_ = v___y_1424_;
v___y_1405_ = v___y_1425_;
v___y_1406_ = v___y_1434_;
v___y_1407_ = v___y_1426_;
v___y_1408_ = v___y_1427_;
v___y_1409_ = v___y_1429_;
v___y_1410_ = v___y_1430_;
v___y_1411_ = v___y_1433_;
v___y_1412_ = v___y_1428_;
goto v___jp_1398_;
}
else
{
v___y_1399_ = v___y_1419_;
v___y_1400_ = v___y_1420_;
v___y_1401_ = v___y_1421_;
v___y_1402_ = v___y_1422_;
v___y_1403_ = v___y_1423_;
v___y_1404_ = v___y_1424_;
v___y_1405_ = v___y_1425_;
v___y_1406_ = v___y_1434_;
v___y_1407_ = v___y_1426_;
v___y_1408_ = v___y_1427_;
v___y_1409_ = v___y_1429_;
v___y_1410_ = v___y_1430_;
v___y_1411_ = v___y_1433_;
v___y_1412_ = v___y_1432_;
goto v___jp_1398_;
}
}
v___jp_1435_:
{
uint64_t v_high_1451_; uint8_t v___x_1452_; 
v_high_1451_ = lean_uint64_shift_right(v___y_1450_, v___y_1443_);
v___x_1452_ = lean_uint64_dec_eq(v_high_1451_, v___y_1446_);
if (v___x_1452_ == 0)
{
v___y_1419_ = v___y_1436_;
v___y_1420_ = v___y_1437_;
v___y_1421_ = v___y_1438_;
v___y_1422_ = v___y_1439_;
v___y_1423_ = v___y_1440_;
v___y_1424_ = v___y_1441_;
v___y_1425_ = v___y_1442_;
v___y_1426_ = v___y_1444_;
v___y_1427_ = v___y_1445_;
v___y_1428_ = v_high_1451_;
v___y_1429_ = v___y_1447_;
v___y_1430_ = v___y_1448_;
v___y_1431_ = v___x_1452_;
v___y_1432_ = v___y_1450_;
v___y_1433_ = v___y_1449_;
v___y_1434_ = v___y_1443_;
goto v___jp_1418_;
}
else
{
v___y_1419_ = v___y_1436_;
v___y_1420_ = v___y_1437_;
v___y_1421_ = v___y_1438_;
v___y_1422_ = v___y_1439_;
v___y_1423_ = v___y_1440_;
v___y_1424_ = v___y_1441_;
v___y_1425_ = v___y_1442_;
v___y_1426_ = v___y_1444_;
v___y_1427_ = v___y_1445_;
v___y_1428_ = v_high_1451_;
v___y_1429_ = v___y_1447_;
v___y_1430_ = v___y_1448_;
v___y_1431_ = v___x_1452_;
v___y_1432_ = v___y_1450_;
v___y_1433_ = v___y_1449_;
v___y_1434_ = v___y_1446_;
goto v___jp_1418_;
}
}
v___jp_1453_:
{
if (v___y_1468_ == 0)
{
v___y_1436_ = v___y_1454_;
v___y_1437_ = v___y_1455_;
v___y_1438_ = v___y_1456_;
v___y_1439_ = v___y_1457_;
v___y_1440_ = v___y_1458_;
v___y_1441_ = v___y_1459_;
v___y_1442_ = v___y_1470_;
v___y_1443_ = v___y_1461_;
v___y_1444_ = v___y_1462_;
v___y_1445_ = v___y_1463_;
v___y_1446_ = v___y_1464_;
v___y_1447_ = v___y_1466_;
v___y_1448_ = v___y_1467_;
v___y_1449_ = v___y_1469_;
v___y_1450_ = v___y_1465_;
goto v___jp_1435_;
}
else
{
v___y_1436_ = v___y_1454_;
v___y_1437_ = v___y_1455_;
v___y_1438_ = v___y_1456_;
v___y_1439_ = v___y_1457_;
v___y_1440_ = v___y_1458_;
v___y_1441_ = v___y_1459_;
v___y_1442_ = v___y_1470_;
v___y_1443_ = v___y_1461_;
v___y_1444_ = v___y_1462_;
v___y_1445_ = v___y_1463_;
v___y_1446_ = v___y_1464_;
v___y_1447_ = v___y_1466_;
v___y_1448_ = v___y_1467_;
v___y_1449_ = v___y_1469_;
v___y_1450_ = v___y_1460_;
goto v___jp_1435_;
}
}
v___jp_1471_:
{
uint64_t v_high_1487_; uint8_t v___x_1488_; 
v_high_1487_ = lean_uint64_shift_right(v___y_1486_, v___y_1484_);
v___x_1488_ = lean_uint64_dec_eq(v_high_1487_, v___y_1481_);
if (v___x_1488_ == 0)
{
v___y_1454_ = v___y_1472_;
v___y_1455_ = v___y_1473_;
v___y_1456_ = v___y_1474_;
v___y_1457_ = v___y_1475_;
v___y_1458_ = v___y_1476_;
v___y_1459_ = v___y_1477_;
v___y_1460_ = v___y_1486_;
v___y_1461_ = v___y_1478_;
v___y_1462_ = v___y_1479_;
v___y_1463_ = v___y_1480_;
v___y_1464_ = v___y_1481_;
v___y_1465_ = v_high_1487_;
v___y_1466_ = v___y_1482_;
v___y_1467_ = v___y_1483_;
v___y_1468_ = v___x_1488_;
v___y_1469_ = v___y_1485_;
v___y_1470_ = v___y_1484_;
goto v___jp_1453_;
}
else
{
v___y_1454_ = v___y_1472_;
v___y_1455_ = v___y_1473_;
v___y_1456_ = v___y_1474_;
v___y_1457_ = v___y_1475_;
v___y_1458_ = v___y_1476_;
v___y_1459_ = v___y_1477_;
v___y_1460_ = v___y_1486_;
v___y_1461_ = v___y_1478_;
v___y_1462_ = v___y_1479_;
v___y_1463_ = v___y_1480_;
v___y_1464_ = v___y_1481_;
v___y_1465_ = v_high_1487_;
v___y_1466_ = v___y_1482_;
v___y_1467_ = v___y_1483_;
v___y_1468_ = v___x_1488_;
v___y_1469_ = v___y_1485_;
v___y_1470_ = v___y_1481_;
goto v___jp_1453_;
}
}
v___jp_1489_:
{
if (v___y_1495_ == 0)
{
v___y_1472_ = v___y_1490_;
v___y_1473_ = v___y_1491_;
v___y_1474_ = v___y_1492_;
v___y_1475_ = v___y_1493_;
v___y_1476_ = v___y_1494_;
v___y_1477_ = v___y_1496_;
v___y_1478_ = v___y_1499_;
v___y_1479_ = v___y_1500_;
v___y_1480_ = v___y_1501_;
v___y_1481_ = v___y_1502_;
v___y_1482_ = v___y_1503_;
v___y_1483_ = v___y_1504_;
v___y_1484_ = v___y_1505_;
v___y_1485_ = v___y_1506_;
v___y_1486_ = v___y_1497_;
goto v___jp_1471_;
}
else
{
v___y_1472_ = v___y_1490_;
v___y_1473_ = v___y_1491_;
v___y_1474_ = v___y_1492_;
v___y_1475_ = v___y_1493_;
v___y_1476_ = v___y_1494_;
v___y_1477_ = v___y_1496_;
v___y_1478_ = v___y_1499_;
v___y_1479_ = v___y_1500_;
v___y_1480_ = v___y_1501_;
v___y_1481_ = v___y_1502_;
v___y_1482_ = v___y_1503_;
v___y_1483_ = v___y_1504_;
v___y_1484_ = v___y_1505_;
v___y_1485_ = v___y_1506_;
v___y_1486_ = v___y_1498_;
goto v___jp_1471_;
}
}
v___jp_1507_:
{
uint64_t v_high_1523_; uint8_t v___x_1524_; 
v_high_1523_ = lean_uint64_shift_right(v___y_1522_, v___y_1521_);
v___x_1524_ = lean_uint64_dec_eq(v_high_1523_, v___y_1517_);
if (v___x_1524_ == 0)
{
v___y_1490_ = v___y_1508_;
v___y_1491_ = v___y_1509_;
v___y_1492_ = v___y_1510_;
v___y_1493_ = v___y_1511_;
v___y_1494_ = v___y_1512_;
v___y_1495_ = v___x_1524_;
v___y_1496_ = v___y_1513_;
v___y_1497_ = v_high_1523_;
v___y_1498_ = v___y_1522_;
v___y_1499_ = v___y_1514_;
v___y_1500_ = v___y_1515_;
v___y_1501_ = v___y_1516_;
v___y_1502_ = v___y_1517_;
v___y_1503_ = v___y_1518_;
v___y_1504_ = v___y_1519_;
v___y_1505_ = v___y_1520_;
v___y_1506_ = v___y_1521_;
goto v___jp_1489_;
}
else
{
v___y_1490_ = v___y_1508_;
v___y_1491_ = v___y_1509_;
v___y_1492_ = v___y_1510_;
v___y_1493_ = v___y_1511_;
v___y_1494_ = v___y_1512_;
v___y_1495_ = v___x_1524_;
v___y_1496_ = v___y_1513_;
v___y_1497_ = v_high_1523_;
v___y_1498_ = v___y_1522_;
v___y_1499_ = v___y_1514_;
v___y_1500_ = v___y_1515_;
v___y_1501_ = v___y_1516_;
v___y_1502_ = v___y_1517_;
v___y_1503_ = v___y_1518_;
v___y_1504_ = v___y_1519_;
v___y_1505_ = v___y_1520_;
v___y_1506_ = v___y_1517_;
goto v___jp_1489_;
}
}
v___jp_1525_:
{
if (v___y_1527_ == 0)
{
v___y_1508_ = v___y_1526_;
v___y_1509_ = v___y_1528_;
v___y_1510_ = v___y_1529_;
v___y_1511_ = v___y_1530_;
v___y_1512_ = v___y_1532_;
v___y_1513_ = v___y_1533_;
v___y_1514_ = v___y_1534_;
v___y_1515_ = v___y_1541_;
v___y_1516_ = v___y_1535_;
v___y_1517_ = v___y_1536_;
v___y_1518_ = v___y_1537_;
v___y_1519_ = v___y_1538_;
v___y_1520_ = v___y_1539_;
v___y_1521_ = v___y_1540_;
v___y_1522_ = v___y_1531_;
goto v___jp_1507_;
}
else
{
v___y_1508_ = v___y_1526_;
v___y_1509_ = v___y_1528_;
v___y_1510_ = v___y_1529_;
v___y_1511_ = v___y_1530_;
v___y_1512_ = v___y_1532_;
v___y_1513_ = v___y_1533_;
v___y_1514_ = v___y_1534_;
v___y_1515_ = v___y_1541_;
v___y_1516_ = v___y_1535_;
v___y_1517_ = v___y_1536_;
v___y_1518_ = v___y_1537_;
v___y_1519_ = v___y_1538_;
v___y_1520_ = v___y_1539_;
v___y_1521_ = v___y_1540_;
v___y_1522_ = v___y_1533_;
goto v___jp_1507_;
}
}
v___jp_1542_:
{
lean_object* v___x_1555_; lean_object* v___x_1556_; uint8_t v___x_1557_; 
v___x_1555_ = lean_nat_mul(v___y_1552_, v___y_1552_);
lean_dec(v___y_1552_);
v___x_1556_ = lean_nat_shiftl(v___x_1555_, v___y_1550_);
lean_dec(v___y_1550_);
lean_dec(v___x_1555_);
v___x_1557_ = lean_nat_dec_eq(v___y_1549_, v___x_1556_);
lean_dec(v___x_1556_);
lean_dec(v___y_1549_);
if (v___x_1557_ == 0)
{
lean_object* v___x_1558_; 
v___x_1558_ = lean_alloc_ctor(0, 1, 2);
lean_ctor_set(v___x_1558_, 0, v___y_1548_);
lean_ctor_set_uint8(v___x_1558_, sizeof(void*)*1, v___y_1554_);
lean_ctor_set_uint8(v___x_1558_, sizeof(void*)*1 + 1, v___y_1551_);
v___y_1318_ = v___y_1543_;
v___y_1319_ = v___y_1545_;
v___y_1320_ = v___y_1544_;
v___y_1321_ = v___y_1546_;
v___y_1322_ = v___y_1547_;
v___y_1323_ = v___x_1558_;
goto v___jp_1317_;
}
else
{
lean_object* v___x_1559_; 
v___x_1559_ = lean_alloc_ctor(0, 1, 2);
lean_ctor_set(v___x_1559_, 0, v___y_1548_);
lean_ctor_set_uint8(v___x_1559_, sizeof(void*)*1, v___y_1554_);
lean_ctor_set_uint8(v___x_1559_, sizeof(void*)*1 + 1, v___y_1553_);
v___y_1318_ = v___y_1543_;
v___y_1319_ = v___y_1545_;
v___y_1320_ = v___y_1544_;
v___y_1321_ = v___y_1546_;
v___y_1322_ = v___y_1547_;
v___y_1323_ = v___x_1559_;
goto v___jp_1317_;
}
}
v___jp_1560_:
{
lean_object* v___x_1573_; lean_object* v___x_1574_; uint8_t v___x_1575_; 
v___x_1573_ = lean_nat_shiftr(v___y_1572_, v___y_1566_);
lean_dec(v___y_1566_);
v___x_1574_ = lean_nat_mod(v___y_1572_, v___y_1562_);
lean_dec(v___y_1562_);
v___x_1575_ = lean_nat_dec_eq(v___x_1574_, v___y_1565_);
lean_dec(v___x_1574_);
if (v___x_1575_ == 0)
{
v___y_1543_ = v___y_1561_;
v___y_1544_ = v___y_1564_;
v___y_1545_ = v___y_1563_;
v___y_1546_ = v___y_1565_;
v___y_1547_ = v___y_1567_;
v___y_1548_ = v___x_1573_;
v___y_1549_ = v___y_1568_;
v___y_1550_ = v___y_1569_;
v___y_1551_ = v___y_1570_;
v___y_1552_ = v___y_1572_;
v___y_1553_ = v___y_1571_;
v___y_1554_ = v___y_1570_;
goto v___jp_1542_;
}
else
{
v___y_1543_ = v___y_1561_;
v___y_1544_ = v___y_1564_;
v___y_1545_ = v___y_1563_;
v___y_1546_ = v___y_1565_;
v___y_1547_ = v___y_1567_;
v___y_1548_ = v___x_1573_;
v___y_1549_ = v___y_1568_;
v___y_1550_ = v___y_1569_;
v___y_1551_ = v___y_1570_;
v___y_1552_ = v___y_1572_;
v___y_1553_ = v___y_1571_;
v___y_1554_ = v___y_1571_;
goto v___jp_1542_;
}
}
v___jp_1576_:
{
lean_object* v___x_1591_; lean_object* v___x_1592_; lean_object* v_shift_1593_; uint64_t v___x_1594_; uint64_t v___x_1595_; uint64_t v___x_1596_; lean_object* v___x_1597_; 
v___x_1591_ = lean_uint64_to_nat(v___y_1590_);
v___x_1592_ = lean_nat_shiftr(v___x_1591_, v___y_1585_);
lean_dec(v___x_1591_);
v_shift_1593_ = lean_nat_add(v___x_1592_, v___y_1585_);
lean_dec(v___x_1592_);
v___x_1594_ = lean_uint64_of_nat(v_shift_1593_);
lean_dec(v_shift_1593_);
v___x_1595_ = lean_uint64_shift_left(v___y_1577_, v___x_1594_);
v___x_1596_ = lp_floatlib_FloatLib_Numerics_FixedWord_IntegerSquareRoot_sqrtIter(v___y_1582_, v___x_1595_);
v___x_1597_ = lean_uint64_to_nat(v___x_1596_);
v___y_1561_ = v___y_1583_;
v___y_1562_ = v___y_1584_;
v___y_1563_ = v___y_1578_;
v___y_1564_ = v___y_1579_;
v___y_1565_ = v___y_1586_;
v___y_1566_ = v___y_1585_;
v___y_1567_ = v___y_1580_;
v___y_1568_ = v___y_1581_;
v___y_1569_ = v___y_1587_;
v___y_1570_ = v___y_1588_;
v___y_1571_ = v___y_1589_;
v___y_1572_ = v___x_1597_;
goto v___jp_1560_;
}
v___jp_1598_:
{
uint64_t v___x_1617_; uint64_t v___x_1618_; uint64_t v___x_1619_; uint64_t v___x_1620_; uint64_t v___x_1621_; 
v___x_1617_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___y_1616_);
v___x_1618_ = lean_uint64_add(v___y_1600_, v___x_1617_);
v___x_1619_ = lean_uint64_add(v___y_1611_, v___x_1618_);
v___x_1620_ = lean_uint64_add(v___y_1612_, v___x_1619_);
v___x_1621_ = lean_uint64_add(v___y_1605_, v___x_1620_);
v___y_1577_ = v___y_1599_;
v___y_1578_ = v___y_1601_;
v___y_1579_ = v___y_1602_;
v___y_1580_ = v___y_1603_;
v___y_1581_ = v___y_1604_;
v___y_1582_ = v___y_1606_;
v___y_1583_ = v___y_1607_;
v___y_1584_ = v___y_1608_;
v___y_1585_ = v___y_1610_;
v___y_1586_ = v___y_1609_;
v___y_1587_ = v___y_1613_;
v___y_1588_ = v___y_1614_;
v___y_1589_ = v___y_1615_;
v___y_1590_ = v___x_1621_;
goto v___jp_1576_;
}
v___jp_1622_:
{
if (v___y_1629_ == 0)
{
v___y_1599_ = v___y_1623_;
v___y_1600_ = v___y_1642_;
v___y_1601_ = v___y_1624_;
v___y_1602_ = v___y_1625_;
v___y_1603_ = v___y_1626_;
v___y_1604_ = v___y_1627_;
v___y_1605_ = v___y_1628_;
v___y_1606_ = v___y_1630_;
v___y_1607_ = v___y_1632_;
v___y_1608_ = v___y_1633_;
v___y_1609_ = v___y_1634_;
v___y_1610_ = v___y_1635_;
v___y_1611_ = v___y_1637_;
v___y_1612_ = v___y_1638_;
v___y_1613_ = v___y_1639_;
v___y_1614_ = v___y_1640_;
v___y_1615_ = v___y_1641_;
v___y_1616_ = v___y_1636_;
goto v___jp_1598_;
}
else
{
v___y_1599_ = v___y_1623_;
v___y_1600_ = v___y_1642_;
v___y_1601_ = v___y_1624_;
v___y_1602_ = v___y_1625_;
v___y_1603_ = v___y_1626_;
v___y_1604_ = v___y_1627_;
v___y_1605_ = v___y_1628_;
v___y_1606_ = v___y_1630_;
v___y_1607_ = v___y_1632_;
v___y_1608_ = v___y_1633_;
v___y_1609_ = v___y_1634_;
v___y_1610_ = v___y_1635_;
v___y_1611_ = v___y_1637_;
v___y_1612_ = v___y_1638_;
v___y_1613_ = v___y_1639_;
v___y_1614_ = v___y_1640_;
v___y_1615_ = v___y_1641_;
v___y_1616_ = v___y_1631_;
goto v___jp_1598_;
}
}
v___jp_1643_:
{
uint64_t v_high_1663_; uint8_t v___x_1664_; 
v_high_1663_ = lean_uint64_shift_right(v___y_1662_, v___y_1644_);
v___x_1664_ = lean_uint64_dec_eq(v_high_1663_, v___y_1654_);
if (v___x_1664_ == 0)
{
v___y_1623_ = v___y_1645_;
v___y_1624_ = v___y_1646_;
v___y_1625_ = v___y_1647_;
v___y_1626_ = v___y_1648_;
v___y_1627_ = v___y_1649_;
v___y_1628_ = v___y_1650_;
v___y_1629_ = v___x_1664_;
v___y_1630_ = v___y_1651_;
v___y_1631_ = v___y_1662_;
v___y_1632_ = v___y_1652_;
v___y_1633_ = v___y_1653_;
v___y_1634_ = v___y_1655_;
v___y_1635_ = v___y_1656_;
v___y_1636_ = v_high_1663_;
v___y_1637_ = v___y_1657_;
v___y_1638_ = v___y_1658_;
v___y_1639_ = v___y_1659_;
v___y_1640_ = v___y_1660_;
v___y_1641_ = v___y_1661_;
v___y_1642_ = v___y_1644_;
goto v___jp_1622_;
}
else
{
v___y_1623_ = v___y_1645_;
v___y_1624_ = v___y_1646_;
v___y_1625_ = v___y_1647_;
v___y_1626_ = v___y_1648_;
v___y_1627_ = v___y_1649_;
v___y_1628_ = v___y_1650_;
v___y_1629_ = v___x_1664_;
v___y_1630_ = v___y_1651_;
v___y_1631_ = v___y_1662_;
v___y_1632_ = v___y_1652_;
v___y_1633_ = v___y_1653_;
v___y_1634_ = v___y_1655_;
v___y_1635_ = v___y_1656_;
v___y_1636_ = v_high_1663_;
v___y_1637_ = v___y_1657_;
v___y_1638_ = v___y_1658_;
v___y_1639_ = v___y_1659_;
v___y_1640_ = v___y_1660_;
v___y_1641_ = v___y_1661_;
v___y_1642_ = v___y_1654_;
goto v___jp_1622_;
}
}
v___jp_1665_:
{
if (v___y_1669_ == 0)
{
v___y_1644_ = v___y_1666_;
v___y_1645_ = v___y_1667_;
v___y_1646_ = v___y_1670_;
v___y_1647_ = v___y_1671_;
v___y_1648_ = v___y_1672_;
v___y_1649_ = v___y_1673_;
v___y_1650_ = v___y_1674_;
v___y_1651_ = v___y_1675_;
v___y_1652_ = v___y_1677_;
v___y_1653_ = v___y_1678_;
v___y_1654_ = v___y_1679_;
v___y_1655_ = v___y_1680_;
v___y_1656_ = v___y_1681_;
v___y_1657_ = v___y_1686_;
v___y_1658_ = v___y_1682_;
v___y_1659_ = v___y_1683_;
v___y_1660_ = v___y_1684_;
v___y_1661_ = v___y_1685_;
v___y_1662_ = v___y_1668_;
goto v___jp_1643_;
}
else
{
v___y_1644_ = v___y_1666_;
v___y_1645_ = v___y_1667_;
v___y_1646_ = v___y_1670_;
v___y_1647_ = v___y_1671_;
v___y_1648_ = v___y_1672_;
v___y_1649_ = v___y_1673_;
v___y_1650_ = v___y_1674_;
v___y_1651_ = v___y_1675_;
v___y_1652_ = v___y_1677_;
v___y_1653_ = v___y_1678_;
v___y_1654_ = v___y_1679_;
v___y_1655_ = v___y_1680_;
v___y_1656_ = v___y_1681_;
v___y_1657_ = v___y_1686_;
v___y_1658_ = v___y_1682_;
v___y_1659_ = v___y_1683_;
v___y_1660_ = v___y_1684_;
v___y_1661_ = v___y_1685_;
v___y_1662_ = v___y_1676_;
goto v___jp_1643_;
}
}
v___jp_1687_:
{
uint64_t v_high_1707_; uint8_t v___x_1708_; 
v_high_1707_ = lean_uint64_shift_right(v___y_1706_, v___y_1689_);
v___x_1708_ = lean_uint64_dec_eq(v_high_1707_, v___y_1700_);
if (v___x_1708_ == 0)
{
v___y_1666_ = v___y_1688_;
v___y_1667_ = v___y_1690_;
v___y_1668_ = v_high_1707_;
v___y_1669_ = v___x_1708_;
v___y_1670_ = v___y_1691_;
v___y_1671_ = v___y_1692_;
v___y_1672_ = v___y_1693_;
v___y_1673_ = v___y_1694_;
v___y_1674_ = v___y_1695_;
v___y_1675_ = v___y_1696_;
v___y_1676_ = v___y_1706_;
v___y_1677_ = v___y_1697_;
v___y_1678_ = v___y_1698_;
v___y_1679_ = v___y_1700_;
v___y_1680_ = v___y_1701_;
v___y_1681_ = v___y_1699_;
v___y_1682_ = v___y_1702_;
v___y_1683_ = v___y_1703_;
v___y_1684_ = v___y_1704_;
v___y_1685_ = v___y_1705_;
v___y_1686_ = v___y_1689_;
goto v___jp_1665_;
}
else
{
v___y_1666_ = v___y_1688_;
v___y_1667_ = v___y_1690_;
v___y_1668_ = v_high_1707_;
v___y_1669_ = v___x_1708_;
v___y_1670_ = v___y_1691_;
v___y_1671_ = v___y_1692_;
v___y_1672_ = v___y_1693_;
v___y_1673_ = v___y_1694_;
v___y_1674_ = v___y_1695_;
v___y_1675_ = v___y_1696_;
v___y_1676_ = v___y_1706_;
v___y_1677_ = v___y_1697_;
v___y_1678_ = v___y_1698_;
v___y_1679_ = v___y_1700_;
v___y_1680_ = v___y_1701_;
v___y_1681_ = v___y_1699_;
v___y_1682_ = v___y_1702_;
v___y_1683_ = v___y_1703_;
v___y_1684_ = v___y_1704_;
v___y_1685_ = v___y_1705_;
v___y_1686_ = v___y_1700_;
goto v___jp_1665_;
}
}
v___jp_1709_:
{
if (v___y_1723_ == 0)
{
v___y_1688_ = v___y_1710_;
v___y_1689_ = v___y_1712_;
v___y_1690_ = v___y_1713_;
v___y_1691_ = v___y_1714_;
v___y_1692_ = v___y_1715_;
v___y_1693_ = v___y_1716_;
v___y_1694_ = v___y_1717_;
v___y_1695_ = v___y_1718_;
v___y_1696_ = v___y_1719_;
v___y_1697_ = v___y_1721_;
v___y_1698_ = v___y_1722_;
v___y_1699_ = v___y_1725_;
v___y_1700_ = v___y_1726_;
v___y_1701_ = v___y_1724_;
v___y_1702_ = v___y_1730_;
v___y_1703_ = v___y_1727_;
v___y_1704_ = v___y_1728_;
v___y_1705_ = v___y_1729_;
v___y_1706_ = v___y_1720_;
goto v___jp_1687_;
}
else
{
v___y_1688_ = v___y_1710_;
v___y_1689_ = v___y_1712_;
v___y_1690_ = v___y_1713_;
v___y_1691_ = v___y_1714_;
v___y_1692_ = v___y_1715_;
v___y_1693_ = v___y_1716_;
v___y_1694_ = v___y_1717_;
v___y_1695_ = v___y_1718_;
v___y_1696_ = v___y_1719_;
v___y_1697_ = v___y_1721_;
v___y_1698_ = v___y_1722_;
v___y_1699_ = v___y_1725_;
v___y_1700_ = v___y_1726_;
v___y_1701_ = v___y_1724_;
v___y_1702_ = v___y_1730_;
v___y_1703_ = v___y_1727_;
v___y_1704_ = v___y_1728_;
v___y_1705_ = v___y_1729_;
v___y_1706_ = v___y_1711_;
goto v___jp_1687_;
}
}
v___jp_1731_:
{
uint64_t v_high_1751_; uint8_t v___x_1752_; 
v_high_1751_ = lean_uint64_shift_right(v___y_1750_, v___y_1749_);
v___x_1752_ = lean_uint64_dec_eq(v_high_1751_, v___y_1745_);
if (v___x_1752_ == 0)
{
v___y_1710_ = v___y_1732_;
v___y_1711_ = v___y_1750_;
v___y_1712_ = v___y_1733_;
v___y_1713_ = v___y_1734_;
v___y_1714_ = v___y_1735_;
v___y_1715_ = v___y_1736_;
v___y_1716_ = v___y_1737_;
v___y_1717_ = v___y_1738_;
v___y_1718_ = v___y_1739_;
v___y_1719_ = v___y_1740_;
v___y_1720_ = v_high_1751_;
v___y_1721_ = v___y_1741_;
v___y_1722_ = v___y_1742_;
v___y_1723_ = v___x_1752_;
v___y_1724_ = v___y_1744_;
v___y_1725_ = v___y_1743_;
v___y_1726_ = v___y_1745_;
v___y_1727_ = v___y_1746_;
v___y_1728_ = v___y_1747_;
v___y_1729_ = v___y_1748_;
v___y_1730_ = v___y_1749_;
goto v___jp_1709_;
}
else
{
v___y_1710_ = v___y_1732_;
v___y_1711_ = v___y_1750_;
v___y_1712_ = v___y_1733_;
v___y_1713_ = v___y_1734_;
v___y_1714_ = v___y_1735_;
v___y_1715_ = v___y_1736_;
v___y_1716_ = v___y_1737_;
v___y_1717_ = v___y_1738_;
v___y_1718_ = v___y_1739_;
v___y_1719_ = v___y_1740_;
v___y_1720_ = v_high_1751_;
v___y_1721_ = v___y_1741_;
v___y_1722_ = v___y_1742_;
v___y_1723_ = v___x_1752_;
v___y_1724_ = v___y_1744_;
v___y_1725_ = v___y_1743_;
v___y_1726_ = v___y_1745_;
v___y_1727_ = v___y_1746_;
v___y_1728_ = v___y_1747_;
v___y_1729_ = v___y_1748_;
v___y_1730_ = v___y_1745_;
goto v___jp_1709_;
}
}
v___jp_1753_:
{
if (v___y_1755_ == 0)
{
v___y_1732_ = v___y_1754_;
v___y_1733_ = v___y_1756_;
v___y_1734_ = v___y_1757_;
v___y_1735_ = v___y_1758_;
v___y_1736_ = v___y_1759_;
v___y_1737_ = v___y_1760_;
v___y_1738_ = v___y_1761_;
v___y_1739_ = v___y_1773_;
v___y_1740_ = v___y_1762_;
v___y_1741_ = v___y_1763_;
v___y_1742_ = v___y_1764_;
v___y_1743_ = v___y_1765_;
v___y_1744_ = v___y_1766_;
v___y_1745_ = v___y_1767_;
v___y_1746_ = v___y_1768_;
v___y_1747_ = v___y_1769_;
v___y_1748_ = v___y_1772_;
v___y_1749_ = v___y_1771_;
v___y_1750_ = v___y_1770_;
goto v___jp_1731_;
}
else
{
v___y_1732_ = v___y_1754_;
v___y_1733_ = v___y_1756_;
v___y_1734_ = v___y_1757_;
v___y_1735_ = v___y_1758_;
v___y_1736_ = v___y_1759_;
v___y_1737_ = v___y_1760_;
v___y_1738_ = v___y_1761_;
v___y_1739_ = v___y_1773_;
v___y_1740_ = v___y_1762_;
v___y_1741_ = v___y_1763_;
v___y_1742_ = v___y_1764_;
v___y_1743_ = v___y_1765_;
v___y_1744_ = v___y_1766_;
v___y_1745_ = v___y_1767_;
v___y_1746_ = v___y_1768_;
v___y_1747_ = v___y_1769_;
v___y_1748_ = v___y_1772_;
v___y_1749_ = v___y_1771_;
v___y_1750_ = v___y_1762_;
goto v___jp_1731_;
}
}
v___jp_1774_:
{
uint64_t v___x_1790_; uint64_t v___x_1791_; 
v___x_1790_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___y_1789_);
v___x_1791_ = lean_uint64_add(v___y_1781_, v___x_1790_);
v___y_1577_ = v___y_1775_;
v___y_1578_ = v___y_1776_;
v___y_1579_ = v___y_1777_;
v___y_1580_ = v___y_1778_;
v___y_1581_ = v___y_1779_;
v___y_1582_ = v___y_1780_;
v___y_1583_ = v___y_1782_;
v___y_1584_ = v___y_1783_;
v___y_1585_ = v___y_1784_;
v___y_1586_ = v___y_1785_;
v___y_1587_ = v___y_1786_;
v___y_1588_ = v___y_1787_;
v___y_1589_ = v___y_1788_;
v___y_1590_ = v___x_1791_;
goto v___jp_1576_;
}
v___jp_1792_:
{
if (v___y_1807_ == 0)
{
v___y_1775_ = v___y_1793_;
v___y_1776_ = v___y_1794_;
v___y_1777_ = v___y_1795_;
v___y_1778_ = v___y_1796_;
v___y_1779_ = v___y_1797_;
v___y_1780_ = v___y_1798_;
v___y_1781_ = v___y_1808_;
v___y_1782_ = v___y_1800_;
v___y_1783_ = v___y_1801_;
v___y_1784_ = v___y_1802_;
v___y_1785_ = v___y_1803_;
v___y_1786_ = v___y_1804_;
v___y_1787_ = v___y_1805_;
v___y_1788_ = v___y_1806_;
v___y_1789_ = v___y_1799_;
goto v___jp_1774_;
}
else
{
v___y_1775_ = v___y_1793_;
v___y_1776_ = v___y_1794_;
v___y_1777_ = v___y_1795_;
v___y_1778_ = v___y_1796_;
v___y_1779_ = v___y_1797_;
v___y_1780_ = v___y_1798_;
v___y_1781_ = v___y_1808_;
v___y_1782_ = v___y_1800_;
v___y_1783_ = v___y_1801_;
v___y_1784_ = v___y_1802_;
v___y_1785_ = v___y_1803_;
v___y_1786_ = v___y_1804_;
v___y_1787_ = v___y_1805_;
v___y_1788_ = v___y_1806_;
v___y_1789_ = v___y_1798_;
goto v___jp_1774_;
}
}
v___jp_1809_:
{
lean_object* v___x_1821_; lean_object* v___x_1822_; lean_object* v_shiftAmount_1823_; lean_object* v___x_1824_; lean_object* v___x_1825_; lean_object* v___x_1826_; lean_object* v___x_1827_; lean_object* v___x_1828_; lean_object* v___x_1829_; lean_object* v_totalExponent_1830_; lean_object* v___x_1831_; lean_object* v___x_1832_; lean_object* v_shift_1833_; lean_object* v_zero_1834_; uint8_t v_isZero_1835_; 
v___x_1821_ = lean_int_mul(v___y_1815_, v___y_1820_);
lean_dec(v___y_1815_);
v___x_1822_ = lean_int_sub(v___y_1816_, v___x_1821_);
lean_dec(v___x_1821_);
lean_dec(v___y_1816_);
v_shiftAmount_1823_ = l_Int_toNat(v___x_1822_);
lean_dec(v___x_1822_);
v___x_1824_ = lean_nat_shiftl(v___y_1817_, v_shiftAmount_1823_);
lean_dec(v_shiftAmount_1823_);
lean_dec(v___y_1817_);
v___x_1825_ = lean_nat_log2(v___x_1824_);
v___x_1826_ = lean_nat_shiftr(v___x_1825_, v___y_1813_);
lean_dec(v___x_1825_);
v___x_1827_ = lean_nat_to_int(v___x_1826_);
lean_inc(v___y_1813_);
v___x_1828_ = lean_nat_to_int(v___y_1813_);
v___x_1829_ = lean_int_add(v___x_1827_, v___x_1828_);
lean_dec(v___x_1828_);
lean_dec(v___x_1827_);
v_totalExponent_1830_ = lean_int_add(v___x_1829_, v___y_1820_);
lean_dec(v___x_1829_);
v___x_1831_ = l_Float_Model_Format_targetExponent(v___y_1811_, v_totalExponent_1830_);
lean_dec(v_totalExponent_1830_);
v___x_1832_ = lean_int_sub(v___x_1831_, v___y_1820_);
lean_dec(v___x_1831_);
v_shift_1833_ = l_Int_toNat(v___x_1832_);
lean_dec(v___x_1832_);
v_zero_1834_ = lean_unsigned_to_nat(0u);
v_isZero_1835_ = lean_nat_dec_eq(v_shift_1833_, v_zero_1834_);
if (v_isZero_1835_ == 1)
{
lean_object* v___x_1836_; uint8_t v___x_1837_; 
lean_dec(v___y_1810_);
v___x_1836_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3);
v___x_1837_ = lean_nat_dec_lt(v___x_1824_, v___x_1836_);
if (v___x_1837_ == 0)
{
lean_object* v___x_1838_; lean_object* v_fst_1839_; 
lean_dec(v___y_1813_);
lean_inc(v___x_1824_);
v___x_1838_ = lp_floatlib_FloatLib_Numerics_FixedWord_IntegerSquareRoot_sqrtRem(v___x_1824_);
v_fst_1839_ = lean_ctor_get(v___x_1838_, 0);
lean_inc(v_fst_1839_);
lean_dec_ref(v___x_1838_);
v___y_1336_ = v_shift_1833_;
v___y_1337_ = v___y_1820_;
v___y_1338_ = v___y_1811_;
v___y_1339_ = v___y_1812_;
v___y_1340_ = v___y_1814_;
v___y_1341_ = v___x_1824_;
v___y_1342_ = v_fst_1839_;
goto v___jp_1335_;
}
else
{
uint64_t v___x_1840_; uint64_t v___x_1841_; uint8_t v___x_1842_; 
v___x_1840_ = lean_uint64_of_nat(v___x_1824_);
v___x_1841_ = 1ULL;
v___x_1842_ = lean_uint64_dec_le(v___x_1840_, v___x_1841_);
if (v___x_1842_ == 0)
{
uint64_t v___x_1843_; uint8_t v___x_1844_; 
v___x_1843_ = 2ULL;
v___x_1844_ = lean_uint64_dec_lt(v___x_1840_, v___x_1843_);
if (v___x_1844_ == 0)
{
uint64_t v___x_1845_; uint8_t v___x_1846_; 
v___x_1845_ = 16ULL;
v___x_1846_ = lean_uint64_dec_lt(v___x_1840_, v___x_1845_);
if (v___x_1846_ == 0)
{
uint64_t v___x_1847_; uint64_t v___x_1848_; uint8_t v___x_1849_; 
v___x_1847_ = 4ULL;
v___x_1848_ = 256ULL;
v___x_1849_ = lean_uint64_dec_lt(v___x_1840_, v___x_1848_);
if (v___x_1849_ == 0)
{
uint64_t v___x_1850_; uint64_t v___x_1851_; uint64_t v_high_1852_; uint64_t v___x_1853_; uint8_t v___x_1854_; 
v___x_1850_ = 32ULL;
v___x_1851_ = 8ULL;
v_high_1852_ = lean_uint64_shift_right(v___x_1840_, v___x_1850_);
v___x_1853_ = 0ULL;
v___x_1854_ = lean_uint64_dec_eq(v_high_1852_, v___x_1853_);
if (v___x_1854_ == 0)
{
v___y_1526_ = v___x_1841_;
v___y_1527_ = v___x_1854_;
v___y_1528_ = v___y_1811_;
v___y_1529_ = v___y_1820_;
v___y_1530_ = v___y_1814_;
v___y_1531_ = v_high_1852_;
v___y_1532_ = v___x_1824_;
v___y_1533_ = v___x_1840_;
v___y_1534_ = v___x_1847_;
v___y_1535_ = v_shift_1833_;
v___y_1536_ = v___x_1853_;
v___y_1537_ = v___y_1812_;
v___y_1538_ = v___y_1813_;
v___y_1539_ = v___x_1851_;
v___y_1540_ = v___x_1845_;
v___y_1541_ = v___x_1850_;
goto v___jp_1525_;
}
else
{
v___y_1526_ = v___x_1841_;
v___y_1527_ = v___x_1854_;
v___y_1528_ = v___y_1811_;
v___y_1529_ = v___y_1820_;
v___y_1530_ = v___y_1814_;
v___y_1531_ = v_high_1852_;
v___y_1532_ = v___x_1824_;
v___y_1533_ = v___x_1840_;
v___y_1534_ = v___x_1847_;
v___y_1535_ = v_shift_1833_;
v___y_1536_ = v___x_1853_;
v___y_1537_ = v___y_1812_;
v___y_1538_ = v___y_1813_;
v___y_1539_ = v___x_1851_;
v___y_1540_ = v___x_1845_;
v___y_1541_ = v___x_1853_;
goto v___jp_1525_;
}
}
else
{
uint64_t v_high_1855_; uint64_t v___x_1856_; uint8_t v___x_1857_; 
v_high_1855_ = lean_uint64_shift_right(v___x_1840_, v___x_1847_);
v___x_1856_ = 0ULL;
v___x_1857_ = lean_uint64_dec_eq(v_high_1855_, v___x_1856_);
if (v___x_1857_ == 0)
{
v___y_1386_ = v___x_1841_;
v___y_1387_ = v_shift_1833_;
v___y_1388_ = v_high_1855_;
v___y_1389_ = v___y_1811_;
v___y_1390_ = v___y_1820_;
v___y_1391_ = v___y_1812_;
v___y_1392_ = v___y_1813_;
v___y_1393_ = v___y_1814_;
v___y_1394_ = v___x_1824_;
v___y_1395_ = v___x_1840_;
v___y_1396_ = v___x_1857_;
v___y_1397_ = v___x_1847_;
goto v___jp_1385_;
}
else
{
v___y_1386_ = v___x_1841_;
v___y_1387_ = v_shift_1833_;
v___y_1388_ = v_high_1855_;
v___y_1389_ = v___y_1811_;
v___y_1390_ = v___y_1820_;
v___y_1391_ = v___y_1812_;
v___y_1392_ = v___y_1813_;
v___y_1393_ = v___y_1814_;
v___y_1394_ = v___x_1824_;
v___y_1395_ = v___x_1840_;
v___y_1396_ = v___x_1857_;
v___y_1397_ = v___x_1856_;
goto v___jp_1385_;
}
}
}
else
{
uint64_t v___x_1858_; 
v___x_1858_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___x_1840_);
v___y_1354_ = v___x_1841_;
v___y_1355_ = v_shift_1833_;
v___y_1356_ = v___y_1811_;
v___y_1357_ = v___y_1820_;
v___y_1358_ = v___y_1812_;
v___y_1359_ = v___y_1813_;
v___y_1360_ = v___y_1814_;
v___y_1361_ = v___x_1824_;
v___y_1362_ = v___x_1840_;
v___y_1363_ = v___x_1858_;
goto v___jp_1353_;
}
}
else
{
uint64_t v___x_1859_; 
v___x_1859_ = 0ULL;
v___y_1354_ = v___x_1841_;
v___y_1355_ = v_shift_1833_;
v___y_1356_ = v___y_1811_;
v___y_1357_ = v___y_1820_;
v___y_1358_ = v___y_1812_;
v___y_1359_ = v___y_1813_;
v___y_1360_ = v___y_1814_;
v___y_1361_ = v___x_1824_;
v___y_1362_ = v___x_1840_;
v___y_1363_ = v___x_1859_;
goto v___jp_1353_;
}
}
else
{
lean_object* v___x_1860_; 
lean_dec(v___y_1813_);
v___x_1860_ = lean_uint64_to_nat(v___x_1840_);
v___y_1336_ = v_shift_1833_;
v___y_1337_ = v___y_1820_;
v___y_1338_ = v___y_1811_;
v___y_1339_ = v___y_1812_;
v___y_1340_ = v___y_1814_;
v___y_1341_ = v___x_1824_;
v___y_1342_ = v___x_1860_;
goto v___jp_1335_;
}
}
}
else
{
lean_object* v_one_1861_; lean_object* v_n_1862_; lean_object* v_radicandShift_1863_; lean_object* v___x_1864_; lean_object* v___x_1865_; uint8_t v___x_1866_; 
v_one_1861_ = lean_unsigned_to_nat(1u);
v_n_1862_ = lean_nat_sub(v_shift_1833_, v_one_1861_);
v_radicandShift_1863_ = lean_nat_mul(v___y_1810_, v_n_1862_);
lean_dec(v_n_1862_);
v___x_1864_ = lean_nat_shiftr(v___x_1824_, v_radicandShift_1863_);
v___x_1865_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3);
v___x_1866_ = lean_nat_dec_lt(v___x_1864_, v___x_1865_);
if (v___x_1866_ == 0)
{
lean_object* v___x_1867_; lean_object* v_fst_1868_; 
v___x_1867_ = lp_floatlib_FloatLib_Numerics_FixedWord_IntegerSquareRoot_sqrtRem(v___x_1864_);
v_fst_1868_ = lean_ctor_get(v___x_1867_, 0);
lean_inc(v_fst_1868_);
lean_dec_ref(v___x_1867_);
v___y_1561_ = v_shift_1833_;
v___y_1562_ = v___y_1810_;
v___y_1563_ = v___y_1811_;
v___y_1564_ = v___y_1820_;
v___y_1565_ = v___y_1812_;
v___y_1566_ = v___y_1813_;
v___y_1567_ = v___y_1814_;
v___y_1568_ = v___x_1824_;
v___y_1569_ = v_radicandShift_1863_;
v___y_1570_ = v___y_1818_;
v___y_1571_ = v___y_1819_;
v___y_1572_ = v_fst_1868_;
goto v___jp_1560_;
}
else
{
uint64_t v___x_1869_; uint64_t v___x_1870_; uint8_t v___x_1871_; 
v___x_1869_ = lean_uint64_of_nat(v___x_1864_);
lean_dec(v___x_1864_);
v___x_1870_ = 1ULL;
v___x_1871_ = lean_uint64_dec_le(v___x_1869_, v___x_1870_);
if (v___x_1871_ == 0)
{
uint64_t v___x_1872_; uint8_t v___x_1873_; 
v___x_1872_ = 2ULL;
v___x_1873_ = lean_uint64_dec_lt(v___x_1869_, v___x_1872_);
if (v___x_1873_ == 0)
{
uint64_t v___x_1874_; uint8_t v___x_1875_; 
v___x_1874_ = 16ULL;
v___x_1875_ = lean_uint64_dec_lt(v___x_1869_, v___x_1874_);
if (v___x_1875_ == 0)
{
uint64_t v___x_1876_; uint64_t v___x_1877_; uint8_t v___x_1878_; 
v___x_1876_ = 4ULL;
v___x_1877_ = 256ULL;
v___x_1878_ = lean_uint64_dec_lt(v___x_1869_, v___x_1877_);
if (v___x_1878_ == 0)
{
uint64_t v___x_1879_; uint64_t v___x_1880_; uint64_t v_high_1881_; uint64_t v___x_1882_; uint8_t v___x_1883_; 
v___x_1879_ = 32ULL;
v___x_1880_ = 8ULL;
v_high_1881_ = lean_uint64_shift_right(v___x_1869_, v___x_1879_);
v___x_1882_ = 0ULL;
v___x_1883_ = lean_uint64_dec_eq(v_high_1881_, v___x_1882_);
if (v___x_1883_ == 0)
{
v___y_1754_ = v___x_1876_;
v___y_1755_ = v___x_1883_;
v___y_1756_ = v___x_1880_;
v___y_1757_ = v___x_1870_;
v___y_1758_ = v___y_1811_;
v___y_1759_ = v___y_1820_;
v___y_1760_ = v___y_1814_;
v___y_1761_ = v___x_1824_;
v___y_1762_ = v___x_1869_;
v___y_1763_ = v_shift_1833_;
v___y_1764_ = v___y_1810_;
v___y_1765_ = v___y_1813_;
v___y_1766_ = v___y_1812_;
v___y_1767_ = v___x_1882_;
v___y_1768_ = v_radicandShift_1863_;
v___y_1769_ = v___y_1818_;
v___y_1770_ = v_high_1881_;
v___y_1771_ = v___x_1874_;
v___y_1772_ = v___y_1819_;
v___y_1773_ = v___x_1879_;
goto v___jp_1753_;
}
else
{
v___y_1754_ = v___x_1876_;
v___y_1755_ = v___x_1883_;
v___y_1756_ = v___x_1880_;
v___y_1757_ = v___x_1870_;
v___y_1758_ = v___y_1811_;
v___y_1759_ = v___y_1820_;
v___y_1760_ = v___y_1814_;
v___y_1761_ = v___x_1824_;
v___y_1762_ = v___x_1869_;
v___y_1763_ = v_shift_1833_;
v___y_1764_ = v___y_1810_;
v___y_1765_ = v___y_1813_;
v___y_1766_ = v___y_1812_;
v___y_1767_ = v___x_1882_;
v___y_1768_ = v_radicandShift_1863_;
v___y_1769_ = v___y_1818_;
v___y_1770_ = v_high_1881_;
v___y_1771_ = v___x_1874_;
v___y_1772_ = v___y_1819_;
v___y_1773_ = v___x_1882_;
goto v___jp_1753_;
}
}
else
{
uint64_t v_high_1884_; uint64_t v___x_1885_; uint8_t v___x_1886_; 
v_high_1884_ = lean_uint64_shift_right(v___x_1869_, v___x_1876_);
v___x_1885_ = 0ULL;
v___x_1886_ = lean_uint64_dec_eq(v_high_1884_, v___x_1885_);
if (v___x_1886_ == 0)
{
v___y_1793_ = v___x_1870_;
v___y_1794_ = v___y_1811_;
v___y_1795_ = v___y_1820_;
v___y_1796_ = v___y_1814_;
v___y_1797_ = v___x_1824_;
v___y_1798_ = v___x_1869_;
v___y_1799_ = v_high_1884_;
v___y_1800_ = v_shift_1833_;
v___y_1801_ = v___y_1810_;
v___y_1802_ = v___y_1813_;
v___y_1803_ = v___y_1812_;
v___y_1804_ = v_radicandShift_1863_;
v___y_1805_ = v___y_1818_;
v___y_1806_ = v___y_1819_;
v___y_1807_ = v___x_1886_;
v___y_1808_ = v___x_1876_;
goto v___jp_1792_;
}
else
{
v___y_1793_ = v___x_1870_;
v___y_1794_ = v___y_1811_;
v___y_1795_ = v___y_1820_;
v___y_1796_ = v___y_1814_;
v___y_1797_ = v___x_1824_;
v___y_1798_ = v___x_1869_;
v___y_1799_ = v_high_1884_;
v___y_1800_ = v_shift_1833_;
v___y_1801_ = v___y_1810_;
v___y_1802_ = v___y_1813_;
v___y_1803_ = v___y_1812_;
v___y_1804_ = v_radicandShift_1863_;
v___y_1805_ = v___y_1818_;
v___y_1806_ = v___y_1819_;
v___y_1807_ = v___x_1886_;
v___y_1808_ = v___x_1885_;
goto v___jp_1792_;
}
}
}
else
{
uint64_t v___x_1887_; 
v___x_1887_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___x_1869_);
v___y_1577_ = v___x_1870_;
v___y_1578_ = v___y_1811_;
v___y_1579_ = v___y_1820_;
v___y_1580_ = v___y_1814_;
v___y_1581_ = v___x_1824_;
v___y_1582_ = v___x_1869_;
v___y_1583_ = v_shift_1833_;
v___y_1584_ = v___y_1810_;
v___y_1585_ = v___y_1813_;
v___y_1586_ = v___y_1812_;
v___y_1587_ = v_radicandShift_1863_;
v___y_1588_ = v___y_1818_;
v___y_1589_ = v___y_1819_;
v___y_1590_ = v___x_1887_;
goto v___jp_1576_;
}
}
else
{
uint64_t v___x_1888_; 
v___x_1888_ = 0ULL;
v___y_1577_ = v___x_1870_;
v___y_1578_ = v___y_1811_;
v___y_1579_ = v___y_1820_;
v___y_1580_ = v___y_1814_;
v___y_1581_ = v___x_1824_;
v___y_1582_ = v___x_1869_;
v___y_1583_ = v_shift_1833_;
v___y_1584_ = v___y_1810_;
v___y_1585_ = v___y_1813_;
v___y_1586_ = v___y_1812_;
v___y_1587_ = v_radicandShift_1863_;
v___y_1588_ = v___y_1818_;
v___y_1589_ = v___y_1819_;
v___y_1590_ = v___x_1888_;
goto v___jp_1576_;
}
}
else
{
lean_object* v___x_1889_; 
v___x_1889_ = lean_uint64_to_nat(v___x_1869_);
v___y_1561_ = v_shift_1833_;
v___y_1562_ = v___y_1810_;
v___y_1563_ = v___y_1811_;
v___y_1564_ = v___y_1820_;
v___y_1565_ = v___y_1812_;
v___y_1566_ = v___y_1813_;
v___y_1567_ = v___y_1814_;
v___y_1568_ = v___x_1824_;
v___y_1569_ = v_radicandShift_1863_;
v___y_1570_ = v___y_1818_;
v___y_1571_ = v___y_1819_;
v___y_1572_ = v___x_1889_;
goto v___jp_1560_;
}
}
}
}
v___jp_1890_:
{
lean_object* v___x_1897_; uint8_t v___x_1898_; 
v___x_1897_ = lean_unsigned_to_nat(0u);
v___x_1898_ = lean_nat_dec_eq(v___y_1894_, v___x_1897_);
if (v___x_1898_ == 0)
{
lean_object* v___x_1899_; uint8_t v___x_1900_; lean_object* v___x_1901_; lean_object* v___x_1902_; lean_object* v___x_1903_; lean_object* v___x_1904_; lean_object* v___x_1905_; lean_object* v___x_1906_; lean_object* v___x_1907_; uint8_t v___x_1908_; 
v___x_1899_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__0));
v___x_1900_ = 1;
lean_inc(v___y_1891_);
v___x_1901_ = lean_nat_to_int(v___y_1891_);
v___x_1902_ = lean_int_ediv(v___y_1896_, v___x_1901_);
v___x_1903_ = l_Float_Model_totalExponent(v___y_1894_, v___y_1896_);
lean_inc(v___y_1892_);
v___x_1904_ = lean_nat_to_int(v___y_1892_);
v___x_1905_ = lean_int_add(v___x_1903_, v___x_1904_);
lean_dec(v___x_1904_);
lean_dec(v___x_1903_);
v___x_1906_ = lean_int_ediv(v___x_1905_, v___x_1901_);
lean_dec(v___x_1905_);
v___x_1907_ = l_Float_Model_Format_targetExponent(v___x_1899_, v___x_1906_);
lean_dec(v___x_1906_);
v___x_1908_ = lean_int_dec_le(v___x_1902_, v___x_1907_);
if (v___x_1908_ == 0)
{
lean_dec(v___x_1902_);
v___y_1810_ = v___y_1891_;
v___y_1811_ = v___x_1899_;
v___y_1812_ = v___x_1897_;
v___y_1813_ = v___y_1892_;
v___y_1814_ = v___x_1900_;
v___y_1815_ = v___x_1901_;
v___y_1816_ = v___y_1896_;
v___y_1817_ = v___y_1894_;
v___y_1818_ = v___y_1895_;
v___y_1819_ = v___x_1898_;
v___y_1820_ = v___x_1907_;
goto v___jp_1809_;
}
else
{
lean_dec(v___x_1907_);
v___y_1810_ = v___y_1891_;
v___y_1811_ = v___x_1899_;
v___y_1812_ = v___x_1897_;
v___y_1813_ = v___y_1892_;
v___y_1814_ = v___x_1900_;
v___y_1815_ = v___x_1901_;
v___y_1816_ = v___y_1896_;
v___y_1817_ = v___y_1894_;
v___y_1818_ = v___y_1895_;
v___y_1819_ = v___x_1898_;
v___y_1820_ = v___x_1902_;
goto v___jp_1809_;
}
}
else
{
lean_object* v___x_1909_; 
lean_dec(v___y_1896_);
lean_dec(v___y_1894_);
lean_dec(v___y_1892_);
lean_dec(v___y_1891_);
v___x_1909_ = l_BitVec_ofNat(v___y_1893_, v___x_1897_);
return v___x_1909_;
}
}
v___jp_1910_:
{
lean_object* v___x_1917_; uint8_t v___x_1918_; 
v___x_1917_ = lean_unsigned_to_nat(0u);
v___x_1918_ = lean_nat_dec_eq(v___y_1913_, v___x_1917_);
if (v___x_1918_ == 0)
{
lean_object* v___x_1919_; lean_object* v___x_1920_; lean_object* v___x_1921_; lean_object* v___x_1922_; lean_object* v___x_1923_; 
v___x_1919_ = lean_nat_to_int(v___y_1913_);
v___x_1920_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4);
v___x_1921_ = lean_int_sub(v___x_1919_, v___x_1920_);
lean_dec(v___x_1919_);
v___x_1922_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__1, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__1_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__1);
v___x_1923_ = lean_int_sub(v___x_1921_, v___x_1922_);
lean_dec(v___x_1921_);
v___y_1891_ = v___y_1911_;
v___y_1892_ = v___y_1912_;
v___y_1893_ = v___y_1914_;
v___y_1894_ = v___y_1916_;
v___y_1895_ = v___y_1915_;
v___y_1896_ = v___x_1923_;
goto v___jp_1890_;
}
else
{
lean_object* v___x_1924_; lean_object* v___x_1925_; lean_object* v___x_1926_; lean_object* v___x_1927_; lean_object* v___x_1928_; 
lean_dec(v___y_1913_);
lean_inc(v___y_1912_);
v___x_1924_ = lean_nat_to_int(v___y_1912_);
v___x_1925_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4);
v___x_1926_ = lean_int_sub(v___x_1924_, v___x_1925_);
lean_dec(v___x_1924_);
v___x_1927_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__1, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__1_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__1);
v___x_1928_ = lean_int_sub(v___x_1926_, v___x_1927_);
lean_dec(v___x_1926_);
v___y_1891_ = v___y_1911_;
v___y_1892_ = v___y_1912_;
v___y_1893_ = v___y_1914_;
v___y_1894_ = v___y_1916_;
v___y_1895_ = v___y_1915_;
v___y_1896_ = v___x_1928_;
goto v___jp_1890_;
}
}
v___jp_1929_:
{
lean_object* v___x_1930_; lean_object* v___x_1931_; uint8_t v___x_1932_; 
v___x_1930_ = lean_unsigned_to_nat(2048u);
v___x_1931_ = lean_unsigned_to_nat(2047u);
v___x_1932_ = l_Nat_testBit(v_x_1311_, v___x_1931_);
if (v___x_1932_ == 0)
{
lean_object* v___x_1933_; lean_object* v___x_1934_; uint8_t v___x_1935_; lean_object* v___x_1936_; lean_object* v___x_1937_; lean_object* v_exponent_1938_; lean_object* v___x_1939_; lean_object* v_fraction_1940_; lean_object* v___x_1941_; uint8_t v___x_1942_; 
v___x_1933_ = lean_unsigned_to_nat(1u);
v___x_1934_ = lean_unsigned_to_nat(2u);
v___x_1935_ = 1;
v___x_1936_ = lean_nat_shiftr(v_x_1311_, v___x_1312_);
v___x_1937_ = lean_unsigned_to_nat(524287u);
v_exponent_1938_ = lean_nat_land(v___x_1936_, v___x_1937_);
lean_dec(v___x_1936_);
v___x_1939_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__2, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__2_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__2);
v_fraction_1940_ = lean_nat_land(v_x_1311_, v___x_1939_);
lean_dec(v_x_1311_);
v___x_1941_ = lean_unsigned_to_nat(0u);
v___x_1942_ = lean_nat_dec_eq(v_exponent_1938_, v___x_1941_);
if (v___x_1942_ == 0)
{
lean_object* v___x_1943_; lean_object* v___x_1944_; 
v___x_1943_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__3, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__3_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__3);
v___x_1944_ = lean_nat_add(v___x_1943_, v_fraction_1940_);
lean_dec(v_fraction_1940_);
v___y_1911_ = v___x_1934_;
v___y_1912_ = v___x_1933_;
v___y_1913_ = v_exponent_1938_;
v___y_1914_ = v___x_1930_;
v___y_1915_ = v___x_1935_;
v___y_1916_ = v___x_1944_;
goto v___jp_1910_;
}
else
{
v___y_1911_ = v___x_1934_;
v___y_1912_ = v___x_1933_;
v___y_1913_ = v_exponent_1938_;
v___y_1914_ = v___x_1930_;
v___y_1915_ = v___x_1935_;
v___y_1916_ = v_fraction_1940_;
goto v___jp_1910_;
}
}
else
{
lean_object* v___x_1945_; 
lean_dec(v_x_1311_);
v___x_1945_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__9, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__9_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__9);
return v___x_1945_;
}
}
v___jp_1946_:
{
lean_object* v___x_1947_; lean_object* v___x_1948_; lean_object* v___x_1949_; lean_object* v___x_1950_; uint8_t v___x_1951_; 
v___x_1947_ = lean_nat_shiftr(v_x_1311_, v___x_1312_);
v___x_1948_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__10, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__10_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__10);
v___x_1949_ = lean_nat_land(v___x_1947_, v___x_1948_);
lean_dec(v___x_1947_);
v___x_1950_ = lean_unsigned_to_nat(0u);
v___x_1951_ = lean_nat_dec_eq(v___x_1949_, v___x_1950_);
lean_dec(v___x_1949_);
if (v___x_1951_ == 0)
{
goto v___jp_1929_;
}
else
{
lean_object* v___x_1952_; lean_object* v___x_1953_; uint8_t v___x_1954_; 
v___x_1952_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__12, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__12_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__12);
v___x_1953_ = lean_nat_land(v_x_1311_, v___x_1952_);
v___x_1954_ = lean_nat_dec_eq(v___x_1953_, v___x_1950_);
lean_dec(v___x_1953_);
if (v___x_1954_ == 0)
{
goto v___jp_1929_;
}
else
{
return v_x_1311_;
}
}
}
v___jp_1955_:
{
uint8_t v___x_1957_; 
v___x_1957_ = l_Option_decidableEqNone___redArg(v___y_1956_);
if (v___x_1957_ == 0)
{
lean_object* v_val_1958_; 
lean_dec(v_x_1311_);
v_val_1958_ = lean_ctor_get(v___y_1956_, 0);
lean_inc(v_val_1958_);
lean_dec(v___y_1956_);
return v_val_1958_;
}
else
{
lean_object* v___x_1959_; lean_object* v___x_1960_; lean_object* v___x_1961_; lean_object* v___x_1962_; uint8_t v___x_1963_; 
lean_dec(v___y_1956_);
v___x_1959_ = lean_nat_shiftr(v_x_1311_, v___x_1312_);
v___x_1960_ = lean_unsigned_to_nat(524287u);
v___x_1961_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__10, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__10_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__10);
v___x_1962_ = lean_nat_land(v___x_1959_, v___x_1961_);
lean_dec(v___x_1959_);
v___x_1963_ = lean_nat_dec_eq(v___x_1962_, v___x_1960_);
lean_dec(v___x_1962_);
if (v___x_1963_ == 0)
{
goto v___jp_1946_;
}
else
{
lean_object* v___x_1964_; lean_object* v___x_1965_; lean_object* v___x_1966_; uint8_t v___x_1967_; 
v___x_1964_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__12, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__12_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__12);
v___x_1965_ = lean_nat_land(v_x_1311_, v___x_1964_);
v___x_1966_ = lean_unsigned_to_nat(0u);
v___x_1967_ = lean_nat_dec_eq(v___x_1965_, v___x_1966_);
lean_dec(v___x_1965_);
if (v___x_1967_ == 0)
{
goto v___jp_1946_;
}
else
{
lean_object* v___x_1968_; uint8_t v___x_1969_; 
v___x_1968_ = lean_unsigned_to_nat(2047u);
v___x_1969_ = l_Nat_testBit(v_x_1311_, v___x_1968_);
lean_dec(v_x_1311_);
if (v___x_1969_ == 0)
{
if (v___x_1969_ == 0)
{
lean_object* v___x_1970_; 
v___x_1970_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__6, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__6_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__6);
return v___x_1970_;
}
else
{
lean_object* v___x_1971_; 
v___x_1971_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__15, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__15_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__15);
return v___x_1971_;
}
}
else
{
lean_object* v___x_1972_; 
v___x_1972_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__9, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__9_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1___closed__9);
return v___x_1972_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0(lean_object* v_x_1989_){
_start:
{
lean_object* v___x_1990_; 
v___x_1990_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1(v_x_1989_);
return v___x_1990_;
}
}
static lean_object* _init_l_BalancedSqrt_block2048___closed__4(void){
_start:
{
lean_object* v___x_2007_; uint8_t v___x_2008_; lean_object* v___x_2009_; lean_object* v___x_2010_; 
v___x_2007_ = ((lean_object*)(l_BalancedSqrt_block2048___closed__3));
v___x_2008_ = 5;
v___x_2009_ = ((lean_object*)(l_BalancedSqrt_block2048___closed__0));
v___x_2010_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep_configuredBenchmarkCarrier(v___x_2009_, v___x_2008_, v___x_2007_);
return v___x_2010_;
}
}
static lean_object* _init_l_BalancedSqrt_block2048___closed__5(void){
_start:
{
lean_object* v___x_2011_; lean_object* v___x_2012_; 
v___x_2011_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__4, &l_BalancedSqrt_block2048___closed__4_once, _init_l_BalancedSqrt_block2048___closed__4);
v___x_2012_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep_benchmarkExecFloatInhabited___redArg(v___x_2011_);
return v___x_2012_;
}
}
static uint8_t _init_l_BalancedSqrt_block2048___closed__6(void){
_start:
{
uint8_t v___x_2013_; uint8_t v___x_2014_; lean_object* v___x_2015_; lean_object* v___x_2016_; uint8_t v___x_2017_; 
v___x_2013_ = 4;
v___x_2014_ = 5;
v___x_2015_ = lp_floatlib_FloatLib_Floats_ExecFloat_Backend_Policy_throughput;
v___x_2016_ = ((lean_object*)(l_BalancedSqrt_block2048___closed__0));
v___x_2017_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Plan_firstOrderSelected(v___x_2016_, v___x_2015_, v___x_2014_, v___x_2013_);
return v___x_2017_;
}
}
static uint8_t _init_l_BalancedSqrt_block2048___closed__7(void){
_start:
{
uint8_t v___x_2018_; uint8_t v___x_2019_; lean_object* v___x_2020_; lean_object* v___x_2021_; uint8_t v___x_2022_; 
v___x_2018_ = 4;
v___x_2019_ = 5;
v___x_2020_ = lp_floatlib_FloatLib_Floats_ExecFloat_Backend_Policy_throughput;
v___x_2021_ = ((lean_object*)(l_BalancedSqrt_block2048___closed__0));
v___x_2022_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Plan_firstOrderGenericSelected(v___x_2021_, v___x_2020_, v___x_2019_, v___x_2018_);
return v___x_2022_;
}
}
static lean_object* _init_l_BalancedSqrt_block2048___closed__9(void){
_start:
{
lean_object* v___f_2027_; lean_object* v_selection_2028_; 
v___f_2027_ = ((lean_object*)(l_BalancedSqrt_block2048___closed__8));
v_selection_2028_ = lean_mk_thunk(v___f_2027_);
return v_selection_2028_;
}
}
static lean_object* _init_l_BalancedSqrt_block2048___closed__10(void){
_start:
{
lean_object* v_selection_2029_; lean_object* v___x_2030_; 
v_selection_2029_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__9, &l_BalancedSqrt_block2048___closed__9_once, _init_l_BalancedSqrt_block2048___closed__9);
v___x_2030_ = lean_thunk_get_own(v_selection_2029_);
return v___x_2030_;
}
}
static lean_object* _init_l_BalancedSqrt_block2048___closed__11(void){
_start:
{
uint8_t v___x_2031_; lean_object* v___x_2032_; lean_object* v___x_2033_; 
v___x_2031_ = 4;
v___x_2032_ = ((lean_object*)(l_BalancedSqrt_block2048___closed__0));
v___x_2033_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Descriptor_Plan_structuralRoute_x3f(v___x_2032_, v___x_2031_);
return v___x_2033_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_block2048(lean_object* v_x_2034_, uint64_t v_x_2035_, lean_object* v_x_2036_, lean_object* v_x_2037_){
_start:
{
lean_object* v_zero_2038_; uint8_t v_isZero_2039_; 
v_zero_2038_ = lean_unsigned_to_nat(0u);
v_isZero_2039_ = lean_nat_dec_eq(v_x_2034_, v_zero_2038_);
if (v_isZero_2039_ == 1)
{
lean_dec(v_x_2034_);
return v_x_2037_;
}
else
{
uint64_t v_sink_2040_; uint64_t v_trace_2041_; lean_object* v___x_2043_; uint8_t v_isShared_2044_; uint8_t v_isSharedCheck_2079_; 
v_sink_2040_ = lean_ctor_get_uint64(v_x_2037_, 0);
v_trace_2041_ = lean_ctor_get_uint64(v_x_2037_, 8);
v_isSharedCheck_2079_ = !lean_is_exclusive(v_x_2037_);
if (v_isSharedCheck_2079_ == 0)
{
v___x_2043_ = v_x_2037_;
v_isShared_2044_ = v_isSharedCheck_2079_;
goto v_resetjp_2042_;
}
else
{
lean_dec(v_x_2037_);
v___x_2043_ = lean_box(0);
v_isShared_2044_ = v_isSharedCheck_2079_;
goto v_resetjp_2042_;
}
v_resetjp_2042_:
{
lean_object* v_one_2045_; lean_object* v_n_2046_; lean_object* v_index_2047_; lean_object* v___y_2049_; lean_object* v___y_2065_; lean_object* v___x_2067_; lean_object* v___x_2068_; uint8_t v___x_2069_; 
v_one_2045_ = lean_unsigned_to_nat(1u);
v_n_2046_ = lean_nat_sub(v_x_2034_, v_one_2045_);
lean_dec(v_x_2034_);
v_index_2047_ = l_BalancedSqrt_nextUnused(v_x_2035_, v_sink_2040_);
v___x_2067_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__5, &l_BalancedSqrt_block2048___closed__5_once, _init_l_BalancedSqrt_block2048___closed__5);
v___x_2068_ = lean_array_get_borrowed(v___x_2067_, v_x_2036_, v_index_2047_);
v___x_2069_ = lean_uint8_once(&l_BalancedSqrt_block2048___closed__6, &l_BalancedSqrt_block2048___closed__6_once, _init_l_BalancedSqrt_block2048___closed__6);
if (v___x_2069_ == 0)
{
uint8_t v___x_2070_; 
v___x_2070_ = lean_uint8_once(&l_BalancedSqrt_block2048___closed__7, &l_BalancedSqrt_block2048___closed__7_once, _init_l_BalancedSqrt_block2048___closed__7);
if (v___x_2070_ == 0)
{
lean_object* v___x_2071_; lean_object* v_run_2072_; lean_object* v___x_2073_; 
v___x_2071_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__10, &l_BalancedSqrt_block2048___closed__10_once, _init_l_BalancedSqrt_block2048___closed__10);
v_run_2072_ = lean_ctor_get(v___x_2071_, 1);
lean_inc(v_run_2072_);
lean_inc(v___x_2068_);
v___x_2073_ = lean_apply_1(v_run_2072_, v___x_2068_);
v___y_2049_ = v___x_2073_;
goto v___jp_2048_;
}
else
{
lean_object* v___x_2074_; 
lean_inc(v___x_2068_);
v___x_2074_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1(v___x_2068_);
v___y_2049_ = v___x_2074_;
goto v___jp_2048_;
}
}
else
{
lean_object* v___x_2075_; 
v___x_2075_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__11, &l_BalancedSqrt_block2048___closed__11_once, _init_l_BalancedSqrt_block2048___closed__11);
if (lean_obj_tag(v___x_2075_) == 1)
{
lean_object* v_val_2076_; uint8_t v___x_2077_; 
v_val_2076_ = lean_ctor_get(v___x_2075_, 0);
v___x_2077_ = lean_unbox(v_val_2076_);
if (v___x_2077_ == 2)
{
lean_object* v___x_2078_; 
lean_inc(v___x_2068_);
v___x_2078_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1(v___x_2068_);
v___y_2049_ = v___x_2078_;
goto v___jp_2048_;
}
else
{
lean_inc(v___x_2068_);
v___y_2065_ = v___x_2068_;
goto v___jp_2064_;
}
}
else
{
lean_inc(v___x_2068_);
v___y_2065_ = v___x_2068_;
goto v___jp_2064_;
}
}
v___jp_2048_:
{
uint64_t v___x_2050_; uint64_t v___x_2051_; uint64_t v___x_2052_; uint64_t v___x_2053_; uint64_t v___x_2054_; uint64_t v___x_2055_; uint64_t v___x_2056_; uint64_t v___x_2057_; uint64_t v___x_2058_; uint64_t v___x_2059_; lean_object* v___x_2061_; 
v___x_2050_ = 1ULL;
v___x_2051_ = lean_uint64_of_nat(v_index_2047_);
lean_dec(v_index_2047_);
v___x_2052_ = lean_uint64_shift_left(v___x_2050_, v___x_2051_);
v___x_2053_ = lean_uint64_lor(v_x_2035_, v___x_2052_);
v___x_2054_ = lean_uint64_of_nat(v___y_2049_);
lean_dec(v___y_2049_);
v___x_2055_ = lean_uint64_xor(v_sink_2040_, v___x_2054_);
v___x_2056_ = 1099511628211ULL;
v___x_2057_ = lean_uint64_mul(v___x_2055_, v___x_2056_);
v___x_2058_ = lean_uint64_xor(v_trace_2041_, v___x_2051_);
v___x_2059_ = lean_uint64_mul(v___x_2058_, v___x_2056_);
if (v_isShared_2044_ == 0)
{
v___x_2061_ = v___x_2043_;
goto v_reusejp_2060_;
}
else
{
lean_object* v_reuseFailAlloc_2063_; 
v_reuseFailAlloc_2063_ = lean_alloc_ctor(0, 0, 16);
v___x_2061_ = v_reuseFailAlloc_2063_;
goto v_reusejp_2060_;
}
v_reusejp_2060_:
{
lean_ctor_set_uint64(v___x_2061_, 0, v___x_2057_);
lean_ctor_set_uint64(v___x_2061_, 8, v___x_2059_);
v_x_2034_ = v_n_2046_;
v_x_2035_ = v___x_2053_;
v_x_2037_ = v___x_2061_;
goto _start;
}
}
v___jp_2064_:
{
lean_object* v___x_2066_; 
v___x_2066_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1(v___y_2065_);
v___y_2049_ = v___x_2066_;
goto v___jp_2048_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_block2048___boxed(lean_object* v_x_2080_, lean_object* v_x_2081_, lean_object* v_x_2082_, lean_object* v_x_2083_){
_start:
{
uint64_t v_x_25947__boxed_2084_; lean_object* v_res_2085_; 
v_x_25947__boxed_2084_ = lean_unbox_uint64(v_x_2081_);
lean_dec_ref(v_x_2081_);
v_res_2085_ = l_BalancedSqrt_block2048(v_x_2080_, v_x_25947__boxed_2084_, v_x_2082_, v_x_2083_);
lean_dec_ref(v_x_2082_);
return v_res_2085_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block4096_spec__2___redArg(){
_start:
{
lean_object* v___x_2087_; 
v___x_2087_ = lean_box(0);
return v___x_2087_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block4096_spec__2___redArg___boxed(lean_object* v___dummy_2088_){
_start:
{
lean_object* v_res_2089_; 
v_res_2089_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block4096_spec__2___redArg();
return v_res_2089_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block4096_spec__2(lean_object* v_x_2090_){
_start:
{
lean_object* v___x_2091_; 
v___x_2091_ = lean_box(0);
return v___x_2091_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block4096_spec__2___boxed(lean_object* v_x_2092_){
_start:
{
lean_object* v_res_2093_; 
v_res_2093_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block4096_spec__2(v_x_2092_);
lean_dec(v_x_2092_);
return v_res_2093_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__1(void){
_start:
{
lean_object* v___x_2097_; lean_object* v___x_2098_; 
v___x_2097_ = lean_unsigned_to_nat(4076u);
v___x_2098_ = lean_nat_to_int(v___x_2097_);
return v___x_2098_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__2(void){
_start:
{
lean_object* v___x_2099_; 
v___x_2099_ = lean_cstr_to_nat("996006852543976313297035895077347166614498375937827854522927745136217029544408280228449642119405325261011225428046477163302968443094056708586917960978856351800877548736295698490487661489852636637142248164993234850288695182225907083198866543144785516259010227876476005622180985202902421106784799369428662306487025238878047738978295927229176464652614072258780926993395515864428544059727096431459632436460338172803203092878568567690369352424442169799324488735379258488663117467570394199689722586663219536084700365050903672611172690595433069073856441339165450307196133467071652937150953579342217240202518152706331841491514688409085856271488032703483208295920213957021425440133255975416189837642178611680637759561810851216110243708762298068983831895255672027391692263442167368492386707572738222932608560870680348458503026067156702029889108775103946388037566135826698310292192149085829783031122567324463197117453618910709511687000601631584864089870426084310022128556465006129506168269916530695723981096052765672415208690124186754396752424691314156690169150894376608440157292649159348315735166031839791227929030298374543264781884960673314912165620468237997136977196981824366750456498352519522792437477857339890895929569058140125659135");
return v___x_2099_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__3(void){
_start:
{
lean_object* v___x_2100_; 
v___x_2100_ = lean_cstr_to_nat("996006852543976313297035895077347166614498375937827854522927745136217029544408280228449642119405325261011225428046477163302968443094056708586917960978856351800877548736295698490487661489852636637142248164993234850288695182225907083198866543144785516259010227876476005622180985202902421106784799369428662306487025238878047738978295927229176464652614072258780926993395515864428544059727096431459632436460338172803203092878568567690369352424442169799324488735379258488663117467570394199689722586663219536084700365050903672611172690595433069073856441339165450307196133467071652937150953579342217240202518152706331841491514688409085856271488032703483208295920213957021425440133255975416189837642178611680637759561810851216110243708762298068983831895255672027391692263442167368492386707572738222932608560870680348458503026067156702029889108775103946388037566135826698310292192149085829783031122567324463197117453618910709511687000601631584864089870426084310022128556465006129506168269916530695723981096052765672415208690124186754396752424691314156690169150894376608440157292649159348315735166031839791227929030298374543264781884960673314912165620468237997136977196981824366750456498352519522792437477857339890895929569058140125659136");
return v___x_2100_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__4(void){
_start:
{
lean_object* v___x_2101_; lean_object* v___x_2102_; lean_object* v___x_2103_; 
v___x_2101_ = lean_unsigned_to_nat(4076u);
v___x_2102_ = lean_unsigned_to_nat(2u);
v___x_2103_ = lean_nat_pow(v___x_2102_, v___x_2101_);
return v___x_2103_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__5(void){
_start:
{
lean_object* v___x_2104_; lean_object* v___x_2105_; lean_object* v___x_2106_; 
v___x_2104_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__4, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__4_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__4);
v___x_2105_ = lean_unsigned_to_nat(524287u);
v___x_2106_ = lean_nat_mul(v___x_2105_, v___x_2104_);
return v___x_2106_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__6(void){
_start:
{
lean_object* v___x_2107_; lean_object* v___x_2108_; lean_object* v___x_2109_; 
v___x_2107_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__5, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__5_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__5);
v___x_2108_ = lean_unsigned_to_nat(4096u);
v___x_2109_ = l_BitVec_ofNat(v___x_2108_, v___x_2107_);
return v___x_2109_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__7(void){
_start:
{
lean_object* v___x_2110_; lean_object* v___x_2111_; lean_object* v___x_2112_; 
v___x_2110_ = lean_unsigned_to_nat(4075u);
v___x_2111_ = lean_unsigned_to_nat(2u);
v___x_2112_ = lean_nat_pow(v___x_2111_, v___x_2110_);
return v___x_2112_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__8(void){
_start:
{
lean_object* v___x_2113_; lean_object* v___x_2114_; lean_object* v___x_2115_; 
v___x_2113_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__7, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__7_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__7);
v___x_2114_ = lean_unsigned_to_nat(4096u);
v___x_2115_ = l_BitVec_ofNat(v___x_2114_, v___x_2113_);
return v___x_2115_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__9(void){
_start:
{
lean_object* v___x_2116_; lean_object* v___x_2117_; lean_object* v___x_2118_; 
v___x_2116_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__8, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__8_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__8);
v___x_2117_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__6, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__6_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__6);
v___x_2118_ = lean_nat_lor(v___x_2117_, v___x_2116_);
return v___x_2118_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__10(void){
_start:
{
lean_object* v___x_2119_; lean_object* v___x_2120_; lean_object* v___x_2121_; 
v___x_2119_ = lean_unsigned_to_nat(524287u);
v___x_2120_ = lean_unsigned_to_nat(4096u);
v___x_2121_ = l_BitVec_ofNat(v___x_2120_, v___x_2119_);
return v___x_2121_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__11(void){
_start:
{
lean_object* v___x_2122_; lean_object* v___x_2123_; lean_object* v___x_2124_; 
v___x_2122_ = lean_unsigned_to_nat(1u);
v___x_2123_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__4, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__4_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__4);
v___x_2124_ = lean_nat_sub(v___x_2123_, v___x_2122_);
return v___x_2124_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__12(void){
_start:
{
lean_object* v___x_2125_; lean_object* v___x_2126_; lean_object* v___x_2127_; 
v___x_2125_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__11, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__11_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__11);
v___x_2126_ = lean_unsigned_to_nat(4096u);
v___x_2127_ = l_BitVec_ofNat(v___x_2126_, v___x_2125_);
return v___x_2127_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__13(void){
_start:
{
lean_object* v___x_2128_; lean_object* v___x_2129_; lean_object* v___x_2130_; 
v___x_2128_ = lean_unsigned_to_nat(4095u);
v___x_2129_ = lean_unsigned_to_nat(2u);
v___x_2130_ = lean_nat_pow(v___x_2129_, v___x_2128_);
return v___x_2130_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__14(void){
_start:
{
lean_object* v___x_2131_; lean_object* v___x_2132_; lean_object* v___x_2133_; 
v___x_2131_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__13, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__13_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__13);
v___x_2132_ = lean_unsigned_to_nat(4096u);
v___x_2133_ = l_BitVec_ofNat(v___x_2132_, v___x_2131_);
return v___x_2133_;
}
}
static lean_object* _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__15(void){
_start:
{
lean_object* v___x_2134_; lean_object* v___x_2135_; lean_object* v___x_2136_; 
v___x_2134_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__6, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__6_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__6);
v___x_2135_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__14, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__14_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__14);
v___x_2136_ = lean_nat_lor(v___x_2135_, v___x_2134_);
return v___x_2136_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1(lean_object* v_x_2137_){
_start:
{
lean_object* v___x_2138_; lean_object* v___y_2140_; lean_object* v___y_2144_; lean_object* v___y_2145_; lean_object* v___y_2146_; lean_object* v___y_2147_; uint8_t v___y_2148_; lean_object* v___y_2149_; lean_object* v___y_2162_; lean_object* v___y_2163_; lean_object* v___y_2164_; lean_object* v___y_2165_; lean_object* v___y_2166_; uint8_t v___y_2167_; lean_object* v___y_2168_; uint64_t v___y_2180_; lean_object* v___y_2181_; lean_object* v___y_2182_; lean_object* v___y_2183_; lean_object* v___y_2184_; uint64_t v___y_2185_; lean_object* v___y_2186_; uint8_t v___y_2187_; lean_object* v___y_2188_; uint64_t v___y_2189_; uint64_t v___y_2198_; lean_object* v___y_2199_; lean_object* v___y_2200_; lean_object* v___y_2201_; lean_object* v___y_2202_; uint64_t v___y_2203_; uint64_t v___y_2204_; lean_object* v___y_2205_; uint8_t v___y_2206_; lean_object* v___y_2207_; uint64_t v___y_2208_; uint64_t v___y_2212_; uint64_t v___y_2213_; uint8_t v___y_2214_; lean_object* v___y_2215_; lean_object* v___y_2216_; lean_object* v___y_2217_; lean_object* v___y_2218_; uint64_t v___y_2219_; lean_object* v___y_2220_; uint8_t v___y_2221_; lean_object* v___y_2222_; uint64_t v___y_2223_; uint64_t v___y_2225_; lean_object* v___y_2226_; lean_object* v___y_2227_; lean_object* v___y_2228_; uint64_t v___y_2229_; uint64_t v___y_2230_; uint64_t v___y_2231_; uint64_t v___y_2232_; uint64_t v___y_2233_; uint8_t v___y_2234_; lean_object* v___y_2235_; lean_object* v___y_2236_; lean_object* v___y_2237_; uint64_t v___y_2238_; uint64_t v___y_2245_; lean_object* v___y_2246_; lean_object* v___y_2247_; lean_object* v___y_2248_; uint64_t v___y_2249_; uint64_t v___y_2250_; uint64_t v___y_2251_; uint64_t v___y_2252_; uint8_t v___y_2253_; uint64_t v___y_2254_; lean_object* v___y_2255_; uint8_t v___y_2256_; lean_object* v___y_2257_; uint64_t v___y_2258_; lean_object* v___y_2259_; uint64_t v___y_2260_; uint64_t v___y_2262_; uint64_t v___y_2263_; lean_object* v___y_2264_; lean_object* v___y_2265_; lean_object* v___y_2266_; uint64_t v___y_2267_; uint64_t v___y_2268_; uint64_t v___y_2269_; uint64_t v___y_2270_; uint64_t v___y_2271_; uint8_t v___y_2272_; lean_object* v___y_2273_; lean_object* v___y_2274_; lean_object* v___y_2275_; uint64_t v___y_2276_; uint64_t v___y_2280_; uint64_t v___y_2281_; lean_object* v___y_2282_; lean_object* v___y_2283_; lean_object* v___y_2284_; uint64_t v___y_2285_; uint64_t v___y_2286_; uint8_t v___y_2287_; uint64_t v___y_2288_; uint64_t v___y_2289_; uint8_t v___y_2290_; uint64_t v___y_2291_; lean_object* v___y_2292_; lean_object* v___y_2293_; uint64_t v___y_2294_; lean_object* v___y_2295_; uint64_t v___y_2296_; uint64_t v___y_2298_; uint64_t v___y_2299_; lean_object* v___y_2300_; uint64_t v___y_2301_; lean_object* v___y_2302_; lean_object* v___y_2303_; uint64_t v___y_2304_; uint64_t v___y_2305_; uint64_t v___y_2306_; uint64_t v___y_2307_; uint8_t v___y_2308_; lean_object* v___y_2309_; lean_object* v___y_2310_; lean_object* v___y_2311_; uint64_t v___y_2312_; uint64_t v___y_2316_; uint64_t v___y_2317_; lean_object* v___y_2318_; uint64_t v___y_2319_; uint64_t v___y_2320_; lean_object* v___y_2321_; lean_object* v___y_2322_; uint64_t v___y_2323_; uint8_t v___y_2324_; uint64_t v___y_2325_; uint64_t v___y_2326_; uint8_t v___y_2327_; lean_object* v___y_2328_; lean_object* v___y_2329_; uint64_t v___y_2330_; lean_object* v___y_2331_; uint64_t v___y_2332_; uint64_t v___y_2334_; uint64_t v___y_2335_; uint64_t v___y_2336_; lean_object* v___y_2337_; uint64_t v___y_2338_; lean_object* v___y_2339_; lean_object* v___y_2340_; uint64_t v___y_2341_; uint64_t v___y_2342_; uint64_t v___y_2343_; uint8_t v___y_2344_; lean_object* v___y_2345_; lean_object* v___y_2346_; lean_object* v___y_2347_; uint64_t v___y_2348_; uint64_t v___y_2352_; uint64_t v___y_2353_; uint64_t v___y_2354_; lean_object* v___y_2355_; uint64_t v___y_2356_; lean_object* v___y_2357_; lean_object* v___y_2358_; uint64_t v___y_2359_; uint64_t v___y_2360_; uint64_t v___y_2361_; uint8_t v___y_2362_; lean_object* v___y_2363_; lean_object* v___y_2364_; lean_object* v___y_2365_; uint8_t v___y_2366_; uint64_t v___y_2367_; lean_object* v___y_2369_; lean_object* v___y_2370_; lean_object* v___y_2371_; lean_object* v___y_2372_; lean_object* v___y_2373_; lean_object* v___y_2374_; lean_object* v___y_2375_; uint8_t v___y_2376_; uint8_t v___y_2377_; uint8_t v___y_2378_; lean_object* v___y_2379_; uint8_t v___y_2380_; lean_object* v___y_2387_; lean_object* v___y_2388_; lean_object* v___y_2389_; lean_object* v___y_2390_; lean_object* v___y_2391_; lean_object* v___y_2392_; lean_object* v___y_2393_; uint8_t v___y_2394_; uint8_t v___y_2395_; uint8_t v___y_2396_; lean_object* v___y_2397_; lean_object* v___y_2398_; lean_object* v___y_2403_; lean_object* v___y_2404_; lean_object* v___y_2405_; uint64_t v___y_2406_; uint8_t v___y_2407_; uint8_t v___y_2408_; uint8_t v___y_2409_; lean_object* v___y_2410_; lean_object* v___y_2411_; lean_object* v___y_2412_; uint64_t v___y_2413_; lean_object* v___y_2414_; lean_object* v___y_2415_; uint64_t v___y_2416_; uint64_t v___y_2425_; lean_object* v___y_2426_; uint64_t v___y_2427_; lean_object* v___y_2428_; lean_object* v___y_2429_; uint64_t v___y_2430_; uint8_t v___y_2431_; uint8_t v___y_2432_; uint8_t v___y_2433_; lean_object* v___y_2434_; lean_object* v___y_2435_; lean_object* v___y_2436_; uint64_t v___y_2437_; lean_object* v___y_2438_; lean_object* v___y_2439_; uint64_t v___y_2440_; uint64_t v___y_2441_; uint64_t v___y_2442_; uint64_t v___y_2449_; uint64_t v___y_2450_; lean_object* v___y_2451_; lean_object* v___y_2452_; lean_object* v___y_2453_; uint64_t v___y_2454_; uint8_t v___y_2455_; uint8_t v___y_2456_; uint8_t v___y_2457_; uint8_t v___y_2458_; lean_object* v___y_2459_; lean_object* v___y_2460_; uint64_t v___y_2461_; lean_object* v___y_2462_; uint64_t v___y_2463_; lean_object* v___y_2464_; lean_object* v___y_2465_; uint64_t v___y_2466_; uint64_t v___y_2467_; uint64_t v___y_2468_; uint64_t v___y_2470_; lean_object* v___y_2471_; lean_object* v___y_2472_; lean_object* v___y_2473_; uint64_t v___y_2474_; uint64_t v___y_2475_; uint8_t v___y_2476_; uint8_t v___y_2477_; uint8_t v___y_2478_; lean_object* v___y_2479_; lean_object* v___y_2480_; lean_object* v___y_2481_; uint64_t v___y_2482_; uint64_t v___y_2483_; lean_object* v___y_2484_; lean_object* v___y_2485_; uint64_t v___y_2486_; uint64_t v___y_2487_; uint64_t v___y_2488_; uint64_t v___y_2492_; uint8_t v___y_2493_; lean_object* v___y_2494_; lean_object* v___y_2495_; lean_object* v___y_2496_; uint64_t v___y_2497_; uint64_t v___y_2498_; uint64_t v___y_2499_; uint8_t v___y_2500_; uint8_t v___y_2501_; uint8_t v___y_2502_; lean_object* v___y_2503_; lean_object* v___y_2504_; lean_object* v___y_2505_; uint64_t v___y_2506_; uint64_t v___y_2507_; uint64_t v___y_2508_; lean_object* v___y_2509_; lean_object* v___y_2510_; uint64_t v___y_2511_; uint64_t v___y_2512_; uint64_t v___y_2514_; lean_object* v___y_2515_; lean_object* v___y_2516_; lean_object* v___y_2517_; uint64_t v___y_2518_; uint64_t v___y_2519_; uint64_t v___y_2520_; uint8_t v___y_2521_; uint8_t v___y_2522_; uint8_t v___y_2523_; lean_object* v___y_2524_; lean_object* v___y_2525_; lean_object* v___y_2526_; uint64_t v___y_2527_; uint64_t v___y_2528_; lean_object* v___y_2529_; lean_object* v___y_2530_; uint64_t v___y_2531_; uint64_t v___y_2532_; uint64_t v___y_2536_; uint64_t v___y_2537_; lean_object* v___y_2538_; lean_object* v___y_2539_; lean_object* v___y_2540_; uint64_t v___y_2541_; uint64_t v___y_2542_; uint64_t v___y_2543_; uint8_t v___y_2544_; uint8_t v___y_2545_; uint8_t v___y_2546_; lean_object* v___y_2547_; lean_object* v___y_2548_; lean_object* v___y_2549_; uint8_t v___y_2550_; uint64_t v___y_2551_; uint64_t v___y_2552_; lean_object* v___y_2553_; lean_object* v___y_2554_; uint64_t v___y_2555_; uint64_t v___y_2556_; lean_object* v___y_2558_; lean_object* v___y_2559_; lean_object* v___y_2560_; uint64_t v___y_2561_; uint64_t v___y_2562_; uint64_t v___y_2563_; uint8_t v___y_2564_; uint8_t v___y_2565_; uint8_t v___y_2566_; lean_object* v___y_2567_; uint64_t v___y_2568_; lean_object* v___y_2569_; lean_object* v___y_2570_; uint64_t v___y_2571_; uint64_t v___y_2572_; lean_object* v___y_2573_; lean_object* v___y_2574_; uint64_t v___y_2575_; uint64_t v___y_2576_; lean_object* v___y_2580_; lean_object* v___y_2581_; lean_object* v___y_2582_; uint64_t v___y_2583_; uint64_t v___y_2584_; uint64_t v___y_2585_; uint64_t v___y_2586_; uint8_t v___y_2587_; uint8_t v___y_2588_; uint8_t v___y_2589_; lean_object* v___y_2590_; uint64_t v___y_2591_; lean_object* v___y_2592_; lean_object* v___y_2593_; uint64_t v___y_2594_; uint64_t v___y_2595_; lean_object* v___y_2596_; uint8_t v___y_2597_; lean_object* v___y_2598_; uint64_t v___y_2599_; lean_object* v___y_2601_; lean_object* v___y_2602_; lean_object* v___y_2603_; uint64_t v___y_2604_; uint8_t v___y_2605_; uint8_t v___y_2606_; uint8_t v___y_2607_; lean_object* v___y_2608_; lean_object* v___y_2609_; lean_object* v___y_2610_; uint64_t v___y_2611_; lean_object* v___y_2612_; lean_object* v___y_2613_; uint64_t v___y_2614_; uint64_t v___y_2615_; lean_object* v___y_2619_; lean_object* v___y_2620_; lean_object* v___y_2621_; uint64_t v___y_2622_; uint64_t v___y_2623_; uint8_t v___y_2624_; uint8_t v___y_2625_; uint8_t v___y_2626_; uint8_t v___y_2627_; lean_object* v___y_2628_; lean_object* v___y_2629_; lean_object* v___y_2630_; uint64_t v___y_2631_; lean_object* v___y_2632_; lean_object* v___y_2633_; uint64_t v___y_2634_; lean_object* v___y_2636_; lean_object* v___y_2637_; lean_object* v___y_2638_; uint8_t v___y_2639_; uint8_t v___y_2640_; uint8_t v___y_2641_; lean_object* v___y_2642_; lean_object* v___y_2643_; lean_object* v___y_2644_; lean_object* v___y_2645_; lean_object* v___y_2646_; lean_object* v___y_2717_; lean_object* v___y_2718_; uint8_t v___y_2719_; lean_object* v___y_2720_; lean_object* v___y_2721_; lean_object* v___y_2722_; lean_object* v___y_2737_; lean_object* v___y_2738_; lean_object* v___y_2739_; uint8_t v___y_2740_; lean_object* v___y_2741_; lean_object* v___y_2742_; lean_object* v___y_2782_; lean_object* v___x_2799_; lean_object* v___x_2800_; lean_object* v___x_2801_; lean_object* v___x_2802_; uint8_t v___x_2803_; 
v___x_2138_ = lean_unsigned_to_nat(4076u);
v___x_2799_ = lean_nat_shiftr(v_x_2137_, v___x_2138_);
v___x_2800_ = lean_unsigned_to_nat(524287u);
v___x_2801_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__10, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__10_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__10);
v___x_2802_ = lean_nat_land(v___x_2799_, v___x_2801_);
lean_dec(v___x_2799_);
v___x_2803_ = lean_nat_dec_eq(v___x_2802_, v___x_2800_);
lean_dec(v___x_2802_);
if (v___x_2803_ == 0)
{
lean_object* v___x_2804_; 
v___x_2804_ = lean_box(0);
v___y_2782_ = v___x_2804_;
goto v___jp_2781_;
}
else
{
lean_object* v___x_2805_; lean_object* v___x_2806_; lean_object* v___x_2807_; uint8_t v___x_2808_; 
v___x_2805_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__12, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__12_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__12);
v___x_2806_ = lean_nat_land(v_x_2137_, v___x_2805_);
v___x_2807_ = lean_unsigned_to_nat(0u);
v___x_2808_ = lean_nat_dec_eq(v___x_2806_, v___x_2807_);
lean_dec(v___x_2806_);
if (v___x_2808_ == 0)
{
if (v___x_2803_ == 0)
{
lean_object* v___x_2809_; 
lean_inc(v_x_2137_);
v___x_2809_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2809_, 0, v_x_2137_);
v___y_2782_ = v___x_2809_;
goto v___jp_2781_;
}
else
{
if (v___x_2808_ == 0)
{
lean_object* v___x_2810_; lean_object* v___x_2811_; lean_object* v___x_2812_; 
v___x_2810_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__8, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__8_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__8);
v___x_2811_ = lean_nat_lor(v_x_2137_, v___x_2810_);
v___x_2812_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2812_, 0, v___x_2811_);
v___y_2782_ = v___x_2812_;
goto v___jp_2781_;
}
else
{
lean_object* v___x_2813_; 
lean_inc(v_x_2137_);
v___x_2813_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2813_, 0, v_x_2137_);
v___y_2782_ = v___x_2813_;
goto v___jp_2781_;
}
}
}
else
{
lean_object* v___x_2814_; 
v___x_2814_ = lean_box(0);
v___y_2782_ = v___x_2814_;
goto v___jp_2781_;
}
}
v___jp_2139_:
{
lean_object* v___x_2141_; lean_object* v___x_2142_; 
v___x_2141_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__0));
v___x_2142_ = l_Float_Model_UnpackedFloat_pack(v___x_2141_, v___y_2140_);
lean_dec(v___y_2140_);
return v___x_2142_;
}
v___jp_2143_:
{
lean_object* v_rounded_2150_; lean_object* v___x_2151_; lean_object* v___x_2152_; lean_object* v___x_2153_; lean_object* v___x_2154_; lean_object* v_fst_2155_; lean_object* v_snd_2156_; lean_object* v_mantissa_2157_; uint8_t v___x_2158_; 
v_rounded_2150_ = l_Float_Model_UnpackedFloat_ExtendedMantissa_roundedMantissa(v___y_2149_);
lean_dec_ref(v___y_2149_);
v___x_2151_ = lean_nat_to_int(v___y_2144_);
v___x_2152_ = lean_int_add(v___y_2145_, v___x_2151_);
lean_dec(v___x_2151_);
lean_dec(v___y_2145_);
v___x_2153_ = lean_box(0);
v___x_2154_ = l_Float_Model_UnpackedFloat_shiftToTargetExponent(v___y_2147_, v_rounded_2150_, v___x_2152_, v___x_2153_);
lean_dec(v___x_2152_);
v_fst_2155_ = lean_ctor_get(v___x_2154_, 0);
lean_inc(v_fst_2155_);
v_snd_2156_ = lean_ctor_get(v___x_2154_, 1);
lean_inc(v_snd_2156_);
lean_dec_ref(v___x_2154_);
v_mantissa_2157_ = lean_ctor_get(v_fst_2155_, 0);
lean_inc(v_mantissa_2157_);
lean_dec(v_fst_2155_);
v___x_2158_ = lean_nat_dec_eq(v_mantissa_2157_, v___y_2146_);
if (v___x_2158_ == 0)
{
lean_object* v___x_2159_; 
v___x_2159_ = lean_alloc_ctor(3, 2, 1);
lean_ctor_set(v___x_2159_, 0, v_mantissa_2157_);
lean_ctor_set(v___x_2159_, 1, v_snd_2156_);
lean_ctor_set_uint8(v___x_2159_, sizeof(void*)*2, v___y_2148_);
v___y_2140_ = v___x_2159_;
goto v___jp_2139_;
}
else
{
lean_object* v___x_2160_; 
lean_dec(v_mantissa_2157_);
lean_dec(v_snd_2156_);
v___x_2160_ = lean_alloc_ctor(2, 0, 1);
lean_ctor_set_uint8(v___x_2160_, 0, v___y_2148_);
v___y_2140_ = v___x_2160_;
goto v___jp_2139_;
}
}
v___jp_2161_:
{
lean_object* v___x_2169_; lean_object* v_remainder_2170_; uint8_t v___x_2171_; 
v___x_2169_ = lean_nat_mul(v___y_2168_, v___y_2168_);
v_remainder_2170_ = lean_nat_sub(v___y_2165_, v___x_2169_);
lean_dec(v___x_2169_);
lean_dec(v___y_2165_);
v___x_2171_ = lean_nat_dec_eq(v_remainder_2170_, v___y_2164_);
if (v___x_2171_ == 0)
{
uint8_t v___x_2172_; 
v___x_2172_ = lean_nat_dec_le(v_remainder_2170_, v___y_2168_);
lean_dec(v_remainder_2170_);
if (v___x_2172_ == 0)
{
lean_object* v___x_2173_; lean_object* v___x_2174_; 
v___x_2173_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__1));
v___x_2174_ = l_Float_Model_UnpackedFloat_ExtendedMantissa_ofMantissaAndAccuracy(v___y_2168_, v___x_2173_);
v___y_2144_ = v___y_2162_;
v___y_2145_ = v___y_2163_;
v___y_2146_ = v___y_2164_;
v___y_2147_ = v___y_2166_;
v___y_2148_ = v___y_2167_;
v___y_2149_ = v___x_2174_;
goto v___jp_2143_;
}
else
{
lean_object* v___x_2175_; lean_object* v___x_2176_; 
v___x_2175_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__2));
v___x_2176_ = l_Float_Model_UnpackedFloat_ExtendedMantissa_ofMantissaAndAccuracy(v___y_2168_, v___x_2175_);
v___y_2144_ = v___y_2162_;
v___y_2145_ = v___y_2163_;
v___y_2146_ = v___y_2164_;
v___y_2147_ = v___y_2166_;
v___y_2148_ = v___y_2167_;
v___y_2149_ = v___x_2176_;
goto v___jp_2143_;
}
}
else
{
lean_object* v___x_2177_; lean_object* v___x_2178_; 
lean_dec(v_remainder_2170_);
v___x_2177_ = lean_box(0);
v___x_2178_ = l_Float_Model_UnpackedFloat_ExtendedMantissa_ofMantissaAndAccuracy(v___y_2168_, v___x_2177_);
v___y_2144_ = v___y_2162_;
v___y_2145_ = v___y_2163_;
v___y_2146_ = v___y_2164_;
v___y_2147_ = v___y_2166_;
v___y_2148_ = v___y_2167_;
v___y_2149_ = v___x_2178_;
goto v___jp_2143_;
}
}
v___jp_2179_:
{
lean_object* v___x_2190_; lean_object* v___x_2191_; lean_object* v_shift_2192_; uint64_t v___x_2193_; uint64_t v___x_2194_; uint64_t v___x_2195_; lean_object* v___x_2196_; 
v___x_2190_ = lean_uint64_to_nat(v___y_2189_);
v___x_2191_ = lean_nat_shiftr(v___x_2190_, v___y_2188_);
lean_dec(v___x_2190_);
v_shift_2192_ = lean_nat_add(v___x_2191_, v___y_2188_);
lean_dec(v___y_2188_);
lean_dec(v___x_2191_);
v___x_2193_ = lean_uint64_of_nat(v_shift_2192_);
lean_dec(v_shift_2192_);
v___x_2194_ = lean_uint64_shift_left(v___y_2180_, v___x_2193_);
v___x_2195_ = lp_floatlib_FloatLib_Numerics_FixedWord_IntegerSquareRoot_sqrtIter(v___y_2185_, v___x_2194_);
v___x_2196_ = lean_uint64_to_nat(v___x_2195_);
v___y_2162_ = v___y_2181_;
v___y_2163_ = v___y_2182_;
v___y_2164_ = v___y_2184_;
v___y_2165_ = v___y_2183_;
v___y_2166_ = v___y_2186_;
v___y_2167_ = v___y_2187_;
v___y_2168_ = v___x_2196_;
goto v___jp_2161_;
}
v___jp_2197_:
{
uint64_t v___x_2209_; uint64_t v___x_2210_; 
v___x_2209_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___y_2208_);
v___x_2210_ = lean_uint64_add(v___y_2204_, v___x_2209_);
v___y_2180_ = v___y_2198_;
v___y_2181_ = v___y_2199_;
v___y_2182_ = v___y_2200_;
v___y_2183_ = v___y_2202_;
v___y_2184_ = v___y_2201_;
v___y_2185_ = v___y_2203_;
v___y_2186_ = v___y_2205_;
v___y_2187_ = v___y_2206_;
v___y_2188_ = v___y_2207_;
v___y_2189_ = v___x_2210_;
goto v___jp_2179_;
}
v___jp_2211_:
{
if (v___y_2214_ == 0)
{
v___y_2198_ = v___y_2213_;
v___y_2199_ = v___y_2215_;
v___y_2200_ = v___y_2216_;
v___y_2201_ = v___y_2218_;
v___y_2202_ = v___y_2217_;
v___y_2203_ = v___y_2219_;
v___y_2204_ = v___y_2223_;
v___y_2205_ = v___y_2220_;
v___y_2206_ = v___y_2221_;
v___y_2207_ = v___y_2222_;
v___y_2208_ = v___y_2212_;
goto v___jp_2197_;
}
else
{
v___y_2198_ = v___y_2213_;
v___y_2199_ = v___y_2215_;
v___y_2200_ = v___y_2216_;
v___y_2201_ = v___y_2218_;
v___y_2202_ = v___y_2217_;
v___y_2203_ = v___y_2219_;
v___y_2204_ = v___y_2223_;
v___y_2205_ = v___y_2220_;
v___y_2206_ = v___y_2221_;
v___y_2207_ = v___y_2222_;
v___y_2208_ = v___y_2219_;
goto v___jp_2197_;
}
}
v___jp_2224_:
{
uint64_t v___x_2239_; uint64_t v___x_2240_; uint64_t v___x_2241_; uint64_t v___x_2242_; uint64_t v___x_2243_; 
v___x_2239_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___y_2238_);
v___x_2240_ = lean_uint64_add(v___y_2230_, v___x_2239_);
v___x_2241_ = lean_uint64_add(v___y_2231_, v___x_2240_);
v___x_2242_ = lean_uint64_add(v___y_2233_, v___x_2241_);
v___x_2243_ = lean_uint64_add(v___y_2232_, v___x_2242_);
v___y_2180_ = v___y_2225_;
v___y_2181_ = v___y_2226_;
v___y_2182_ = v___y_2236_;
v___y_2183_ = v___y_2227_;
v___y_2184_ = v___y_2228_;
v___y_2185_ = v___y_2229_;
v___y_2186_ = v___y_2237_;
v___y_2187_ = v___y_2234_;
v___y_2188_ = v___y_2235_;
v___y_2189_ = v___x_2243_;
goto v___jp_2179_;
}
v___jp_2244_:
{
if (v___y_2256_ == 0)
{
v___y_2225_ = v___y_2245_;
v___y_2226_ = v___y_2246_;
v___y_2227_ = v___y_2247_;
v___y_2228_ = v___y_2248_;
v___y_2229_ = v___y_2249_;
v___y_2230_ = v___y_2260_;
v___y_2231_ = v___y_2250_;
v___y_2232_ = v___y_2251_;
v___y_2233_ = v___y_2252_;
v___y_2234_ = v___y_2253_;
v___y_2235_ = v___y_2255_;
v___y_2236_ = v___y_2257_;
v___y_2237_ = v___y_2259_;
v___y_2238_ = v___y_2254_;
goto v___jp_2224_;
}
else
{
v___y_2225_ = v___y_2245_;
v___y_2226_ = v___y_2246_;
v___y_2227_ = v___y_2247_;
v___y_2228_ = v___y_2248_;
v___y_2229_ = v___y_2249_;
v___y_2230_ = v___y_2260_;
v___y_2231_ = v___y_2250_;
v___y_2232_ = v___y_2251_;
v___y_2233_ = v___y_2252_;
v___y_2234_ = v___y_2253_;
v___y_2235_ = v___y_2255_;
v___y_2236_ = v___y_2257_;
v___y_2237_ = v___y_2259_;
v___y_2238_ = v___y_2258_;
goto v___jp_2224_;
}
}
v___jp_2261_:
{
uint64_t v_high_2277_; uint8_t v___x_2278_; 
v_high_2277_ = lean_uint64_shift_right(v___y_2276_, v___y_2271_);
v___x_2278_ = lean_uint64_dec_eq(v_high_2277_, v___y_2262_);
if (v___x_2278_ == 0)
{
v___y_2245_ = v___y_2263_;
v___y_2246_ = v___y_2264_;
v___y_2247_ = v___y_2265_;
v___y_2248_ = v___y_2266_;
v___y_2249_ = v___y_2267_;
v___y_2250_ = v___y_2268_;
v___y_2251_ = v___y_2269_;
v___y_2252_ = v___y_2270_;
v___y_2253_ = v___y_2272_;
v___y_2254_ = v_high_2277_;
v___y_2255_ = v___y_2273_;
v___y_2256_ = v___x_2278_;
v___y_2257_ = v___y_2274_;
v___y_2258_ = v___y_2276_;
v___y_2259_ = v___y_2275_;
v___y_2260_ = v___y_2271_;
goto v___jp_2244_;
}
else
{
v___y_2245_ = v___y_2263_;
v___y_2246_ = v___y_2264_;
v___y_2247_ = v___y_2265_;
v___y_2248_ = v___y_2266_;
v___y_2249_ = v___y_2267_;
v___y_2250_ = v___y_2268_;
v___y_2251_ = v___y_2269_;
v___y_2252_ = v___y_2270_;
v___y_2253_ = v___y_2272_;
v___y_2254_ = v_high_2277_;
v___y_2255_ = v___y_2273_;
v___y_2256_ = v___x_2278_;
v___y_2257_ = v___y_2274_;
v___y_2258_ = v___y_2276_;
v___y_2259_ = v___y_2275_;
v___y_2260_ = v___y_2262_;
goto v___jp_2244_;
}
}
v___jp_2279_:
{
if (v___y_2287_ == 0)
{
v___y_2262_ = v___y_2280_;
v___y_2263_ = v___y_2281_;
v___y_2264_ = v___y_2282_;
v___y_2265_ = v___y_2283_;
v___y_2266_ = v___y_2284_;
v___y_2267_ = v___y_2285_;
v___y_2268_ = v___y_2296_;
v___y_2269_ = v___y_2286_;
v___y_2270_ = v___y_2288_;
v___y_2271_ = v___y_2289_;
v___y_2272_ = v___y_2290_;
v___y_2273_ = v___y_2292_;
v___y_2274_ = v___y_2293_;
v___y_2275_ = v___y_2295_;
v___y_2276_ = v___y_2291_;
goto v___jp_2261_;
}
else
{
v___y_2262_ = v___y_2280_;
v___y_2263_ = v___y_2281_;
v___y_2264_ = v___y_2282_;
v___y_2265_ = v___y_2283_;
v___y_2266_ = v___y_2284_;
v___y_2267_ = v___y_2285_;
v___y_2268_ = v___y_2296_;
v___y_2269_ = v___y_2286_;
v___y_2270_ = v___y_2288_;
v___y_2271_ = v___y_2289_;
v___y_2272_ = v___y_2290_;
v___y_2273_ = v___y_2292_;
v___y_2274_ = v___y_2293_;
v___y_2275_ = v___y_2295_;
v___y_2276_ = v___y_2294_;
goto v___jp_2261_;
}
}
v___jp_2297_:
{
uint64_t v_high_2313_; uint8_t v___x_2314_; 
v_high_2313_ = lean_uint64_shift_right(v___y_2312_, v___y_2301_);
v___x_2314_ = lean_uint64_dec_eq(v_high_2313_, v___y_2298_);
if (v___x_2314_ == 0)
{
v___y_2280_ = v___y_2298_;
v___y_2281_ = v___y_2299_;
v___y_2282_ = v___y_2300_;
v___y_2283_ = v___y_2302_;
v___y_2284_ = v___y_2303_;
v___y_2285_ = v___y_2304_;
v___y_2286_ = v___y_2305_;
v___y_2287_ = v___x_2314_;
v___y_2288_ = v___y_2306_;
v___y_2289_ = v___y_2307_;
v___y_2290_ = v___y_2308_;
v___y_2291_ = v_high_2313_;
v___y_2292_ = v___y_2309_;
v___y_2293_ = v___y_2310_;
v___y_2294_ = v___y_2312_;
v___y_2295_ = v___y_2311_;
v___y_2296_ = v___y_2301_;
goto v___jp_2279_;
}
else
{
v___y_2280_ = v___y_2298_;
v___y_2281_ = v___y_2299_;
v___y_2282_ = v___y_2300_;
v___y_2283_ = v___y_2302_;
v___y_2284_ = v___y_2303_;
v___y_2285_ = v___y_2304_;
v___y_2286_ = v___y_2305_;
v___y_2287_ = v___x_2314_;
v___y_2288_ = v___y_2306_;
v___y_2289_ = v___y_2307_;
v___y_2290_ = v___y_2308_;
v___y_2291_ = v_high_2313_;
v___y_2292_ = v___y_2309_;
v___y_2293_ = v___y_2310_;
v___y_2294_ = v___y_2312_;
v___y_2295_ = v___y_2311_;
v___y_2296_ = v___y_2298_;
goto v___jp_2279_;
}
}
v___jp_2315_:
{
if (v___y_2324_ == 0)
{
v___y_2298_ = v___y_2316_;
v___y_2299_ = v___y_2317_;
v___y_2300_ = v___y_2318_;
v___y_2301_ = v___y_2320_;
v___y_2302_ = v___y_2321_;
v___y_2303_ = v___y_2322_;
v___y_2304_ = v___y_2323_;
v___y_2305_ = v___y_2325_;
v___y_2306_ = v___y_2332_;
v___y_2307_ = v___y_2326_;
v___y_2308_ = v___y_2327_;
v___y_2309_ = v___y_2328_;
v___y_2310_ = v___y_2329_;
v___y_2311_ = v___y_2331_;
v___y_2312_ = v___y_2319_;
goto v___jp_2297_;
}
else
{
v___y_2298_ = v___y_2316_;
v___y_2299_ = v___y_2317_;
v___y_2300_ = v___y_2318_;
v___y_2301_ = v___y_2320_;
v___y_2302_ = v___y_2321_;
v___y_2303_ = v___y_2322_;
v___y_2304_ = v___y_2323_;
v___y_2305_ = v___y_2325_;
v___y_2306_ = v___y_2332_;
v___y_2307_ = v___y_2326_;
v___y_2308_ = v___y_2327_;
v___y_2309_ = v___y_2328_;
v___y_2310_ = v___y_2329_;
v___y_2311_ = v___y_2331_;
v___y_2312_ = v___y_2330_;
goto v___jp_2297_;
}
}
v___jp_2333_:
{
uint64_t v_high_2349_; uint8_t v___x_2350_; 
v_high_2349_ = lean_uint64_shift_right(v___y_2348_, v___y_2334_);
v___x_2350_ = lean_uint64_dec_eq(v_high_2349_, v___y_2335_);
if (v___x_2350_ == 0)
{
v___y_2316_ = v___y_2335_;
v___y_2317_ = v___y_2336_;
v___y_2318_ = v___y_2337_;
v___y_2319_ = v_high_2349_;
v___y_2320_ = v___y_2338_;
v___y_2321_ = v___y_2339_;
v___y_2322_ = v___y_2340_;
v___y_2323_ = v___y_2341_;
v___y_2324_ = v___x_2350_;
v___y_2325_ = v___y_2342_;
v___y_2326_ = v___y_2343_;
v___y_2327_ = v___y_2344_;
v___y_2328_ = v___y_2345_;
v___y_2329_ = v___y_2346_;
v___y_2330_ = v___y_2348_;
v___y_2331_ = v___y_2347_;
v___y_2332_ = v___y_2334_;
goto v___jp_2315_;
}
else
{
v___y_2316_ = v___y_2335_;
v___y_2317_ = v___y_2336_;
v___y_2318_ = v___y_2337_;
v___y_2319_ = v_high_2349_;
v___y_2320_ = v___y_2338_;
v___y_2321_ = v___y_2339_;
v___y_2322_ = v___y_2340_;
v___y_2323_ = v___y_2341_;
v___y_2324_ = v___x_2350_;
v___y_2325_ = v___y_2342_;
v___y_2326_ = v___y_2343_;
v___y_2327_ = v___y_2344_;
v___y_2328_ = v___y_2345_;
v___y_2329_ = v___y_2346_;
v___y_2330_ = v___y_2348_;
v___y_2331_ = v___y_2347_;
v___y_2332_ = v___y_2335_;
goto v___jp_2315_;
}
}
v___jp_2351_:
{
if (v___y_2366_ == 0)
{
v___y_2334_ = v___y_2352_;
v___y_2335_ = v___y_2353_;
v___y_2336_ = v___y_2354_;
v___y_2337_ = v___y_2355_;
v___y_2338_ = v___y_2356_;
v___y_2339_ = v___y_2357_;
v___y_2340_ = v___y_2358_;
v___y_2341_ = v___y_2359_;
v___y_2342_ = v___y_2367_;
v___y_2343_ = v___y_2361_;
v___y_2344_ = v___y_2362_;
v___y_2345_ = v___y_2363_;
v___y_2346_ = v___y_2364_;
v___y_2347_ = v___y_2365_;
v___y_2348_ = v___y_2360_;
goto v___jp_2333_;
}
else
{
v___y_2334_ = v___y_2352_;
v___y_2335_ = v___y_2353_;
v___y_2336_ = v___y_2354_;
v___y_2337_ = v___y_2355_;
v___y_2338_ = v___y_2356_;
v___y_2339_ = v___y_2357_;
v___y_2340_ = v___y_2358_;
v___y_2341_ = v___y_2359_;
v___y_2342_ = v___y_2367_;
v___y_2343_ = v___y_2361_;
v___y_2344_ = v___y_2362_;
v___y_2345_ = v___y_2363_;
v___y_2346_ = v___y_2364_;
v___y_2347_ = v___y_2365_;
v___y_2348_ = v___y_2359_;
goto v___jp_2333_;
}
}
v___jp_2368_:
{
lean_object* v___x_2381_; lean_object* v___x_2382_; uint8_t v___x_2383_; 
v___x_2381_ = lean_nat_mul(v___y_2374_, v___y_2374_);
lean_dec(v___y_2374_);
v___x_2382_ = lean_nat_shiftl(v___x_2381_, v___y_2369_);
lean_dec(v___y_2369_);
lean_dec(v___x_2381_);
v___x_2383_ = lean_nat_dec_eq(v___y_2373_, v___x_2382_);
lean_dec(v___x_2382_);
lean_dec(v___y_2373_);
if (v___x_2383_ == 0)
{
lean_object* v___x_2384_; 
v___x_2384_ = lean_alloc_ctor(0, 1, 2);
lean_ctor_set(v___x_2384_, 0, v___y_2379_);
lean_ctor_set_uint8(v___x_2384_, sizeof(void*)*1, v___y_2380_);
lean_ctor_set_uint8(v___x_2384_, sizeof(void*)*1 + 1, v___y_2377_);
v___y_2144_ = v___y_2370_;
v___y_2145_ = v___y_2371_;
v___y_2146_ = v___y_2372_;
v___y_2147_ = v___y_2375_;
v___y_2148_ = v___y_2376_;
v___y_2149_ = v___x_2384_;
goto v___jp_2143_;
}
else
{
lean_object* v___x_2385_; 
v___x_2385_ = lean_alloc_ctor(0, 1, 2);
lean_ctor_set(v___x_2385_, 0, v___y_2379_);
lean_ctor_set_uint8(v___x_2385_, sizeof(void*)*1, v___y_2380_);
lean_ctor_set_uint8(v___x_2385_, sizeof(void*)*1 + 1, v___y_2378_);
v___y_2144_ = v___y_2370_;
v___y_2145_ = v___y_2371_;
v___y_2146_ = v___y_2372_;
v___y_2147_ = v___y_2375_;
v___y_2148_ = v___y_2376_;
v___y_2149_ = v___x_2385_;
goto v___jp_2143_;
}
}
v___jp_2386_:
{
lean_object* v___x_2399_; lean_object* v___x_2400_; uint8_t v___x_2401_; 
v___x_2399_ = lean_nat_shiftr(v___y_2398_, v___y_2397_);
lean_dec(v___y_2397_);
v___x_2400_ = lean_nat_mod(v___y_2398_, v___y_2392_);
lean_dec(v___y_2392_);
v___x_2401_ = lean_nat_dec_eq(v___x_2400_, v___y_2391_);
lean_dec(v___x_2400_);
if (v___x_2401_ == 0)
{
v___y_2369_ = v___y_2387_;
v___y_2370_ = v___y_2388_;
v___y_2371_ = v___y_2389_;
v___y_2372_ = v___y_2391_;
v___y_2373_ = v___y_2390_;
v___y_2374_ = v___y_2398_;
v___y_2375_ = v___y_2393_;
v___y_2376_ = v___y_2395_;
v___y_2377_ = v___y_2394_;
v___y_2378_ = v___y_2396_;
v___y_2379_ = v___x_2399_;
v___y_2380_ = v___y_2394_;
goto v___jp_2368_;
}
else
{
v___y_2369_ = v___y_2387_;
v___y_2370_ = v___y_2388_;
v___y_2371_ = v___y_2389_;
v___y_2372_ = v___y_2391_;
v___y_2373_ = v___y_2390_;
v___y_2374_ = v___y_2398_;
v___y_2375_ = v___y_2393_;
v___y_2376_ = v___y_2395_;
v___y_2377_ = v___y_2394_;
v___y_2378_ = v___y_2396_;
v___y_2379_ = v___x_2399_;
v___y_2380_ = v___y_2396_;
goto v___jp_2368_;
}
}
v___jp_2402_:
{
lean_object* v___x_2417_; lean_object* v___x_2418_; lean_object* v_shift_2419_; uint64_t v___x_2420_; uint64_t v___x_2421_; uint64_t v___x_2422_; lean_object* v___x_2423_; 
v___x_2417_ = lean_uint64_to_nat(v___y_2416_);
v___x_2418_ = lean_nat_shiftr(v___x_2417_, v___y_2410_);
lean_dec(v___x_2417_);
v_shift_2419_ = lean_nat_add(v___x_2418_, v___y_2410_);
lean_dec(v___x_2418_);
v___x_2420_ = lean_uint64_of_nat(v_shift_2419_);
lean_dec(v_shift_2419_);
v___x_2421_ = lean_uint64_shift_left(v___y_2406_, v___x_2420_);
v___x_2422_ = lp_floatlib_FloatLib_Numerics_FixedWord_IntegerSquareRoot_sqrtIter(v___y_2413_, v___x_2421_);
v___x_2423_ = lean_uint64_to_nat(v___x_2422_);
v___y_2387_ = v___y_2411_;
v___y_2388_ = v___y_2403_;
v___y_2389_ = v___y_2412_;
v___y_2390_ = v___y_2404_;
v___y_2391_ = v___y_2405_;
v___y_2392_ = v___y_2414_;
v___y_2393_ = v___y_2415_;
v___y_2394_ = v___y_2407_;
v___y_2395_ = v___y_2408_;
v___y_2396_ = v___y_2409_;
v___y_2397_ = v___y_2410_;
v___y_2398_ = v___x_2423_;
goto v___jp_2386_;
}
v___jp_2424_:
{
uint64_t v___x_2443_; uint64_t v___x_2444_; uint64_t v___x_2445_; uint64_t v___x_2446_; uint64_t v___x_2447_; 
v___x_2443_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___y_2442_);
v___x_2444_ = lean_uint64_add(v___y_2427_, v___x_2443_);
v___x_2445_ = lean_uint64_add(v___y_2441_, v___x_2444_);
v___x_2446_ = lean_uint64_add(v___y_2425_, v___x_2445_);
v___x_2447_ = lean_uint64_add(v___y_2440_, v___x_2446_);
v___y_2403_ = v___y_2426_;
v___y_2404_ = v___y_2428_;
v___y_2405_ = v___y_2429_;
v___y_2406_ = v___y_2430_;
v___y_2407_ = v___y_2431_;
v___y_2408_ = v___y_2432_;
v___y_2409_ = v___y_2433_;
v___y_2410_ = v___y_2434_;
v___y_2411_ = v___y_2435_;
v___y_2412_ = v___y_2436_;
v___y_2413_ = v___y_2437_;
v___y_2414_ = v___y_2438_;
v___y_2415_ = v___y_2439_;
v___y_2416_ = v___x_2447_;
goto v___jp_2402_;
}
v___jp_2448_:
{
if (v___y_2455_ == 0)
{
v___y_2425_ = v___y_2449_;
v___y_2426_ = v___y_2451_;
v___y_2427_ = v___y_2468_;
v___y_2428_ = v___y_2452_;
v___y_2429_ = v___y_2453_;
v___y_2430_ = v___y_2454_;
v___y_2431_ = v___y_2456_;
v___y_2432_ = v___y_2457_;
v___y_2433_ = v___y_2458_;
v___y_2434_ = v___y_2459_;
v___y_2435_ = v___y_2460_;
v___y_2436_ = v___y_2462_;
v___y_2437_ = v___y_2463_;
v___y_2438_ = v___y_2464_;
v___y_2439_ = v___y_2465_;
v___y_2440_ = v___y_2466_;
v___y_2441_ = v___y_2467_;
v___y_2442_ = v___y_2461_;
goto v___jp_2424_;
}
else
{
v___y_2425_ = v___y_2449_;
v___y_2426_ = v___y_2451_;
v___y_2427_ = v___y_2468_;
v___y_2428_ = v___y_2452_;
v___y_2429_ = v___y_2453_;
v___y_2430_ = v___y_2454_;
v___y_2431_ = v___y_2456_;
v___y_2432_ = v___y_2457_;
v___y_2433_ = v___y_2458_;
v___y_2434_ = v___y_2459_;
v___y_2435_ = v___y_2460_;
v___y_2436_ = v___y_2462_;
v___y_2437_ = v___y_2463_;
v___y_2438_ = v___y_2464_;
v___y_2439_ = v___y_2465_;
v___y_2440_ = v___y_2466_;
v___y_2441_ = v___y_2467_;
v___y_2442_ = v___y_2450_;
goto v___jp_2424_;
}
}
v___jp_2469_:
{
uint64_t v_high_2489_; uint8_t v___x_2490_; 
v_high_2489_ = lean_uint64_shift_right(v___y_2488_, v___y_2475_);
v___x_2490_ = lean_uint64_dec_eq(v_high_2489_, v___y_2483_);
if (v___x_2490_ == 0)
{
v___y_2449_ = v___y_2470_;
v___y_2450_ = v___y_2488_;
v___y_2451_ = v___y_2471_;
v___y_2452_ = v___y_2472_;
v___y_2453_ = v___y_2473_;
v___y_2454_ = v___y_2474_;
v___y_2455_ = v___x_2490_;
v___y_2456_ = v___y_2476_;
v___y_2457_ = v___y_2477_;
v___y_2458_ = v___y_2478_;
v___y_2459_ = v___y_2479_;
v___y_2460_ = v___y_2480_;
v___y_2461_ = v_high_2489_;
v___y_2462_ = v___y_2481_;
v___y_2463_ = v___y_2482_;
v___y_2464_ = v___y_2484_;
v___y_2465_ = v___y_2485_;
v___y_2466_ = v___y_2486_;
v___y_2467_ = v___y_2487_;
v___y_2468_ = v___y_2475_;
goto v___jp_2448_;
}
else
{
v___y_2449_ = v___y_2470_;
v___y_2450_ = v___y_2488_;
v___y_2451_ = v___y_2471_;
v___y_2452_ = v___y_2472_;
v___y_2453_ = v___y_2473_;
v___y_2454_ = v___y_2474_;
v___y_2455_ = v___x_2490_;
v___y_2456_ = v___y_2476_;
v___y_2457_ = v___y_2477_;
v___y_2458_ = v___y_2478_;
v___y_2459_ = v___y_2479_;
v___y_2460_ = v___y_2480_;
v___y_2461_ = v_high_2489_;
v___y_2462_ = v___y_2481_;
v___y_2463_ = v___y_2482_;
v___y_2464_ = v___y_2484_;
v___y_2465_ = v___y_2485_;
v___y_2466_ = v___y_2486_;
v___y_2467_ = v___y_2487_;
v___y_2468_ = v___y_2483_;
goto v___jp_2448_;
}
}
v___jp_2491_:
{
if (v___y_2493_ == 0)
{
v___y_2470_ = v___y_2492_;
v___y_2471_ = v___y_2494_;
v___y_2472_ = v___y_2495_;
v___y_2473_ = v___y_2496_;
v___y_2474_ = v___y_2497_;
v___y_2475_ = v___y_2498_;
v___y_2476_ = v___y_2500_;
v___y_2477_ = v___y_2501_;
v___y_2478_ = v___y_2502_;
v___y_2479_ = v___y_2503_;
v___y_2480_ = v___y_2504_;
v___y_2481_ = v___y_2505_;
v___y_2482_ = v___y_2508_;
v___y_2483_ = v___y_2507_;
v___y_2484_ = v___y_2509_;
v___y_2485_ = v___y_2510_;
v___y_2486_ = v___y_2511_;
v___y_2487_ = v___y_2512_;
v___y_2488_ = v___y_2506_;
goto v___jp_2469_;
}
else
{
v___y_2470_ = v___y_2492_;
v___y_2471_ = v___y_2494_;
v___y_2472_ = v___y_2495_;
v___y_2473_ = v___y_2496_;
v___y_2474_ = v___y_2497_;
v___y_2475_ = v___y_2498_;
v___y_2476_ = v___y_2500_;
v___y_2477_ = v___y_2501_;
v___y_2478_ = v___y_2502_;
v___y_2479_ = v___y_2503_;
v___y_2480_ = v___y_2504_;
v___y_2481_ = v___y_2505_;
v___y_2482_ = v___y_2508_;
v___y_2483_ = v___y_2507_;
v___y_2484_ = v___y_2509_;
v___y_2485_ = v___y_2510_;
v___y_2486_ = v___y_2511_;
v___y_2487_ = v___y_2512_;
v___y_2488_ = v___y_2499_;
goto v___jp_2469_;
}
}
v___jp_2513_:
{
uint64_t v_high_2533_; uint8_t v___x_2534_; 
v_high_2533_ = lean_uint64_shift_right(v___y_2532_, v___y_2520_);
v___x_2534_ = lean_uint64_dec_eq(v_high_2533_, v___y_2528_);
if (v___x_2534_ == 0)
{
v___y_2492_ = v___y_2514_;
v___y_2493_ = v___x_2534_;
v___y_2494_ = v___y_2515_;
v___y_2495_ = v___y_2516_;
v___y_2496_ = v___y_2517_;
v___y_2497_ = v___y_2518_;
v___y_2498_ = v___y_2519_;
v___y_2499_ = v___y_2532_;
v___y_2500_ = v___y_2521_;
v___y_2501_ = v___y_2522_;
v___y_2502_ = v___y_2523_;
v___y_2503_ = v___y_2524_;
v___y_2504_ = v___y_2525_;
v___y_2505_ = v___y_2526_;
v___y_2506_ = v_high_2533_;
v___y_2507_ = v___y_2528_;
v___y_2508_ = v___y_2527_;
v___y_2509_ = v___y_2529_;
v___y_2510_ = v___y_2530_;
v___y_2511_ = v___y_2531_;
v___y_2512_ = v___y_2520_;
goto v___jp_2491_;
}
else
{
v___y_2492_ = v___y_2514_;
v___y_2493_ = v___x_2534_;
v___y_2494_ = v___y_2515_;
v___y_2495_ = v___y_2516_;
v___y_2496_ = v___y_2517_;
v___y_2497_ = v___y_2518_;
v___y_2498_ = v___y_2519_;
v___y_2499_ = v___y_2532_;
v___y_2500_ = v___y_2521_;
v___y_2501_ = v___y_2522_;
v___y_2502_ = v___y_2523_;
v___y_2503_ = v___y_2524_;
v___y_2504_ = v___y_2525_;
v___y_2505_ = v___y_2526_;
v___y_2506_ = v_high_2533_;
v___y_2507_ = v___y_2528_;
v___y_2508_ = v___y_2527_;
v___y_2509_ = v___y_2529_;
v___y_2510_ = v___y_2530_;
v___y_2511_ = v___y_2531_;
v___y_2512_ = v___y_2528_;
goto v___jp_2491_;
}
}
v___jp_2535_:
{
if (v___y_2550_ == 0)
{
v___y_2514_ = v___y_2556_;
v___y_2515_ = v___y_2538_;
v___y_2516_ = v___y_2539_;
v___y_2517_ = v___y_2540_;
v___y_2518_ = v___y_2541_;
v___y_2519_ = v___y_2542_;
v___y_2520_ = v___y_2543_;
v___y_2521_ = v___y_2544_;
v___y_2522_ = v___y_2545_;
v___y_2523_ = v___y_2546_;
v___y_2524_ = v___y_2547_;
v___y_2525_ = v___y_2548_;
v___y_2526_ = v___y_2549_;
v___y_2527_ = v___y_2552_;
v___y_2528_ = v___y_2551_;
v___y_2529_ = v___y_2553_;
v___y_2530_ = v___y_2554_;
v___y_2531_ = v___y_2555_;
v___y_2532_ = v___y_2537_;
goto v___jp_2513_;
}
else
{
v___y_2514_ = v___y_2556_;
v___y_2515_ = v___y_2538_;
v___y_2516_ = v___y_2539_;
v___y_2517_ = v___y_2540_;
v___y_2518_ = v___y_2541_;
v___y_2519_ = v___y_2542_;
v___y_2520_ = v___y_2543_;
v___y_2521_ = v___y_2544_;
v___y_2522_ = v___y_2545_;
v___y_2523_ = v___y_2546_;
v___y_2524_ = v___y_2547_;
v___y_2525_ = v___y_2548_;
v___y_2526_ = v___y_2549_;
v___y_2527_ = v___y_2552_;
v___y_2528_ = v___y_2551_;
v___y_2529_ = v___y_2553_;
v___y_2530_ = v___y_2554_;
v___y_2531_ = v___y_2555_;
v___y_2532_ = v___y_2536_;
goto v___jp_2513_;
}
}
v___jp_2557_:
{
uint64_t v_high_2577_; uint8_t v___x_2578_; 
v_high_2577_ = lean_uint64_shift_right(v___y_2576_, v___y_2568_);
v___x_2578_ = lean_uint64_dec_eq(v_high_2577_, v___y_2572_);
if (v___x_2578_ == 0)
{
v___y_2536_ = v___y_2576_;
v___y_2537_ = v_high_2577_;
v___y_2538_ = v___y_2558_;
v___y_2539_ = v___y_2559_;
v___y_2540_ = v___y_2560_;
v___y_2541_ = v___y_2561_;
v___y_2542_ = v___y_2562_;
v___y_2543_ = v___y_2563_;
v___y_2544_ = v___y_2564_;
v___y_2545_ = v___y_2565_;
v___y_2546_ = v___y_2566_;
v___y_2547_ = v___y_2567_;
v___y_2548_ = v___y_2569_;
v___y_2549_ = v___y_2570_;
v___y_2550_ = v___x_2578_;
v___y_2551_ = v___y_2572_;
v___y_2552_ = v___y_2571_;
v___y_2553_ = v___y_2573_;
v___y_2554_ = v___y_2574_;
v___y_2555_ = v___y_2575_;
v___y_2556_ = v___y_2568_;
goto v___jp_2535_;
}
else
{
v___y_2536_ = v___y_2576_;
v___y_2537_ = v_high_2577_;
v___y_2538_ = v___y_2558_;
v___y_2539_ = v___y_2559_;
v___y_2540_ = v___y_2560_;
v___y_2541_ = v___y_2561_;
v___y_2542_ = v___y_2562_;
v___y_2543_ = v___y_2563_;
v___y_2544_ = v___y_2564_;
v___y_2545_ = v___y_2565_;
v___y_2546_ = v___y_2566_;
v___y_2547_ = v___y_2567_;
v___y_2548_ = v___y_2569_;
v___y_2549_ = v___y_2570_;
v___y_2550_ = v___x_2578_;
v___y_2551_ = v___y_2572_;
v___y_2552_ = v___y_2571_;
v___y_2553_ = v___y_2573_;
v___y_2554_ = v___y_2574_;
v___y_2555_ = v___y_2575_;
v___y_2556_ = v___y_2572_;
goto v___jp_2535_;
}
}
v___jp_2579_:
{
if (v___y_2597_ == 0)
{
v___y_2558_ = v___y_2580_;
v___y_2559_ = v___y_2581_;
v___y_2560_ = v___y_2582_;
v___y_2561_ = v___y_2583_;
v___y_2562_ = v___y_2585_;
v___y_2563_ = v___y_2586_;
v___y_2564_ = v___y_2587_;
v___y_2565_ = v___y_2588_;
v___y_2566_ = v___y_2589_;
v___y_2567_ = v___y_2590_;
v___y_2568_ = v___y_2591_;
v___y_2569_ = v___y_2592_;
v___y_2570_ = v___y_2593_;
v___y_2571_ = v___y_2595_;
v___y_2572_ = v___y_2594_;
v___y_2573_ = v___y_2596_;
v___y_2574_ = v___y_2598_;
v___y_2575_ = v___y_2599_;
v___y_2576_ = v___y_2584_;
goto v___jp_2557_;
}
else
{
v___y_2558_ = v___y_2580_;
v___y_2559_ = v___y_2581_;
v___y_2560_ = v___y_2582_;
v___y_2561_ = v___y_2583_;
v___y_2562_ = v___y_2585_;
v___y_2563_ = v___y_2586_;
v___y_2564_ = v___y_2587_;
v___y_2565_ = v___y_2588_;
v___y_2566_ = v___y_2589_;
v___y_2567_ = v___y_2590_;
v___y_2568_ = v___y_2591_;
v___y_2569_ = v___y_2592_;
v___y_2570_ = v___y_2593_;
v___y_2571_ = v___y_2595_;
v___y_2572_ = v___y_2594_;
v___y_2573_ = v___y_2596_;
v___y_2574_ = v___y_2598_;
v___y_2575_ = v___y_2599_;
v___y_2576_ = v___y_2595_;
goto v___jp_2557_;
}
}
v___jp_2600_:
{
uint64_t v___x_2616_; uint64_t v___x_2617_; 
v___x_2616_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___y_2615_);
v___x_2617_ = lean_uint64_add(v___y_2614_, v___x_2616_);
v___y_2403_ = v___y_2601_;
v___y_2404_ = v___y_2602_;
v___y_2405_ = v___y_2603_;
v___y_2406_ = v___y_2604_;
v___y_2407_ = v___y_2605_;
v___y_2408_ = v___y_2606_;
v___y_2409_ = v___y_2607_;
v___y_2410_ = v___y_2608_;
v___y_2411_ = v___y_2609_;
v___y_2412_ = v___y_2610_;
v___y_2413_ = v___y_2611_;
v___y_2414_ = v___y_2612_;
v___y_2415_ = v___y_2613_;
v___y_2416_ = v___x_2617_;
goto v___jp_2402_;
}
v___jp_2618_:
{
if (v___y_2624_ == 0)
{
v___y_2601_ = v___y_2619_;
v___y_2602_ = v___y_2620_;
v___y_2603_ = v___y_2621_;
v___y_2604_ = v___y_2623_;
v___y_2605_ = v___y_2625_;
v___y_2606_ = v___y_2626_;
v___y_2607_ = v___y_2627_;
v___y_2608_ = v___y_2628_;
v___y_2609_ = v___y_2629_;
v___y_2610_ = v___y_2630_;
v___y_2611_ = v___y_2631_;
v___y_2612_ = v___y_2632_;
v___y_2613_ = v___y_2633_;
v___y_2614_ = v___y_2634_;
v___y_2615_ = v___y_2622_;
goto v___jp_2600_;
}
else
{
v___y_2601_ = v___y_2619_;
v___y_2602_ = v___y_2620_;
v___y_2603_ = v___y_2621_;
v___y_2604_ = v___y_2623_;
v___y_2605_ = v___y_2625_;
v___y_2606_ = v___y_2626_;
v___y_2607_ = v___y_2627_;
v___y_2608_ = v___y_2628_;
v___y_2609_ = v___y_2629_;
v___y_2610_ = v___y_2630_;
v___y_2611_ = v___y_2631_;
v___y_2612_ = v___y_2632_;
v___y_2613_ = v___y_2633_;
v___y_2614_ = v___y_2634_;
v___y_2615_ = v___y_2631_;
goto v___jp_2600_;
}
}
v___jp_2635_:
{
lean_object* v___x_2647_; lean_object* v___x_2648_; lean_object* v_shiftAmount_2649_; lean_object* v___x_2650_; lean_object* v___x_2651_; lean_object* v___x_2652_; lean_object* v___x_2653_; lean_object* v___x_2654_; lean_object* v___x_2655_; lean_object* v_totalExponent_2656_; lean_object* v___x_2657_; lean_object* v___x_2658_; lean_object* v_shift_2659_; lean_object* v_zero_2660_; uint8_t v_isZero_2661_; 
v___x_2647_ = lean_int_mul(v___y_2645_, v___y_2646_);
lean_dec(v___y_2645_);
v___x_2648_ = lean_int_sub(v___y_2644_, v___x_2647_);
lean_dec(v___x_2647_);
lean_dec(v___y_2644_);
v_shiftAmount_2649_ = l_Int_toNat(v___x_2648_);
lean_dec(v___x_2648_);
v___x_2650_ = lean_nat_shiftl(v___y_2643_, v_shiftAmount_2649_);
lean_dec(v_shiftAmount_2649_);
lean_dec(v___y_2643_);
v___x_2651_ = lean_nat_log2(v___x_2650_);
v___x_2652_ = lean_nat_shiftr(v___x_2651_, v___y_2642_);
lean_dec(v___x_2651_);
v___x_2653_ = lean_nat_to_int(v___x_2652_);
lean_inc(v___y_2642_);
v___x_2654_ = lean_nat_to_int(v___y_2642_);
v___x_2655_ = lean_int_add(v___x_2653_, v___x_2654_);
lean_dec(v___x_2654_);
lean_dec(v___x_2653_);
v_totalExponent_2656_ = lean_int_add(v___x_2655_, v___y_2646_);
lean_dec(v___x_2655_);
v___x_2657_ = l_Float_Model_Format_targetExponent(v___y_2638_, v_totalExponent_2656_);
lean_dec(v_totalExponent_2656_);
v___x_2658_ = lean_int_sub(v___x_2657_, v___y_2646_);
lean_dec(v___x_2657_);
v_shift_2659_ = l_Int_toNat(v___x_2658_);
lean_dec(v___x_2658_);
v_zero_2660_ = lean_unsigned_to_nat(0u);
v_isZero_2661_ = lean_nat_dec_eq(v_shift_2659_, v_zero_2660_);
if (v_isZero_2661_ == 1)
{
lean_object* v___x_2662_; uint8_t v___x_2663_; 
lean_dec(v___y_2637_);
v___x_2662_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3);
v___x_2663_ = lean_nat_dec_lt(v___x_2650_, v___x_2662_);
if (v___x_2663_ == 0)
{
lean_object* v___x_2664_; lean_object* v_fst_2665_; 
lean_dec(v___y_2642_);
lean_inc(v___x_2650_);
v___x_2664_ = lp_floatlib_FloatLib_Numerics_FixedWord_IntegerSquareRoot_sqrtRem(v___x_2650_);
v_fst_2665_ = lean_ctor_get(v___x_2664_, 0);
lean_inc(v_fst_2665_);
lean_dec_ref(v___x_2664_);
v___y_2162_ = v_shift_2659_;
v___y_2163_ = v___y_2646_;
v___y_2164_ = v___y_2636_;
v___y_2165_ = v___x_2650_;
v___y_2166_ = v___y_2638_;
v___y_2167_ = v___y_2640_;
v___y_2168_ = v_fst_2665_;
goto v___jp_2161_;
}
else
{
uint64_t v___x_2666_; uint64_t v___x_2667_; uint8_t v___x_2668_; 
v___x_2666_ = lean_uint64_of_nat(v___x_2650_);
v___x_2667_ = 1ULL;
v___x_2668_ = lean_uint64_dec_le(v___x_2666_, v___x_2667_);
if (v___x_2668_ == 0)
{
uint64_t v___x_2669_; uint8_t v___x_2670_; 
v___x_2669_ = 2ULL;
v___x_2670_ = lean_uint64_dec_lt(v___x_2666_, v___x_2669_);
if (v___x_2670_ == 0)
{
uint64_t v___x_2671_; uint8_t v___x_2672_; 
v___x_2671_ = 16ULL;
v___x_2672_ = lean_uint64_dec_lt(v___x_2666_, v___x_2671_);
if (v___x_2672_ == 0)
{
uint64_t v___x_2673_; uint64_t v___x_2674_; uint8_t v___x_2675_; 
v___x_2673_ = 4ULL;
v___x_2674_ = 256ULL;
v___x_2675_ = lean_uint64_dec_lt(v___x_2666_, v___x_2674_);
if (v___x_2675_ == 0)
{
uint64_t v___x_2676_; uint64_t v___x_2677_; uint64_t v_high_2678_; uint64_t v___x_2679_; uint8_t v___x_2680_; 
v___x_2676_ = 32ULL;
v___x_2677_ = 8ULL;
v_high_2678_ = lean_uint64_shift_right(v___x_2666_, v___x_2676_);
v___x_2679_ = 0ULL;
v___x_2680_ = lean_uint64_dec_eq(v_high_2678_, v___x_2679_);
if (v___x_2680_ == 0)
{
v___y_2352_ = v___x_2671_;
v___y_2353_ = v___x_2679_;
v___y_2354_ = v___x_2667_;
v___y_2355_ = v_shift_2659_;
v___y_2356_ = v___x_2677_;
v___y_2357_ = v___x_2650_;
v___y_2358_ = v___y_2636_;
v___y_2359_ = v___x_2666_;
v___y_2360_ = v_high_2678_;
v___y_2361_ = v___x_2673_;
v___y_2362_ = v___y_2640_;
v___y_2363_ = v___y_2642_;
v___y_2364_ = v___y_2646_;
v___y_2365_ = v___y_2638_;
v___y_2366_ = v___x_2680_;
v___y_2367_ = v___x_2676_;
goto v___jp_2351_;
}
else
{
v___y_2352_ = v___x_2671_;
v___y_2353_ = v___x_2679_;
v___y_2354_ = v___x_2667_;
v___y_2355_ = v_shift_2659_;
v___y_2356_ = v___x_2677_;
v___y_2357_ = v___x_2650_;
v___y_2358_ = v___y_2636_;
v___y_2359_ = v___x_2666_;
v___y_2360_ = v_high_2678_;
v___y_2361_ = v___x_2673_;
v___y_2362_ = v___y_2640_;
v___y_2363_ = v___y_2642_;
v___y_2364_ = v___y_2646_;
v___y_2365_ = v___y_2638_;
v___y_2366_ = v___x_2680_;
v___y_2367_ = v___x_2679_;
goto v___jp_2351_;
}
}
else
{
uint64_t v_high_2681_; uint64_t v___x_2682_; uint8_t v___x_2683_; 
v_high_2681_ = lean_uint64_shift_right(v___x_2666_, v___x_2673_);
v___x_2682_ = 0ULL;
v___x_2683_ = lean_uint64_dec_eq(v_high_2681_, v___x_2682_);
if (v___x_2683_ == 0)
{
v___y_2212_ = v_high_2681_;
v___y_2213_ = v___x_2667_;
v___y_2214_ = v___x_2683_;
v___y_2215_ = v_shift_2659_;
v___y_2216_ = v___y_2646_;
v___y_2217_ = v___x_2650_;
v___y_2218_ = v___y_2636_;
v___y_2219_ = v___x_2666_;
v___y_2220_ = v___y_2638_;
v___y_2221_ = v___y_2640_;
v___y_2222_ = v___y_2642_;
v___y_2223_ = v___x_2673_;
goto v___jp_2211_;
}
else
{
v___y_2212_ = v_high_2681_;
v___y_2213_ = v___x_2667_;
v___y_2214_ = v___x_2683_;
v___y_2215_ = v_shift_2659_;
v___y_2216_ = v___y_2646_;
v___y_2217_ = v___x_2650_;
v___y_2218_ = v___y_2636_;
v___y_2219_ = v___x_2666_;
v___y_2220_ = v___y_2638_;
v___y_2221_ = v___y_2640_;
v___y_2222_ = v___y_2642_;
v___y_2223_ = v___x_2682_;
goto v___jp_2211_;
}
}
}
else
{
uint64_t v___x_2684_; 
v___x_2684_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___x_2666_);
v___y_2180_ = v___x_2667_;
v___y_2181_ = v_shift_2659_;
v___y_2182_ = v___y_2646_;
v___y_2183_ = v___x_2650_;
v___y_2184_ = v___y_2636_;
v___y_2185_ = v___x_2666_;
v___y_2186_ = v___y_2638_;
v___y_2187_ = v___y_2640_;
v___y_2188_ = v___y_2642_;
v___y_2189_ = v___x_2684_;
goto v___jp_2179_;
}
}
else
{
uint64_t v___x_2685_; 
v___x_2685_ = 0ULL;
v___y_2180_ = v___x_2667_;
v___y_2181_ = v_shift_2659_;
v___y_2182_ = v___y_2646_;
v___y_2183_ = v___x_2650_;
v___y_2184_ = v___y_2636_;
v___y_2185_ = v___x_2666_;
v___y_2186_ = v___y_2638_;
v___y_2187_ = v___y_2640_;
v___y_2188_ = v___y_2642_;
v___y_2189_ = v___x_2685_;
goto v___jp_2179_;
}
}
else
{
lean_object* v___x_2686_; 
lean_dec(v___y_2642_);
v___x_2686_ = lean_uint64_to_nat(v___x_2666_);
v___y_2162_ = v_shift_2659_;
v___y_2163_ = v___y_2646_;
v___y_2164_ = v___y_2636_;
v___y_2165_ = v___x_2650_;
v___y_2166_ = v___y_2638_;
v___y_2167_ = v___y_2640_;
v___y_2168_ = v___x_2686_;
goto v___jp_2161_;
}
}
}
else
{
lean_object* v_one_2687_; lean_object* v_n_2688_; lean_object* v_radicandShift_2689_; lean_object* v___x_2690_; lean_object* v___x_2691_; uint8_t v___x_2692_; 
v_one_2687_ = lean_unsigned_to_nat(1u);
v_n_2688_ = lean_nat_sub(v_shift_2659_, v_one_2687_);
v_radicandShift_2689_ = lean_nat_mul(v___y_2637_, v_n_2688_);
lean_dec(v_n_2688_);
v___x_2690_ = lean_nat_shiftr(v___x_2650_, v_radicandShift_2689_);
v___x_2691_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__3);
v___x_2692_ = lean_nat_dec_lt(v___x_2690_, v___x_2691_);
if (v___x_2692_ == 0)
{
lean_object* v___x_2693_; lean_object* v_fst_2694_; 
v___x_2693_ = lp_floatlib_FloatLib_Numerics_FixedWord_IntegerSquareRoot_sqrtRem(v___x_2690_);
v_fst_2694_ = lean_ctor_get(v___x_2693_, 0);
lean_inc(v_fst_2694_);
lean_dec_ref(v___x_2693_);
v___y_2387_ = v_radicandShift_2689_;
v___y_2388_ = v_shift_2659_;
v___y_2389_ = v___y_2646_;
v___y_2390_ = v___x_2650_;
v___y_2391_ = v___y_2636_;
v___y_2392_ = v___y_2637_;
v___y_2393_ = v___y_2638_;
v___y_2394_ = v___y_2639_;
v___y_2395_ = v___y_2640_;
v___y_2396_ = v___y_2641_;
v___y_2397_ = v___y_2642_;
v___y_2398_ = v_fst_2694_;
goto v___jp_2386_;
}
else
{
uint64_t v___x_2695_; uint64_t v___x_2696_; uint8_t v___x_2697_; 
v___x_2695_ = lean_uint64_of_nat(v___x_2690_);
lean_dec(v___x_2690_);
v___x_2696_ = 1ULL;
v___x_2697_ = lean_uint64_dec_le(v___x_2695_, v___x_2696_);
if (v___x_2697_ == 0)
{
uint64_t v___x_2698_; uint8_t v___x_2699_; 
v___x_2698_ = 2ULL;
v___x_2699_ = lean_uint64_dec_lt(v___x_2695_, v___x_2698_);
if (v___x_2699_ == 0)
{
uint64_t v___x_2700_; uint8_t v___x_2701_; 
v___x_2700_ = 16ULL;
v___x_2701_ = lean_uint64_dec_lt(v___x_2695_, v___x_2700_);
if (v___x_2701_ == 0)
{
uint64_t v___x_2702_; uint64_t v___x_2703_; uint8_t v___x_2704_; 
v___x_2702_ = 4ULL;
v___x_2703_ = 256ULL;
v___x_2704_ = lean_uint64_dec_lt(v___x_2695_, v___x_2703_);
if (v___x_2704_ == 0)
{
uint64_t v___x_2705_; uint64_t v___x_2706_; uint64_t v_high_2707_; uint64_t v___x_2708_; uint8_t v___x_2709_; 
v___x_2705_ = 32ULL;
v___x_2706_ = 8ULL;
v_high_2707_ = lean_uint64_shift_right(v___x_2695_, v___x_2705_);
v___x_2708_ = 0ULL;
v___x_2709_ = lean_uint64_dec_eq(v_high_2707_, v___x_2708_);
if (v___x_2709_ == 0)
{
v___y_2580_ = v_shift_2659_;
v___y_2581_ = v___x_2650_;
v___y_2582_ = v___y_2636_;
v___y_2583_ = v___x_2696_;
v___y_2584_ = v_high_2707_;
v___y_2585_ = v___x_2702_;
v___y_2586_ = v___x_2706_;
v___y_2587_ = v___y_2639_;
v___y_2588_ = v___y_2640_;
v___y_2589_ = v___y_2641_;
v___y_2590_ = v___y_2642_;
v___y_2591_ = v___x_2700_;
v___y_2592_ = v_radicandShift_2689_;
v___y_2593_ = v___y_2646_;
v___y_2594_ = v___x_2708_;
v___y_2595_ = v___x_2695_;
v___y_2596_ = v___y_2637_;
v___y_2597_ = v___x_2709_;
v___y_2598_ = v___y_2638_;
v___y_2599_ = v___x_2705_;
goto v___jp_2579_;
}
else
{
v___y_2580_ = v_shift_2659_;
v___y_2581_ = v___x_2650_;
v___y_2582_ = v___y_2636_;
v___y_2583_ = v___x_2696_;
v___y_2584_ = v_high_2707_;
v___y_2585_ = v___x_2702_;
v___y_2586_ = v___x_2706_;
v___y_2587_ = v___y_2639_;
v___y_2588_ = v___y_2640_;
v___y_2589_ = v___y_2641_;
v___y_2590_ = v___y_2642_;
v___y_2591_ = v___x_2700_;
v___y_2592_ = v_radicandShift_2689_;
v___y_2593_ = v___y_2646_;
v___y_2594_ = v___x_2708_;
v___y_2595_ = v___x_2695_;
v___y_2596_ = v___y_2637_;
v___y_2597_ = v___x_2709_;
v___y_2598_ = v___y_2638_;
v___y_2599_ = v___x_2708_;
goto v___jp_2579_;
}
}
else
{
uint64_t v_high_2710_; uint64_t v___x_2711_; uint8_t v___x_2712_; 
v_high_2710_ = lean_uint64_shift_right(v___x_2695_, v___x_2702_);
v___x_2711_ = 0ULL;
v___x_2712_ = lean_uint64_dec_eq(v_high_2710_, v___x_2711_);
if (v___x_2712_ == 0)
{
v___y_2619_ = v_shift_2659_;
v___y_2620_ = v___x_2650_;
v___y_2621_ = v___y_2636_;
v___y_2622_ = v_high_2710_;
v___y_2623_ = v___x_2696_;
v___y_2624_ = v___x_2712_;
v___y_2625_ = v___y_2639_;
v___y_2626_ = v___y_2640_;
v___y_2627_ = v___y_2641_;
v___y_2628_ = v___y_2642_;
v___y_2629_ = v_radicandShift_2689_;
v___y_2630_ = v___y_2646_;
v___y_2631_ = v___x_2695_;
v___y_2632_ = v___y_2637_;
v___y_2633_ = v___y_2638_;
v___y_2634_ = v___x_2702_;
goto v___jp_2618_;
}
else
{
v___y_2619_ = v_shift_2659_;
v___y_2620_ = v___x_2650_;
v___y_2621_ = v___y_2636_;
v___y_2622_ = v_high_2710_;
v___y_2623_ = v___x_2696_;
v___y_2624_ = v___x_2712_;
v___y_2625_ = v___y_2639_;
v___y_2626_ = v___y_2640_;
v___y_2627_ = v___y_2641_;
v___y_2628_ = v___y_2642_;
v___y_2629_ = v_radicandShift_2689_;
v___y_2630_ = v___y_2646_;
v___y_2631_ = v___x_2695_;
v___y_2632_ = v___y_2637_;
v___y_2633_ = v___y_2638_;
v___y_2634_ = v___x_2711_;
goto v___jp_2618_;
}
}
}
else
{
uint64_t v___x_2713_; 
v___x_2713_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___lam__0(v___x_2695_);
v___y_2403_ = v_shift_2659_;
v___y_2404_ = v___x_2650_;
v___y_2405_ = v___y_2636_;
v___y_2406_ = v___x_2696_;
v___y_2407_ = v___y_2639_;
v___y_2408_ = v___y_2640_;
v___y_2409_ = v___y_2641_;
v___y_2410_ = v___y_2642_;
v___y_2411_ = v_radicandShift_2689_;
v___y_2412_ = v___y_2646_;
v___y_2413_ = v___x_2695_;
v___y_2414_ = v___y_2637_;
v___y_2415_ = v___y_2638_;
v___y_2416_ = v___x_2713_;
goto v___jp_2402_;
}
}
else
{
uint64_t v___x_2714_; 
v___x_2714_ = 0ULL;
v___y_2403_ = v_shift_2659_;
v___y_2404_ = v___x_2650_;
v___y_2405_ = v___y_2636_;
v___y_2406_ = v___x_2696_;
v___y_2407_ = v___y_2639_;
v___y_2408_ = v___y_2640_;
v___y_2409_ = v___y_2641_;
v___y_2410_ = v___y_2642_;
v___y_2411_ = v_radicandShift_2689_;
v___y_2412_ = v___y_2646_;
v___y_2413_ = v___x_2695_;
v___y_2414_ = v___y_2637_;
v___y_2415_ = v___y_2638_;
v___y_2416_ = v___x_2714_;
goto v___jp_2402_;
}
}
else
{
lean_object* v___x_2715_; 
v___x_2715_ = lean_uint64_to_nat(v___x_2695_);
v___y_2387_ = v_radicandShift_2689_;
v___y_2388_ = v_shift_2659_;
v___y_2389_ = v___y_2646_;
v___y_2390_ = v___x_2650_;
v___y_2391_ = v___y_2636_;
v___y_2392_ = v___y_2637_;
v___y_2393_ = v___y_2638_;
v___y_2394_ = v___y_2639_;
v___y_2395_ = v___y_2640_;
v___y_2396_ = v___y_2641_;
v___y_2397_ = v___y_2642_;
v___y_2398_ = v___x_2715_;
goto v___jp_2386_;
}
}
}
}
v___jp_2716_:
{
lean_object* v___x_2723_; uint8_t v___x_2724_; 
v___x_2723_ = lean_unsigned_to_nat(0u);
v___x_2724_ = lean_nat_dec_eq(v___y_2721_, v___x_2723_);
if (v___x_2724_ == 0)
{
lean_object* v___x_2725_; uint8_t v___x_2726_; lean_object* v___x_2727_; lean_object* v___x_2728_; lean_object* v___x_2729_; lean_object* v___x_2730_; lean_object* v___x_2731_; lean_object* v___x_2732_; lean_object* v___x_2733_; uint8_t v___x_2734_; 
v___x_2725_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__0));
v___x_2726_ = 1;
lean_inc(v___y_2718_);
v___x_2727_ = lean_nat_to_int(v___y_2718_);
v___x_2728_ = lean_int_ediv(v___y_2722_, v___x_2727_);
v___x_2729_ = l_Float_Model_totalExponent(v___y_2721_, v___y_2722_);
lean_inc(v___y_2720_);
v___x_2730_ = lean_nat_to_int(v___y_2720_);
v___x_2731_ = lean_int_add(v___x_2729_, v___x_2730_);
lean_dec(v___x_2730_);
lean_dec(v___x_2729_);
v___x_2732_ = lean_int_ediv(v___x_2731_, v___x_2727_);
lean_dec(v___x_2731_);
v___x_2733_ = l_Float_Model_Format_targetExponent(v___x_2725_, v___x_2732_);
lean_dec(v___x_2732_);
v___x_2734_ = lean_int_dec_le(v___x_2728_, v___x_2733_);
if (v___x_2734_ == 0)
{
lean_dec(v___x_2728_);
v___y_2636_ = v___x_2723_;
v___y_2637_ = v___y_2718_;
v___y_2638_ = v___x_2725_;
v___y_2639_ = v___y_2719_;
v___y_2640_ = v___x_2726_;
v___y_2641_ = v___x_2724_;
v___y_2642_ = v___y_2720_;
v___y_2643_ = v___y_2721_;
v___y_2644_ = v___y_2722_;
v___y_2645_ = v___x_2727_;
v___y_2646_ = v___x_2733_;
goto v___jp_2635_;
}
else
{
lean_dec(v___x_2733_);
v___y_2636_ = v___x_2723_;
v___y_2637_ = v___y_2718_;
v___y_2638_ = v___x_2725_;
v___y_2639_ = v___y_2719_;
v___y_2640_ = v___x_2726_;
v___y_2641_ = v___x_2724_;
v___y_2642_ = v___y_2720_;
v___y_2643_ = v___y_2721_;
v___y_2644_ = v___y_2722_;
v___y_2645_ = v___x_2727_;
v___y_2646_ = v___x_2728_;
goto v___jp_2635_;
}
}
else
{
lean_object* v___x_2735_; 
lean_dec(v___y_2722_);
lean_dec(v___y_2721_);
lean_dec(v___y_2720_);
lean_dec(v___y_2718_);
v___x_2735_ = l_BitVec_ofNat(v___y_2717_, v___x_2723_);
return v___x_2735_;
}
}
v___jp_2736_:
{
lean_object* v___x_2743_; uint8_t v___x_2744_; 
v___x_2743_ = lean_unsigned_to_nat(0u);
v___x_2744_ = lean_nat_dec_eq(v___y_2737_, v___x_2743_);
if (v___x_2744_ == 0)
{
lean_object* v___x_2745_; lean_object* v___x_2746_; lean_object* v___x_2747_; lean_object* v___x_2748_; lean_object* v___x_2749_; 
v___x_2745_ = lean_nat_to_int(v___y_2737_);
v___x_2746_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4);
v___x_2747_ = lean_int_sub(v___x_2745_, v___x_2746_);
lean_dec(v___x_2745_);
v___x_2748_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__1, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__1_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__1);
v___x_2749_ = lean_int_sub(v___x_2747_, v___x_2748_);
lean_dec(v___x_2747_);
v___y_2717_ = v___y_2738_;
v___y_2718_ = v___y_2739_;
v___y_2719_ = v___y_2740_;
v___y_2720_ = v___y_2741_;
v___y_2721_ = v___y_2742_;
v___y_2722_ = v___x_2749_;
goto v___jp_2716_;
}
else
{
lean_object* v___x_2750_; lean_object* v___x_2751_; lean_object* v___x_2752_; lean_object* v___x_2753_; lean_object* v___x_2754_; 
lean_dec(v___y_2737_);
lean_inc(v___y_2741_);
v___x_2750_ = lean_nat_to_int(v___y_2741_);
v___x_2751_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2___closed__4);
v___x_2752_ = lean_int_sub(v___x_2750_, v___x_2751_);
lean_dec(v___x_2750_);
v___x_2753_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__1, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__1_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__1);
v___x_2754_ = lean_int_sub(v___x_2752_, v___x_2753_);
lean_dec(v___x_2752_);
v___y_2717_ = v___y_2738_;
v___y_2718_ = v___y_2739_;
v___y_2719_ = v___y_2740_;
v___y_2720_ = v___y_2741_;
v___y_2721_ = v___y_2742_;
v___y_2722_ = v___x_2754_;
goto v___jp_2716_;
}
}
v___jp_2755_:
{
lean_object* v___x_2756_; lean_object* v___x_2757_; uint8_t v___x_2758_; 
v___x_2756_ = lean_unsigned_to_nat(4096u);
v___x_2757_ = lean_unsigned_to_nat(4095u);
v___x_2758_ = l_Nat_testBit(v_x_2137_, v___x_2757_);
if (v___x_2758_ == 0)
{
lean_object* v___x_2759_; lean_object* v___x_2760_; uint8_t v___x_2761_; lean_object* v___x_2762_; lean_object* v___x_2763_; lean_object* v_exponent_2764_; lean_object* v___x_2765_; lean_object* v_fraction_2766_; lean_object* v___x_2767_; uint8_t v___x_2768_; 
v___x_2759_ = lean_unsigned_to_nat(1u);
v___x_2760_ = lean_unsigned_to_nat(2u);
v___x_2761_ = 1;
v___x_2762_ = lean_nat_shiftr(v_x_2137_, v___x_2138_);
v___x_2763_ = lean_unsigned_to_nat(524287u);
v_exponent_2764_ = lean_nat_land(v___x_2762_, v___x_2763_);
lean_dec(v___x_2762_);
v___x_2765_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__2, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__2_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__2);
v_fraction_2766_ = lean_nat_land(v_x_2137_, v___x_2765_);
lean_dec(v_x_2137_);
v___x_2767_ = lean_unsigned_to_nat(0u);
v___x_2768_ = lean_nat_dec_eq(v_exponent_2764_, v___x_2767_);
if (v___x_2768_ == 0)
{
lean_object* v___x_2769_; lean_object* v___x_2770_; 
v___x_2769_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__3, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__3_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__3);
v___x_2770_ = lean_nat_add(v___x_2769_, v_fraction_2766_);
lean_dec(v_fraction_2766_);
v___y_2737_ = v_exponent_2764_;
v___y_2738_ = v___x_2756_;
v___y_2739_ = v___x_2760_;
v___y_2740_ = v___x_2761_;
v___y_2741_ = v___x_2759_;
v___y_2742_ = v___x_2770_;
goto v___jp_2736_;
}
else
{
v___y_2737_ = v_exponent_2764_;
v___y_2738_ = v___x_2756_;
v___y_2739_ = v___x_2760_;
v___y_2740_ = v___x_2761_;
v___y_2741_ = v___x_2759_;
v___y_2742_ = v_fraction_2766_;
goto v___jp_2736_;
}
}
else
{
lean_object* v___x_2771_; 
lean_dec(v_x_2137_);
v___x_2771_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__9, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__9_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__9);
return v___x_2771_;
}
}
v___jp_2772_:
{
lean_object* v___x_2773_; lean_object* v___x_2774_; lean_object* v___x_2775_; lean_object* v___x_2776_; uint8_t v___x_2777_; 
v___x_2773_ = lean_nat_shiftr(v_x_2137_, v___x_2138_);
v___x_2774_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__10, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__10_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__10);
v___x_2775_ = lean_nat_land(v___x_2773_, v___x_2774_);
lean_dec(v___x_2773_);
v___x_2776_ = lean_unsigned_to_nat(0u);
v___x_2777_ = lean_nat_dec_eq(v___x_2775_, v___x_2776_);
lean_dec(v___x_2775_);
if (v___x_2777_ == 0)
{
goto v___jp_2755_;
}
else
{
lean_object* v___x_2778_; lean_object* v___x_2779_; uint8_t v___x_2780_; 
v___x_2778_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__12, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__12_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__12);
v___x_2779_ = lean_nat_land(v_x_2137_, v___x_2778_);
v___x_2780_ = lean_nat_dec_eq(v___x_2779_, v___x_2776_);
lean_dec(v___x_2779_);
if (v___x_2780_ == 0)
{
goto v___jp_2755_;
}
else
{
return v_x_2137_;
}
}
}
v___jp_2781_:
{
uint8_t v___x_2783_; 
v___x_2783_ = l_Option_decidableEqNone___redArg(v___y_2782_);
if (v___x_2783_ == 0)
{
lean_object* v_val_2784_; 
lean_dec(v_x_2137_);
v_val_2784_ = lean_ctor_get(v___y_2782_, 0);
lean_inc(v_val_2784_);
lean_dec(v___y_2782_);
return v_val_2784_;
}
else
{
lean_object* v___x_2785_; lean_object* v___x_2786_; lean_object* v___x_2787_; lean_object* v___x_2788_; uint8_t v___x_2789_; 
lean_dec(v___y_2782_);
v___x_2785_ = lean_nat_shiftr(v_x_2137_, v___x_2138_);
v___x_2786_ = lean_unsigned_to_nat(524287u);
v___x_2787_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__10, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__10_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__10);
v___x_2788_ = lean_nat_land(v___x_2785_, v___x_2787_);
lean_dec(v___x_2785_);
v___x_2789_ = lean_nat_dec_eq(v___x_2788_, v___x_2786_);
lean_dec(v___x_2788_);
if (v___x_2789_ == 0)
{
goto v___jp_2772_;
}
else
{
lean_object* v___x_2790_; lean_object* v___x_2791_; lean_object* v___x_2792_; uint8_t v___x_2793_; 
v___x_2790_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__12, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__12_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__12);
v___x_2791_ = lean_nat_land(v_x_2137_, v___x_2790_);
v___x_2792_ = lean_unsigned_to_nat(0u);
v___x_2793_ = lean_nat_dec_eq(v___x_2791_, v___x_2792_);
lean_dec(v___x_2791_);
if (v___x_2793_ == 0)
{
goto v___jp_2772_;
}
else
{
lean_object* v___x_2794_; uint8_t v___x_2795_; 
v___x_2794_ = lean_unsigned_to_nat(4095u);
v___x_2795_ = l_Nat_testBit(v_x_2137_, v___x_2794_);
lean_dec(v_x_2137_);
if (v___x_2795_ == 0)
{
if (v___x_2795_ == 0)
{
lean_object* v___x_2796_; 
v___x_2796_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__6, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__6_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__6);
return v___x_2796_;
}
else
{
lean_object* v___x_2797_; 
v___x_2797_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__15, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__15_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__15);
return v___x_2797_;
}
}
else
{
lean_object* v___x_2798_; 
v___x_2798_ = lean_obj_once(&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__9, &l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__9_once, _init_l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1___closed__9);
return v___x_2798_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0(lean_object* v_x_2815_){
_start:
{
lean_object* v___x_2816_; 
v___x_2816_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1(v_x_2815_);
return v___x_2816_;
}
}
static lean_object* _init_l_BalancedSqrt_block4096___closed__4(void){
_start:
{
lean_object* v___x_2833_; uint8_t v___x_2834_; lean_object* v___x_2835_; lean_object* v___x_2836_; 
v___x_2833_ = ((lean_object*)(l_BalancedSqrt_block4096___closed__3));
v___x_2834_ = 5;
v___x_2835_ = ((lean_object*)(l_BalancedSqrt_block4096___closed__0));
v___x_2836_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep_configuredBenchmarkCarrier(v___x_2835_, v___x_2834_, v___x_2833_);
return v___x_2836_;
}
}
static lean_object* _init_l_BalancedSqrt_block4096___closed__5(void){
_start:
{
lean_object* v___x_2837_; lean_object* v___x_2838_; 
v___x_2837_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__4, &l_BalancedSqrt_block4096___closed__4_once, _init_l_BalancedSqrt_block4096___closed__4);
v___x_2838_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep_benchmarkExecFloatInhabited___redArg(v___x_2837_);
return v___x_2838_;
}
}
static uint8_t _init_l_BalancedSqrt_block4096___closed__6(void){
_start:
{
uint8_t v___x_2839_; uint8_t v___x_2840_; lean_object* v___x_2841_; lean_object* v___x_2842_; uint8_t v___x_2843_; 
v___x_2839_ = 4;
v___x_2840_ = 5;
v___x_2841_ = lp_floatlib_FloatLib_Floats_ExecFloat_Backend_Policy_throughput;
v___x_2842_ = ((lean_object*)(l_BalancedSqrt_block4096___closed__0));
v___x_2843_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Plan_firstOrderSelected(v___x_2842_, v___x_2841_, v___x_2840_, v___x_2839_);
return v___x_2843_;
}
}
static uint8_t _init_l_BalancedSqrt_block4096___closed__7(void){
_start:
{
uint8_t v___x_2844_; uint8_t v___x_2845_; lean_object* v___x_2846_; lean_object* v___x_2847_; uint8_t v___x_2848_; 
v___x_2844_ = 4;
v___x_2845_ = 5;
v___x_2846_ = lp_floatlib_FloatLib_Floats_ExecFloat_Backend_Policy_throughput;
v___x_2847_ = ((lean_object*)(l_BalancedSqrt_block4096___closed__0));
v___x_2848_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Plan_firstOrderGenericSelected(v___x_2847_, v___x_2846_, v___x_2845_, v___x_2844_);
return v___x_2848_;
}
}
static lean_object* _init_l_BalancedSqrt_block4096___closed__9(void){
_start:
{
lean_object* v___f_2853_; lean_object* v_selection_2854_; 
v___f_2853_ = ((lean_object*)(l_BalancedSqrt_block4096___closed__8));
v_selection_2854_ = lean_mk_thunk(v___f_2853_);
return v_selection_2854_;
}
}
static lean_object* _init_l_BalancedSqrt_block4096___closed__10(void){
_start:
{
lean_object* v_selection_2855_; lean_object* v___x_2856_; 
v_selection_2855_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__9, &l_BalancedSqrt_block4096___closed__9_once, _init_l_BalancedSqrt_block4096___closed__9);
v___x_2856_ = lean_thunk_get_own(v_selection_2855_);
return v___x_2856_;
}
}
static lean_object* _init_l_BalancedSqrt_block4096___closed__11(void){
_start:
{
uint8_t v___x_2857_; lean_object* v___x_2858_; lean_object* v___x_2859_; 
v___x_2857_ = 4;
v___x_2858_ = ((lean_object*)(l_BalancedSqrt_block4096___closed__0));
v___x_2859_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Descriptor_Plan_structuralRoute_x3f(v___x_2858_, v___x_2857_);
return v___x_2859_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_block4096(lean_object* v_x_2860_, uint64_t v_x_2861_, lean_object* v_x_2862_, lean_object* v_x_2863_){
_start:
{
lean_object* v_zero_2864_; uint8_t v_isZero_2865_; 
v_zero_2864_ = lean_unsigned_to_nat(0u);
v_isZero_2865_ = lean_nat_dec_eq(v_x_2860_, v_zero_2864_);
if (v_isZero_2865_ == 1)
{
lean_dec(v_x_2860_);
return v_x_2863_;
}
else
{
uint64_t v_sink_2866_; uint64_t v_trace_2867_; lean_object* v___x_2869_; uint8_t v_isShared_2870_; uint8_t v_isSharedCheck_2905_; 
v_sink_2866_ = lean_ctor_get_uint64(v_x_2863_, 0);
v_trace_2867_ = lean_ctor_get_uint64(v_x_2863_, 8);
v_isSharedCheck_2905_ = !lean_is_exclusive(v_x_2863_);
if (v_isSharedCheck_2905_ == 0)
{
v___x_2869_ = v_x_2863_;
v_isShared_2870_ = v_isSharedCheck_2905_;
goto v_resetjp_2868_;
}
else
{
lean_dec(v_x_2863_);
v___x_2869_ = lean_box(0);
v_isShared_2870_ = v_isSharedCheck_2905_;
goto v_resetjp_2868_;
}
v_resetjp_2868_:
{
lean_object* v_one_2871_; lean_object* v_n_2872_; lean_object* v_index_2873_; lean_object* v___y_2875_; lean_object* v___y_2891_; lean_object* v___x_2893_; lean_object* v___x_2894_; uint8_t v___x_2895_; 
v_one_2871_ = lean_unsigned_to_nat(1u);
v_n_2872_ = lean_nat_sub(v_x_2860_, v_one_2871_);
lean_dec(v_x_2860_);
v_index_2873_ = l_BalancedSqrt_nextUnused(v_x_2861_, v_sink_2866_);
v___x_2893_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__5, &l_BalancedSqrt_block4096___closed__5_once, _init_l_BalancedSqrt_block4096___closed__5);
v___x_2894_ = lean_array_get_borrowed(v___x_2893_, v_x_2862_, v_index_2873_);
v___x_2895_ = lean_uint8_once(&l_BalancedSqrt_block4096___closed__6, &l_BalancedSqrt_block4096___closed__6_once, _init_l_BalancedSqrt_block4096___closed__6);
if (v___x_2895_ == 0)
{
uint8_t v___x_2896_; 
v___x_2896_ = lean_uint8_once(&l_BalancedSqrt_block4096___closed__7, &l_BalancedSqrt_block4096___closed__7_once, _init_l_BalancedSqrt_block4096___closed__7);
if (v___x_2896_ == 0)
{
lean_object* v___x_2897_; lean_object* v_run_2898_; lean_object* v___x_2899_; 
v___x_2897_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__10, &l_BalancedSqrt_block4096___closed__10_once, _init_l_BalancedSqrt_block4096___closed__10);
v_run_2898_ = lean_ctor_get(v___x_2897_, 1);
lean_inc(v_run_2898_);
lean_inc(v___x_2894_);
v___x_2899_ = lean_apply_1(v_run_2898_, v___x_2894_);
v___y_2875_ = v___x_2899_;
goto v___jp_2874_;
}
else
{
lean_object* v___x_2900_; 
lean_inc(v___x_2894_);
v___x_2900_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1(v___x_2894_);
v___y_2875_ = v___x_2900_;
goto v___jp_2874_;
}
}
else
{
lean_object* v___x_2901_; 
v___x_2901_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__11, &l_BalancedSqrt_block4096___closed__11_once, _init_l_BalancedSqrt_block4096___closed__11);
if (lean_obj_tag(v___x_2901_) == 1)
{
lean_object* v_val_2902_; uint8_t v___x_2903_; 
v_val_2902_ = lean_ctor_get(v___x_2901_, 0);
v___x_2903_ = lean_unbox(v_val_2902_);
if (v___x_2903_ == 2)
{
lean_object* v___x_2904_; 
lean_inc(v___x_2894_);
v___x_2904_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1(v___x_2894_);
v___y_2875_ = v___x_2904_;
goto v___jp_2874_;
}
else
{
lean_inc(v___x_2894_);
v___y_2891_ = v___x_2894_;
goto v___jp_2890_;
}
}
else
{
lean_inc(v___x_2894_);
v___y_2891_ = v___x_2894_;
goto v___jp_2890_;
}
}
v___jp_2874_:
{
uint64_t v___x_2876_; uint64_t v___x_2877_; uint64_t v___x_2878_; uint64_t v___x_2879_; uint64_t v___x_2880_; uint64_t v___x_2881_; uint64_t v___x_2882_; uint64_t v___x_2883_; uint64_t v___x_2884_; uint64_t v___x_2885_; lean_object* v___x_2887_; 
v___x_2876_ = 1ULL;
v___x_2877_ = lean_uint64_of_nat(v_index_2873_);
lean_dec(v_index_2873_);
v___x_2878_ = lean_uint64_shift_left(v___x_2876_, v___x_2877_);
v___x_2879_ = lean_uint64_lor(v_x_2861_, v___x_2878_);
v___x_2880_ = lean_uint64_of_nat(v___y_2875_);
lean_dec(v___y_2875_);
v___x_2881_ = lean_uint64_xor(v_sink_2866_, v___x_2880_);
v___x_2882_ = 1099511628211ULL;
v___x_2883_ = lean_uint64_mul(v___x_2881_, v___x_2882_);
v___x_2884_ = lean_uint64_xor(v_trace_2867_, v___x_2877_);
v___x_2885_ = lean_uint64_mul(v___x_2884_, v___x_2882_);
if (v_isShared_2870_ == 0)
{
v___x_2887_ = v___x_2869_;
goto v_reusejp_2886_;
}
else
{
lean_object* v_reuseFailAlloc_2889_; 
v_reuseFailAlloc_2889_ = lean_alloc_ctor(0, 0, 16);
v___x_2887_ = v_reuseFailAlloc_2889_;
goto v_reusejp_2886_;
}
v_reusejp_2886_:
{
lean_ctor_set_uint64(v___x_2887_, 0, v___x_2883_);
lean_ctor_set_uint64(v___x_2887_, 8, v___x_2885_);
v_x_2860_ = v_n_2872_;
v_x_2861_ = v___x_2879_;
v_x_2863_ = v___x_2887_;
goto _start;
}
}
v___jp_2890_:
{
lean_object* v___x_2892_; 
v___x_2892_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1(v___y_2891_);
v___y_2875_ = v___x_2892_;
goto v___jp_2874_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_block4096___boxed(lean_object* v_x_2906_, lean_object* v_x_2907_, lean_object* v_x_2908_, lean_object* v_x_2909_){
_start:
{
uint64_t v_x_25947__boxed_2910_; lean_object* v_res_2911_; 
v_x_25947__boxed_2910_ = lean_unbox_uint64(v_x_2907_);
lean_dec_ref(v_x_2907_);
v_res_2911_ = l_BalancedSqrt_block4096(v_x_2906_, v_x_25947__boxed_2910_, v_x_2908_, v_x_2909_);
lean_dec_ref(v_x_2908_);
return v_res_2911_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks1024(lean_object* v_xs_2912_, lean_object* v_x_2913_, lean_object* v_x_2914_){
_start:
{
lean_object* v_zero_2915_; uint8_t v_isZero_2916_; 
v_zero_2915_ = lean_unsigned_to_nat(0u);
v_isZero_2916_ = lean_nat_dec_eq(v_x_2913_, v_zero_2915_);
if (v_isZero_2916_ == 1)
{
lean_dec(v_x_2913_);
return v_x_2914_;
}
else
{
lean_object* v_one_2917_; lean_object* v_n_2918_; lean_object* v___x_2919_; uint64_t v___x_2920_; lean_object* v___x_2921_; 
v_one_2917_ = lean_unsigned_to_nat(1u);
v_n_2918_ = lean_nat_sub(v_x_2913_, v_one_2917_);
lean_dec(v_x_2913_);
v___x_2919_ = lean_unsigned_to_nat(16u);
v___x_2920_ = 0ULL;
v___x_2921_ = l_BalancedSqrt_block1024(v___x_2919_, v___x_2920_, v_xs_2912_, v_x_2914_);
v_x_2913_ = v_n_2918_;
v_x_2914_ = v___x_2921_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks1024___boxed(lean_object* v_xs_2923_, lean_object* v_x_2924_, lean_object* v_x_2925_){
_start:
{
lean_object* v_res_2926_; 
v_res_2926_ = l_BalancedSqrt_blocks1024(v_xs_2923_, v_x_2924_, v_x_2925_);
lean_dec_ref(v_xs_2923_);
return v_res_2926_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks2048(lean_object* v_xs_2927_, lean_object* v_x_2928_, lean_object* v_x_2929_){
_start:
{
lean_object* v_zero_2930_; uint8_t v_isZero_2931_; 
v_zero_2930_ = lean_unsigned_to_nat(0u);
v_isZero_2931_ = lean_nat_dec_eq(v_x_2928_, v_zero_2930_);
if (v_isZero_2931_ == 1)
{
lean_dec(v_x_2928_);
return v_x_2929_;
}
else
{
lean_object* v_one_2932_; lean_object* v_n_2933_; lean_object* v___x_2934_; uint64_t v___x_2935_; lean_object* v___x_2936_; 
v_one_2932_ = lean_unsigned_to_nat(1u);
v_n_2933_ = lean_nat_sub(v_x_2928_, v_one_2932_);
lean_dec(v_x_2928_);
v___x_2934_ = lean_unsigned_to_nat(16u);
v___x_2935_ = 0ULL;
v___x_2936_ = l_BalancedSqrt_block2048(v___x_2934_, v___x_2935_, v_xs_2927_, v_x_2929_);
v_x_2928_ = v_n_2933_;
v_x_2929_ = v___x_2936_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks2048___boxed(lean_object* v_xs_2938_, lean_object* v_x_2939_, lean_object* v_x_2940_){
_start:
{
lean_object* v_res_2941_; 
v_res_2941_ = l_BalancedSqrt_blocks2048(v_xs_2938_, v_x_2939_, v_x_2940_);
lean_dec_ref(v_xs_2938_);
return v_res_2941_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks4096(lean_object* v_xs_2942_, lean_object* v_x_2943_, lean_object* v_x_2944_){
_start:
{
lean_object* v_zero_2945_; uint8_t v_isZero_2946_; 
v_zero_2945_ = lean_unsigned_to_nat(0u);
v_isZero_2946_ = lean_nat_dec_eq(v_x_2943_, v_zero_2945_);
if (v_isZero_2946_ == 1)
{
lean_dec(v_x_2943_);
return v_x_2944_;
}
else
{
lean_object* v_one_2947_; lean_object* v_n_2948_; lean_object* v___x_2949_; uint64_t v___x_2950_; lean_object* v___x_2951_; 
v_one_2947_ = lean_unsigned_to_nat(1u);
v_n_2948_ = lean_nat_sub(v_x_2943_, v_one_2947_);
lean_dec(v_x_2943_);
v___x_2949_ = lean_unsigned_to_nat(16u);
v___x_2950_ = 0ULL;
v___x_2951_ = l_BalancedSqrt_block4096(v___x_2949_, v___x_2950_, v_xs_2942_, v_x_2944_);
v_x_2943_ = v_n_2948_;
v_x_2944_ = v___x_2951_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks4096___boxed(lean_object* v_xs_2953_, lean_object* v_x_2954_, lean_object* v_x_2955_){
_start:
{
lean_object* v_res_2956_; 
v_res_2956_ = l_BalancedSqrt_blocks4096(v_xs_2953_, v_x_2954_, v_x_2955_);
lean_dec_ref(v_xs_2953_);
return v_res_2956_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_output(lean_object* v_mode_2959_, lean_object* v_width_2960_, lean_object* v_blocks_2961_, lean_object* v_nanos_2962_, lean_object* v_s_2963_){
_start:
{
uint64_t v_sink_2965_; uint64_t v_trace_2966_; lean_object* v___x_2967_; lean_object* v___x_2968_; lean_object* v___x_2969_; lean_object* v___x_2970_; lean_object* v___x_2971_; lean_object* v___x_2972_; lean_object* v___x_2973_; lean_object* v___x_2974_; lean_object* v___x_2975_; lean_object* v___x_2976_; lean_object* v___x_2977_; lean_object* v___x_2978_; lean_object* v___x_2979_; lean_object* v___x_2980_; lean_object* v___x_2981_; lean_object* v___x_2982_; lean_object* v___x_2983_; lean_object* v___x_2984_; lean_object* v___x_2985_; lean_object* v___x_2986_; lean_object* v___x_2987_; 
v_sink_2965_ = lean_ctor_get_uint64(v_s_2963_, 0);
v_trace_2966_ = lean_ctor_get_uint64(v_s_2963_, 8);
v___x_2967_ = ((lean_object*)(l_BalancedSqrt_output___closed__0));
v___x_2968_ = lean_string_append(v___x_2967_, v_mode_2959_);
v___x_2969_ = ((lean_object*)(l_BalancedSqrt_output___closed__1));
v___x_2970_ = lean_string_append(v___x_2968_, v___x_2969_);
v___x_2971_ = l_Nat_reprFast(v_width_2960_);
v___x_2972_ = lean_string_append(v___x_2970_, v___x_2971_);
lean_dec_ref(v___x_2971_);
v___x_2973_ = lean_string_append(v___x_2972_, v___x_2969_);
v___x_2974_ = l_Nat_reprFast(v_blocks_2961_);
v___x_2975_ = lean_string_append(v___x_2973_, v___x_2974_);
lean_dec_ref(v___x_2974_);
v___x_2976_ = lean_string_append(v___x_2975_, v___x_2969_);
v___x_2977_ = l_Nat_reprFast(v_nanos_2962_);
v___x_2978_ = lean_string_append(v___x_2976_, v___x_2977_);
lean_dec_ref(v___x_2977_);
v___x_2979_ = lean_string_append(v___x_2978_, v___x_2969_);
v___x_2980_ = lean_uint64_to_nat(v_sink_2965_);
v___x_2981_ = l_Nat_reprFast(v___x_2980_);
v___x_2982_ = lean_string_append(v___x_2979_, v___x_2981_);
lean_dec_ref(v___x_2981_);
v___x_2983_ = lean_string_append(v___x_2982_, v___x_2969_);
v___x_2984_ = lean_uint64_to_nat(v_trace_2966_);
v___x_2985_ = l_Nat_reprFast(v___x_2984_);
v___x_2986_ = lean_string_append(v___x_2983_, v___x_2985_);
lean_dec_ref(v___x_2985_);
v___x_2987_ = lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(v___x_2986_);
return v___x_2987_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_output___boxed(lean_object* v_mode_2988_, lean_object* v_width_2989_, lean_object* v_blocks_2990_, lean_object* v_nanos_2991_, lean_object* v_s_2992_, lean_object* v_a_2993_){
_start:
{
lean_object* v_res_2994_; 
v_res_2994_ = l_BalancedSqrt_output(v_mode_2988_, v_width_2989_, v_blocks_2990_, v_nanos_2991_, v_s_2992_);
lean_dec_ref(v_s_2992_);
lean_dec_ref(v_mode_2988_);
return v_res_2994_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_execute(lean_object* v_mode_3000_, lean_object* v_width_3001_, lean_object* v_blocks_3002_, lean_object* v_run_3003_, lean_object* v_dump_3004_){
_start:
{
lean_object* v___x_3006_; lean_object* v___x_3007_; lean_object* v___x_3008_; uint8_t v___x_3009_; 
v___x_3006_ = ((lean_object*)(l_BalancedSqrt_execute___closed__0));
v___x_3007_ = lean_st_mk_ref(v___x_3006_);
v___x_3008_ = ((lean_object*)(l_BalancedSqrt_execute___closed__1));
v___x_3009_ = lean_string_dec_eq(v_mode_3000_, v___x_3008_);
if (v___x_3009_ == 0)
{
lean_object* v___x_3010_; lean_object* v___x_3011_; lean_object* v___x_3012_; lean_object* v___x_3013_; uint64_t v_sink_3014_; uint64_t v_trace_3015_; lean_object* v___x_3016_; lean_object* v___x_3017_; lean_object* v___x_3018_; lean_object* v___x_3019_; lean_object* v___x_3020_; lean_object* v___x_3021_; lean_object* v___x_3022_; lean_object* v___x_3023_; lean_object* v___x_3024_; lean_object* v___x_3025_; lean_object* v___x_3026_; lean_object* v___x_3027_; lean_object* v___x_3028_; lean_object* v___x_3029_; 
lean_dec_ref(v_dump_3004_);
v___x_3010_ = lean_unsigned_to_nat(1u);
lean_inc_ref(v_run_3003_);
v___x_3011_ = lean_apply_2(v_run_3003_, v___x_3010_, v___x_3006_);
v___x_3012_ = lean_st_ref_swap(v___x_3007_, v___x_3011_);
lean_dec(v___x_3012_);
v___x_3013_ = lean_st_ref_get(v___x_3007_);
v_sink_3014_ = lean_ctor_get_uint64(v___x_3013_, 0);
v_trace_3015_ = lean_ctor_get_uint64(v___x_3013_, 8);
lean_dec(v___x_3013_);
v___x_3016_ = ((lean_object*)(l_BalancedSqrt_execute___closed__2));
lean_inc(v_width_3001_);
v___x_3017_ = l_Nat_reprFast(v_width_3001_);
v___x_3018_ = lean_string_append(v___x_3016_, v___x_3017_);
lean_dec_ref(v___x_3017_);
v___x_3019_ = ((lean_object*)(l_BalancedSqrt_execute___closed__3));
v___x_3020_ = lean_string_append(v___x_3018_, v___x_3019_);
v___x_3021_ = lean_uint64_to_nat(v_sink_3014_);
v___x_3022_ = l_Nat_reprFast(v___x_3021_);
v___x_3023_ = lean_string_append(v___x_3020_, v___x_3022_);
lean_dec_ref(v___x_3022_);
v___x_3024_ = ((lean_object*)(l_BalancedSqrt_output___closed__1));
v___x_3025_ = lean_string_append(v___x_3023_, v___x_3024_);
v___x_3026_ = lean_uint64_to_nat(v_trace_3015_);
v___x_3027_ = l_Nat_reprFast(v___x_3026_);
v___x_3028_ = lean_string_append(v___x_3025_, v___x_3027_);
lean_dec_ref(v___x_3027_);
v___x_3029_ = lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(v___x_3028_);
if (lean_obj_tag(v___x_3029_) == 0)
{
lean_object* v___x_3030_; lean_object* v___x_3031_; lean_object* v___x_3032_; lean_object* v___x_3033_; lean_object* v___x_3034_; lean_object* v___x_3035_; lean_object* v___x_3036_; 
lean_dec_ref_known(v___x_3029_, 1);
v___x_3030_ = lean_io_mono_nanos_now();
lean_inc(v_blocks_3002_);
v___x_3031_ = lean_apply_2(v_run_3003_, v_blocks_3002_, v___x_3006_);
v___x_3032_ = lean_st_ref_swap(v___x_3007_, v___x_3031_);
lean_dec(v___x_3032_);
v___x_3033_ = lean_io_mono_nanos_now();
v___x_3034_ = lean_st_ref_get(v___x_3007_);
lean_dec(v___x_3007_);
v___x_3035_ = lean_nat_sub(v___x_3033_, v___x_3030_);
lean_dec(v___x_3030_);
lean_dec(v___x_3033_);
v___x_3036_ = l_BalancedSqrt_output(v_mode_3000_, v_width_3001_, v_blocks_3002_, v___x_3035_, v___x_3034_);
lean_dec(v___x_3034_);
return v___x_3036_;
}
else
{
lean_dec(v___x_3007_);
lean_dec_ref(v_run_3003_);
lean_dec(v_blocks_3002_);
lean_dec(v_width_3001_);
return v___x_3029_;
}
}
else
{
lean_object* v___x_3037_; 
v___x_3037_ = lean_apply_1(v_dump_3004_, lean_box(0));
if (lean_obj_tag(v___x_3037_) == 0)
{
lean_object* v___x_3038_; lean_object* v___x_3039_; lean_object* v___x_3040_; lean_object* v___x_3041_; lean_object* v___x_3042_; 
lean_dec_ref_known(v___x_3037_, 1);
lean_inc(v_blocks_3002_);
v___x_3038_ = lean_apply_2(v_run_3003_, v_blocks_3002_, v___x_3006_);
v___x_3039_ = lean_st_ref_swap(v___x_3007_, v___x_3038_);
lean_dec(v___x_3039_);
v___x_3040_ = lean_st_ref_get(v___x_3007_);
lean_dec(v___x_3007_);
v___x_3041_ = lean_unsigned_to_nat(0u);
v___x_3042_ = l_BalancedSqrt_output(v_mode_3000_, v_width_3001_, v_blocks_3002_, v___x_3041_, v___x_3040_);
lean_dec(v___x_3040_);
return v___x_3042_;
}
else
{
lean_dec(v___x_3007_);
lean_dec_ref(v_run_3003_);
lean_dec(v_blocks_3002_);
lean_dec(v_width_3001_);
return v___x_3037_;
}
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_execute___boxed(lean_object* v_mode_3043_, lean_object* v_width_3044_, lean_object* v_blocks_3045_, lean_object* v_run_3046_, lean_object* v_dump_3047_, lean_object* v_a_3048_){
_start:
{
lean_object* v_res_3049_; 
v_res_3049_ = l_BalancedSqrt_execute(v_mode_3043_, v_width_3044_, v_blocks_3045_, v_run_3046_, v_dump_3047_);
lean_dec_ref(v_mode_3043_);
return v_res_3049_;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0___closed__0(void){
_start:
{
lean_object* v___x_3050_; lean_object* v___x_3051_; 
v___x_3050_ = lean_unsigned_to_nat(0u);
v___x_3051_ = lean_nat_to_int(v___x_3050_);
return v___x_3051_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0(size_t v_sz_3052_, size_t v_i_3053_, lean_object* v_bs_3054_){
_start:
{
uint8_t v___x_3055_; 
v___x_3055_ = lean_usize_dec_lt(v_i_3053_, v_sz_3052_);
if (v___x_3055_ == 0)
{
return v_bs_3054_;
}
else
{
lean_object* v_v_3056_; lean_object* v_num_3057_; lean_object* v_den_3058_; lean_object* v___x_3059_; lean_object* v___x_3060_; lean_object* v_bs_x27_3061_; uint8_t v___x_3062_; lean_object* v___x_3063_; uint8_t v___x_3064_; lean_object* v___x_3065_; lean_object* v___x_3066_; size_t v___x_3067_; size_t v___x_3068_; lean_object* v___x_3069_; 
v_v_3056_ = lean_array_uget_borrowed(v_bs_3054_, v_i_3053_);
v_num_3057_ = lean_ctor_get(v_v_3056_, 0);
lean_inc(v_num_3057_);
v_den_3058_ = lean_ctor_get(v_v_3056_, 1);
lean_inc(v_den_3058_);
v___x_3059_ = ((lean_object*)(l_BalancedSqrt_block1024___closed__0));
v___x_3060_ = lean_unsigned_to_nat(0u);
v_bs_x27_3061_ = lean_array_uset(v_bs_3054_, v_i_3053_, v___x_3060_);
v___x_3062_ = 0;
v___x_3063_ = lean_obj_once(&l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0___closed__0, &l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0___closed__0_once, _init_l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0___closed__0);
v___x_3064_ = lean_int_dec_lt(v_num_3057_, v___x_3063_);
v___x_3065_ = lean_nat_abs(v_num_3057_);
lean_dec(v_num_3057_);
v___x_3066_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Model_Internal_Directed_roundRat(v___x_3059_, v___x_3062_, v___x_3064_, v___x_3065_, v_den_3058_);
v___x_3067_ = ((size_t)1ULL);
v___x_3068_ = lean_usize_add(v_i_3053_, v___x_3067_);
v___x_3069_ = lean_array_uset(v_bs_x27_3061_, v_i_3053_, v___x_3066_);
v_i_3053_ = v___x_3068_;
v_bs_3054_ = v___x_3069_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0___boxed(lean_object* v_sz_3071_, lean_object* v_i_3072_, lean_object* v_bs_3073_){
_start:
{
size_t v_sz_boxed_3074_; size_t v_i_boxed_3075_; lean_object* v_res_3076_; 
v_sz_boxed_3074_ = lean_unbox_usize(v_sz_3071_);
lean_dec(v_sz_3071_);
v_i_boxed_3075_ = lean_unbox_usize(v_i_3072_);
lean_dec(v_i_3072_);
v_res_3076_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0(v_sz_boxed_3074_, v_i_boxed_3075_, v_bs_3073_);
return v_res_3076_;
}
}
static size_t _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0(void){
_start:
{
lean_object* v___x_3077_; size_t v_sz_3078_; 
v___x_3077_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Support_ExactWorkload_sqrtXs;
v_sz_3078_ = lean_array_size(v___x_3077_);
return v_sz_3078_;
}
}
static lean_object* _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__1(void){
_start:
{
lean_object* v___x_3079_; size_t v___x_3080_; size_t v_sz_3081_; lean_object* v___x_3082_; 
v___x_3079_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Support_ExactWorkload_sqrtXs;
v___x_3080_ = ((size_t)0ULL);
v_sz_3081_ = lean_usize_once(&l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0, &l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0_once, _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0);
v___x_3082_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0(v_sz_3081_, v___x_3080_, v___x_3079_);
return v___x_3082_;
}
}
static lean_object* _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0(void){
_start:
{
lean_object* v___x_3083_; 
v___x_3083_ = lean_obj_once(&l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__1, &l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__1_once, _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__1);
return v___x_3083_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg(lean_object* v_range_3086_, lean_object* v_b_3087_, lean_object* v_i_3088_){
_start:
{
lean_object* v_stop_3090_; lean_object* v_step_3091_; uint8_t v___x_3092_; 
v_stop_3090_ = lean_ctor_get(v_range_3086_, 1);
v_step_3091_ = lean_ctor_get(v_range_3086_, 2);
v___x_3092_ = lean_nat_dec_lt(v_i_3088_, v_stop_3090_);
if (v___x_3092_ == 0)
{
lean_object* v___x_3093_; 
lean_dec(v_i_3088_);
v___x_3093_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3093_, 0, v_b_3087_);
return v___x_3093_;
}
else
{
lean_object* v___x_3094_; lean_object* v___y_3096_; lean_object* v___y_3108_; lean_object* v___x_3110_; lean_object* v_xs_3111_; lean_object* v___x_3112_; uint8_t v___x_3113_; 
v___x_3094_ = lean_box(0);
v___x_3110_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__5, &l_BalancedSqrt_block1024___closed__5_once, _init_l_BalancedSqrt_block1024___closed__5);
v_xs_3111_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0;
v___x_3112_ = lean_array_get_borrowed(v___x_3110_, v_xs_3111_, v_i_3088_);
v___x_3113_ = lean_uint8_once(&l_BalancedSqrt_block1024___closed__6, &l_BalancedSqrt_block1024___closed__6_once, _init_l_BalancedSqrt_block1024___closed__6);
if (v___x_3113_ == 0)
{
uint8_t v___x_3114_; 
v___x_3114_ = lean_uint8_once(&l_BalancedSqrt_block1024___closed__7, &l_BalancedSqrt_block1024___closed__7_once, _init_l_BalancedSqrt_block1024___closed__7);
if (v___x_3114_ == 0)
{
lean_object* v___x_3115_; lean_object* v_run_3116_; lean_object* v___x_3117_; 
v___x_3115_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__10, &l_BalancedSqrt_block1024___closed__10_once, _init_l_BalancedSqrt_block1024___closed__10);
v_run_3116_ = lean_ctor_get(v___x_3115_, 1);
lean_inc(v_run_3116_);
lean_inc(v___x_3112_);
v___x_3117_ = lean_apply_1(v_run_3116_, v___x_3112_);
v___y_3096_ = v___x_3117_;
goto v___jp_3095_;
}
else
{
lean_object* v___x_3118_; 
lean_inc(v___x_3112_);
v___x_3118_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2(v___x_3112_);
v___y_3096_ = v___x_3118_;
goto v___jp_3095_;
}
}
else
{
lean_object* v___x_3119_; 
v___x_3119_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__11, &l_BalancedSqrt_block1024___closed__11_once, _init_l_BalancedSqrt_block1024___closed__11);
if (lean_obj_tag(v___x_3119_) == 1)
{
lean_object* v_val_3120_; uint8_t v___x_3121_; 
v_val_3120_ = lean_ctor_get(v___x_3119_, 0);
v___x_3121_ = lean_unbox(v_val_3120_);
if (v___x_3121_ == 2)
{
lean_object* v___x_3122_; 
lean_inc(v___x_3112_);
v___x_3122_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2(v___x_3112_);
v___y_3096_ = v___x_3122_;
goto v___jp_3095_;
}
else
{
lean_inc(v___x_3112_);
v___y_3108_ = v___x_3112_;
goto v___jp_3107_;
}
}
else
{
lean_inc(v___x_3112_);
v___y_3108_ = v___x_3112_;
goto v___jp_3107_;
}
}
v___jp_3095_:
{
lean_object* v___x_3097_; lean_object* v___x_3098_; lean_object* v___x_3099_; lean_object* v___x_3100_; lean_object* v___x_3101_; lean_object* v___x_3102_; lean_object* v___x_3103_; lean_object* v___x_3104_; 
v___x_3097_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__0));
lean_inc(v_i_3088_);
v___x_3098_ = l_Nat_reprFast(v_i_3088_);
v___x_3099_ = lean_string_append(v___x_3097_, v___x_3098_);
lean_dec_ref(v___x_3098_);
v___x_3100_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1));
v___x_3101_ = lean_string_append(v___x_3099_, v___x_3100_);
v___x_3102_ = l_Nat_reprFast(v___y_3096_);
v___x_3103_ = lean_string_append(v___x_3101_, v___x_3102_);
lean_dec_ref(v___x_3102_);
v___x_3104_ = lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(v___x_3103_);
if (lean_obj_tag(v___x_3104_) == 0)
{
lean_object* v___x_3105_; 
lean_dec_ref_known(v___x_3104_, 1);
v___x_3105_ = lean_nat_add(v_i_3088_, v_step_3091_);
lean_dec(v_i_3088_);
v_b_3087_ = v___x_3094_;
v_i_3088_ = v___x_3105_;
goto _start;
}
else
{
lean_dec(v_i_3088_);
return v___x_3104_;
}
}
v___jp_3107_:
{
lean_object* v___x_3109_; 
v___x_3109_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2(v___y_3108_);
v___y_3096_ = v___x_3109_;
goto v___jp_3095_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___boxed(lean_object* v_range_3123_, lean_object* v_b_3124_, lean_object* v_i_3125_, lean_object* v___y_3126_){
_start:
{
lean_object* v_res_3127_; 
v_res_3127_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg(v_range_3123_, v_b_3124_, v_i_3125_);
lean_dec_ref(v_range_3123_);
return v_res_3127_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___redArg(lean_object* v_range_3128_, lean_object* v_b_3129_, lean_object* v_i_3130_){
_start:
{
lean_object* v_stop_3132_; lean_object* v_step_3133_; uint8_t v___x_3134_; 
v_stop_3132_ = lean_ctor_get(v_range_3128_, 1);
v_step_3133_ = lean_ctor_get(v_range_3128_, 2);
v___x_3134_ = lean_nat_dec_lt(v_i_3130_, v_stop_3132_);
if (v___x_3134_ == 0)
{
lean_object* v___x_3135_; 
lean_dec(v_i_3130_);
v___x_3135_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3135_, 0, v_b_3129_);
return v___x_3135_;
}
else
{
lean_object* v___x_3136_; lean_object* v___y_3138_; lean_object* v___y_3150_; lean_object* v___x_3152_; lean_object* v_xs_3153_; lean_object* v___x_3154_; uint8_t v___x_3155_; 
v___x_3136_ = lean_box(0);
v___x_3152_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__5, &l_BalancedSqrt_block1024___closed__5_once, _init_l_BalancedSqrt_block1024___closed__5);
v_xs_3153_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0;
v___x_3154_ = lean_array_get_borrowed(v___x_3152_, v_xs_3153_, v_i_3130_);
v___x_3155_ = lean_uint8_once(&l_BalancedSqrt_block1024___closed__6, &l_BalancedSqrt_block1024___closed__6_once, _init_l_BalancedSqrt_block1024___closed__6);
if (v___x_3155_ == 0)
{
uint8_t v___x_3156_; 
v___x_3156_ = lean_uint8_once(&l_BalancedSqrt_block1024___closed__7, &l_BalancedSqrt_block1024___closed__7_once, _init_l_BalancedSqrt_block1024___closed__7);
if (v___x_3156_ == 0)
{
lean_object* v___x_3157_; lean_object* v_run_3158_; lean_object* v___x_3159_; 
v___x_3157_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__10, &l_BalancedSqrt_block1024___closed__10_once, _init_l_BalancedSqrt_block1024___closed__10);
v_run_3158_ = lean_ctor_get(v___x_3157_, 1);
lean_inc(v_run_3158_);
lean_inc(v___x_3154_);
v___x_3159_ = lean_apply_1(v_run_3158_, v___x_3154_);
v___y_3138_ = v___x_3159_;
goto v___jp_3137_;
}
else
{
lean_object* v___x_3160_; 
lean_inc(v___x_3154_);
v___x_3160_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2(v___x_3154_);
v___y_3138_ = v___x_3160_;
goto v___jp_3137_;
}
}
else
{
lean_object* v___x_3161_; 
v___x_3161_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__11, &l_BalancedSqrt_block1024___closed__11_once, _init_l_BalancedSqrt_block1024___closed__11);
if (lean_obj_tag(v___x_3161_) == 1)
{
lean_object* v_val_3162_; uint8_t v___x_3163_; 
v_val_3162_ = lean_ctor_get(v___x_3161_, 0);
v___x_3163_ = lean_unbox(v_val_3162_);
if (v___x_3163_ == 2)
{
lean_object* v___x_3164_; 
lean_inc(v___x_3154_);
v___x_3164_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2(v___x_3154_);
v___y_3138_ = v___x_3164_;
goto v___jp_3137_;
}
else
{
lean_inc(v___x_3154_);
v___y_3150_ = v___x_3154_;
goto v___jp_3149_;
}
}
else
{
lean_inc(v___x_3154_);
v___y_3150_ = v___x_3154_;
goto v___jp_3149_;
}
}
v___jp_3137_:
{
lean_object* v___x_3139_; lean_object* v___x_3140_; lean_object* v___x_3141_; lean_object* v___x_3142_; lean_object* v___x_3143_; lean_object* v___x_3144_; lean_object* v___x_3145_; lean_object* v___x_3146_; 
v___x_3139_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__0));
lean_inc(v_i_3130_);
v___x_3140_ = l_Nat_reprFast(v_i_3130_);
v___x_3141_ = lean_string_append(v___x_3139_, v___x_3140_);
lean_dec_ref(v___x_3140_);
v___x_3142_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1));
v___x_3143_ = lean_string_append(v___x_3141_, v___x_3142_);
v___x_3144_ = l_Nat_reprFast(v___y_3138_);
v___x_3145_ = lean_string_append(v___x_3143_, v___x_3144_);
lean_dec_ref(v___x_3144_);
v___x_3146_ = lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(v___x_3145_);
if (lean_obj_tag(v___x_3146_) == 0)
{
lean_object* v___x_3147_; lean_object* v___x_3148_; 
lean_dec_ref_known(v___x_3146_, 1);
v___x_3147_ = lean_nat_add(v_i_3130_, v_step_3133_);
lean_dec(v_i_3130_);
v___x_3148_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg(v_range_3128_, v___x_3136_, v___x_3147_);
return v___x_3148_;
}
else
{
lean_dec(v_i_3130_);
return v___x_3146_;
}
}
v___jp_3149_:
{
lean_object* v___x_3151_; 
v___x_3151_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block1024_spec__2(v___y_3150_);
v___y_3138_ = v___x_3151_;
goto v___jp_3137_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___redArg___boxed(lean_object* v_range_3165_, lean_object* v_b_3166_, lean_object* v_i_3167_, lean_object* v___y_3168_){
_start:
{
lean_object* v_res_3169_; 
v_res_3169_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___redArg(v_range_3165_, v_b_3166_, v_i_3167_);
lean_dec_ref(v_range_3165_);
return v_res_3169_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run1024___lam__0(lean_object* v___x_3170_, lean_object* v___x_3171_, lean_object* v___x_3172_){
_start:
{
lean_object* v___x_3174_; 
v___x_3174_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___redArg(v___x_3170_, v___x_3171_, v___x_3172_);
if (lean_obj_tag(v___x_3174_) == 0)
{
lean_object* v___x_3176_; uint8_t v_isShared_3177_; uint8_t v_isSharedCheck_3181_; 
v_isSharedCheck_3181_ = !lean_is_exclusive(v___x_3174_);
if (v_isSharedCheck_3181_ == 0)
{
lean_object* v_unused_3182_; 
v_unused_3182_ = lean_ctor_get(v___x_3174_, 0);
lean_dec(v_unused_3182_);
v___x_3176_ = v___x_3174_;
v_isShared_3177_ = v_isSharedCheck_3181_;
goto v_resetjp_3175_;
}
else
{
lean_dec(v___x_3174_);
v___x_3176_ = lean_box(0);
v_isShared_3177_ = v_isSharedCheck_3181_;
goto v_resetjp_3175_;
}
v_resetjp_3175_:
{
lean_object* v___x_3179_; 
if (v_isShared_3177_ == 0)
{
lean_ctor_set(v___x_3176_, 0, v___x_3171_);
v___x_3179_ = v___x_3176_;
goto v_reusejp_3178_;
}
else
{
lean_object* v_reuseFailAlloc_3180_; 
v_reuseFailAlloc_3180_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3180_, 0, v___x_3171_);
v___x_3179_ = v_reuseFailAlloc_3180_;
goto v_reusejp_3178_;
}
v_reusejp_3178_:
{
return v___x_3179_;
}
}
}
else
{
return v___x_3174_;
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run1024___lam__0___boxed(lean_object* v___x_3183_, lean_object* v___x_3184_, lean_object* v___x_3185_, lean_object* v___y_3186_){
_start:
{
lean_object* v_res_3187_; 
v_res_3187_ = l_BalancedSqrt_run1024___lam__0(v___x_3183_, v___x_3184_, v___x_3185_);
lean_dec_ref(v___x_3183_);
return v_res_3187_;
}
}
static lean_object* _init_l_BalancedSqrt_run1024___closed__0(void){
_start:
{
lean_object* v_xs_3188_; lean_object* v___x_3189_; 
v_xs_3188_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0;
v___x_3189_ = lean_alloc_closure((void*)(l_BalancedSqrt_blocks1024___boxed), 3, 1);
lean_closure_set(v___x_3189_, 0, v_xs_3188_);
return v___x_3189_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run1024(lean_object* v_mode_3194_, lean_object* v_blocks_3195_){
_start:
{
lean_object* v___x_3197_; lean_object* v___x_3198_; lean_object* v___f_3199_; lean_object* v___x_3200_; 
v___x_3197_ = lean_unsigned_to_nat(1024u);
v___x_3198_ = lean_obj_once(&l_BalancedSqrt_run1024___closed__0, &l_BalancedSqrt_run1024___closed__0_once, _init_l_BalancedSqrt_run1024___closed__0);
v___f_3199_ = ((lean_object*)(l_BalancedSqrt_run1024___closed__1));
v___x_3200_ = l_BalancedSqrt_execute(v_mode_3194_, v___x_3197_, v_blocks_3195_, v___x_3198_, v___f_3199_);
return v___x_3200_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run1024___boxed(lean_object* v_mode_3201_, lean_object* v_blocks_3202_, lean_object* v_a_3203_){
_start:
{
lean_object* v_res_3204_; 
v_res_3204_ = l_BalancedSqrt_run1024(v_mode_3201_, v_blocks_3202_);
lean_dec_ref(v_mode_3201_);
return v_res_3204_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1(lean_object* v_range_3205_, lean_object* v_b_3206_, lean_object* v_i_3207_, lean_object* v_hs_3208_, lean_object* v_hl_3209_){
_start:
{
lean_object* v___x_3211_; 
v___x_3211_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___redArg(v_range_3205_, v_b_3206_, v_i_3207_);
return v___x_3211_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___boxed(lean_object* v_range_3212_, lean_object* v_b_3213_, lean_object* v_i_3214_, lean_object* v_hs_3215_, lean_object* v_hl_3216_, lean_object* v___y_3217_){
_start:
{
lean_object* v_res_3218_; 
v_res_3218_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1(v_range_3212_, v_b_3213_, v_i_3214_, v_hs_3215_, v_hl_3216_);
lean_dec_ref(v_range_3212_);
return v_res_3218_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2(lean_object* v_range_3219_, lean_object* v_b_3220_, lean_object* v_i_3221_, lean_object* v_hs_3222_, lean_object* v_hl_3223_){
_start:
{
lean_object* v___x_3225_; 
v___x_3225_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg(v_range_3219_, v_b_3220_, v_i_3221_);
return v___x_3225_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___boxed(lean_object* v_range_3226_, lean_object* v_b_3227_, lean_object* v_i_3228_, lean_object* v_hs_3229_, lean_object* v_hl_3230_, lean_object* v___y_3231_){
_start:
{
lean_object* v_res_3232_; 
v_res_3232_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2(v_range_3226_, v_b_3227_, v_i_3228_, v_hs_3229_, v_hl_3230_);
lean_dec_ref(v_range_3226_);
return v_res_3232_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0_spec__0(size_t v_sz_3233_, size_t v_i_3234_, lean_object* v_bs_3235_){
_start:
{
uint8_t v___x_3236_; 
v___x_3236_ = lean_usize_dec_lt(v_i_3234_, v_sz_3233_);
if (v___x_3236_ == 0)
{
return v_bs_3235_;
}
else
{
lean_object* v_v_3237_; lean_object* v_num_3238_; lean_object* v_den_3239_; lean_object* v___x_3240_; lean_object* v___x_3241_; lean_object* v_bs_x27_3242_; uint8_t v___x_3243_; lean_object* v___x_3244_; uint8_t v___x_3245_; lean_object* v___x_3246_; lean_object* v___x_3247_; size_t v___x_3248_; size_t v___x_3249_; lean_object* v___x_3250_; 
v_v_3237_ = lean_array_uget_borrowed(v_bs_3235_, v_i_3234_);
v_num_3238_ = lean_ctor_get(v_v_3237_, 0);
lean_inc(v_num_3238_);
v_den_3239_ = lean_ctor_get(v_v_3237_, 1);
lean_inc(v_den_3239_);
v___x_3240_ = ((lean_object*)(l_BalancedSqrt_block2048___closed__0));
v___x_3241_ = lean_unsigned_to_nat(0u);
v_bs_x27_3242_ = lean_array_uset(v_bs_3235_, v_i_3234_, v___x_3241_);
v___x_3243_ = 0;
v___x_3244_ = lean_obj_once(&l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0___closed__0, &l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0___closed__0_once, _init_l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0___closed__0);
v___x_3245_ = lean_int_dec_lt(v_num_3238_, v___x_3244_);
v___x_3246_ = lean_nat_abs(v_num_3238_);
lean_dec(v_num_3238_);
v___x_3247_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Model_Internal_Directed_roundRat(v___x_3240_, v___x_3243_, v___x_3245_, v___x_3246_, v_den_3239_);
v___x_3248_ = ((size_t)1ULL);
v___x_3249_ = lean_usize_add(v_i_3234_, v___x_3248_);
v___x_3250_ = lean_array_uset(v_bs_x27_3242_, v_i_3234_, v___x_3247_);
v_i_3234_ = v___x_3249_;
v_bs_3235_ = v___x_3250_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0_spec__0___boxed(lean_object* v_sz_3252_, lean_object* v_i_3253_, lean_object* v_bs_3254_){
_start:
{
size_t v_sz_boxed_3255_; size_t v_i_boxed_3256_; lean_object* v_res_3257_; 
v_sz_boxed_3255_ = lean_unbox_usize(v_sz_3252_);
lean_dec(v_sz_3252_);
v_i_boxed_3256_ = lean_unbox_usize(v_i_3253_);
lean_dec(v_i_3253_);
v_res_3257_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0_spec__0(v_sz_boxed_3255_, v_i_boxed_3256_, v_bs_3254_);
return v_res_3257_;
}
}
static lean_object* _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0___closed__0(void){
_start:
{
lean_object* v___x_3258_; size_t v___x_3259_; size_t v_sz_3260_; lean_object* v___x_3261_; 
v___x_3258_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Support_ExactWorkload_sqrtXs;
v___x_3259_ = ((size_t)0ULL);
v_sz_3260_ = lean_usize_once(&l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0, &l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0_once, _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0);
v___x_3261_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0_spec__0(v_sz_3260_, v___x_3259_, v___x_3258_);
return v___x_3261_;
}
}
static lean_object* _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0(void){
_start:
{
lean_object* v___x_3262_; 
v___x_3262_ = lean_obj_once(&l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0___closed__0, &l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0___closed__0_once, _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0___closed__0);
return v___x_3262_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg(lean_object* v_range_3264_, lean_object* v_b_3265_, lean_object* v_i_3266_){
_start:
{
lean_object* v_stop_3268_; lean_object* v_step_3269_; uint8_t v___x_3270_; 
v_stop_3268_ = lean_ctor_get(v_range_3264_, 1);
v_step_3269_ = lean_ctor_get(v_range_3264_, 2);
v___x_3270_ = lean_nat_dec_lt(v_i_3266_, v_stop_3268_);
if (v___x_3270_ == 0)
{
lean_object* v___x_3271_; 
lean_dec(v_i_3266_);
v___x_3271_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3271_, 0, v_b_3265_);
return v___x_3271_;
}
else
{
lean_object* v___x_3272_; lean_object* v___y_3274_; lean_object* v___y_3286_; lean_object* v___x_3288_; lean_object* v_xs_3289_; lean_object* v___x_3290_; uint8_t v___x_3291_; 
v___x_3272_ = lean_box(0);
v___x_3288_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__5, &l_BalancedSqrt_block2048___closed__5_once, _init_l_BalancedSqrt_block2048___closed__5);
v_xs_3289_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0;
v___x_3290_ = lean_array_get_borrowed(v___x_3288_, v_xs_3289_, v_i_3266_);
v___x_3291_ = lean_uint8_once(&l_BalancedSqrt_block2048___closed__6, &l_BalancedSqrt_block2048___closed__6_once, _init_l_BalancedSqrt_block2048___closed__6);
if (v___x_3291_ == 0)
{
uint8_t v___x_3292_; 
v___x_3292_ = lean_uint8_once(&l_BalancedSqrt_block2048___closed__7, &l_BalancedSqrt_block2048___closed__7_once, _init_l_BalancedSqrt_block2048___closed__7);
if (v___x_3292_ == 0)
{
lean_object* v___x_3293_; lean_object* v_run_3294_; lean_object* v___x_3295_; 
v___x_3293_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__10, &l_BalancedSqrt_block2048___closed__10_once, _init_l_BalancedSqrt_block2048___closed__10);
v_run_3294_ = lean_ctor_get(v___x_3293_, 1);
lean_inc(v_run_3294_);
lean_inc(v___x_3290_);
v___x_3295_ = lean_apply_1(v_run_3294_, v___x_3290_);
v___y_3274_ = v___x_3295_;
goto v___jp_3273_;
}
else
{
lean_object* v___x_3296_; 
lean_inc(v___x_3290_);
v___x_3296_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1(v___x_3290_);
v___y_3274_ = v___x_3296_;
goto v___jp_3273_;
}
}
else
{
lean_object* v___x_3297_; 
v___x_3297_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__11, &l_BalancedSqrt_block2048___closed__11_once, _init_l_BalancedSqrt_block2048___closed__11);
if (lean_obj_tag(v___x_3297_) == 1)
{
lean_object* v_val_3298_; uint8_t v___x_3299_; 
v_val_3298_ = lean_ctor_get(v___x_3297_, 0);
v___x_3299_ = lean_unbox(v_val_3298_);
if (v___x_3299_ == 2)
{
lean_object* v___x_3300_; 
lean_inc(v___x_3290_);
v___x_3300_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1(v___x_3290_);
v___y_3274_ = v___x_3300_;
goto v___jp_3273_;
}
else
{
lean_inc(v___x_3290_);
v___y_3286_ = v___x_3290_;
goto v___jp_3285_;
}
}
else
{
lean_inc(v___x_3290_);
v___y_3286_ = v___x_3290_;
goto v___jp_3285_;
}
}
v___jp_3273_:
{
lean_object* v___x_3275_; lean_object* v___x_3276_; lean_object* v___x_3277_; lean_object* v___x_3278_; lean_object* v___x_3279_; lean_object* v___x_3280_; lean_object* v___x_3281_; lean_object* v___x_3282_; 
v___x_3275_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg___closed__0));
lean_inc(v_i_3266_);
v___x_3276_ = l_Nat_reprFast(v_i_3266_);
v___x_3277_ = lean_string_append(v___x_3275_, v___x_3276_);
lean_dec_ref(v___x_3276_);
v___x_3278_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1));
v___x_3279_ = lean_string_append(v___x_3277_, v___x_3278_);
v___x_3280_ = l_Nat_reprFast(v___y_3274_);
v___x_3281_ = lean_string_append(v___x_3279_, v___x_3280_);
lean_dec_ref(v___x_3280_);
v___x_3282_ = lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(v___x_3281_);
if (lean_obj_tag(v___x_3282_) == 0)
{
lean_object* v___x_3283_; 
lean_dec_ref_known(v___x_3282_, 1);
v___x_3283_ = lean_nat_add(v_i_3266_, v_step_3269_);
lean_dec(v_i_3266_);
v_b_3265_ = v___x_3272_;
v_i_3266_ = v___x_3283_;
goto _start;
}
else
{
lean_dec(v_i_3266_);
return v___x_3282_;
}
}
v___jp_3285_:
{
lean_object* v___x_3287_; 
v___x_3287_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1(v___y_3286_);
v___y_3274_ = v___x_3287_;
goto v___jp_3273_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg___boxed(lean_object* v_range_3301_, lean_object* v_b_3302_, lean_object* v_i_3303_, lean_object* v___y_3304_){
_start:
{
lean_object* v_res_3305_; 
v_res_3305_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg(v_range_3301_, v_b_3302_, v_i_3303_);
lean_dec_ref(v_range_3301_);
return v_res_3305_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___redArg(lean_object* v_range_3306_, lean_object* v_b_3307_, lean_object* v_i_3308_){
_start:
{
lean_object* v_stop_3310_; lean_object* v_step_3311_; uint8_t v___x_3312_; 
v_stop_3310_ = lean_ctor_get(v_range_3306_, 1);
v_step_3311_ = lean_ctor_get(v_range_3306_, 2);
v___x_3312_ = lean_nat_dec_lt(v_i_3308_, v_stop_3310_);
if (v___x_3312_ == 0)
{
lean_object* v___x_3313_; 
lean_dec(v_i_3308_);
v___x_3313_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3313_, 0, v_b_3307_);
return v___x_3313_;
}
else
{
lean_object* v___x_3314_; lean_object* v___y_3316_; lean_object* v___y_3328_; lean_object* v___x_3330_; lean_object* v_xs_3331_; lean_object* v___x_3332_; uint8_t v___x_3333_; 
v___x_3314_ = lean_box(0);
v___x_3330_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__5, &l_BalancedSqrt_block2048___closed__5_once, _init_l_BalancedSqrt_block2048___closed__5);
v_xs_3331_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0;
v___x_3332_ = lean_array_get_borrowed(v___x_3330_, v_xs_3331_, v_i_3308_);
v___x_3333_ = lean_uint8_once(&l_BalancedSqrt_block2048___closed__6, &l_BalancedSqrt_block2048___closed__6_once, _init_l_BalancedSqrt_block2048___closed__6);
if (v___x_3333_ == 0)
{
uint8_t v___x_3334_; 
v___x_3334_ = lean_uint8_once(&l_BalancedSqrt_block2048___closed__7, &l_BalancedSqrt_block2048___closed__7_once, _init_l_BalancedSqrt_block2048___closed__7);
if (v___x_3334_ == 0)
{
lean_object* v___x_3335_; lean_object* v_run_3336_; lean_object* v___x_3337_; 
v___x_3335_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__10, &l_BalancedSqrt_block2048___closed__10_once, _init_l_BalancedSqrt_block2048___closed__10);
v_run_3336_ = lean_ctor_get(v___x_3335_, 1);
lean_inc(v_run_3336_);
lean_inc(v___x_3332_);
v___x_3337_ = lean_apply_1(v_run_3336_, v___x_3332_);
v___y_3316_ = v___x_3337_;
goto v___jp_3315_;
}
else
{
lean_object* v___x_3338_; 
lean_inc(v___x_3332_);
v___x_3338_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1(v___x_3332_);
v___y_3316_ = v___x_3338_;
goto v___jp_3315_;
}
}
else
{
lean_object* v___x_3339_; 
v___x_3339_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__11, &l_BalancedSqrt_block2048___closed__11_once, _init_l_BalancedSqrt_block2048___closed__11);
if (lean_obj_tag(v___x_3339_) == 1)
{
lean_object* v_val_3340_; uint8_t v___x_3341_; 
v_val_3340_ = lean_ctor_get(v___x_3339_, 0);
v___x_3341_ = lean_unbox(v_val_3340_);
if (v___x_3341_ == 2)
{
lean_object* v___x_3342_; 
lean_inc(v___x_3332_);
v___x_3342_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1(v___x_3332_);
v___y_3316_ = v___x_3342_;
goto v___jp_3315_;
}
else
{
lean_inc(v___x_3332_);
v___y_3328_ = v___x_3332_;
goto v___jp_3327_;
}
}
else
{
lean_inc(v___x_3332_);
v___y_3328_ = v___x_3332_;
goto v___jp_3327_;
}
}
v___jp_3315_:
{
lean_object* v___x_3317_; lean_object* v___x_3318_; lean_object* v___x_3319_; lean_object* v___x_3320_; lean_object* v___x_3321_; lean_object* v___x_3322_; lean_object* v___x_3323_; lean_object* v___x_3324_; 
v___x_3317_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg___closed__0));
lean_inc(v_i_3308_);
v___x_3318_ = l_Nat_reprFast(v_i_3308_);
v___x_3319_ = lean_string_append(v___x_3317_, v___x_3318_);
lean_dec_ref(v___x_3318_);
v___x_3320_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1));
v___x_3321_ = lean_string_append(v___x_3319_, v___x_3320_);
v___x_3322_ = l_Nat_reprFast(v___y_3316_);
v___x_3323_ = lean_string_append(v___x_3321_, v___x_3322_);
lean_dec_ref(v___x_3322_);
v___x_3324_ = lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(v___x_3323_);
if (lean_obj_tag(v___x_3324_) == 0)
{
lean_object* v___x_3325_; lean_object* v___x_3326_; 
lean_dec_ref_known(v___x_3324_, 1);
v___x_3325_ = lean_nat_add(v_i_3308_, v_step_3311_);
lean_dec(v_i_3308_);
v___x_3326_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg(v_range_3306_, v___x_3314_, v___x_3325_);
return v___x_3326_;
}
else
{
lean_dec(v_i_3308_);
return v___x_3324_;
}
}
v___jp_3327_:
{
lean_object* v___x_3329_; 
v___x_3329_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block2048_spec__1(v___y_3328_);
v___y_3316_ = v___x_3329_;
goto v___jp_3315_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___redArg___boxed(lean_object* v_range_3343_, lean_object* v_b_3344_, lean_object* v_i_3345_, lean_object* v___y_3346_){
_start:
{
lean_object* v_res_3347_; 
v_res_3347_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___redArg(v_range_3343_, v_b_3344_, v_i_3345_);
lean_dec_ref(v_range_3343_);
return v_res_3347_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run2048___lam__0(lean_object* v___x_3348_, lean_object* v___x_3349_, lean_object* v___x_3350_){
_start:
{
lean_object* v___x_3352_; 
v___x_3352_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___redArg(v___x_3348_, v___x_3349_, v___x_3350_);
if (lean_obj_tag(v___x_3352_) == 0)
{
lean_object* v___x_3354_; uint8_t v_isShared_3355_; uint8_t v_isSharedCheck_3359_; 
v_isSharedCheck_3359_ = !lean_is_exclusive(v___x_3352_);
if (v_isSharedCheck_3359_ == 0)
{
lean_object* v_unused_3360_; 
v_unused_3360_ = lean_ctor_get(v___x_3352_, 0);
lean_dec(v_unused_3360_);
v___x_3354_ = v___x_3352_;
v_isShared_3355_ = v_isSharedCheck_3359_;
goto v_resetjp_3353_;
}
else
{
lean_dec(v___x_3352_);
v___x_3354_ = lean_box(0);
v_isShared_3355_ = v_isSharedCheck_3359_;
goto v_resetjp_3353_;
}
v_resetjp_3353_:
{
lean_object* v___x_3357_; 
if (v_isShared_3355_ == 0)
{
lean_ctor_set(v___x_3354_, 0, v___x_3349_);
v___x_3357_ = v___x_3354_;
goto v_reusejp_3356_;
}
else
{
lean_object* v_reuseFailAlloc_3358_; 
v_reuseFailAlloc_3358_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3358_, 0, v___x_3349_);
v___x_3357_ = v_reuseFailAlloc_3358_;
goto v_reusejp_3356_;
}
v_reusejp_3356_:
{
return v___x_3357_;
}
}
}
else
{
return v___x_3352_;
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run2048___lam__0___boxed(lean_object* v___x_3361_, lean_object* v___x_3362_, lean_object* v___x_3363_, lean_object* v___y_3364_){
_start:
{
lean_object* v_res_3365_; 
v_res_3365_ = l_BalancedSqrt_run2048___lam__0(v___x_3361_, v___x_3362_, v___x_3363_);
lean_dec_ref(v___x_3361_);
return v_res_3365_;
}
}
static lean_object* _init_l_BalancedSqrt_run2048___closed__0(void){
_start:
{
lean_object* v_xs_3366_; lean_object* v___x_3367_; 
v_xs_3366_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0;
v___x_3367_ = lean_alloc_closure((void*)(l_BalancedSqrt_blocks2048___boxed), 3, 1);
lean_closure_set(v___x_3367_, 0, v_xs_3366_);
return v___x_3367_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run2048(lean_object* v_mode_3372_, lean_object* v_blocks_3373_){
_start:
{
lean_object* v___x_3375_; lean_object* v___x_3376_; lean_object* v___f_3377_; lean_object* v___x_3378_; 
v___x_3375_ = lean_unsigned_to_nat(2048u);
v___x_3376_ = lean_obj_once(&l_BalancedSqrt_run2048___closed__0, &l_BalancedSqrt_run2048___closed__0_once, _init_l_BalancedSqrt_run2048___closed__0);
v___f_3377_ = ((lean_object*)(l_BalancedSqrt_run2048___closed__1));
v___x_3378_ = l_BalancedSqrt_execute(v_mode_3372_, v___x_3375_, v_blocks_3373_, v___x_3376_, v___f_3377_);
return v___x_3378_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run2048___boxed(lean_object* v_mode_3379_, lean_object* v_blocks_3380_, lean_object* v_a_3381_){
_start:
{
lean_object* v_res_3382_; 
v_res_3382_ = l_BalancedSqrt_run2048(v_mode_3379_, v_blocks_3380_);
lean_dec_ref(v_mode_3379_);
return v_res_3382_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1(lean_object* v_range_3383_, lean_object* v_b_3384_, lean_object* v_i_3385_, lean_object* v_hs_3386_, lean_object* v_hl_3387_){
_start:
{
lean_object* v___x_3389_; 
v___x_3389_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___redArg(v_range_3383_, v_b_3384_, v_i_3385_);
return v___x_3389_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___boxed(lean_object* v_range_3390_, lean_object* v_b_3391_, lean_object* v_i_3392_, lean_object* v_hs_3393_, lean_object* v_hl_3394_, lean_object* v___y_3395_){
_start:
{
lean_object* v_res_3396_; 
v_res_3396_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1(v_range_3390_, v_b_3391_, v_i_3392_, v_hs_3393_, v_hl_3394_);
lean_dec_ref(v_range_3390_);
return v_res_3396_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2(lean_object* v_range_3397_, lean_object* v_b_3398_, lean_object* v_i_3399_, lean_object* v_hs_3400_, lean_object* v_hl_3401_){
_start:
{
lean_object* v___x_3403_; 
v___x_3403_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg(v_range_3397_, v_b_3398_, v_i_3399_);
return v___x_3403_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___boxed(lean_object* v_range_3404_, lean_object* v_b_3405_, lean_object* v_i_3406_, lean_object* v_hs_3407_, lean_object* v_hl_3408_, lean_object* v___y_3409_){
_start:
{
lean_object* v_res_3410_; 
v_res_3410_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2(v_range_3404_, v_b_3405_, v_i_3406_, v_hs_3407_, v_hl_3408_);
lean_dec_ref(v_range_3404_);
return v_res_3410_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0_spec__0(size_t v_sz_3411_, size_t v_i_3412_, lean_object* v_bs_3413_){
_start:
{
uint8_t v___x_3414_; 
v___x_3414_ = lean_usize_dec_lt(v_i_3412_, v_sz_3411_);
if (v___x_3414_ == 0)
{
return v_bs_3413_;
}
else
{
lean_object* v_v_3415_; lean_object* v_num_3416_; lean_object* v_den_3417_; lean_object* v___x_3418_; lean_object* v___x_3419_; lean_object* v_bs_x27_3420_; uint8_t v___x_3421_; lean_object* v___x_3422_; uint8_t v___x_3423_; lean_object* v___x_3424_; lean_object* v___x_3425_; size_t v___x_3426_; size_t v___x_3427_; lean_object* v___x_3428_; 
v_v_3415_ = lean_array_uget_borrowed(v_bs_3413_, v_i_3412_);
v_num_3416_ = lean_ctor_get(v_v_3415_, 0);
lean_inc(v_num_3416_);
v_den_3417_ = lean_ctor_get(v_v_3415_, 1);
lean_inc(v_den_3417_);
v___x_3418_ = ((lean_object*)(l_BalancedSqrt_block4096___closed__0));
v___x_3419_ = lean_unsigned_to_nat(0u);
v_bs_x27_3420_ = lean_array_uset(v_bs_3413_, v_i_3412_, v___x_3419_);
v___x_3421_ = 0;
v___x_3422_ = lean_obj_once(&l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0___closed__0, &l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0___closed__0_once, _init_l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0___closed__0);
v___x_3423_ = lean_int_dec_lt(v_num_3416_, v___x_3422_);
v___x_3424_ = lean_nat_abs(v_num_3416_);
lean_dec(v_num_3416_);
v___x_3425_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Model_Internal_Directed_roundRat(v___x_3418_, v___x_3421_, v___x_3423_, v___x_3424_, v_den_3417_);
v___x_3426_ = ((size_t)1ULL);
v___x_3427_ = lean_usize_add(v_i_3412_, v___x_3426_);
v___x_3428_ = lean_array_uset(v_bs_x27_3420_, v_i_3412_, v___x_3425_);
v_i_3412_ = v___x_3427_;
v_bs_3413_ = v___x_3428_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0_spec__0___boxed(lean_object* v_sz_3430_, lean_object* v_i_3431_, lean_object* v_bs_3432_){
_start:
{
size_t v_sz_boxed_3433_; size_t v_i_boxed_3434_; lean_object* v_res_3435_; 
v_sz_boxed_3433_ = lean_unbox_usize(v_sz_3430_);
lean_dec(v_sz_3430_);
v_i_boxed_3434_ = lean_unbox_usize(v_i_3431_);
lean_dec(v_i_3431_);
v_res_3435_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0_spec__0(v_sz_boxed_3433_, v_i_boxed_3434_, v_bs_3432_);
return v_res_3435_;
}
}
static lean_object* _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0___closed__0(void){
_start:
{
lean_object* v___x_3436_; size_t v___x_3437_; size_t v_sz_3438_; lean_object* v___x_3439_; 
v___x_3436_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Support_ExactWorkload_sqrtXs;
v___x_3437_ = ((size_t)0ULL);
v_sz_3438_ = lean_usize_once(&l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0, &l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0_once, _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0);
v___x_3439_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0_spec__0(v_sz_3438_, v___x_3437_, v___x_3436_);
return v___x_3439_;
}
}
static lean_object* _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0(void){
_start:
{
lean_object* v___x_3440_; 
v___x_3440_ = lean_obj_once(&l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0___closed__0, &l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0___closed__0_once, _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0___closed__0);
return v___x_3440_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg(lean_object* v_range_3442_, lean_object* v_b_3443_, lean_object* v_i_3444_){
_start:
{
lean_object* v_stop_3446_; lean_object* v_step_3447_; uint8_t v___x_3448_; 
v_stop_3446_ = lean_ctor_get(v_range_3442_, 1);
v_step_3447_ = lean_ctor_get(v_range_3442_, 2);
v___x_3448_ = lean_nat_dec_lt(v_i_3444_, v_stop_3446_);
if (v___x_3448_ == 0)
{
lean_object* v___x_3449_; 
lean_dec(v_i_3444_);
v___x_3449_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3449_, 0, v_b_3443_);
return v___x_3449_;
}
else
{
lean_object* v___x_3450_; lean_object* v___y_3452_; lean_object* v___y_3464_; lean_object* v___x_3466_; lean_object* v_xs_3467_; lean_object* v___x_3468_; uint8_t v___x_3469_; 
v___x_3450_ = lean_box(0);
v___x_3466_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__5, &l_BalancedSqrt_block4096___closed__5_once, _init_l_BalancedSqrt_block4096___closed__5);
v_xs_3467_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0;
v___x_3468_ = lean_array_get_borrowed(v___x_3466_, v_xs_3467_, v_i_3444_);
v___x_3469_ = lean_uint8_once(&l_BalancedSqrt_block4096___closed__6, &l_BalancedSqrt_block4096___closed__6_once, _init_l_BalancedSqrt_block4096___closed__6);
if (v___x_3469_ == 0)
{
uint8_t v___x_3470_; 
v___x_3470_ = lean_uint8_once(&l_BalancedSqrt_block4096___closed__7, &l_BalancedSqrt_block4096___closed__7_once, _init_l_BalancedSqrt_block4096___closed__7);
if (v___x_3470_ == 0)
{
lean_object* v___x_3471_; lean_object* v_run_3472_; lean_object* v___x_3473_; 
v___x_3471_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__10, &l_BalancedSqrt_block4096___closed__10_once, _init_l_BalancedSqrt_block4096___closed__10);
v_run_3472_ = lean_ctor_get(v___x_3471_, 1);
lean_inc(v_run_3472_);
lean_inc(v___x_3468_);
v___x_3473_ = lean_apply_1(v_run_3472_, v___x_3468_);
v___y_3452_ = v___x_3473_;
goto v___jp_3451_;
}
else
{
lean_object* v___x_3474_; 
lean_inc(v___x_3468_);
v___x_3474_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1(v___x_3468_);
v___y_3452_ = v___x_3474_;
goto v___jp_3451_;
}
}
else
{
lean_object* v___x_3475_; 
v___x_3475_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__11, &l_BalancedSqrt_block4096___closed__11_once, _init_l_BalancedSqrt_block4096___closed__11);
if (lean_obj_tag(v___x_3475_) == 1)
{
lean_object* v_val_3476_; uint8_t v___x_3477_; 
v_val_3476_ = lean_ctor_get(v___x_3475_, 0);
v___x_3477_ = lean_unbox(v_val_3476_);
if (v___x_3477_ == 2)
{
lean_object* v___x_3478_; 
lean_inc(v___x_3468_);
v___x_3478_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1(v___x_3468_);
v___y_3452_ = v___x_3478_;
goto v___jp_3451_;
}
else
{
lean_inc(v___x_3468_);
v___y_3464_ = v___x_3468_;
goto v___jp_3463_;
}
}
else
{
lean_inc(v___x_3468_);
v___y_3464_ = v___x_3468_;
goto v___jp_3463_;
}
}
v___jp_3451_:
{
lean_object* v___x_3453_; lean_object* v___x_3454_; lean_object* v___x_3455_; lean_object* v___x_3456_; lean_object* v___x_3457_; lean_object* v___x_3458_; lean_object* v___x_3459_; lean_object* v___x_3460_; 
v___x_3453_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg___closed__0));
lean_inc(v_i_3444_);
v___x_3454_ = l_Nat_reprFast(v_i_3444_);
v___x_3455_ = lean_string_append(v___x_3453_, v___x_3454_);
lean_dec_ref(v___x_3454_);
v___x_3456_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1));
v___x_3457_ = lean_string_append(v___x_3455_, v___x_3456_);
v___x_3458_ = l_Nat_reprFast(v___y_3452_);
v___x_3459_ = lean_string_append(v___x_3457_, v___x_3458_);
lean_dec_ref(v___x_3458_);
v___x_3460_ = lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(v___x_3459_);
if (lean_obj_tag(v___x_3460_) == 0)
{
lean_object* v___x_3461_; 
lean_dec_ref_known(v___x_3460_, 1);
v___x_3461_ = lean_nat_add(v_i_3444_, v_step_3447_);
lean_dec(v_i_3444_);
v_b_3443_ = v___x_3450_;
v_i_3444_ = v___x_3461_;
goto _start;
}
else
{
lean_dec(v_i_3444_);
return v___x_3460_;
}
}
v___jp_3463_:
{
lean_object* v___x_3465_; 
v___x_3465_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1(v___y_3464_);
v___y_3452_ = v___x_3465_;
goto v___jp_3451_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg___boxed(lean_object* v_range_3479_, lean_object* v_b_3480_, lean_object* v_i_3481_, lean_object* v___y_3482_){
_start:
{
lean_object* v_res_3483_; 
v_res_3483_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg(v_range_3479_, v_b_3480_, v_i_3481_);
lean_dec_ref(v_range_3479_);
return v_res_3483_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___redArg(lean_object* v_range_3484_, lean_object* v_b_3485_, lean_object* v_i_3486_){
_start:
{
lean_object* v_stop_3488_; lean_object* v_step_3489_; uint8_t v___x_3490_; 
v_stop_3488_ = lean_ctor_get(v_range_3484_, 1);
v_step_3489_ = lean_ctor_get(v_range_3484_, 2);
v___x_3490_ = lean_nat_dec_lt(v_i_3486_, v_stop_3488_);
if (v___x_3490_ == 0)
{
lean_object* v___x_3491_; 
lean_dec(v_i_3486_);
v___x_3491_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3491_, 0, v_b_3485_);
return v___x_3491_;
}
else
{
lean_object* v___x_3492_; lean_object* v___y_3494_; lean_object* v___y_3506_; lean_object* v___x_3508_; lean_object* v_xs_3509_; lean_object* v___x_3510_; uint8_t v___x_3511_; 
v___x_3492_ = lean_box(0);
v___x_3508_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__5, &l_BalancedSqrt_block4096___closed__5_once, _init_l_BalancedSqrt_block4096___closed__5);
v_xs_3509_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0;
v___x_3510_ = lean_array_get_borrowed(v___x_3508_, v_xs_3509_, v_i_3486_);
v___x_3511_ = lean_uint8_once(&l_BalancedSqrt_block4096___closed__6, &l_BalancedSqrt_block4096___closed__6_once, _init_l_BalancedSqrt_block4096___closed__6);
if (v___x_3511_ == 0)
{
uint8_t v___x_3512_; 
v___x_3512_ = lean_uint8_once(&l_BalancedSqrt_block4096___closed__7, &l_BalancedSqrt_block4096___closed__7_once, _init_l_BalancedSqrt_block4096___closed__7);
if (v___x_3512_ == 0)
{
lean_object* v___x_3513_; lean_object* v_run_3514_; lean_object* v___x_3515_; 
v___x_3513_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__10, &l_BalancedSqrt_block4096___closed__10_once, _init_l_BalancedSqrt_block4096___closed__10);
v_run_3514_ = lean_ctor_get(v___x_3513_, 1);
lean_inc(v_run_3514_);
lean_inc(v___x_3510_);
v___x_3515_ = lean_apply_1(v_run_3514_, v___x_3510_);
v___y_3494_ = v___x_3515_;
goto v___jp_3493_;
}
else
{
lean_object* v___x_3516_; 
lean_inc(v___x_3510_);
v___x_3516_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1(v___x_3510_);
v___y_3494_ = v___x_3516_;
goto v___jp_3493_;
}
}
else
{
lean_object* v___x_3517_; 
v___x_3517_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__11, &l_BalancedSqrt_block4096___closed__11_once, _init_l_BalancedSqrt_block4096___closed__11);
if (lean_obj_tag(v___x_3517_) == 1)
{
lean_object* v_val_3518_; uint8_t v___x_3519_; 
v_val_3518_ = lean_ctor_get(v___x_3517_, 0);
v___x_3519_ = lean_unbox(v_val_3518_);
if (v___x_3519_ == 2)
{
lean_object* v___x_3520_; 
lean_inc(v___x_3510_);
v___x_3520_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1(v___x_3510_);
v___y_3494_ = v___x_3520_;
goto v___jp_3493_;
}
else
{
lean_inc(v___x_3510_);
v___y_3506_ = v___x_3510_;
goto v___jp_3505_;
}
}
else
{
lean_inc(v___x_3510_);
v___y_3506_ = v___x_3510_;
goto v___jp_3505_;
}
}
v___jp_3493_:
{
lean_object* v___x_3495_; lean_object* v___x_3496_; lean_object* v___x_3497_; lean_object* v___x_3498_; lean_object* v___x_3499_; lean_object* v___x_3500_; lean_object* v___x_3501_; lean_object* v___x_3502_; 
v___x_3495_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg___closed__0));
lean_inc(v_i_3486_);
v___x_3496_ = l_Nat_reprFast(v_i_3486_);
v___x_3497_ = lean_string_append(v___x_3495_, v___x_3496_);
lean_dec_ref(v___x_3496_);
v___x_3498_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1));
v___x_3499_ = lean_string_append(v___x_3497_, v___x_3498_);
v___x_3500_ = l_Nat_reprFast(v___y_3494_);
v___x_3501_ = lean_string_append(v___x_3499_, v___x_3500_);
lean_dec_ref(v___x_3500_);
v___x_3502_ = lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(v___x_3501_);
if (lean_obj_tag(v___x_3502_) == 0)
{
lean_object* v___x_3503_; lean_object* v___x_3504_; 
lean_dec_ref_known(v___x_3502_, 1);
v___x_3503_ = lean_nat_add(v_i_3486_, v_step_3489_);
lean_dec(v_i_3486_);
v___x_3504_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg(v_range_3484_, v___x_3492_, v___x_3503_);
return v___x_3504_;
}
else
{
lean_dec(v_i_3486_);
return v___x_3502_;
}
}
v___jp_3505_:
{
lean_object* v___x_3507_; 
v___x_3507_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic___at___00BalancedSqrt_block4096_spec__1(v___y_3506_);
v___y_3494_ = v___x_3507_;
goto v___jp_3493_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___redArg___boxed(lean_object* v_range_3521_, lean_object* v_b_3522_, lean_object* v_i_3523_, lean_object* v___y_3524_){
_start:
{
lean_object* v_res_3525_; 
v_res_3525_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___redArg(v_range_3521_, v_b_3522_, v_i_3523_);
lean_dec_ref(v_range_3521_);
return v_res_3525_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run4096___lam__0(lean_object* v___x_3526_, lean_object* v___x_3527_, lean_object* v___x_3528_){
_start:
{
lean_object* v___x_3530_; 
v___x_3530_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___redArg(v___x_3526_, v___x_3527_, v___x_3528_);
if (lean_obj_tag(v___x_3530_) == 0)
{
lean_object* v___x_3532_; uint8_t v_isShared_3533_; uint8_t v_isSharedCheck_3537_; 
v_isSharedCheck_3537_ = !lean_is_exclusive(v___x_3530_);
if (v_isSharedCheck_3537_ == 0)
{
lean_object* v_unused_3538_; 
v_unused_3538_ = lean_ctor_get(v___x_3530_, 0);
lean_dec(v_unused_3538_);
v___x_3532_ = v___x_3530_;
v_isShared_3533_ = v_isSharedCheck_3537_;
goto v_resetjp_3531_;
}
else
{
lean_dec(v___x_3530_);
v___x_3532_ = lean_box(0);
v_isShared_3533_ = v_isSharedCheck_3537_;
goto v_resetjp_3531_;
}
v_resetjp_3531_:
{
lean_object* v___x_3535_; 
if (v_isShared_3533_ == 0)
{
lean_ctor_set(v___x_3532_, 0, v___x_3527_);
v___x_3535_ = v___x_3532_;
goto v_reusejp_3534_;
}
else
{
lean_object* v_reuseFailAlloc_3536_; 
v_reuseFailAlloc_3536_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3536_, 0, v___x_3527_);
v___x_3535_ = v_reuseFailAlloc_3536_;
goto v_reusejp_3534_;
}
v_reusejp_3534_:
{
return v___x_3535_;
}
}
}
else
{
return v___x_3530_;
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run4096___lam__0___boxed(lean_object* v___x_3539_, lean_object* v___x_3540_, lean_object* v___x_3541_, lean_object* v___y_3542_){
_start:
{
lean_object* v_res_3543_; 
v_res_3543_ = l_BalancedSqrt_run4096___lam__0(v___x_3539_, v___x_3540_, v___x_3541_);
lean_dec_ref(v___x_3539_);
return v_res_3543_;
}
}
static lean_object* _init_l_BalancedSqrt_run4096___closed__0(void){
_start:
{
lean_object* v_xs_3544_; lean_object* v___x_3545_; 
v_xs_3544_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0;
v___x_3545_ = lean_alloc_closure((void*)(l_BalancedSqrt_blocks4096___boxed), 3, 1);
lean_closure_set(v___x_3545_, 0, v_xs_3544_);
return v___x_3545_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run4096(lean_object* v_mode_3550_, lean_object* v_blocks_3551_){
_start:
{
lean_object* v___x_3553_; lean_object* v___x_3554_; lean_object* v___f_3555_; lean_object* v___x_3556_; 
v___x_3553_ = lean_unsigned_to_nat(4096u);
v___x_3554_ = lean_obj_once(&l_BalancedSqrt_run4096___closed__0, &l_BalancedSqrt_run4096___closed__0_once, _init_l_BalancedSqrt_run4096___closed__0);
v___f_3555_ = ((lean_object*)(l_BalancedSqrt_run4096___closed__1));
v___x_3556_ = l_BalancedSqrt_execute(v_mode_3550_, v___x_3553_, v_blocks_3551_, v___x_3554_, v___f_3555_);
return v___x_3556_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run4096___boxed(lean_object* v_mode_3557_, lean_object* v_blocks_3558_, lean_object* v_a_3559_){
_start:
{
lean_object* v_res_3560_; 
v_res_3560_ = l_BalancedSqrt_run4096(v_mode_3557_, v_blocks_3558_);
lean_dec_ref(v_mode_3557_);
return v_res_3560_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1(lean_object* v_range_3561_, lean_object* v_b_3562_, lean_object* v_i_3563_, lean_object* v_hs_3564_, lean_object* v_hl_3565_){
_start:
{
lean_object* v___x_3567_; 
v___x_3567_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___redArg(v_range_3561_, v_b_3562_, v_i_3563_);
return v___x_3567_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___boxed(lean_object* v_range_3568_, lean_object* v_b_3569_, lean_object* v_i_3570_, lean_object* v_hs_3571_, lean_object* v_hl_3572_, lean_object* v___y_3573_){
_start:
{
lean_object* v_res_3574_; 
v_res_3574_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1(v_range_3568_, v_b_3569_, v_i_3570_, v_hs_3571_, v_hl_3572_);
lean_dec_ref(v_range_3568_);
return v_res_3574_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2(lean_object* v_range_3575_, lean_object* v_b_3576_, lean_object* v_i_3577_, lean_object* v_hs_3578_, lean_object* v_hl_3579_){
_start:
{
lean_object* v___x_3581_; 
v___x_3581_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg(v_range_3575_, v_b_3576_, v_i_3577_);
return v___x_3581_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___boxed(lean_object* v_range_3582_, lean_object* v_b_3583_, lean_object* v_i_3584_, lean_object* v_hs_3585_, lean_object* v_hl_3586_, lean_object* v___y_3587_){
_start:
{
lean_object* v_res_3588_; 
v_res_3588_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2(v_range_3582_, v_b_3583_, v_i_3584_, v_hs_3585_, v_hl_3586_);
lean_dec_ref(v_range_3582_);
return v_res_3588_;
}
}
static lean_object* _init_l_main___boxed__const__1(void){
_start:
{
uint32_t v___x_3608_; lean_object* v___x_3609_; 
v___x_3608_ = 0;
v___x_3609_ = lean_box_uint32(v___x_3608_);
return v___x_3609_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_3610_){
_start:
{
if (lean_obj_tag(v_args_3610_) == 1)
{
lean_object* v_tail_3618_; 
v_tail_3618_ = lean_ctor_get(v_args_3610_, 1);
lean_inc(v_tail_3618_);
if (lean_obj_tag(v_tail_3618_) == 1)
{
lean_object* v_tail_3619_; 
v_tail_3619_ = lean_ctor_get(v_tail_3618_, 1);
lean_inc(v_tail_3619_);
if (lean_obj_tag(v_tail_3619_) == 1)
{
lean_object* v_head_3620_; lean_object* v_head_3621_; lean_object* v_head_3622_; lean_object* v_tail_3623_; 
v_head_3620_ = lean_ctor_get(v_args_3610_, 0);
lean_inc(v_head_3620_);
lean_dec_ref_known(v_args_3610_, 2);
v_head_3621_ = lean_ctor_get(v_tail_3618_, 0);
lean_inc(v_head_3621_);
lean_dec_ref_known(v_tail_3618_, 2);
v_head_3622_ = lean_ctor_get(v_tail_3619_, 0);
lean_inc(v_head_3622_);
v_tail_3623_ = lean_ctor_get(v_tail_3619_, 1);
lean_inc(v_tail_3623_);
lean_dec_ref_known(v_tail_3619_, 2);
if (lean_obj_tag(v_tail_3623_) == 0)
{
lean_object* v___x_3678_; uint8_t v___x_3679_; 
v___x_3678_ = ((lean_object*)(l_BalancedSqrt_execute___closed__1));
v___x_3679_ = lean_string_dec_eq(v_head_3620_, v___x_3678_);
if (v___x_3679_ == 0)
{
lean_object* v___x_3680_; uint8_t v___x_3681_; 
v___x_3680_ = ((lean_object*)(l_main___closed__11));
v___x_3681_ = lean_string_dec_eq(v_head_3620_, v___x_3680_);
if (v___x_3681_ == 0)
{
lean_object* v___x_3682_; lean_object* v___x_3683_; 
lean_dec(v_head_3622_);
lean_dec(v_head_3621_);
lean_dec(v_head_3620_);
v___x_3682_ = ((lean_object*)(l_main___closed__13));
v___x_3683_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3683_, 0, v___x_3682_);
return v___x_3683_;
}
else
{
goto v___jp_3624_;
}
}
else
{
goto v___jp_3624_;
}
}
else
{
lean_dec(v_tail_3623_);
lean_dec(v_head_3622_);
lean_dec(v_head_3621_);
lean_dec(v_head_3620_);
goto v___jp_3615_;
}
v___jp_3624_:
{
lean_object* v___x_3625_; lean_object* v___x_3626_; lean_object* v___x_3627_; lean_object* v___x_3628_; 
v___x_3625_ = lean_unsigned_to_nat(0u);
v___x_3626_ = lean_string_utf8_byte_size(v_head_3622_);
v___x_3627_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_3627_, 0, v_head_3622_);
lean_ctor_set(v___x_3627_, 1, v___x_3625_);
lean_ctor_set(v___x_3627_, 2, v___x_3626_);
v___x_3628_ = l_String_Slice_toNat_x3f(v___x_3627_);
lean_dec_ref_known(v___x_3627_, 3);
if (lean_obj_tag(v___x_3628_) == 1)
{
lean_object* v_val_3629_; lean_object* v___x_3631_; uint8_t v_isShared_3632_; uint8_t v_isSharedCheck_3675_; 
v_val_3629_ = lean_ctor_get(v___x_3628_, 0);
v_isSharedCheck_3675_ = !lean_is_exclusive(v___x_3628_);
if (v_isSharedCheck_3675_ == 0)
{
v___x_3631_ = v___x_3628_;
v_isShared_3632_ = v_isSharedCheck_3675_;
goto v_resetjp_3630_;
}
else
{
lean_inc(v_val_3629_);
lean_dec(v___x_3628_);
v___x_3631_ = lean_box(0);
v_isShared_3632_ = v_isSharedCheck_3675_;
goto v_resetjp_3630_;
}
v_resetjp_3630_:
{
uint8_t v___x_3633_; 
v___x_3633_ = lean_nat_dec_lt(v___x_3625_, v_val_3629_);
if (v___x_3633_ == 0)
{
lean_object* v___x_3634_; lean_object* v___x_3636_; 
lean_dec(v_val_3629_);
lean_dec(v_head_3621_);
lean_dec(v_head_3620_);
v___x_3634_ = ((lean_object*)(l_main___closed__3));
if (v_isShared_3632_ == 0)
{
lean_ctor_set(v___x_3631_, 0, v___x_3634_);
v___x_3636_ = v___x_3631_;
goto v_reusejp_3635_;
}
else
{
lean_object* v_reuseFailAlloc_3637_; 
v_reuseFailAlloc_3637_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3637_, 0, v___x_3634_);
v___x_3636_ = v_reuseFailAlloc_3637_;
goto v_reusejp_3635_;
}
v_reusejp_3635_:
{
return v___x_3636_;
}
}
else
{
lean_object* v___x_3638_; uint8_t v___x_3639_; 
v___x_3638_ = ((lean_object*)(l_main___closed__4));
v___x_3639_ = lean_string_dec_eq(v_head_3621_, v___x_3638_);
if (v___x_3639_ == 0)
{
lean_object* v___x_3640_; uint8_t v___x_3641_; 
v___x_3640_ = ((lean_object*)(l_main___closed__5));
v___x_3641_ = lean_string_dec_eq(v_head_3621_, v___x_3640_);
if (v___x_3641_ == 0)
{
lean_object* v___x_3642_; uint8_t v___x_3643_; 
v___x_3642_ = ((lean_object*)(l_main___closed__6));
v___x_3643_ = lean_string_dec_eq(v_head_3621_, v___x_3642_);
lean_dec(v_head_3621_);
if (v___x_3643_ == 0)
{
lean_object* v___x_3644_; lean_object* v___x_3646_; 
lean_dec(v_val_3629_);
lean_dec(v_head_3620_);
v___x_3644_ = ((lean_object*)(l_main___closed__8));
if (v_isShared_3632_ == 0)
{
lean_ctor_set(v___x_3631_, 0, v___x_3644_);
v___x_3646_ = v___x_3631_;
goto v_reusejp_3645_;
}
else
{
lean_object* v_reuseFailAlloc_3647_; 
v_reuseFailAlloc_3647_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3647_, 0, v___x_3644_);
v___x_3646_ = v_reuseFailAlloc_3647_;
goto v_reusejp_3645_;
}
v_reusejp_3645_:
{
return v___x_3646_;
}
}
else
{
lean_object* v___x_3648_; 
lean_del_object(v___x_3631_);
v___x_3648_ = l_BalancedSqrt_run4096(v_head_3620_, v_val_3629_);
lean_dec(v_head_3620_);
if (lean_obj_tag(v___x_3648_) == 0)
{
lean_dec_ref_known(v___x_3648_, 1);
goto v___jp_3612_;
}
else
{
lean_object* v_a_3649_; lean_object* v___x_3651_; uint8_t v_isShared_3652_; uint8_t v_isSharedCheck_3656_; 
v_a_3649_ = lean_ctor_get(v___x_3648_, 0);
v_isSharedCheck_3656_ = !lean_is_exclusive(v___x_3648_);
if (v_isSharedCheck_3656_ == 0)
{
v___x_3651_ = v___x_3648_;
v_isShared_3652_ = v_isSharedCheck_3656_;
goto v_resetjp_3650_;
}
else
{
lean_inc(v_a_3649_);
lean_dec(v___x_3648_);
v___x_3651_ = lean_box(0);
v_isShared_3652_ = v_isSharedCheck_3656_;
goto v_resetjp_3650_;
}
v_resetjp_3650_:
{
lean_object* v___x_3654_; 
if (v_isShared_3652_ == 0)
{
v___x_3654_ = v___x_3651_;
goto v_reusejp_3653_;
}
else
{
lean_object* v_reuseFailAlloc_3655_; 
v_reuseFailAlloc_3655_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3655_, 0, v_a_3649_);
v___x_3654_ = v_reuseFailAlloc_3655_;
goto v_reusejp_3653_;
}
v_reusejp_3653_:
{
return v___x_3654_;
}
}
}
}
}
else
{
lean_object* v___x_3657_; 
lean_del_object(v___x_3631_);
lean_dec(v_head_3621_);
v___x_3657_ = l_BalancedSqrt_run2048(v_head_3620_, v_val_3629_);
lean_dec(v_head_3620_);
if (lean_obj_tag(v___x_3657_) == 0)
{
lean_dec_ref_known(v___x_3657_, 1);
goto v___jp_3612_;
}
else
{
lean_object* v_a_3658_; lean_object* v___x_3660_; uint8_t v_isShared_3661_; uint8_t v_isSharedCheck_3665_; 
v_a_3658_ = lean_ctor_get(v___x_3657_, 0);
v_isSharedCheck_3665_ = !lean_is_exclusive(v___x_3657_);
if (v_isSharedCheck_3665_ == 0)
{
v___x_3660_ = v___x_3657_;
v_isShared_3661_ = v_isSharedCheck_3665_;
goto v_resetjp_3659_;
}
else
{
lean_inc(v_a_3658_);
lean_dec(v___x_3657_);
v___x_3660_ = lean_box(0);
v_isShared_3661_ = v_isSharedCheck_3665_;
goto v_resetjp_3659_;
}
v_resetjp_3659_:
{
lean_object* v___x_3663_; 
if (v_isShared_3661_ == 0)
{
v___x_3663_ = v___x_3660_;
goto v_reusejp_3662_;
}
else
{
lean_object* v_reuseFailAlloc_3664_; 
v_reuseFailAlloc_3664_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3664_, 0, v_a_3658_);
v___x_3663_ = v_reuseFailAlloc_3664_;
goto v_reusejp_3662_;
}
v_reusejp_3662_:
{
return v___x_3663_;
}
}
}
}
}
else
{
lean_object* v___x_3666_; 
lean_del_object(v___x_3631_);
lean_dec(v_head_3621_);
v___x_3666_ = l_BalancedSqrt_run1024(v_head_3620_, v_val_3629_);
lean_dec(v_head_3620_);
if (lean_obj_tag(v___x_3666_) == 0)
{
lean_dec_ref_known(v___x_3666_, 1);
goto v___jp_3612_;
}
else
{
lean_object* v_a_3667_; lean_object* v___x_3669_; uint8_t v_isShared_3670_; uint8_t v_isSharedCheck_3674_; 
v_a_3667_ = lean_ctor_get(v___x_3666_, 0);
v_isSharedCheck_3674_ = !lean_is_exclusive(v___x_3666_);
if (v_isSharedCheck_3674_ == 0)
{
v___x_3669_ = v___x_3666_;
v_isShared_3670_ = v_isSharedCheck_3674_;
goto v_resetjp_3668_;
}
else
{
lean_inc(v_a_3667_);
lean_dec(v___x_3666_);
v___x_3669_ = lean_box(0);
v_isShared_3670_ = v_isSharedCheck_3674_;
goto v_resetjp_3668_;
}
v_resetjp_3668_:
{
lean_object* v___x_3672_; 
if (v_isShared_3670_ == 0)
{
v___x_3672_ = v___x_3669_;
goto v_reusejp_3671_;
}
else
{
lean_object* v_reuseFailAlloc_3673_; 
v_reuseFailAlloc_3673_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3673_, 0, v_a_3667_);
v___x_3672_ = v_reuseFailAlloc_3673_;
goto v_reusejp_3671_;
}
v_reusejp_3671_:
{
return v___x_3672_;
}
}
}
}
}
}
}
else
{
lean_object* v___x_3676_; lean_object* v___x_3677_; 
lean_dec(v___x_3628_);
lean_dec(v_head_3621_);
lean_dec(v_head_3620_);
v___x_3676_ = ((lean_object*)(l_main___closed__10));
v___x_3677_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3677_, 0, v___x_3676_);
return v___x_3677_;
}
}
}
else
{
lean_dec(v_tail_3619_);
lean_dec_ref_known(v_tail_3618_, 2);
lean_dec_ref_known(v_args_3610_, 2);
goto v___jp_3615_;
}
}
else
{
lean_dec(v_tail_3618_);
lean_dec_ref_known(v_args_3610_, 2);
goto v___jp_3615_;
}
}
else
{
lean_dec(v_args_3610_);
goto v___jp_3615_;
}
v___jp_3612_:
{
lean_object* v___x_3613_; lean_object* v___x_3614_; 
v___x_3613_ = l_main___boxed__const__1;
v___x_3614_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3614_, 0, v___x_3613_);
return v___x_3614_;
}
v___jp_3615_:
{
lean_object* v___x_3616_; lean_object* v___x_3617_; 
v___x_3616_ = ((lean_object*)(l_main___closed__1));
v___x_3617_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3617_, 0, v___x_3616_);
return v___x_3617_;
}
}
}
LEAN_EXPORT lean_object* l_main___boxed(lean_object* v_args_3684_, lean_object* v_a_3685_){
_start:
{
lean_object* v_res_3686_; 
v_res_3686_ = _lean_main(v_args_3684_);
return v_res_3686_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_BalancedSqrt(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0 = _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0();
lean_mark_persistent(l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0);
l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0 = _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0();
lean_mark_persistent(l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0);
l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0 = _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0();
lean_mark_persistent(l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0);
l_main___boxed__const__1 = _init_l_main___boxed__const__1();
lean_mark_persistent(l_main___boxed__const__1);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_BalancedSqrt(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = lean_unbox_uint32(lean_io_result_get_value(res));
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
