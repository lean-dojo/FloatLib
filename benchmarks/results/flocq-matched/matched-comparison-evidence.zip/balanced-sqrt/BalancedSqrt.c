// Lean compiler output
// Module: BalancedSqrt
// Imports: public import Init public meta import Init public import FloatLibBenchmarks.Public.Sweep
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
extern lean_object* lp_floatlib_FloatLib_Floats_ExecFloat_Backend_Policy_throughput;
uint8_t lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Plan_firstOrderSelected(lean_object*, lean_object*, uint8_t, uint8_t);
uint64_t lean_uint64_shift_right(uint64_t, uint64_t);
uint64_t lean_uint64_xor(uint64_t, uint64_t);
uint64_t lean_uint64_land(uint64_t, uint64_t);
lean_object* lean_uint64_to_nat(uint64_t);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
uint64_t lean_uint64_shift_left(uint64_t, uint64_t);
uint8_t lean_uint64_dec_eq(uint64_t, uint64_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lean_nat_mod(lean_object*, lean_object*);
lean_object* lean_st_mk_ref(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
lean_object* lean_st_ref_set(lean_object*, lean_object*);
lean_object* lean_st_ref_get(lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(lean_object*);
lean_object* lean_io_mono_nanos_now();
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic(lean_object*, lean_object*);
lean_object* lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Code_ofModel___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Code_toModel___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lp_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep_configuredBenchmarkCarrier(lean_object*, uint8_t, lean_object*);
lean_object* lp_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep_benchmarkExecFloatInhabited___redArg(lean_object*);
extern lean_object* lp_floatlibBenchmarks_FloatLibBenchmarks_Support_ExactWorkload_sqrtXs;
size_t lean_array_size(lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget(lean_object*, size_t);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
lean_object* lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Model_roundRatQ(lean_object*, lean_object*);
size_t lean_usize_add(size_t, size_t);
lean_object* lean_array_get_borrowed(lean_object*, lean_object*, lean_object*);
lean_object* lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Plan_automaticSqrtCandidates(lean_object*, uint8_t);
lean_object* lean_nat_mul(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_div(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lean_mk_thunk(lean_object*);
lean_object* lean_thunk_get_own(lean_object*);
lean_object* lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Descriptor_Plan_structuralRoute_x3f(lean_object*, uint8_t);
uint64_t lean_uint64_lor(uint64_t, uint64_t);
uint64_t lean_uint64_mul(uint64_t, uint64_t);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x3f(lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___redArg(uint64_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object l_BalancedSqrt_nextUnused___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*3 + 0, .m_other = 3, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(16) << 1) | 1)),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_BalancedSqrt_nextUnused___closed__0 = (const lean_object*)&l_BalancedSqrt_nextUnused___closed__0_value;
LEAN_EXPORT lean_object* l_BalancedSqrt_nextUnused(uint64_t, uint64_t);
LEAN_EXPORT lean_object* l_BalancedSqrt_nextUnused___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_advance(lean_object*, lean_object*, uint64_t);
LEAN_EXPORT lean_object* l_BalancedSqrt_advance___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block1024_spec__2(lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block1024_spec__2___boxed(lean_object*);
LEAN_EXPORT lean_object* l_List_foldl___at___00BalancedSqrt_block1024_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_block1024___lam__0(lean_object*, uint8_t, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_block1024___lam__0___boxed(lean_object*, lean_object*, lean_object*);
static const lean_ctor_object l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*3 + 8, .m_other = 3, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(19) << 1) | 1)),((lean_object*)(((size_t)(1004) << 1) | 1)),((lean_object*)(((size_t)(262143) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1___closed__0 = (const lean_object*)&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1___closed__0_value;
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1(lean_object*);
static const lean_closure_object l_BalancedSqrt_block1024___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Code_toModel___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1___closed__0_value),((lean_object*)(((size_t)(4) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block1024___closed__0 = (const lean_object*)&l_BalancedSqrt_block1024___closed__0_value;
static const lean_closure_object l_BalancedSqrt_block1024___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Code_ofModel___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1___closed__0_value),((lean_object*)(((size_t)(4) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block1024___closed__1 = (const lean_object*)&l_BalancedSqrt_block1024___closed__1_value;
static const lean_ctor_object l_BalancedSqrt_block1024___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l_BalancedSqrt_block1024___closed__0_value),((lean_object*)&l_BalancedSqrt_block1024___closed__1_value)}};
static const lean_object* l_BalancedSqrt_block1024___closed__2 = (const lean_object*)&l_BalancedSqrt_block1024___closed__2_value;
static lean_once_cell_t l_BalancedSqrt_block1024___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block1024___closed__3;
static lean_once_cell_t l_BalancedSqrt_block1024___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block1024___closed__4;
static lean_once_cell_t l_BalancedSqrt_block1024___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static uint8_t l_BalancedSqrt_block1024___closed__5;
static const lean_closure_object l_BalancedSqrt_block1024___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_BalancedSqrt_block1024___lam__0___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1___closed__0_value),((lean_object*)(((size_t)(4) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block1024___closed__6 = (const lean_object*)&l_BalancedSqrt_block1024___closed__6_value;
static lean_once_cell_t l_BalancedSqrt_block1024___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block1024___closed__7;
static lean_once_cell_t l_BalancedSqrt_block1024___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block1024___closed__8;
static lean_once_cell_t l_BalancedSqrt_block1024___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block1024___closed__9;
LEAN_EXPORT lean_object* l_BalancedSqrt_block1024(lean_object*, uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_block1024___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block2048_spec__1(lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block2048_spec__1___boxed(lean_object*);
static const lean_ctor_object l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*3 + 8, .m_other = 3, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(19) << 1) | 1)),((lean_object*)(((size_t)(2028) << 1) | 1)),((lean_object*)(((size_t)(262143) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0___closed__0 = (const lean_object*)&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0___closed__0_value;
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0(lean_object*);
static const lean_closure_object l_BalancedSqrt_block2048___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Code_toModel___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0___closed__0_value),((lean_object*)(((size_t)(4) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block2048___closed__0 = (const lean_object*)&l_BalancedSqrt_block2048___closed__0_value;
static const lean_closure_object l_BalancedSqrt_block2048___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Code_ofModel___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0___closed__0_value),((lean_object*)(((size_t)(4) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block2048___closed__1 = (const lean_object*)&l_BalancedSqrt_block2048___closed__1_value;
static const lean_ctor_object l_BalancedSqrt_block2048___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l_BalancedSqrt_block2048___closed__0_value),((lean_object*)&l_BalancedSqrt_block2048___closed__1_value)}};
static const lean_object* l_BalancedSqrt_block2048___closed__2 = (const lean_object*)&l_BalancedSqrt_block2048___closed__2_value;
static lean_once_cell_t l_BalancedSqrt_block2048___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block2048___closed__3;
static lean_once_cell_t l_BalancedSqrt_block2048___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block2048___closed__4;
static lean_once_cell_t l_BalancedSqrt_block2048___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static uint8_t l_BalancedSqrt_block2048___closed__5;
static const lean_closure_object l_BalancedSqrt_block2048___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_BalancedSqrt_block1024___lam__0___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0___closed__0_value),((lean_object*)(((size_t)(4) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block2048___closed__6 = (const lean_object*)&l_BalancedSqrt_block2048___closed__6_value;
static lean_once_cell_t l_BalancedSqrt_block2048___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block2048___closed__7;
static lean_once_cell_t l_BalancedSqrt_block2048___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block2048___closed__8;
static lean_once_cell_t l_BalancedSqrt_block2048___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block2048___closed__9;
LEAN_EXPORT lean_object* l_BalancedSqrt_block2048(lean_object*, uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_block2048___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block4096_spec__1(lean_object*);
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block4096_spec__1___boxed(lean_object*);
static const lean_ctor_object l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*3 + 8, .m_other = 3, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(19) << 1) | 1)),((lean_object*)(((size_t)(4076) << 1) | 1)),((lean_object*)(((size_t)(262143) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0___closed__0 = (const lean_object*)&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0___closed__0_value;
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0(lean_object*);
static const lean_closure_object l_BalancedSqrt_block4096___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Code_toModel___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0___closed__0_value),((lean_object*)(((size_t)(4) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block4096___closed__0 = (const lean_object*)&l_BalancedSqrt_block4096___closed__0_value;
static const lean_closure_object l_BalancedSqrt_block4096___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Code_ofModel___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0___closed__0_value),((lean_object*)(((size_t)(4) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block4096___closed__1 = (const lean_object*)&l_BalancedSqrt_block4096___closed__1_value;
static const lean_ctor_object l_BalancedSqrt_block4096___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l_BalancedSqrt_block4096___closed__0_value),((lean_object*)&l_BalancedSqrt_block4096___closed__1_value)}};
static const lean_object* l_BalancedSqrt_block4096___closed__2 = (const lean_object*)&l_BalancedSqrt_block4096___closed__2_value;
static lean_once_cell_t l_BalancedSqrt_block4096___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block4096___closed__3;
static lean_once_cell_t l_BalancedSqrt_block4096___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block4096___closed__4;
static lean_once_cell_t l_BalancedSqrt_block4096___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static uint8_t l_BalancedSqrt_block4096___closed__5;
static const lean_closure_object l_BalancedSqrt_block4096___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_BalancedSqrt_block1024___lam__0___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)&l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0___closed__0_value),((lean_object*)(((size_t)(4) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_block4096___closed__6 = (const lean_object*)&l_BalancedSqrt_block4096___closed__6_value;
static lean_once_cell_t l_BalancedSqrt_block4096___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block4096___closed__7;
static lean_once_cell_t l_BalancedSqrt_block4096___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block4096___closed__8;
static lean_once_cell_t l_BalancedSqrt_block4096___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_block4096___closed__9;
LEAN_EXPORT lean_object* l_BalancedSqrt_block4096(lean_object*, uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_block4096___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks1024(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks1024___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks2048(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks2048___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks4096(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks4096___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object l_BalancedSqrt_output___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 16, .m_capacity = 16, .m_length = 15, .m_data = "block|floatlib|"};
static const lean_object* l_BalancedSqrt_output___closed__0 = (const lean_object*)&l_BalancedSqrt_output___closed__0_value;
static const lean_string_object l_BalancedSqrt_output___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "|"};
static const lean_object* l_BalancedSqrt_output___closed__1 = (const lean_object*)&l_BalancedSqrt_output___closed__1_value;
LEAN_EXPORT lean_object* l_BalancedSqrt_output(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_output___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object l_BalancedSqrt_execute___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 16, .m_other = 0, .m_tag = 0}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(37, 35, 34, 132, 228, 156, 242, 203),LEAN_SCALAR_PTR_LITERAL(37, 35, 34, 132, 228, 156, 242, 203)}};
static const lean_object* l_BalancedSqrt_execute___closed__0 = (const lean_object*)&l_BalancedSqrt_execute___closed__0_value;
static const lean_string_object l_BalancedSqrt_execute___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "validate"};
static const lean_object* l_BalancedSqrt_execute___closed__1 = (const lean_object*)&l_BalancedSqrt_execute___closed__1_value;
static const lean_string_object l_BalancedSqrt_execute___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "warmup|floatlib|"};
static const lean_object* l_BalancedSqrt_execute___closed__2 = (const lean_object*)&l_BalancedSqrt_execute___closed__2_value;
static const lean_string_object l_BalancedSqrt_execute___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "|1|"};
static const lean_object* l_BalancedSqrt_execute___closed__3 = (const lean_object*)&l_BalancedSqrt_execute___closed__3_value;
LEAN_EXPORT lean_object* l_BalancedSqrt_execute(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_execute___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static size_t l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0;
static lean_once_cell_t l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__1;
LEAN_EXPORT lean_object* l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0;
static const lean_string_object l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "value|1024|"};
static const lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__0 = (const lean_object*)&l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__0_value;
static const lean_string_object l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "|raw|"};
static const lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1 = (const lean_object*)&l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run1024___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run1024___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_BalancedSqrt_run1024___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_run1024___closed__0;
static const lean_closure_object l_BalancedSqrt_run1024___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*3, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_BalancedSqrt_run1024___lam__0___boxed, .m_arity = 4, .m_num_fixed = 3, .m_objs = {((lean_object*)&l_BalancedSqrt_nextUnused___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_run1024___closed__1 = (const lean_object*)&l_BalancedSqrt_run1024___closed__1_value;
LEAN_EXPORT lean_object* l_BalancedSqrt_run1024(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run1024___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0_spec__0(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0___closed__0;
LEAN_EXPORT lean_object* l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0;
static const lean_string_object l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "value|2048|"};
static const lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg___closed__0 = (const lean_object*)&l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg___closed__0_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run2048___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run2048___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_BalancedSqrt_run2048___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_run2048___closed__0;
static const lean_closure_object l_BalancedSqrt_run2048___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*3, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_BalancedSqrt_run2048___lam__0___boxed, .m_arity = 4, .m_num_fixed = 3, .m_objs = {((lean_object*)&l_BalancedSqrt_nextUnused___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_run2048___closed__1 = (const lean_object*)&l_BalancedSqrt_run2048___closed__1_value;
LEAN_EXPORT lean_object* l_BalancedSqrt_run2048(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run2048___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0_spec__0(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0___closed__0;
LEAN_EXPORT lean_object* l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0;
static const lean_string_object l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "value|4096|"};
static const lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg___closed__0 = (const lean_object*)&l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg___closed__0_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run4096___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run4096___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_BalancedSqrt_run4096___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_BalancedSqrt_run4096___closed__0;
static const lean_closure_object l_BalancedSqrt_run4096___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*3, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_BalancedSqrt_run4096___lam__0___boxed, .m_arity = 4, .m_num_fixed = 3, .m_objs = {((lean_object*)&l_BalancedSqrt_nextUnused___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_BalancedSqrt_run4096___closed__1 = (const lean_object*)&l_BalancedSqrt_run4096___closed__1_value;
LEAN_EXPORT lean_object* l_BalancedSqrt_run4096(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_BalancedSqrt_run4096___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 54, .m_capacity = 54, .m_length = 53, .m_data = "usage: balanced-floatlib (validate|time) WIDTH BLOCKS"};
static const lean_object* l_main___closed__0 = (const lean_object*)&l_main___closed__0_value;
static const lean_ctor_object l_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_main___closed__0_value)}};
static const lean_object* l_main___closed__1 = (const lean_object*)&l_main___closed__1_value;
static const lean_string_object l_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 30, .m_capacity = 30, .m_length = 29, .m_data = "mode must be validate or time"};
static const lean_object* l_main___closed__2 = (const lean_object*)&l_main___closed__2_value;
static const lean_ctor_object l_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_main___closed__2_value)}};
static const lean_object* l_main___closed__3 = (const lean_object*)&l_main___closed__3_value;
static const lean_string_object l_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 29, .m_capacity = 29, .m_length = 28, .m_data = "block count must be positive"};
static const lean_object* l_main___closed__4 = (const lean_object*)&l_main___closed__4_value;
static const lean_ctor_object l_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_main___closed__4_value)}};
static const lean_object* l_main___closed__5 = (const lean_object*)&l_main___closed__5_value;
static const lean_string_object l_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "1024"};
static const lean_object* l_main___closed__6 = (const lean_object*)&l_main___closed__6_value;
static const lean_string_object l_main___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "2048"};
static const lean_object* l_main___closed__7 = (const lean_object*)&l_main___closed__7_value;
static const lean_string_object l_main___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "4096"};
static const lean_object* l_main___closed__8 = (const lean_object*)&l_main___closed__8_value;
static const lean_string_object l_main___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 34, .m_capacity = 34, .m_length = 33, .m_data = "width must be 1024, 2048, or 4096"};
static const lean_object* l_main___closed__9 = (const lean_object*)&l_main___closed__9_value;
static const lean_ctor_object l_main___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_main___closed__9_value)}};
static const lean_object* l_main___closed__10 = (const lean_object*)&l_main___closed__10_value;
static const lean_string_object l_main___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 20, .m_capacity = 20, .m_length = 19, .m_data = "invalid block count"};
static const lean_object* l_main___closed__11 = (const lean_object*)&l_main___closed__11_value;
static const lean_ctor_object l_main___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_main___closed__11_value)}};
static const lean_object* l_main___closed__12 = (const lean_object*)&l_main___closed__12_value;
static const lean_string_object l_main___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "time"};
static const lean_object* l_main___closed__13 = (const lean_object*)&l_main___closed__13_value;
LEAN_EXPORT lean_object* l_main___boxed__const__1;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* l_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___redArg(uint64_t v_used_1_, lean_object* v_range_2_, lean_object* v_b_3_, lean_object* v_i_4_){
_start:
{
lean_object* v_stop_5_; lean_object* v_step_6_; uint8_t v___x_7_; 
v_stop_5_ = lean_ctor_get(v_range_2_, 1);
v_step_6_ = lean_ctor_get(v_range_2_, 2);
v___x_7_ = lean_nat_dec_lt(v_i_4_, v_stop_5_);
if (v___x_7_ == 0)
{
lean_dec(v_i_4_);
return v_b_3_;
}
else
{
lean_object* v_snd_8_; lean_object* v___x_10_; uint8_t v_isShared_11_; uint8_t v_isSharedCheck_32_; 
v_snd_8_ = lean_ctor_get(v_b_3_, 1);
v_isSharedCheck_32_ = !lean_is_exclusive(v_b_3_);
if (v_isSharedCheck_32_ == 0)
{
lean_object* v_unused_33_; 
v_unused_33_ = lean_ctor_get(v_b_3_, 0);
lean_dec(v_unused_33_);
v___x_10_ = v_b_3_;
v_isShared_11_ = v_isSharedCheck_32_;
goto v_resetjp_9_;
}
else
{
lean_inc(v_snd_8_);
lean_dec(v_b_3_);
v___x_10_ = lean_box(0);
v_isShared_11_ = v_isSharedCheck_32_;
goto v_resetjp_9_;
}
v_resetjp_9_:
{
uint64_t v___x_12_; uint64_t v___x_13_; uint64_t v___x_14_; uint64_t v___x_15_; uint64_t v___x_16_; uint8_t v___x_17_; 
v___x_12_ = 1ULL;
v___x_13_ = lean_uint64_of_nat(v_snd_8_);
v___x_14_ = lean_uint64_shift_left(v___x_12_, v___x_13_);
v___x_15_ = lean_uint64_land(v_used_1_, v___x_14_);
v___x_16_ = 0ULL;
v___x_17_ = lean_uint64_dec_eq(v___x_15_, v___x_16_);
if (v___x_17_ == 0)
{
lean_object* v___x_18_; lean_object* v___x_19_; lean_object* v___x_20_; lean_object* v___x_21_; lean_object* v___x_22_; lean_object* v___x_24_; 
v___x_18_ = lean_unsigned_to_nat(1u);
v___x_19_ = lean_unsigned_to_nat(16u);
v___x_20_ = lean_box(0);
v___x_21_ = lean_nat_add(v_snd_8_, v___x_18_);
lean_dec(v_snd_8_);
v___x_22_ = lean_nat_mod(v___x_21_, v___x_19_);
lean_dec(v___x_21_);
if (v_isShared_11_ == 0)
{
lean_ctor_set(v___x_10_, 1, v___x_22_);
lean_ctor_set(v___x_10_, 0, v___x_20_);
v___x_24_ = v___x_10_;
goto v_reusejp_23_;
}
else
{
lean_object* v_reuseFailAlloc_27_; 
v_reuseFailAlloc_27_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_27_, 0, v___x_20_);
lean_ctor_set(v_reuseFailAlloc_27_, 1, v___x_22_);
v___x_24_ = v_reuseFailAlloc_27_;
goto v_reusejp_23_;
}
v_reusejp_23_:
{
lean_object* v___x_25_; 
v___x_25_ = lean_nat_add(v_i_4_, v_step_6_);
lean_dec(v_i_4_);
v_b_3_ = v___x_24_;
v_i_4_ = v___x_25_;
goto _start;
}
}
else
{
lean_object* v___x_28_; lean_object* v___x_30_; 
lean_dec(v_i_4_);
lean_inc(v_snd_8_);
v___x_28_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_28_, 0, v_snd_8_);
if (v_isShared_11_ == 0)
{
lean_ctor_set(v___x_10_, 0, v___x_28_);
v___x_30_ = v___x_10_;
goto v_reusejp_29_;
}
else
{
lean_object* v_reuseFailAlloc_31_; 
v_reuseFailAlloc_31_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_31_, 0, v___x_28_);
lean_ctor_set(v_reuseFailAlloc_31_, 1, v_snd_8_);
v___x_30_ = v_reuseFailAlloc_31_;
goto v_reusejp_29_;
}
v_reusejp_29_:
{
return v___x_30_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___redArg___boxed(lean_object* v_used_34_, lean_object* v_range_35_, lean_object* v_b_36_, lean_object* v_i_37_){
_start:
{
uint64_t v_used_boxed_38_; lean_object* v_res_39_; 
v_used_boxed_38_ = lean_unbox_uint64(v_used_34_);
lean_dec_ref(v_used_34_);
v_res_39_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___redArg(v_used_boxed_38_, v_range_35_, v_b_36_, v_i_37_);
lean_dec_ref(v_range_35_);
return v_res_39_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_nextUnused(uint64_t v_used_44_, uint64_t v_sink_45_){
_start:
{
uint64_t v___x_46_; uint64_t v___x_47_; uint64_t v___x_48_; uint64_t v___x_49_; uint64_t v___x_50_; uint64_t v_folded_51_; uint64_t v___x_52_; uint64_t v___x_53_; lean_object* v_index_54_; lean_object* v___x_55_; lean_object* v___x_56_; lean_object* v___x_57_; lean_object* v___x_58_; lean_object* v___x_59_; lean_object* v_fst_60_; 
v___x_46_ = 32ULL;
v___x_47_ = lean_uint64_shift_right(v_sink_45_, v___x_46_);
v___x_48_ = lean_uint64_xor(v_sink_45_, v___x_47_);
v___x_49_ = 16ULL;
v___x_50_ = lean_uint64_shift_right(v___x_48_, v___x_49_);
v_folded_51_ = lean_uint64_xor(v___x_48_, v___x_50_);
v___x_52_ = 15ULL;
v___x_53_ = lean_uint64_land(v_folded_51_, v___x_52_);
v_index_54_ = lean_uint64_to_nat(v___x_53_);
v___x_55_ = lean_unsigned_to_nat(0u);
v___x_56_ = ((lean_object*)(l_BalancedSqrt_nextUnused___closed__0));
v___x_57_ = lean_box(0);
v___x_58_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_58_, 0, v___x_57_);
lean_ctor_set(v___x_58_, 1, v_index_54_);
v___x_59_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___redArg(v_used_44_, v___x_56_, v___x_58_, v___x_55_);
v_fst_60_ = lean_ctor_get(v___x_59_, 0);
lean_inc(v_fst_60_);
if (lean_obj_tag(v_fst_60_) == 0)
{
lean_object* v_snd_61_; 
v_snd_61_ = lean_ctor_get(v___x_59_, 1);
lean_inc(v_snd_61_);
lean_dec_ref(v___x_59_);
return v_snd_61_;
}
else
{
lean_object* v_val_62_; 
lean_dec_ref(v___x_59_);
v_val_62_ = lean_ctor_get(v_fst_60_, 0);
lean_inc(v_val_62_);
lean_dec_ref_known(v_fst_60_, 1);
return v_val_62_;
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_nextUnused___boxed(lean_object* v_used_63_, lean_object* v_sink_64_){
_start:
{
uint64_t v_used_boxed_65_; uint64_t v_sink_boxed_66_; lean_object* v_res_67_; 
v_used_boxed_65_ = lean_unbox_uint64(v_used_63_);
lean_dec_ref(v_used_63_);
v_sink_boxed_66_ = lean_unbox_uint64(v_sink_64_);
lean_dec_ref(v_sink_64_);
v_res_67_ = l_BalancedSqrt_nextUnused(v_used_boxed_65_, v_sink_boxed_66_);
return v_res_67_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0(uint64_t v_used_68_, lean_object* v_range_69_, lean_object* v_b_70_, lean_object* v_i_71_, lean_object* v_hs_72_, lean_object* v_hl_73_){
_start:
{
lean_object* v___x_74_; 
v___x_74_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___redArg(v_used_68_, v_range_69_, v_b_70_, v_i_71_);
return v___x_74_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0___boxed(lean_object* v_used_75_, lean_object* v_range_76_, lean_object* v_b_77_, lean_object* v_i_78_, lean_object* v_hs_79_, lean_object* v_hl_80_){
_start:
{
uint64_t v_used_boxed_81_; lean_object* v_res_82_; 
v_used_boxed_81_ = lean_unbox_uint64(v_used_75_);
lean_dec_ref(v_used_75_);
v_res_82_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_nextUnused_spec__0(v_used_boxed_81_, v_range_76_, v_b_77_, v_i_78_, v_hs_79_, v_hl_80_);
lean_dec_ref(v_range_76_);
return v_res_82_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_advance(lean_object* v_s_83_, lean_object* v_index_84_, uint64_t v_bits_85_){
_start:
{
uint64_t v_sink_86_; uint64_t v_trace_87_; lean_object* v___x_89_; uint8_t v_isShared_90_; uint8_t v_isSharedCheck_100_; 
v_sink_86_ = lean_ctor_get_uint64(v_s_83_, 0);
v_trace_87_ = lean_ctor_get_uint64(v_s_83_, 8);
v_isSharedCheck_100_ = !lean_is_exclusive(v_s_83_);
if (v_isSharedCheck_100_ == 0)
{
v___x_89_ = v_s_83_;
v_isShared_90_ = v_isSharedCheck_100_;
goto v_resetjp_88_;
}
else
{
lean_dec(v_s_83_);
v___x_89_ = lean_box(0);
v_isShared_90_ = v_isSharedCheck_100_;
goto v_resetjp_88_;
}
v_resetjp_88_:
{
uint64_t v___x_91_; uint64_t v___x_92_; uint64_t v___x_93_; uint64_t v___x_94_; uint64_t v___x_95_; uint64_t v___x_96_; lean_object* v___x_98_; 
v___x_91_ = lean_uint64_xor(v_sink_86_, v_bits_85_);
v___x_92_ = 1099511628211ULL;
v___x_93_ = lean_uint64_mul(v___x_91_, v___x_92_);
v___x_94_ = lean_uint64_of_nat(v_index_84_);
v___x_95_ = lean_uint64_xor(v_trace_87_, v___x_94_);
v___x_96_ = lean_uint64_mul(v___x_95_, v___x_92_);
if (v_isShared_90_ == 0)
{
v___x_98_ = v___x_89_;
goto v_reusejp_97_;
}
else
{
lean_object* v_reuseFailAlloc_99_; 
v_reuseFailAlloc_99_ = lean_alloc_ctor(0, 0, 16);
v___x_98_ = v_reuseFailAlloc_99_;
goto v_reusejp_97_;
}
v_reusejp_97_:
{
lean_ctor_set_uint64(v___x_98_, 0, v___x_93_);
lean_ctor_set_uint64(v___x_98_, 8, v___x_96_);
return v___x_98_;
}
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_advance___boxed(lean_object* v_s_101_, lean_object* v_index_102_, lean_object* v_bits_103_){
_start:
{
uint64_t v_bits_boxed_104_; lean_object* v_res_105_; 
v_bits_boxed_104_ = lean_unbox_uint64(v_bits_103_);
lean_dec_ref(v_bits_103_);
v_res_105_ = l_BalancedSqrt_advance(v_s_101_, v_index_102_, v_bits_boxed_104_);
lean_dec(v_index_102_);
return v_res_105_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block1024_spec__2(lean_object* v_x_106_){
_start:
{
lean_object* v___x_107_; 
v___x_107_ = lean_box(0);
return v___x_107_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block1024_spec__2___boxed(lean_object* v_x_108_){
_start:
{
lean_object* v_res_109_; 
v_res_109_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block1024_spec__2(v_x_108_);
lean_dec(v_x_108_);
return v_res_109_;
}
}
LEAN_EXPORT lean_object* l_List_foldl___at___00BalancedSqrt_block1024_spec__0(lean_object* v_x_110_, lean_object* v_x_111_){
_start:
{
if (lean_obj_tag(v_x_111_) == 0)
{
return v_x_110_;
}
else
{
lean_object* v_head_112_; lean_object* v_tail_113_; lean_object* v___y_115_; lean_object* v___y_116_; lean_object* v___y_121_; lean_object* v___y_122_; lean_object* v___y_134_; lean_object* v___y_135_; lean_object* v___y_136_; lean_object* v___y_137_; lean_object* v___y_138_; lean_object* v___y_139_; lean_object* v___y_156_; lean_object* v___y_157_; lean_object* v___y_158_; lean_object* v___y_159_; lean_object* v___y_160_; lean_object* v___y_161_; lean_object* v___y_162_; lean_object* v___y_163_; lean_object* v___y_173_; lean_object* v___y_174_; lean_object* v___y_175_; lean_object* v___y_176_; lean_object* v___y_177_; lean_object* v___y_178_; lean_object* v___y_179_; lean_object* v___y_180_; lean_object* v___y_181_; lean_object* v___y_182_; lean_object* v___y_183_; lean_object* v___y_184_; lean_object* v___y_185_; lean_object* v___y_186_; lean_object* v___y_187_; lean_object* v___y_188_; lean_object* v___y_189_; lean_object* v___y_190_; lean_object* v___y_220_; lean_object* v___y_221_; lean_object* v___y_222_; lean_object* v___y_223_; lean_object* v___y_224_; lean_object* v___y_225_; lean_object* v___y_226_; lean_object* v___y_227_; lean_object* v___y_228_; lean_object* v___y_229_; lean_object* v___y_230_; lean_object* v___y_231_; lean_object* v___y_232_; lean_object* v___y_233_; lean_object* v___y_234_; lean_object* v___y_235_; lean_object* v___y_236_; lean_object* v___y_237_; lean_object* v___y_247_; lean_object* v___y_248_; lean_object* v___y_249_; lean_object* v___y_250_; lean_object* v___y_251_; lean_object* v___y_252_; lean_object* v___y_253_; lean_object* v___y_254_; lean_object* v___y_255_; lean_object* v___y_256_; lean_object* v___y_257_; lean_object* v___y_258_; lean_object* v___y_259_; lean_object* v___y_260_; lean_object* v___y_261_; lean_object* v___y_262_; lean_object* v___y_263_; lean_object* v___y_264_; lean_object* v___y_265_; lean_object* v___y_266_; lean_object* v___y_280_; lean_object* v___y_281_; lean_object* v___y_282_; lean_object* v___y_283_; lean_object* v___y_284_; lean_object* v___y_285_; lean_object* v___y_286_; lean_object* v___y_287_; lean_object* v___y_288_; lean_object* v___y_289_; lean_object* v___y_290_; lean_object* v___y_291_; lean_object* v___y_292_; lean_object* v___y_293_; lean_object* v___y_294_; lean_object* v___y_295_; lean_object* v___y_296_; lean_object* v___y_297_; lean_object* v___y_298_; lean_object* v___y_299_; lean_object* v___y_310_; lean_object* v___y_311_; lean_object* v___y_312_; lean_object* v___y_313_; lean_object* v___y_314_; lean_object* v___y_315_; lean_object* v___y_316_; lean_object* v___y_317_; lean_object* v___y_318_; lean_object* v___y_319_; lean_object* v___y_320_; lean_object* v___y_321_; lean_object* v___y_322_; lean_object* v___y_323_; lean_object* v___y_324_; lean_object* v___y_325_; lean_object* v___y_326_; lean_object* v___y_327_; lean_object* v___y_328_; lean_object* v___y_329_; lean_object* v___y_340_; lean_object* v___y_341_; lean_object* v___y_342_; lean_object* v___y_343_; lean_object* v___y_344_; lean_object* v___y_345_; lean_object* v___y_346_; lean_object* v___y_347_; lean_object* v___y_348_; lean_object* v___y_349_; lean_object* v___y_350_; lean_object* v___y_351_; lean_object* v___y_352_; lean_object* v___y_353_; lean_object* v___y_354_; lean_object* v___y_355_; lean_object* v___y_356_; lean_object* v___y_357_; lean_object* v___y_358_; lean_object* v___y_369_; lean_object* v___y_370_; lean_object* v___y_371_; lean_object* v___y_372_; lean_object* v___y_373_; lean_object* v___y_374_; lean_object* v___y_375_; lean_object* v___y_376_; lean_object* v___y_377_; lean_object* v___y_378_; lean_object* v___y_379_; lean_object* v___y_380_; lean_object* v___y_381_; lean_object* v___y_382_; lean_object* v___y_383_; lean_object* v___y_384_; lean_object* v___y_385_; lean_object* v___y_386_; lean_object* v___y_387_; lean_object* v___y_388_; lean_object* v___y_389_; lean_object* v___y_403_; lean_object* v___y_404_; lean_object* v___y_405_; lean_object* v___y_406_; lean_object* v___y_407_; lean_object* v___y_408_; lean_object* v___y_409_; lean_object* v___y_410_; lean_object* v___y_411_; lean_object* v___y_412_; lean_object* v___y_413_; lean_object* v___y_414_; lean_object* v___y_415_; lean_object* v___y_416_; lean_object* v___y_417_; lean_object* v___y_418_; lean_object* v___y_419_; lean_object* v___y_420_; lean_object* v___y_421_; lean_object* v___y_422_; lean_object* v___y_423_; lean_object* v___y_424_; lean_object* v___y_437_; lean_object* v___y_438_; lean_object* v___y_439_; lean_object* v___y_440_; lean_object* v___y_441_; lean_object* v___y_442_; lean_object* v___y_443_; lean_object* v___y_444_; lean_object* v___y_445_; lean_object* v___y_446_; lean_object* v___y_447_; lean_object* v___y_448_; lean_object* v___y_449_; lean_object* v___y_450_; lean_object* v___y_451_; lean_object* v___y_472_; lean_object* v___y_473_; lean_object* v___y_474_; lean_object* v___y_475_; lean_object* v___y_476_; lean_object* v___y_477_; lean_object* v___y_478_; lean_object* v___y_479_; lean_object* v___y_480_; lean_object* v___y_481_; lean_object* v___y_482_; lean_object* v___y_483_; lean_object* v___y_484_; lean_object* v___y_485_; lean_object* v___y_486_; lean_object* v_estimate_498_; lean_object* v_kind_499_; lean_object* v_steadyCost_500_; lean_object* v_marshallingCost_501_; lean_object* v_setupCost_502_; lean_object* v_setupAllocations_503_; lean_object* v_residentBytes_504_; lean_object* v_temporaryBytes_505_; lean_object* v_allocations_506_; lean_object* v___x_507_; uint8_t v___y_509_; lean_object* v_maxTemporaryBytes_526_; lean_object* v_maxResidentBytes_527_; uint8_t v___x_528_; 
v_head_112_ = lean_ctor_get(v_x_111_, 0);
lean_inc(v_head_112_);
v_tail_113_ = lean_ctor_get(v_x_111_, 1);
lean_inc(v_tail_113_);
lean_dec_ref_known(v_x_111_, 2);
v_estimate_498_ = lean_ctor_get(v_head_112_, 0);
v_kind_499_ = lean_ctor_get(v_estimate_498_, 1);
v_steadyCost_500_ = lean_ctor_get(v_estimate_498_, 3);
v_marshallingCost_501_ = lean_ctor_get(v_estimate_498_, 4);
v_setupCost_502_ = lean_ctor_get(v_estimate_498_, 5);
v_setupAllocations_503_ = lean_ctor_get(v_estimate_498_, 6);
v_residentBytes_504_ = lean_ctor_get(v_estimate_498_, 7);
v_temporaryBytes_505_ = lean_ctor_get(v_estimate_498_, 8);
v_allocations_506_ = lean_ctor_get(v_estimate_498_, 9);
v___x_507_ = lp_floatlib_FloatLib_Floats_ExecFloat_Backend_Policy_throughput;
v_maxTemporaryBytes_526_ = lean_ctor_get(v___x_507_, 5);
v_maxResidentBytes_527_ = lean_ctor_get(v___x_507_, 6);
v___x_528_ = lean_nat_dec_le(v_residentBytes_504_, v_maxResidentBytes_527_);
if (v___x_528_ == 0)
{
v___y_509_ = v___x_528_;
goto v___jp_508_;
}
else
{
uint8_t v___x_529_; 
v___x_529_ = lean_nat_dec_le(v_temporaryBytes_505_, v_maxTemporaryBytes_526_);
v___y_509_ = v___x_529_;
goto v___jp_508_;
}
v___jp_114_:
{
uint8_t v___x_117_; 
v___x_117_ = lean_nat_dec_lt(v___y_115_, v___y_116_);
lean_dec(v___y_116_);
lean_dec(v___y_115_);
if (v___x_117_ == 0)
{
lean_dec(v_head_112_);
v_x_111_ = v_tail_113_;
goto _start;
}
else
{
lean_dec_ref(v_x_110_);
v_x_110_ = v_head_112_;
v_x_111_ = v_tail_113_;
goto _start;
}
}
v___jp_120_:
{
lean_object* v_kind_123_; 
v_kind_123_ = lean_ctor_get(v___y_121_, 1);
lean_inc(v_kind_123_);
lean_dec_ref(v___y_121_);
switch(lean_obj_tag(v_kind_123_))
{
case 0:
{
lean_object* v___x_124_; 
v___x_124_ = lean_unsigned_to_nat(0u);
v___y_115_ = v___y_122_;
v___y_116_ = v___x_124_;
goto v___jp_114_;
}
case 1:
{
lean_object* v___x_125_; 
v___x_125_ = lean_unsigned_to_nat(2u);
v___y_115_ = v___y_122_;
v___y_116_ = v___x_125_;
goto v___jp_114_;
}
case 2:
{
lean_object* v___x_126_; 
v___x_126_ = lean_unsigned_to_nat(3u);
v___y_115_ = v___y_122_;
v___y_116_ = v___x_126_;
goto v___jp_114_;
}
case 3:
{
lean_object* v___x_127_; 
v___x_127_ = lean_unsigned_to_nat(4u);
v___y_115_ = v___y_122_;
v___y_116_ = v___x_127_;
goto v___jp_114_;
}
case 4:
{
lean_object* v___x_128_; 
v___x_128_ = lean_unsigned_to_nat(5u);
v___y_115_ = v___y_122_;
v___y_116_ = v___x_128_;
goto v___jp_114_;
}
case 5:
{
lean_object* v___x_129_; 
v___x_129_ = lean_unsigned_to_nat(6u);
v___y_115_ = v___y_122_;
v___y_116_ = v___x_129_;
goto v___jp_114_;
}
default: 
{
lean_object* v_tieRank_130_; lean_object* v___x_131_; lean_object* v___x_132_; 
v_tieRank_130_ = lean_ctor_get(v_kind_123_, 1);
lean_inc(v_tieRank_130_);
lean_dec_ref_known(v_kind_123_, 2);
v___x_131_ = lean_unsigned_to_nat(7u);
v___x_132_ = lean_nat_add(v___x_131_, v_tieRank_130_);
lean_dec(v_tieRank_130_);
v___y_115_ = v___y_122_;
v___y_116_ = v___x_132_;
goto v___jp_114_;
}
}
}
v___jp_133_:
{
lean_object* v___x_140_; lean_object* v___x_141_; uint8_t v___x_142_; 
v___x_140_ = lean_nat_mul(v___y_137_, v___y_139_);
lean_dec(v___y_139_);
v___x_141_ = lean_nat_add(v___y_136_, v___x_140_);
lean_dec(v___x_140_);
lean_dec(v___y_136_);
v___x_142_ = lean_nat_dec_eq(v___y_134_, v___x_141_);
if (v___x_142_ == 0)
{
uint8_t v___x_143_; 
lean_dec_ref(v___y_138_);
lean_dec(v___y_135_);
v___x_143_ = lean_nat_dec_lt(v___y_134_, v___x_141_);
lean_dec(v___x_141_);
lean_dec(v___y_134_);
if (v___x_143_ == 0)
{
lean_dec(v_head_112_);
v_x_111_ = v_tail_113_;
goto _start;
}
else
{
lean_dec_ref(v_x_110_);
v_x_110_ = v_head_112_;
v_x_111_ = v_tail_113_;
goto _start;
}
}
else
{
lean_dec(v___x_141_);
lean_dec(v___y_134_);
switch(lean_obj_tag(v___y_135_))
{
case 0:
{
lean_object* v___x_146_; 
v___x_146_ = lean_unsigned_to_nat(0u);
v___y_121_ = v___y_138_;
v___y_122_ = v___x_146_;
goto v___jp_120_;
}
case 1:
{
lean_object* v___x_147_; 
v___x_147_ = lean_unsigned_to_nat(2u);
v___y_121_ = v___y_138_;
v___y_122_ = v___x_147_;
goto v___jp_120_;
}
case 2:
{
lean_object* v___x_148_; 
v___x_148_ = lean_unsigned_to_nat(3u);
v___y_121_ = v___y_138_;
v___y_122_ = v___x_148_;
goto v___jp_120_;
}
case 3:
{
lean_object* v___x_149_; 
v___x_149_ = lean_unsigned_to_nat(4u);
v___y_121_ = v___y_138_;
v___y_122_ = v___x_149_;
goto v___jp_120_;
}
case 4:
{
lean_object* v___x_150_; 
v___x_150_ = lean_unsigned_to_nat(5u);
v___y_121_ = v___y_138_;
v___y_122_ = v___x_150_;
goto v___jp_120_;
}
case 5:
{
lean_object* v___x_151_; 
v___x_151_ = lean_unsigned_to_nat(6u);
v___y_121_ = v___y_138_;
v___y_122_ = v___x_151_;
goto v___jp_120_;
}
default: 
{
lean_object* v_tieRank_152_; lean_object* v___x_153_; lean_object* v___x_154_; 
v_tieRank_152_ = lean_ctor_get(v___y_135_, 1);
lean_inc(v_tieRank_152_);
lean_dec_ref_known(v___y_135_, 2);
v___x_153_ = lean_unsigned_to_nat(7u);
v___x_154_ = lean_nat_add(v___x_153_, v_tieRank_152_);
lean_dec(v_tieRank_152_);
v___y_121_ = v___y_138_;
v___y_122_ = v___x_154_;
goto v___jp_120_;
}
}
}
}
v___jp_155_:
{
lean_object* v___x_164_; lean_object* v___x_165_; lean_object* v___x_166_; uint8_t v___x_167_; 
v___x_164_ = lean_nat_mul(v___y_160_, v___y_163_);
lean_dec(v___y_163_);
v___x_165_ = lean_nat_add(v___y_157_, v___x_164_);
lean_dec(v___x_164_);
lean_dec(v___y_157_);
v___x_166_ = lean_unsigned_to_nat(0u);
v___x_167_ = lean_nat_dec_eq(v___y_158_, v___x_166_);
if (v___x_167_ == 0)
{
lean_object* v___x_168_; lean_object* v___x_169_; lean_object* v___x_170_; lean_object* v___x_171_; 
v___x_168_ = lean_nat_add(v___y_161_, v___y_158_);
lean_dec(v___y_161_);
v___x_169_ = lean_unsigned_to_nat(1u);
v___x_170_ = lean_nat_sub(v___x_168_, v___x_169_);
lean_dec(v___x_168_);
v___x_171_ = lean_nat_div(v___x_170_, v___y_158_);
lean_dec(v___x_170_);
v___y_134_ = v___x_165_;
v___y_135_ = v___y_156_;
v___y_136_ = v___y_159_;
v___y_137_ = v___y_160_;
v___y_138_ = v___y_162_;
v___y_139_ = v___x_171_;
goto v___jp_133_;
}
else
{
v___y_134_ = v___x_165_;
v___y_135_ = v___y_156_;
v___y_136_ = v___y_159_;
v___y_137_ = v___y_160_;
v___y_138_ = v___y_162_;
v___y_139_ = v___y_161_;
goto v___jp_133_;
}
}
v___jp_172_:
{
lean_object* v___x_191_; lean_object* v___x_192_; uint8_t v___x_193_; 
v___x_191_ = lean_nat_mul(v___y_182_, v___y_190_);
lean_dec(v___y_190_);
v___x_192_ = lean_nat_add(v___y_183_, v___x_191_);
lean_dec(v___x_191_);
lean_dec(v___y_183_);
v___x_193_ = lean_nat_dec_eq(v___y_181_, v___x_192_);
if (v___x_193_ == 0)
{
uint8_t v___x_194_; 
lean_dec_ref(v___y_189_);
lean_dec(v___y_188_);
lean_dec(v___y_185_);
lean_dec(v___y_184_);
lean_dec(v___y_180_);
lean_dec(v___y_179_);
lean_dec(v___y_178_);
lean_dec(v___y_177_);
lean_dec(v___y_176_);
lean_dec(v___y_175_);
lean_dec(v___y_174_);
lean_dec(v___y_173_);
v___x_194_ = lean_nat_dec_lt(v___y_181_, v___x_192_);
lean_dec(v___x_192_);
lean_dec(v___y_181_);
if (v___x_194_ == 0)
{
lean_dec(v_head_112_);
v_x_111_ = v_tail_113_;
goto _start;
}
else
{
lean_dec_ref(v_x_110_);
v_x_110_ = v_head_112_;
v_x_111_ = v_tail_113_;
goto _start;
}
}
else
{
uint8_t v___x_197_; 
lean_dec(v___x_192_);
lean_dec(v___y_181_);
v___x_197_ = lean_nat_dec_eq(v___y_179_, v___y_185_);
if (v___x_197_ == 0)
{
uint8_t v___x_198_; 
lean_dec_ref(v___y_189_);
lean_dec(v___y_188_);
lean_dec(v___y_184_);
lean_dec(v___y_180_);
lean_dec(v___y_178_);
lean_dec(v___y_177_);
lean_dec(v___y_176_);
lean_dec(v___y_175_);
lean_dec(v___y_174_);
lean_dec(v___y_173_);
v___x_198_ = lean_nat_dec_lt(v___y_179_, v___y_185_);
lean_dec(v___y_185_);
lean_dec(v___y_179_);
if (v___x_198_ == 0)
{
lean_dec(v_head_112_);
v_x_111_ = v_tail_113_;
goto _start;
}
else
{
lean_dec_ref(v_x_110_);
v_x_110_ = v_head_112_;
v_x_111_ = v_tail_113_;
goto _start;
}
}
else
{
uint8_t v___x_201_; 
lean_dec(v___y_185_);
lean_dec(v___y_179_);
v___x_201_ = lean_nat_dec_eq(v___y_188_, v___y_180_);
if (v___x_201_ == 0)
{
uint8_t v___x_202_; 
lean_dec_ref(v___y_189_);
lean_dec(v___y_184_);
lean_dec(v___y_178_);
lean_dec(v___y_177_);
lean_dec(v___y_176_);
lean_dec(v___y_175_);
lean_dec(v___y_174_);
lean_dec(v___y_173_);
v___x_202_ = lean_nat_dec_lt(v___y_188_, v___y_180_);
lean_dec(v___y_180_);
lean_dec(v___y_188_);
if (v___x_202_ == 0)
{
lean_dec(v_head_112_);
v_x_111_ = v_tail_113_;
goto _start;
}
else
{
lean_dec_ref(v_x_110_);
v_x_110_ = v_head_112_;
v_x_111_ = v_tail_113_;
goto _start;
}
}
else
{
uint8_t v___x_205_; 
lean_dec(v___y_188_);
lean_dec(v___y_180_);
v___x_205_ = lean_nat_dec_eq(v___y_184_, v___y_173_);
if (v___x_205_ == 0)
{
uint8_t v___x_206_; 
lean_dec_ref(v___y_189_);
lean_dec(v___y_178_);
lean_dec(v___y_177_);
lean_dec(v___y_176_);
lean_dec(v___y_175_);
lean_dec(v___y_174_);
v___x_206_ = lean_nat_dec_lt(v___y_184_, v___y_173_);
lean_dec(v___y_173_);
lean_dec(v___y_184_);
if (v___x_206_ == 0)
{
lean_dec(v_head_112_);
v_x_111_ = v_tail_113_;
goto _start;
}
else
{
lean_dec_ref(v_x_110_);
v_x_110_ = v_head_112_;
v_x_111_ = v_tail_113_;
goto _start;
}
}
else
{
uint8_t v___x_209_; 
lean_dec(v___y_184_);
lean_dec(v___y_173_);
v___x_209_ = lean_nat_dec_eq(v___y_177_, v___y_178_);
if (v___x_209_ == 0)
{
uint8_t v___x_210_; 
lean_dec_ref(v___y_189_);
lean_dec(v___y_176_);
lean_dec(v___y_175_);
lean_dec(v___y_174_);
v___x_210_ = lean_nat_dec_lt(v___y_177_, v___y_178_);
lean_dec(v___y_178_);
lean_dec(v___y_177_);
if (v___x_210_ == 0)
{
lean_dec(v_head_112_);
v_x_111_ = v_tail_113_;
goto _start;
}
else
{
lean_dec_ref(v_x_110_);
v_x_110_ = v_head_112_;
v_x_111_ = v_tail_113_;
goto _start;
}
}
else
{
lean_object* v___x_213_; uint8_t v___x_214_; 
v___x_213_ = lean_unsigned_to_nat(0u);
v___x_214_ = lean_nat_dec_eq(v___y_186_, v___x_213_);
if (v___x_214_ == 0)
{
lean_object* v___x_215_; lean_object* v___x_216_; lean_object* v___x_217_; lean_object* v___x_218_; 
v___x_215_ = lean_nat_add(v___y_177_, v___y_186_);
lean_dec(v___y_177_);
v___x_216_ = lean_unsigned_to_nat(1u);
v___x_217_ = lean_nat_sub(v___x_215_, v___x_216_);
lean_dec(v___x_215_);
v___x_218_ = lean_nat_div(v___x_217_, v___y_186_);
lean_dec(v___x_217_);
v___y_156_ = v___y_174_;
v___y_157_ = v___y_175_;
v___y_158_ = v___y_186_;
v___y_159_ = v___y_176_;
v___y_160_ = v___y_187_;
v___y_161_ = v___y_178_;
v___y_162_ = v___y_189_;
v___y_163_ = v___x_218_;
goto v___jp_155_;
}
else
{
v___y_156_ = v___y_174_;
v___y_157_ = v___y_175_;
v___y_158_ = v___y_186_;
v___y_159_ = v___y_176_;
v___y_160_ = v___y_187_;
v___y_161_ = v___y_178_;
v___y_162_ = v___y_189_;
v___y_163_ = v___y_177_;
goto v___jp_155_;
}
}
}
}
}
}
}
v___jp_219_:
{
lean_object* v___x_238_; lean_object* v___x_239_; lean_object* v___x_240_; uint8_t v___x_241_; 
v___x_238_ = lean_nat_mul(v___y_229_, v___y_237_);
lean_dec(v___y_237_);
v___x_239_ = lean_nat_add(v___y_228_, v___x_238_);
lean_dec(v___x_238_);
lean_dec(v___y_228_);
v___x_240_ = lean_unsigned_to_nat(0u);
v___x_241_ = lean_nat_dec_eq(v___y_233_, v___x_240_);
if (v___x_241_ == 0)
{
lean_object* v___x_242_; lean_object* v___x_243_; lean_object* v___x_244_; lean_object* v___x_245_; 
v___x_242_ = lean_nat_add(v___y_220_, v___y_233_);
v___x_243_ = lean_unsigned_to_nat(1u);
v___x_244_ = lean_nat_sub(v___x_242_, v___x_243_);
lean_dec(v___x_242_);
v___x_245_ = lean_nat_div(v___x_244_, v___y_233_);
lean_dec(v___x_244_);
v___y_173_ = v___y_220_;
v___y_174_ = v___y_221_;
v___y_175_ = v___y_222_;
v___y_176_ = v___y_223_;
v___y_177_ = v___y_224_;
v___y_178_ = v___y_225_;
v___y_179_ = v___y_226_;
v___y_180_ = v___y_227_;
v___y_181_ = v___x_239_;
v___y_182_ = v___y_229_;
v___y_183_ = v___y_230_;
v___y_184_ = v___y_231_;
v___y_185_ = v___y_232_;
v___y_186_ = v___y_233_;
v___y_187_ = v___y_235_;
v___y_188_ = v___y_234_;
v___y_189_ = v___y_236_;
v___y_190_ = v___x_245_;
goto v___jp_172_;
}
else
{
lean_inc(v___y_220_);
v___y_173_ = v___y_220_;
v___y_174_ = v___y_221_;
v___y_175_ = v___y_222_;
v___y_176_ = v___y_223_;
v___y_177_ = v___y_224_;
v___y_178_ = v___y_225_;
v___y_179_ = v___y_226_;
v___y_180_ = v___y_227_;
v___y_181_ = v___x_239_;
v___y_182_ = v___y_229_;
v___y_183_ = v___y_230_;
v___y_184_ = v___y_231_;
v___y_185_ = v___y_232_;
v___y_186_ = v___y_233_;
v___y_187_ = v___y_235_;
v___y_188_ = v___y_234_;
v___y_189_ = v___y_236_;
v___y_190_ = v___y_220_;
goto v___jp_172_;
}
}
v___jp_246_:
{
lean_object* v___x_267_; lean_object* v___x_268_; lean_object* v___x_269_; uint8_t v___x_270_; 
v___x_267_ = lean_nat_mul(v___y_263_, v___y_266_);
lean_dec(v___y_266_);
v___x_268_ = lean_nat_add(v___y_250_, v___x_267_);
lean_dec(v___x_267_);
v___x_269_ = lean_nat_add(v___y_254_, v___x_268_);
lean_dec(v___x_268_);
lean_dec(v___y_254_);
v___x_270_ = lean_nat_dec_eq(v___y_264_, v___x_269_);
lean_dec(v___x_269_);
lean_dec(v___y_264_);
if (v___x_270_ == 0)
{
lean_dec_ref(v___y_265_);
lean_dec(v___y_262_);
lean_dec(v___y_260_);
lean_dec(v___y_259_);
lean_dec(v___y_257_);
lean_dec(v___y_256_);
lean_dec(v___y_255_);
lean_dec(v___y_253_);
lean_dec(v___y_252_);
lean_dec(v___y_251_);
lean_dec(v___y_250_);
lean_dec(v___y_249_);
lean_dec(v___y_248_);
lean_dec(v___y_247_);
if (v___x_270_ == 0)
{
lean_dec(v_head_112_);
v_x_111_ = v_tail_113_;
goto _start;
}
else
{
lean_dec_ref(v_x_110_);
v_x_110_ = v_head_112_;
v_x_111_ = v_tail_113_;
goto _start;
}
}
else
{
lean_object* v___x_273_; uint8_t v___x_274_; 
v___x_273_ = lean_unsigned_to_nat(0u);
v___x_274_ = lean_nat_dec_eq(v___y_261_, v___x_273_);
if (v___x_274_ == 0)
{
lean_object* v___x_275_; lean_object* v___x_276_; lean_object* v___x_277_; lean_object* v___x_278_; 
v___x_275_ = lean_nat_add(v___y_259_, v___y_261_);
v___x_276_ = lean_unsigned_to_nat(1u);
v___x_277_ = lean_nat_sub(v___x_275_, v___x_276_);
lean_dec(v___x_275_);
v___x_278_ = lean_nat_div(v___x_277_, v___y_261_);
lean_dec(v___x_277_);
v___y_220_ = v___y_247_;
v___y_221_ = v___y_248_;
v___y_222_ = v___y_249_;
v___y_223_ = v___y_250_;
v___y_224_ = v___y_251_;
v___y_225_ = v___y_252_;
v___y_226_ = v___y_253_;
v___y_227_ = v___y_255_;
v___y_228_ = v___y_256_;
v___y_229_ = v___y_258_;
v___y_230_ = v___y_257_;
v___y_231_ = v___y_259_;
v___y_232_ = v___y_260_;
v___y_233_ = v___y_261_;
v___y_234_ = v___y_262_;
v___y_235_ = v___y_263_;
v___y_236_ = v___y_265_;
v___y_237_ = v___x_278_;
goto v___jp_219_;
}
else
{
lean_inc(v___y_259_);
v___y_220_ = v___y_247_;
v___y_221_ = v___y_248_;
v___y_222_ = v___y_249_;
v___y_223_ = v___y_250_;
v___y_224_ = v___y_251_;
v___y_225_ = v___y_252_;
v___y_226_ = v___y_253_;
v___y_227_ = v___y_255_;
v___y_228_ = v___y_256_;
v___y_229_ = v___y_258_;
v___y_230_ = v___y_257_;
v___y_231_ = v___y_259_;
v___y_232_ = v___y_260_;
v___y_233_ = v___y_261_;
v___y_234_ = v___y_262_;
v___y_235_ = v___y_263_;
v___y_236_ = v___y_265_;
v___y_237_ = v___y_259_;
goto v___jp_219_;
}
}
}
v___jp_279_:
{
lean_object* v___x_300_; lean_object* v___x_301_; lean_object* v___x_302_; lean_object* v___x_303_; uint8_t v___x_304_; 
v___x_300_ = lean_nat_mul(v___y_290_, v___y_299_);
lean_dec(v___y_299_);
v___x_301_ = lean_nat_add(v___y_291_, v___x_300_);
lean_dec(v___x_300_);
v___x_302_ = lean_nat_mul(v___y_284_, v___x_301_);
lean_dec(v___x_301_);
v___x_303_ = lean_unsigned_to_nat(0u);
v___x_304_ = lean_nat_dec_eq(v___y_294_, v___x_303_);
if (v___x_304_ == 0)
{
lean_object* v___x_305_; lean_object* v___x_306_; lean_object* v___x_307_; lean_object* v___x_308_; 
v___x_305_ = lean_nat_add(v___y_286_, v___y_294_);
v___x_306_ = lean_unsigned_to_nat(1u);
v___x_307_ = lean_nat_sub(v___x_305_, v___x_306_);
lean_dec(v___x_305_);
v___x_308_ = lean_nat_div(v___x_307_, v___y_294_);
lean_dec(v___x_307_);
v___y_247_ = v___y_280_;
v___y_248_ = v___y_281_;
v___y_249_ = v___y_282_;
v___y_250_ = v___y_283_;
v___y_251_ = v___y_285_;
v___y_252_ = v___y_286_;
v___y_253_ = v___y_287_;
v___y_254_ = v___x_302_;
v___y_255_ = v___y_288_;
v___y_256_ = v___y_289_;
v___y_257_ = v___y_291_;
v___y_258_ = v___y_290_;
v___y_259_ = v___y_292_;
v___y_260_ = v___y_293_;
v___y_261_ = v___y_294_;
v___y_262_ = v___y_297_;
v___y_263_ = v___y_296_;
v___y_264_ = v___y_295_;
v___y_265_ = v___y_298_;
v___y_266_ = v___x_308_;
goto v___jp_246_;
}
else
{
lean_inc(v___y_286_);
v___y_247_ = v___y_280_;
v___y_248_ = v___y_281_;
v___y_249_ = v___y_282_;
v___y_250_ = v___y_283_;
v___y_251_ = v___y_285_;
v___y_252_ = v___y_286_;
v___y_253_ = v___y_287_;
v___y_254_ = v___x_302_;
v___y_255_ = v___y_288_;
v___y_256_ = v___y_289_;
v___y_257_ = v___y_291_;
v___y_258_ = v___y_290_;
v___y_259_ = v___y_292_;
v___y_260_ = v___y_293_;
v___y_261_ = v___y_294_;
v___y_262_ = v___y_297_;
v___y_263_ = v___y_296_;
v___y_264_ = v___y_295_;
v___y_265_ = v___y_298_;
v___y_266_ = v___y_286_;
goto v___jp_246_;
}
}
v___jp_309_:
{
lean_object* v___x_330_; lean_object* v___x_331_; lean_object* v___x_332_; lean_object* v___x_333_; uint8_t v___x_334_; 
v___x_330_ = lean_nat_mul(v___y_326_, v___y_329_);
lean_dec(v___y_329_);
v___x_331_ = lean_nat_add(v___y_312_, v___x_330_);
lean_dec(v___x_330_);
v___x_332_ = lean_nat_add(v___y_327_, v___x_331_);
lean_dec(v___x_331_);
lean_dec(v___y_327_);
v___x_333_ = lean_unsigned_to_nat(0u);
v___x_334_ = lean_nat_dec_eq(v___y_324_, v___x_333_);
if (v___x_334_ == 0)
{
lean_object* v___x_335_; lean_object* v___x_336_; lean_object* v___x_337_; lean_object* v___x_338_; 
v___x_335_ = lean_nat_add(v___y_310_, v___y_324_);
v___x_336_ = lean_unsigned_to_nat(1u);
v___x_337_ = lean_nat_sub(v___x_335_, v___x_336_);
lean_dec(v___x_335_);
v___x_338_ = lean_nat_div(v___x_337_, v___y_324_);
lean_dec(v___x_337_);
v___y_280_ = v___y_310_;
v___y_281_ = v___y_311_;
v___y_282_ = v___y_312_;
v___y_283_ = v___y_313_;
v___y_284_ = v___y_314_;
v___y_285_ = v___y_315_;
v___y_286_ = v___y_316_;
v___y_287_ = v___y_317_;
v___y_288_ = v___y_318_;
v___y_289_ = v___y_319_;
v___y_290_ = v___y_321_;
v___y_291_ = v___y_320_;
v___y_292_ = v___y_322_;
v___y_293_ = v___y_323_;
v___y_294_ = v___y_324_;
v___y_295_ = v___x_332_;
v___y_296_ = v___y_326_;
v___y_297_ = v___y_325_;
v___y_298_ = v___y_328_;
v___y_299_ = v___x_338_;
goto v___jp_279_;
}
else
{
lean_inc(v___y_310_);
v___y_280_ = v___y_310_;
v___y_281_ = v___y_311_;
v___y_282_ = v___y_312_;
v___y_283_ = v___y_313_;
v___y_284_ = v___y_314_;
v___y_285_ = v___y_315_;
v___y_286_ = v___y_316_;
v___y_287_ = v___y_317_;
v___y_288_ = v___y_318_;
v___y_289_ = v___y_319_;
v___y_290_ = v___y_321_;
v___y_291_ = v___y_320_;
v___y_292_ = v___y_322_;
v___y_293_ = v___y_323_;
v___y_294_ = v___y_324_;
v___y_295_ = v___x_332_;
v___y_296_ = v___y_326_;
v___y_297_ = v___y_325_;
v___y_298_ = v___y_328_;
v___y_299_ = v___y_310_;
goto v___jp_279_;
}
}
v___jp_339_:
{
lean_object* v___x_359_; lean_object* v___x_360_; lean_object* v___x_361_; lean_object* v___x_362_; uint8_t v___x_363_; 
v___x_359_ = lean_nat_mul(v___y_350_, v___y_358_);
lean_dec(v___y_358_);
v___x_360_ = lean_nat_add(v___y_349_, v___x_359_);
lean_dec(v___x_359_);
v___x_361_ = lean_nat_mul(v___y_344_, v___x_360_);
lean_dec(v___x_360_);
v___x_362_ = lean_unsigned_to_nat(0u);
v___x_363_ = lean_nat_dec_eq(v___y_354_, v___x_362_);
if (v___x_363_ == 0)
{
lean_object* v___x_364_; lean_object* v___x_365_; lean_object* v___x_366_; lean_object* v___x_367_; 
v___x_364_ = lean_nat_add(v___y_345_, v___y_354_);
v___x_365_ = lean_unsigned_to_nat(1u);
v___x_366_ = lean_nat_sub(v___x_364_, v___x_365_);
lean_dec(v___x_364_);
v___x_367_ = lean_nat_div(v___x_366_, v___y_354_);
lean_dec(v___x_366_);
v___y_310_ = v___y_340_;
v___y_311_ = v___y_341_;
v___y_312_ = v___y_342_;
v___y_313_ = v___y_343_;
v___y_314_ = v___y_344_;
v___y_315_ = v___y_345_;
v___y_316_ = v___y_346_;
v___y_317_ = v___y_347_;
v___y_318_ = v___y_348_;
v___y_319_ = v___y_349_;
v___y_320_ = v___y_351_;
v___y_321_ = v___y_350_;
v___y_322_ = v___y_352_;
v___y_323_ = v___y_353_;
v___y_324_ = v___y_354_;
v___y_325_ = v___y_356_;
v___y_326_ = v___y_355_;
v___y_327_ = v___x_361_;
v___y_328_ = v___y_357_;
v___y_329_ = v___x_367_;
goto v___jp_309_;
}
else
{
lean_inc(v___y_345_);
v___y_310_ = v___y_340_;
v___y_311_ = v___y_341_;
v___y_312_ = v___y_342_;
v___y_313_ = v___y_343_;
v___y_314_ = v___y_344_;
v___y_315_ = v___y_345_;
v___y_316_ = v___y_346_;
v___y_317_ = v___y_347_;
v___y_318_ = v___y_348_;
v___y_319_ = v___y_349_;
v___y_320_ = v___y_351_;
v___y_321_ = v___y_350_;
v___y_322_ = v___y_352_;
v___y_323_ = v___y_353_;
v___y_324_ = v___y_354_;
v___y_325_ = v___y_356_;
v___y_326_ = v___y_355_;
v___y_327_ = v___x_361_;
v___y_328_ = v___y_357_;
v___y_329_ = v___y_345_;
goto v___jp_309_;
}
}
v___jp_368_:
{
lean_object* v___x_390_; lean_object* v___x_391_; lean_object* v___x_392_; uint8_t v___x_393_; 
v___x_390_ = lean_nat_mul(v___y_386_, v___y_389_);
lean_dec(v___y_389_);
v___x_391_ = lean_nat_add(v___y_373_, v___x_390_);
lean_dec(v___x_390_);
v___x_392_ = lean_nat_add(v___y_372_, v___x_391_);
lean_dec(v___x_391_);
lean_dec(v___y_372_);
v___x_393_ = lean_nat_dec_lt(v___y_387_, v___x_392_);
lean_dec(v___x_392_);
lean_dec(v___y_387_);
if (v___x_393_ == 0)
{
lean_object* v___x_394_; uint8_t v___x_395_; 
v___x_394_ = lean_unsigned_to_nat(0u);
v___x_395_ = lean_nat_dec_eq(v___y_384_, v___x_394_);
if (v___x_395_ == 0)
{
lean_object* v___x_396_; lean_object* v___x_397_; lean_object* v___x_398_; lean_object* v___x_399_; 
v___x_396_ = lean_nat_add(v___y_382_, v___y_384_);
v___x_397_ = lean_unsigned_to_nat(1u);
v___x_398_ = lean_nat_sub(v___x_396_, v___x_397_);
lean_dec(v___x_396_);
v___x_399_ = lean_nat_div(v___x_398_, v___y_384_);
lean_dec(v___x_398_);
v___y_340_ = v___y_369_;
v___y_341_ = v___y_370_;
v___y_342_ = v___y_371_;
v___y_343_ = v___y_373_;
v___y_344_ = v___y_374_;
v___y_345_ = v___y_375_;
v___y_346_ = v___y_376_;
v___y_347_ = v___y_377_;
v___y_348_ = v___y_378_;
v___y_349_ = v___y_379_;
v___y_350_ = v___y_381_;
v___y_351_ = v___y_380_;
v___y_352_ = v___y_382_;
v___y_353_ = v___y_383_;
v___y_354_ = v___y_384_;
v___y_355_ = v___y_386_;
v___y_356_ = v___y_385_;
v___y_357_ = v___y_388_;
v___y_358_ = v___x_399_;
goto v___jp_339_;
}
else
{
lean_inc(v___y_382_);
v___y_340_ = v___y_369_;
v___y_341_ = v___y_370_;
v___y_342_ = v___y_371_;
v___y_343_ = v___y_373_;
v___y_344_ = v___y_374_;
v___y_345_ = v___y_375_;
v___y_346_ = v___y_376_;
v___y_347_ = v___y_377_;
v___y_348_ = v___y_378_;
v___y_349_ = v___y_379_;
v___y_350_ = v___y_381_;
v___y_351_ = v___y_380_;
v___y_352_ = v___y_382_;
v___y_353_ = v___y_383_;
v___y_354_ = v___y_384_;
v___y_355_ = v___y_386_;
v___y_356_ = v___y_385_;
v___y_357_ = v___y_388_;
v___y_358_ = v___y_382_;
goto v___jp_339_;
}
}
else
{
lean_dec_ref(v___y_388_);
lean_dec(v___y_385_);
lean_dec(v___y_383_);
lean_dec(v___y_382_);
lean_dec(v___y_380_);
lean_dec(v___y_379_);
lean_dec(v___y_378_);
lean_dec(v___y_377_);
lean_dec(v___y_376_);
lean_dec(v___y_375_);
lean_dec(v___y_373_);
lean_dec(v___y_371_);
lean_dec(v___y_370_);
lean_dec(v___y_369_);
if (v___x_393_ == 0)
{
lean_dec(v_head_112_);
v_x_111_ = v_tail_113_;
goto _start;
}
else
{
lean_dec_ref(v_x_110_);
v_x_110_ = v_head_112_;
v_x_111_ = v_tail_113_;
goto _start;
}
}
}
v___jp_402_:
{
lean_object* v___x_425_; lean_object* v___x_426_; lean_object* v___x_427_; lean_object* v___x_428_; lean_object* v___x_429_; lean_object* v___x_430_; uint8_t v___x_431_; 
v___x_425_ = lean_nat_mul(v___y_415_, v___y_424_);
lean_dec(v___y_424_);
v___x_426_ = lean_nat_add(v___y_416_, v___x_425_);
lean_dec(v___x_425_);
v___x_427_ = lean_nat_mul(v___y_407_, v___x_426_);
lean_dec(v___x_426_);
v___x_428_ = lean_nat_mul(v___y_412_, v___y_405_);
lean_dec(v___y_405_);
v___x_429_ = lean_nat_add(v___y_411_, v___x_428_);
lean_dec(v___x_428_);
lean_dec(v___y_411_);
v___x_430_ = lean_unsigned_to_nat(0u);
v___x_431_ = lean_nat_dec_eq(v___y_419_, v___x_430_);
if (v___x_431_ == 0)
{
lean_object* v___x_432_; lean_object* v___x_433_; lean_object* v___x_434_; lean_object* v___x_435_; 
v___x_432_ = lean_nat_add(v___y_409_, v___y_419_);
v___x_433_ = lean_unsigned_to_nat(1u);
v___x_434_ = lean_nat_sub(v___x_432_, v___x_433_);
lean_dec(v___x_432_);
v___x_435_ = lean_nat_div(v___x_434_, v___y_419_);
lean_dec(v___x_434_);
v___y_369_ = v___y_403_;
v___y_370_ = v___y_404_;
v___y_371_ = v___y_406_;
v___y_372_ = v___x_427_;
v___y_373_ = v___x_429_;
v___y_374_ = v___y_407_;
v___y_375_ = v___y_408_;
v___y_376_ = v___y_409_;
v___y_377_ = v___y_410_;
v___y_378_ = v___y_413_;
v___y_379_ = v___y_414_;
v___y_380_ = v___y_416_;
v___y_381_ = v___y_415_;
v___y_382_ = v___y_417_;
v___y_383_ = v___y_418_;
v___y_384_ = v___y_419_;
v___y_385_ = v___y_422_;
v___y_386_ = v___y_421_;
v___y_387_ = v___y_420_;
v___y_388_ = v___y_423_;
v___y_389_ = v___x_435_;
goto v___jp_368_;
}
else
{
lean_inc(v___y_409_);
v___y_369_ = v___y_403_;
v___y_370_ = v___y_404_;
v___y_371_ = v___y_406_;
v___y_372_ = v___x_427_;
v___y_373_ = v___x_429_;
v___y_374_ = v___y_407_;
v___y_375_ = v___y_408_;
v___y_376_ = v___y_409_;
v___y_377_ = v___y_410_;
v___y_378_ = v___y_413_;
v___y_379_ = v___y_414_;
v___y_380_ = v___y_416_;
v___y_381_ = v___y_415_;
v___y_382_ = v___y_417_;
v___y_383_ = v___y_418_;
v___y_384_ = v___y_419_;
v___y_385_ = v___y_422_;
v___y_386_ = v___y_421_;
v___y_387_ = v___y_420_;
v___y_388_ = v___y_423_;
v___y_389_ = v___y_409_;
goto v___jp_368_;
}
}
v___jp_436_:
{
lean_object* v_steadyCost_452_; lean_object* v_marshallingCost_453_; lean_object* v_setupCost_454_; lean_object* v_setupAllocations_455_; lean_object* v_residentBytes_456_; lean_object* v_temporaryBytes_457_; lean_object* v_allocations_458_; lean_object* v___x_459_; lean_object* v___x_460_; lean_object* v___x_461_; lean_object* v___x_462_; lean_object* v___x_463_; lean_object* v___x_464_; lean_object* v___x_465_; uint8_t v___x_466_; 
v_steadyCost_452_ = lean_ctor_get(v___y_450_, 3);
v_marshallingCost_453_ = lean_ctor_get(v___y_450_, 4);
lean_inc(v_marshallingCost_453_);
v_setupCost_454_ = lean_ctor_get(v___y_450_, 5);
lean_inc(v_setupCost_454_);
v_setupAllocations_455_ = lean_ctor_get(v___y_450_, 6);
lean_inc(v_setupAllocations_455_);
v_residentBytes_456_ = lean_ctor_get(v___y_450_, 7);
lean_inc(v_residentBytes_456_);
v_temporaryBytes_457_ = lean_ctor_get(v___y_450_, 8);
lean_inc(v_temporaryBytes_457_);
v_allocations_458_ = lean_ctor_get(v___y_450_, 9);
lean_inc(v_allocations_458_);
v___x_459_ = lean_nat_mul(v___y_449_, v___y_451_);
lean_dec(v___y_451_);
v___x_460_ = lean_nat_add(v___y_438_, v___x_459_);
lean_dec(v___x_459_);
v___x_461_ = lean_nat_add(v___y_439_, v___x_460_);
lean_dec(v___x_460_);
lean_dec(v___y_439_);
v___x_462_ = lean_nat_add(v_steadyCost_452_, v_marshallingCost_453_);
v___x_463_ = lean_nat_mul(v___y_443_, v_allocations_458_);
v___x_464_ = lean_nat_add(v___x_462_, v___x_463_);
lean_dec(v___x_463_);
lean_dec(v___x_462_);
v___x_465_ = lean_unsigned_to_nat(0u);
v___x_466_ = lean_nat_dec_eq(v___y_447_, v___x_465_);
if (v___x_466_ == 0)
{
lean_object* v___x_467_; lean_object* v___x_468_; lean_object* v___x_469_; lean_object* v___x_470_; 
v___x_467_ = lean_nat_add(v_temporaryBytes_457_, v___y_447_);
v___x_468_ = lean_unsigned_to_nat(1u);
v___x_469_ = lean_nat_sub(v___x_467_, v___x_468_);
lean_dec(v___x_467_);
v___x_470_ = lean_nat_div(v___x_469_, v___y_447_);
lean_dec(v___x_469_);
v___y_403_ = v_temporaryBytes_457_;
v___y_404_ = v___y_437_;
v___y_405_ = v_setupAllocations_455_;
v___y_406_ = v___y_438_;
v___y_407_ = v___y_440_;
v___y_408_ = v___y_441_;
v___y_409_ = v_residentBytes_456_;
v___y_410_ = v___y_442_;
v___y_411_ = v_setupCost_454_;
v___y_412_ = v___y_443_;
v___y_413_ = v_allocations_458_;
v___y_414_ = v___y_444_;
v___y_415_ = v___y_445_;
v___y_416_ = v___x_464_;
v___y_417_ = v___y_446_;
v___y_418_ = v_marshallingCost_453_;
v___y_419_ = v___y_447_;
v___y_420_ = v___x_461_;
v___y_421_ = v___y_449_;
v___y_422_ = v___y_448_;
v___y_423_ = v___y_450_;
v___y_424_ = v___x_470_;
goto v___jp_402_;
}
else
{
lean_inc(v_temporaryBytes_457_);
v___y_403_ = v_temporaryBytes_457_;
v___y_404_ = v___y_437_;
v___y_405_ = v_setupAllocations_455_;
v___y_406_ = v___y_438_;
v___y_407_ = v___y_440_;
v___y_408_ = v___y_441_;
v___y_409_ = v_residentBytes_456_;
v___y_410_ = v___y_442_;
v___y_411_ = v_setupCost_454_;
v___y_412_ = v___y_443_;
v___y_413_ = v_allocations_458_;
v___y_414_ = v___y_444_;
v___y_415_ = v___y_445_;
v___y_416_ = v___x_464_;
v___y_417_ = v___y_446_;
v___y_418_ = v_marshallingCost_453_;
v___y_419_ = v___y_447_;
v___y_420_ = v___x_461_;
v___y_421_ = v___y_449_;
v___y_422_ = v___y_448_;
v___y_423_ = v___y_450_;
v___y_424_ = v_temporaryBytes_457_;
goto v___jp_402_;
}
}
v___jp_471_:
{
lean_object* v___x_487_; lean_object* v___x_488_; lean_object* v___x_489_; lean_object* v___x_490_; lean_object* v___x_491_; lean_object* v___x_492_; uint8_t v___x_493_; 
v___x_487_ = lean_nat_mul(v___y_480_, v___y_486_);
lean_dec(v___y_486_);
v___x_488_ = lean_nat_add(v___y_479_, v___x_487_);
lean_dec(v___x_487_);
v___x_489_ = lean_nat_mul(v___y_474_, v___x_488_);
lean_dec(v___x_488_);
v___x_490_ = lean_nat_mul(v___y_477_, v___y_478_);
lean_dec(v___y_478_);
v___x_491_ = lean_nat_add(v___y_473_, v___x_490_);
lean_dec(v___x_490_);
lean_dec(v___y_473_);
v___x_492_ = lean_unsigned_to_nat(0u);
v___x_493_ = lean_nat_dec_eq(v___y_482_, v___x_492_);
if (v___x_493_ == 0)
{
lean_object* v___x_494_; lean_object* v___x_495_; lean_object* v___x_496_; lean_object* v___x_497_; 
v___x_494_ = lean_nat_add(v___y_475_, v___y_482_);
v___x_495_ = lean_unsigned_to_nat(1u);
v___x_496_ = lean_nat_sub(v___x_494_, v___x_495_);
lean_dec(v___x_494_);
v___x_497_ = lean_nat_div(v___x_496_, v___y_482_);
lean_dec(v___x_496_);
v___y_437_ = v___y_472_;
v___y_438_ = v___x_491_;
v___y_439_ = v___x_489_;
v___y_440_ = v___y_474_;
v___y_441_ = v___y_475_;
v___y_442_ = v___y_476_;
v___y_443_ = v___y_477_;
v___y_444_ = v___y_479_;
v___y_445_ = v___y_480_;
v___y_446_ = v___y_481_;
v___y_447_ = v___y_482_;
v___y_448_ = v___y_483_;
v___y_449_ = v___y_484_;
v___y_450_ = v___y_485_;
v___y_451_ = v___x_497_;
goto v___jp_436_;
}
else
{
lean_inc(v___y_475_);
v___y_437_ = v___y_472_;
v___y_438_ = v___x_491_;
v___y_439_ = v___x_489_;
v___y_440_ = v___y_474_;
v___y_441_ = v___y_475_;
v___y_442_ = v___y_476_;
v___y_443_ = v___y_477_;
v___y_444_ = v___y_479_;
v___y_445_ = v___y_480_;
v___y_446_ = v___y_481_;
v___y_447_ = v___y_482_;
v___y_448_ = v___y_483_;
v___y_449_ = v___y_484_;
v___y_450_ = v___y_485_;
v___y_451_ = v___y_475_;
goto v___jp_436_;
}
}
v___jp_508_:
{
if (v___y_509_ == 0)
{
lean_dec(v_head_112_);
v_x_111_ = v_tail_113_;
goto _start;
}
else
{
lean_object* v_estimate_511_; lean_object* v_expectedCalls_512_; lean_object* v_allocationPenalty_513_; lean_object* v_memoryBlockBytes_514_; lean_object* v_temporaryBlockPenalty_515_; lean_object* v_residentBlockPenalty_516_; lean_object* v___x_517_; lean_object* v___x_518_; lean_object* v___x_519_; lean_object* v___x_520_; uint8_t v___x_521_; 
v_estimate_511_ = lean_ctor_get(v_x_110_, 0);
v_expectedCalls_512_ = lean_ctor_get(v___x_507_, 0);
v_allocationPenalty_513_ = lean_ctor_get(v___x_507_, 1);
v_memoryBlockBytes_514_ = lean_ctor_get(v___x_507_, 2);
v_temporaryBlockPenalty_515_ = lean_ctor_get(v___x_507_, 3);
v_residentBlockPenalty_516_ = lean_ctor_get(v___x_507_, 4);
v___x_517_ = lean_nat_add(v_steadyCost_500_, v_marshallingCost_501_);
v___x_518_ = lean_nat_mul(v_allocationPenalty_513_, v_allocations_506_);
v___x_519_ = lean_nat_add(v___x_517_, v___x_518_);
lean_dec(v___x_518_);
lean_dec(v___x_517_);
v___x_520_ = lean_unsigned_to_nat(0u);
v___x_521_ = lean_nat_dec_eq(v_memoryBlockBytes_514_, v___x_520_);
if (v___x_521_ == 0)
{
lean_object* v___x_522_; lean_object* v___x_523_; lean_object* v___x_524_; lean_object* v___x_525_; 
v___x_522_ = lean_nat_add(v_temporaryBytes_505_, v_memoryBlockBytes_514_);
v___x_523_ = lean_unsigned_to_nat(1u);
v___x_524_ = lean_nat_sub(v___x_522_, v___x_523_);
lean_dec(v___x_522_);
v___x_525_ = lean_nat_div(v___x_524_, v_memoryBlockBytes_514_);
lean_dec(v___x_524_);
lean_inc_ref(v_estimate_511_);
lean_inc(v_allocations_506_);
lean_inc(v_temporaryBytes_505_);
lean_inc(v_setupAllocations_503_);
lean_inc(v_marshallingCost_501_);
lean_inc(v_residentBytes_504_);
lean_inc(v_setupCost_502_);
lean_inc(v_kind_499_);
v___y_472_ = v_kind_499_;
v___y_473_ = v_setupCost_502_;
v___y_474_ = v_expectedCalls_512_;
v___y_475_ = v_residentBytes_504_;
v___y_476_ = v_marshallingCost_501_;
v___y_477_ = v_allocationPenalty_513_;
v___y_478_ = v_setupAllocations_503_;
v___y_479_ = v___x_519_;
v___y_480_ = v_temporaryBlockPenalty_515_;
v___y_481_ = v_temporaryBytes_505_;
v___y_482_ = v_memoryBlockBytes_514_;
v___y_483_ = v_allocations_506_;
v___y_484_ = v_residentBlockPenalty_516_;
v___y_485_ = v_estimate_511_;
v___y_486_ = v___x_525_;
goto v___jp_471_;
}
else
{
lean_inc_ref(v_estimate_511_);
lean_inc(v_allocations_506_);
lean_inc_n(v_temporaryBytes_505_, 2);
lean_inc(v_setupAllocations_503_);
lean_inc(v_marshallingCost_501_);
lean_inc(v_residentBytes_504_);
lean_inc(v_setupCost_502_);
lean_inc(v_kind_499_);
v___y_472_ = v_kind_499_;
v___y_473_ = v_setupCost_502_;
v___y_474_ = v_expectedCalls_512_;
v___y_475_ = v_residentBytes_504_;
v___y_476_ = v_marshallingCost_501_;
v___y_477_ = v_allocationPenalty_513_;
v___y_478_ = v_setupAllocations_503_;
v___y_479_ = v___x_519_;
v___y_480_ = v_temporaryBlockPenalty_515_;
v___y_481_ = v_temporaryBytes_505_;
v___y_482_ = v_memoryBlockBytes_514_;
v___y_483_ = v_allocations_506_;
v___y_484_ = v_residentBlockPenalty_516_;
v___y_485_ = v_estimate_511_;
v___y_486_ = v_temporaryBytes_505_;
goto v___jp_471_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_block1024___lam__0(lean_object* v___x_530_, uint8_t v___x_531_, lean_object* v_x_532_){
_start:
{
lean_object* v___x_533_; lean_object* v_alternatives_534_; lean_object* v_baseline_535_; lean_object* v___x_536_; 
v___x_533_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Plan_automaticSqrtCandidates(v___x_530_, v___x_531_);
v_alternatives_534_ = lean_ctor_get(v___x_533_, 0);
lean_inc(v_alternatives_534_);
v_baseline_535_ = lean_ctor_get(v___x_533_, 1);
lean_inc(v_baseline_535_);
lean_dec_ref(v___x_533_);
v___x_536_ = l_List_foldl___at___00BalancedSqrt_block1024_spec__0(v_baseline_535_, v_alternatives_534_);
return v___x_536_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_block1024___lam__0___boxed(lean_object* v___x_537_, lean_object* v___x_538_, lean_object* v_x_539_){
_start:
{
uint8_t v___x_7363__boxed_540_; lean_object* v_res_541_; 
v___x_7363__boxed_540_ = lean_unbox(v___x_538_);
v_res_541_ = l_BalancedSqrt_block1024___lam__0(v___x_537_, v___x_7363__boxed_540_, v_x_539_);
return v_res_541_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1(lean_object* v_x_547_){
_start:
{
lean_object* v___x_548_; lean_object* v___x_549_; 
v___x_548_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1___closed__0));
v___x_549_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic(v___x_548_, v_x_547_);
return v___x_549_;
}
}
static lean_object* _init_l_BalancedSqrt_block1024___closed__3(void){
_start:
{
lean_object* v___x_561_; uint8_t v___x_562_; lean_object* v___x_563_; lean_object* v___x_564_; 
v___x_561_ = ((lean_object*)(l_BalancedSqrt_block1024___closed__2));
v___x_562_ = 4;
v___x_563_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1___closed__0));
v___x_564_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep_configuredBenchmarkCarrier(v___x_563_, v___x_562_, v___x_561_);
return v___x_564_;
}
}
static lean_object* _init_l_BalancedSqrt_block1024___closed__4(void){
_start:
{
lean_object* v___x_565_; lean_object* v___x_566_; 
v___x_565_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__3, &l_BalancedSqrt_block1024___closed__3_once, _init_l_BalancedSqrt_block1024___closed__3);
v___x_566_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep_benchmarkExecFloatInhabited___redArg(v___x_565_);
return v___x_566_;
}
}
static uint8_t _init_l_BalancedSqrt_block1024___closed__5(void){
_start:
{
uint8_t v___x_567_; uint8_t v___x_568_; lean_object* v___x_569_; lean_object* v___x_570_; uint8_t v___x_571_; 
v___x_567_ = 4;
v___x_568_ = 4;
v___x_569_ = lp_floatlib_FloatLib_Floats_ExecFloat_Backend_Policy_throughput;
v___x_570_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1___closed__0));
v___x_571_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Plan_firstOrderSelected(v___x_570_, v___x_569_, v___x_568_, v___x_567_);
return v___x_571_;
}
}
static lean_object* _init_l_BalancedSqrt_block1024___closed__7(void){
_start:
{
lean_object* v___f_576_; lean_object* v_selection_577_; 
v___f_576_ = ((lean_object*)(l_BalancedSqrt_block1024___closed__6));
v_selection_577_ = lean_mk_thunk(v___f_576_);
return v_selection_577_;
}
}
static lean_object* _init_l_BalancedSqrt_block1024___closed__8(void){
_start:
{
lean_object* v_selection_578_; lean_object* v___x_579_; 
v_selection_578_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__7, &l_BalancedSqrt_block1024___closed__7_once, _init_l_BalancedSqrt_block1024___closed__7);
v___x_579_ = lean_thunk_get_own(v_selection_578_);
return v___x_579_;
}
}
static lean_object* _init_l_BalancedSqrt_block1024___closed__9(void){
_start:
{
uint8_t v___x_580_; lean_object* v___x_581_; lean_object* v___x_582_; 
v___x_580_ = 4;
v___x_581_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1___closed__0));
v___x_582_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Descriptor_Plan_structuralRoute_x3f(v___x_581_, v___x_580_);
return v___x_582_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_block1024(lean_object* v_x_583_, uint64_t v_x_584_, lean_object* v_x_585_, lean_object* v_x_586_){
_start:
{
lean_object* v_zero_587_; uint8_t v_isZero_588_; 
v_zero_587_ = lean_unsigned_to_nat(0u);
v_isZero_588_ = lean_nat_dec_eq(v_x_583_, v_zero_587_);
if (v_isZero_588_ == 1)
{
lean_dec(v_x_583_);
return v_x_586_;
}
else
{
uint64_t v_sink_589_; uint64_t v_trace_590_; lean_object* v___x_592_; uint8_t v_isShared_593_; uint8_t v_isSharedCheck_626_; 
v_sink_589_ = lean_ctor_get_uint64(v_x_586_, 0);
v_trace_590_ = lean_ctor_get_uint64(v_x_586_, 8);
v_isSharedCheck_626_ = !lean_is_exclusive(v_x_586_);
if (v_isSharedCheck_626_ == 0)
{
v___x_592_ = v_x_586_;
v_isShared_593_ = v_isSharedCheck_626_;
goto v_resetjp_591_;
}
else
{
lean_dec(v_x_586_);
v___x_592_ = lean_box(0);
v_isShared_593_ = v_isSharedCheck_626_;
goto v_resetjp_591_;
}
v_resetjp_591_:
{
lean_object* v_one_594_; lean_object* v_n_595_; lean_object* v_index_596_; lean_object* v___y_598_; lean_object* v___y_614_; lean_object* v___x_616_; lean_object* v___x_617_; uint8_t v___x_618_; 
v_one_594_ = lean_unsigned_to_nat(1u);
v_n_595_ = lean_nat_sub(v_x_583_, v_one_594_);
lean_dec(v_x_583_);
v_index_596_ = l_BalancedSqrt_nextUnused(v_x_584_, v_sink_589_);
v___x_616_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__4, &l_BalancedSqrt_block1024___closed__4_once, _init_l_BalancedSqrt_block1024___closed__4);
v___x_617_ = lean_array_get_borrowed(v___x_616_, v_x_585_, v_index_596_);
v___x_618_ = lean_uint8_once(&l_BalancedSqrt_block1024___closed__5, &l_BalancedSqrt_block1024___closed__5_once, _init_l_BalancedSqrt_block1024___closed__5);
if (v___x_618_ == 0)
{
lean_object* v___x_619_; lean_object* v_run_620_; lean_object* v___x_621_; 
v___x_619_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__8, &l_BalancedSqrt_block1024___closed__8_once, _init_l_BalancedSqrt_block1024___closed__8);
v_run_620_ = lean_ctor_get(v___x_619_, 1);
lean_inc(v_run_620_);
lean_inc(v___x_617_);
v___x_621_ = lean_apply_1(v_run_620_, v___x_617_);
v___y_598_ = v___x_621_;
goto v___jp_597_;
}
else
{
lean_object* v___x_622_; 
v___x_622_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__9, &l_BalancedSqrt_block1024___closed__9_once, _init_l_BalancedSqrt_block1024___closed__9);
if (lean_obj_tag(v___x_622_) == 1)
{
lean_object* v_val_623_; uint8_t v___x_624_; 
v_val_623_ = lean_ctor_get(v___x_622_, 0);
v___x_624_ = lean_unbox(v_val_623_);
if (v___x_624_ == 2)
{
lean_object* v___x_625_; 
lean_inc(v___x_617_);
v___x_625_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1(v___x_617_);
v___y_598_ = v___x_625_;
goto v___jp_597_;
}
else
{
lean_inc(v___x_617_);
v___y_614_ = v___x_617_;
goto v___jp_613_;
}
}
else
{
lean_inc(v___x_617_);
v___y_614_ = v___x_617_;
goto v___jp_613_;
}
}
v___jp_597_:
{
uint64_t v___x_599_; uint64_t v___x_600_; uint64_t v___x_601_; uint64_t v___x_602_; uint64_t v___x_603_; uint64_t v___x_604_; uint64_t v___x_605_; uint64_t v___x_606_; uint64_t v___x_607_; uint64_t v___x_608_; lean_object* v___x_610_; 
v___x_599_ = 1ULL;
v___x_600_ = lean_uint64_of_nat(v_index_596_);
lean_dec(v_index_596_);
v___x_601_ = lean_uint64_shift_left(v___x_599_, v___x_600_);
v___x_602_ = lean_uint64_lor(v_x_584_, v___x_601_);
v___x_603_ = lean_uint64_of_nat(v___y_598_);
lean_dec(v___y_598_);
v___x_604_ = lean_uint64_xor(v_sink_589_, v___x_603_);
v___x_605_ = 1099511628211ULL;
v___x_606_ = lean_uint64_mul(v___x_604_, v___x_605_);
v___x_607_ = lean_uint64_xor(v_trace_590_, v___x_600_);
v___x_608_ = lean_uint64_mul(v___x_607_, v___x_605_);
if (v_isShared_593_ == 0)
{
v___x_610_ = v___x_592_;
goto v_reusejp_609_;
}
else
{
lean_object* v_reuseFailAlloc_612_; 
v_reuseFailAlloc_612_ = lean_alloc_ctor(0, 0, 16);
v___x_610_ = v_reuseFailAlloc_612_;
goto v_reusejp_609_;
}
v_reusejp_609_:
{
lean_ctor_set_uint64(v___x_610_, 0, v___x_606_);
lean_ctor_set_uint64(v___x_610_, 8, v___x_608_);
v_x_583_ = v_n_595_;
v_x_584_ = v___x_602_;
v_x_586_ = v___x_610_;
goto _start;
}
}
v___jp_613_:
{
lean_object* v___x_615_; 
v___x_615_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1(v___y_614_);
v___y_598_ = v___x_615_;
goto v___jp_597_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_block1024___boxed(lean_object* v_x_627_, lean_object* v_x_628_, lean_object* v_x_629_, lean_object* v_x_630_){
_start:
{
uint64_t v_x_7456__boxed_631_; lean_object* v_res_632_; 
v_x_7456__boxed_631_ = lean_unbox_uint64(v_x_628_);
lean_dec_ref(v_x_628_);
v_res_632_ = l_BalancedSqrt_block1024(v_x_627_, v_x_7456__boxed_631_, v_x_629_, v_x_630_);
lean_dec_ref(v_x_629_);
return v_res_632_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block2048_spec__1(lean_object* v_x_633_){
_start:
{
lean_object* v___x_634_; 
v___x_634_ = lean_box(0);
return v___x_634_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block2048_spec__1___boxed(lean_object* v_x_635_){
_start:
{
lean_object* v_res_636_; 
v_res_636_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block2048_spec__1(v_x_635_);
lean_dec(v_x_635_);
return v_res_636_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0(lean_object* v_x_642_){
_start:
{
lean_object* v___x_643_; lean_object* v___x_644_; 
v___x_643_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0___closed__0));
v___x_644_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic(v___x_643_, v_x_642_);
return v___x_644_;
}
}
static lean_object* _init_l_BalancedSqrt_block2048___closed__3(void){
_start:
{
lean_object* v___x_656_; uint8_t v___x_657_; lean_object* v___x_658_; lean_object* v___x_659_; 
v___x_656_ = ((lean_object*)(l_BalancedSqrt_block2048___closed__2));
v___x_657_ = 4;
v___x_658_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0___closed__0));
v___x_659_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep_configuredBenchmarkCarrier(v___x_658_, v___x_657_, v___x_656_);
return v___x_659_;
}
}
static lean_object* _init_l_BalancedSqrt_block2048___closed__4(void){
_start:
{
lean_object* v___x_660_; lean_object* v___x_661_; 
v___x_660_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__3, &l_BalancedSqrt_block2048___closed__3_once, _init_l_BalancedSqrt_block2048___closed__3);
v___x_661_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep_benchmarkExecFloatInhabited___redArg(v___x_660_);
return v___x_661_;
}
}
static uint8_t _init_l_BalancedSqrt_block2048___closed__5(void){
_start:
{
uint8_t v___x_662_; uint8_t v___x_663_; lean_object* v___x_664_; lean_object* v___x_665_; uint8_t v___x_666_; 
v___x_662_ = 4;
v___x_663_ = 4;
v___x_664_ = lp_floatlib_FloatLib_Floats_ExecFloat_Backend_Policy_throughput;
v___x_665_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0___closed__0));
v___x_666_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Plan_firstOrderSelected(v___x_665_, v___x_664_, v___x_663_, v___x_662_);
return v___x_666_;
}
}
static lean_object* _init_l_BalancedSqrt_block2048___closed__7(void){
_start:
{
lean_object* v___f_671_; lean_object* v_selection_672_; 
v___f_671_ = ((lean_object*)(l_BalancedSqrt_block2048___closed__6));
v_selection_672_ = lean_mk_thunk(v___f_671_);
return v_selection_672_;
}
}
static lean_object* _init_l_BalancedSqrt_block2048___closed__8(void){
_start:
{
lean_object* v_selection_673_; lean_object* v___x_674_; 
v_selection_673_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__7, &l_BalancedSqrt_block2048___closed__7_once, _init_l_BalancedSqrt_block2048___closed__7);
v___x_674_ = lean_thunk_get_own(v_selection_673_);
return v___x_674_;
}
}
static lean_object* _init_l_BalancedSqrt_block2048___closed__9(void){
_start:
{
uint8_t v___x_675_; lean_object* v___x_676_; lean_object* v___x_677_; 
v___x_675_ = 4;
v___x_676_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0___closed__0));
v___x_677_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Descriptor_Plan_structuralRoute_x3f(v___x_676_, v___x_675_);
return v___x_677_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_block2048(lean_object* v_x_678_, uint64_t v_x_679_, lean_object* v_x_680_, lean_object* v_x_681_){
_start:
{
lean_object* v_zero_682_; uint8_t v_isZero_683_; 
v_zero_682_ = lean_unsigned_to_nat(0u);
v_isZero_683_ = lean_nat_dec_eq(v_x_678_, v_zero_682_);
if (v_isZero_683_ == 1)
{
lean_dec(v_x_678_);
return v_x_681_;
}
else
{
uint64_t v_sink_684_; uint64_t v_trace_685_; lean_object* v___x_687_; uint8_t v_isShared_688_; uint8_t v_isSharedCheck_721_; 
v_sink_684_ = lean_ctor_get_uint64(v_x_681_, 0);
v_trace_685_ = lean_ctor_get_uint64(v_x_681_, 8);
v_isSharedCheck_721_ = !lean_is_exclusive(v_x_681_);
if (v_isSharedCheck_721_ == 0)
{
v___x_687_ = v_x_681_;
v_isShared_688_ = v_isSharedCheck_721_;
goto v_resetjp_686_;
}
else
{
lean_dec(v_x_681_);
v___x_687_ = lean_box(0);
v_isShared_688_ = v_isSharedCheck_721_;
goto v_resetjp_686_;
}
v_resetjp_686_:
{
lean_object* v_one_689_; lean_object* v_n_690_; lean_object* v_index_691_; lean_object* v___y_693_; lean_object* v___y_709_; lean_object* v___x_711_; lean_object* v___x_712_; uint8_t v___x_713_; 
v_one_689_ = lean_unsigned_to_nat(1u);
v_n_690_ = lean_nat_sub(v_x_678_, v_one_689_);
lean_dec(v_x_678_);
v_index_691_ = l_BalancedSqrt_nextUnused(v_x_679_, v_sink_684_);
v___x_711_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__4, &l_BalancedSqrt_block2048___closed__4_once, _init_l_BalancedSqrt_block2048___closed__4);
v___x_712_ = lean_array_get_borrowed(v___x_711_, v_x_680_, v_index_691_);
v___x_713_ = lean_uint8_once(&l_BalancedSqrt_block2048___closed__5, &l_BalancedSqrt_block2048___closed__5_once, _init_l_BalancedSqrt_block2048___closed__5);
if (v___x_713_ == 0)
{
lean_object* v___x_714_; lean_object* v_run_715_; lean_object* v___x_716_; 
v___x_714_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__8, &l_BalancedSqrt_block2048___closed__8_once, _init_l_BalancedSqrt_block2048___closed__8);
v_run_715_ = lean_ctor_get(v___x_714_, 1);
lean_inc(v_run_715_);
lean_inc(v___x_712_);
v___x_716_ = lean_apply_1(v_run_715_, v___x_712_);
v___y_693_ = v___x_716_;
goto v___jp_692_;
}
else
{
lean_object* v___x_717_; 
v___x_717_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__9, &l_BalancedSqrt_block2048___closed__9_once, _init_l_BalancedSqrt_block2048___closed__9);
if (lean_obj_tag(v___x_717_) == 1)
{
lean_object* v_val_718_; uint8_t v___x_719_; 
v_val_718_ = lean_ctor_get(v___x_717_, 0);
v___x_719_ = lean_unbox(v_val_718_);
if (v___x_719_ == 2)
{
lean_object* v___x_720_; 
lean_inc(v___x_712_);
v___x_720_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0(v___x_712_);
v___y_693_ = v___x_720_;
goto v___jp_692_;
}
else
{
lean_inc(v___x_712_);
v___y_709_ = v___x_712_;
goto v___jp_708_;
}
}
else
{
lean_inc(v___x_712_);
v___y_709_ = v___x_712_;
goto v___jp_708_;
}
}
v___jp_692_:
{
uint64_t v___x_694_; uint64_t v___x_695_; uint64_t v___x_696_; uint64_t v___x_697_; uint64_t v___x_698_; uint64_t v___x_699_; uint64_t v___x_700_; uint64_t v___x_701_; uint64_t v___x_702_; uint64_t v___x_703_; lean_object* v___x_705_; 
v___x_694_ = 1ULL;
v___x_695_ = lean_uint64_of_nat(v_index_691_);
lean_dec(v_index_691_);
v___x_696_ = lean_uint64_shift_left(v___x_694_, v___x_695_);
v___x_697_ = lean_uint64_lor(v_x_679_, v___x_696_);
v___x_698_ = lean_uint64_of_nat(v___y_693_);
lean_dec(v___y_693_);
v___x_699_ = lean_uint64_xor(v_sink_684_, v___x_698_);
v___x_700_ = 1099511628211ULL;
v___x_701_ = lean_uint64_mul(v___x_699_, v___x_700_);
v___x_702_ = lean_uint64_xor(v_trace_685_, v___x_695_);
v___x_703_ = lean_uint64_mul(v___x_702_, v___x_700_);
if (v_isShared_688_ == 0)
{
v___x_705_ = v___x_687_;
goto v_reusejp_704_;
}
else
{
lean_object* v_reuseFailAlloc_707_; 
v_reuseFailAlloc_707_ = lean_alloc_ctor(0, 0, 16);
v___x_705_ = v_reuseFailAlloc_707_;
goto v_reusejp_704_;
}
v_reusejp_704_:
{
lean_ctor_set_uint64(v___x_705_, 0, v___x_701_);
lean_ctor_set_uint64(v___x_705_, 8, v___x_703_);
v_x_678_ = v_n_690_;
v_x_679_ = v___x_697_;
v_x_681_ = v___x_705_;
goto _start;
}
}
v___jp_708_:
{
lean_object* v___x_710_; 
v___x_710_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0(v___y_709_);
v___y_693_ = v___x_710_;
goto v___jp_692_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_block2048___boxed(lean_object* v_x_722_, lean_object* v_x_723_, lean_object* v_x_724_, lean_object* v_x_725_){
_start:
{
uint64_t v_x_5861__boxed_726_; lean_object* v_res_727_; 
v_x_5861__boxed_726_ = lean_unbox_uint64(v_x_723_);
lean_dec_ref(v_x_723_);
v_res_727_ = l_BalancedSqrt_block2048(v_x_722_, v_x_5861__boxed_726_, v_x_724_, v_x_725_);
lean_dec_ref(v_x_724_);
return v_res_727_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block4096_spec__1(lean_object* v_x_728_){
_start:
{
lean_object* v___x_729_; 
v___x_729_ = lean_box(0);
return v___x_729_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block4096_spec__1___boxed(lean_object* v_x_730_){
_start:
{
lean_object* v_res_731_; 
v_res_731_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_NativePair_sqrtNormal_x3f___at___00BalancedSqrt_block4096_spec__1(v_x_730_);
lean_dec(v_x_730_);
return v_res_731_;
}
}
LEAN_EXPORT lean_object* l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0(lean_object* v_x_737_){
_start:
{
lean_object* v___x_738_; lean_object* v___x_739_; 
v___x_738_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0___closed__0));
v___x_739_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_generic(v___x_738_, v_x_737_);
return v___x_739_;
}
}
static lean_object* _init_l_BalancedSqrt_block4096___closed__3(void){
_start:
{
lean_object* v___x_751_; uint8_t v___x_752_; lean_object* v___x_753_; lean_object* v___x_754_; 
v___x_751_ = ((lean_object*)(l_BalancedSqrt_block4096___closed__2));
v___x_752_ = 4;
v___x_753_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0___closed__0));
v___x_754_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep_configuredBenchmarkCarrier(v___x_753_, v___x_752_, v___x_751_);
return v___x_754_;
}
}
static lean_object* _init_l_BalancedSqrt_block4096___closed__4(void){
_start:
{
lean_object* v___x_755_; lean_object* v___x_756_; 
v___x_755_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__3, &l_BalancedSqrt_block4096___closed__3_once, _init_l_BalancedSqrt_block4096___closed__3);
v___x_756_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep_benchmarkExecFloatInhabited___redArg(v___x_755_);
return v___x_756_;
}
}
static uint8_t _init_l_BalancedSqrt_block4096___closed__5(void){
_start:
{
uint8_t v___x_757_; uint8_t v___x_758_; lean_object* v___x_759_; lean_object* v___x_760_; uint8_t v___x_761_; 
v___x_757_ = 4;
v___x_758_ = 4;
v___x_759_ = lp_floatlib_FloatLib_Floats_ExecFloat_Backend_Policy_throughput;
v___x_760_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0___closed__0));
v___x_761_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Configured_Plan_firstOrderSelected(v___x_760_, v___x_759_, v___x_758_, v___x_757_);
return v___x_761_;
}
}
static lean_object* _init_l_BalancedSqrt_block4096___closed__7(void){
_start:
{
lean_object* v___f_766_; lean_object* v_selection_767_; 
v___f_766_ = ((lean_object*)(l_BalancedSqrt_block4096___closed__6));
v_selection_767_ = lean_mk_thunk(v___f_766_);
return v_selection_767_;
}
}
static lean_object* _init_l_BalancedSqrt_block4096___closed__8(void){
_start:
{
lean_object* v_selection_768_; lean_object* v___x_769_; 
v_selection_768_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__7, &l_BalancedSqrt_block4096___closed__7_once, _init_l_BalancedSqrt_block4096___closed__7);
v___x_769_ = lean_thunk_get_own(v_selection_768_);
return v___x_769_;
}
}
static lean_object* _init_l_BalancedSqrt_block4096___closed__9(void){
_start:
{
uint8_t v___x_770_; lean_object* v___x_771_; lean_object* v___x_772_; 
v___x_770_ = 4;
v___x_771_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0___closed__0));
v___x_772_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Descriptor_Plan_structuralRoute_x3f(v___x_771_, v___x_770_);
return v___x_772_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_block4096(lean_object* v_x_773_, uint64_t v_x_774_, lean_object* v_x_775_, lean_object* v_x_776_){
_start:
{
lean_object* v_zero_777_; uint8_t v_isZero_778_; 
v_zero_777_ = lean_unsigned_to_nat(0u);
v_isZero_778_ = lean_nat_dec_eq(v_x_773_, v_zero_777_);
if (v_isZero_778_ == 1)
{
lean_dec(v_x_773_);
return v_x_776_;
}
else
{
uint64_t v_sink_779_; uint64_t v_trace_780_; lean_object* v___x_782_; uint8_t v_isShared_783_; uint8_t v_isSharedCheck_816_; 
v_sink_779_ = lean_ctor_get_uint64(v_x_776_, 0);
v_trace_780_ = lean_ctor_get_uint64(v_x_776_, 8);
v_isSharedCheck_816_ = !lean_is_exclusive(v_x_776_);
if (v_isSharedCheck_816_ == 0)
{
v___x_782_ = v_x_776_;
v_isShared_783_ = v_isSharedCheck_816_;
goto v_resetjp_781_;
}
else
{
lean_dec(v_x_776_);
v___x_782_ = lean_box(0);
v_isShared_783_ = v_isSharedCheck_816_;
goto v_resetjp_781_;
}
v_resetjp_781_:
{
lean_object* v_one_784_; lean_object* v_n_785_; lean_object* v_index_786_; lean_object* v___y_788_; lean_object* v___y_804_; lean_object* v___x_806_; lean_object* v___x_807_; uint8_t v___x_808_; 
v_one_784_ = lean_unsigned_to_nat(1u);
v_n_785_ = lean_nat_sub(v_x_773_, v_one_784_);
lean_dec(v_x_773_);
v_index_786_ = l_BalancedSqrt_nextUnused(v_x_774_, v_sink_779_);
v___x_806_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__4, &l_BalancedSqrt_block4096___closed__4_once, _init_l_BalancedSqrt_block4096___closed__4);
v___x_807_ = lean_array_get_borrowed(v___x_806_, v_x_775_, v_index_786_);
v___x_808_ = lean_uint8_once(&l_BalancedSqrt_block4096___closed__5, &l_BalancedSqrt_block4096___closed__5_once, _init_l_BalancedSqrt_block4096___closed__5);
if (v___x_808_ == 0)
{
lean_object* v___x_809_; lean_object* v_run_810_; lean_object* v___x_811_; 
v___x_809_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__8, &l_BalancedSqrt_block4096___closed__8_once, _init_l_BalancedSqrt_block4096___closed__8);
v_run_810_ = lean_ctor_get(v___x_809_, 1);
lean_inc(v_run_810_);
lean_inc(v___x_807_);
v___x_811_ = lean_apply_1(v_run_810_, v___x_807_);
v___y_788_ = v___x_811_;
goto v___jp_787_;
}
else
{
lean_object* v___x_812_; 
v___x_812_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__9, &l_BalancedSqrt_block4096___closed__9_once, _init_l_BalancedSqrt_block4096___closed__9);
if (lean_obj_tag(v___x_812_) == 1)
{
lean_object* v_val_813_; uint8_t v___x_814_; 
v_val_813_ = lean_ctor_get(v___x_812_, 0);
v___x_814_ = lean_unbox(v_val_813_);
if (v___x_814_ == 2)
{
lean_object* v___x_815_; 
lean_inc(v___x_807_);
v___x_815_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0(v___x_807_);
v___y_788_ = v___x_815_;
goto v___jp_787_;
}
else
{
lean_inc(v___x_807_);
v___y_804_ = v___x_807_;
goto v___jp_803_;
}
}
else
{
lean_inc(v___x_807_);
v___y_804_ = v___x_807_;
goto v___jp_803_;
}
}
v___jp_787_:
{
uint64_t v___x_789_; uint64_t v___x_790_; uint64_t v___x_791_; uint64_t v___x_792_; uint64_t v___x_793_; uint64_t v___x_794_; uint64_t v___x_795_; uint64_t v___x_796_; uint64_t v___x_797_; uint64_t v___x_798_; lean_object* v___x_800_; 
v___x_789_ = 1ULL;
v___x_790_ = lean_uint64_of_nat(v_index_786_);
lean_dec(v_index_786_);
v___x_791_ = lean_uint64_shift_left(v___x_789_, v___x_790_);
v___x_792_ = lean_uint64_lor(v_x_774_, v___x_791_);
v___x_793_ = lean_uint64_of_nat(v___y_788_);
lean_dec(v___y_788_);
v___x_794_ = lean_uint64_xor(v_sink_779_, v___x_793_);
v___x_795_ = 1099511628211ULL;
v___x_796_ = lean_uint64_mul(v___x_794_, v___x_795_);
v___x_797_ = lean_uint64_xor(v_trace_780_, v___x_790_);
v___x_798_ = lean_uint64_mul(v___x_797_, v___x_795_);
if (v_isShared_783_ == 0)
{
v___x_800_ = v___x_782_;
goto v_reusejp_799_;
}
else
{
lean_object* v_reuseFailAlloc_802_; 
v_reuseFailAlloc_802_ = lean_alloc_ctor(0, 0, 16);
v___x_800_ = v_reuseFailAlloc_802_;
goto v_reusejp_799_;
}
v_reusejp_799_:
{
lean_ctor_set_uint64(v___x_800_, 0, v___x_796_);
lean_ctor_set_uint64(v___x_800_, 8, v___x_798_);
v_x_773_ = v_n_785_;
v_x_774_ = v___x_792_;
v_x_776_ = v___x_800_;
goto _start;
}
}
v___jp_803_:
{
lean_object* v___x_805_; 
v___x_805_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0(v___y_804_);
v___y_788_ = v___x_805_;
goto v___jp_787_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_block4096___boxed(lean_object* v_x_817_, lean_object* v_x_818_, lean_object* v_x_819_, lean_object* v_x_820_){
_start:
{
uint64_t v_x_5861__boxed_821_; lean_object* v_res_822_; 
v_x_5861__boxed_821_ = lean_unbox_uint64(v_x_818_);
lean_dec_ref(v_x_818_);
v_res_822_ = l_BalancedSqrt_block4096(v_x_817_, v_x_5861__boxed_821_, v_x_819_, v_x_820_);
lean_dec_ref(v_x_819_);
return v_res_822_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks1024(lean_object* v_xs_823_, lean_object* v_x_824_, lean_object* v_x_825_){
_start:
{
lean_object* v_zero_826_; uint8_t v_isZero_827_; 
v_zero_826_ = lean_unsigned_to_nat(0u);
v_isZero_827_ = lean_nat_dec_eq(v_x_824_, v_zero_826_);
if (v_isZero_827_ == 1)
{
lean_dec(v_x_824_);
return v_x_825_;
}
else
{
lean_object* v_one_828_; lean_object* v_n_829_; lean_object* v___x_830_; uint64_t v___x_831_; lean_object* v___x_832_; 
v_one_828_ = lean_unsigned_to_nat(1u);
v_n_829_ = lean_nat_sub(v_x_824_, v_one_828_);
lean_dec(v_x_824_);
v___x_830_ = lean_unsigned_to_nat(16u);
v___x_831_ = 0ULL;
v___x_832_ = l_BalancedSqrt_block1024(v___x_830_, v___x_831_, v_xs_823_, v_x_825_);
v_x_824_ = v_n_829_;
v_x_825_ = v___x_832_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks1024___boxed(lean_object* v_xs_834_, lean_object* v_x_835_, lean_object* v_x_836_){
_start:
{
lean_object* v_res_837_; 
v_res_837_ = l_BalancedSqrt_blocks1024(v_xs_834_, v_x_835_, v_x_836_);
lean_dec_ref(v_xs_834_);
return v_res_837_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks2048(lean_object* v_xs_838_, lean_object* v_x_839_, lean_object* v_x_840_){
_start:
{
lean_object* v_zero_841_; uint8_t v_isZero_842_; 
v_zero_841_ = lean_unsigned_to_nat(0u);
v_isZero_842_ = lean_nat_dec_eq(v_x_839_, v_zero_841_);
if (v_isZero_842_ == 1)
{
lean_dec(v_x_839_);
return v_x_840_;
}
else
{
lean_object* v_one_843_; lean_object* v_n_844_; lean_object* v___x_845_; uint64_t v___x_846_; lean_object* v___x_847_; 
v_one_843_ = lean_unsigned_to_nat(1u);
v_n_844_ = lean_nat_sub(v_x_839_, v_one_843_);
lean_dec(v_x_839_);
v___x_845_ = lean_unsigned_to_nat(16u);
v___x_846_ = 0ULL;
v___x_847_ = l_BalancedSqrt_block2048(v___x_845_, v___x_846_, v_xs_838_, v_x_840_);
v_x_839_ = v_n_844_;
v_x_840_ = v___x_847_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks2048___boxed(lean_object* v_xs_849_, lean_object* v_x_850_, lean_object* v_x_851_){
_start:
{
lean_object* v_res_852_; 
v_res_852_ = l_BalancedSqrt_blocks2048(v_xs_849_, v_x_850_, v_x_851_);
lean_dec_ref(v_xs_849_);
return v_res_852_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks4096(lean_object* v_xs_853_, lean_object* v_x_854_, lean_object* v_x_855_){
_start:
{
lean_object* v_zero_856_; uint8_t v_isZero_857_; 
v_zero_856_ = lean_unsigned_to_nat(0u);
v_isZero_857_ = lean_nat_dec_eq(v_x_854_, v_zero_856_);
if (v_isZero_857_ == 1)
{
lean_dec(v_x_854_);
return v_x_855_;
}
else
{
lean_object* v_one_858_; lean_object* v_n_859_; lean_object* v___x_860_; uint64_t v___x_861_; lean_object* v___x_862_; 
v_one_858_ = lean_unsigned_to_nat(1u);
v_n_859_ = lean_nat_sub(v_x_854_, v_one_858_);
lean_dec(v_x_854_);
v___x_860_ = lean_unsigned_to_nat(16u);
v___x_861_ = 0ULL;
v___x_862_ = l_BalancedSqrt_block4096(v___x_860_, v___x_861_, v_xs_853_, v_x_855_);
v_x_854_ = v_n_859_;
v_x_855_ = v___x_862_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_blocks4096___boxed(lean_object* v_xs_864_, lean_object* v_x_865_, lean_object* v_x_866_){
_start:
{
lean_object* v_res_867_; 
v_res_867_ = l_BalancedSqrt_blocks4096(v_xs_864_, v_x_865_, v_x_866_);
lean_dec_ref(v_xs_864_);
return v_res_867_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_output(lean_object* v_mode_870_, lean_object* v_width_871_, lean_object* v_blocks_872_, lean_object* v_nanos_873_, lean_object* v_s_874_){
_start:
{
uint64_t v_sink_876_; uint64_t v_trace_877_; lean_object* v___x_878_; lean_object* v___x_879_; lean_object* v___x_880_; lean_object* v___x_881_; lean_object* v___x_882_; lean_object* v___x_883_; lean_object* v___x_884_; lean_object* v___x_885_; lean_object* v___x_886_; lean_object* v___x_887_; lean_object* v___x_888_; lean_object* v___x_889_; lean_object* v___x_890_; lean_object* v___x_891_; lean_object* v___x_892_; lean_object* v___x_893_; lean_object* v___x_894_; lean_object* v___x_895_; lean_object* v___x_896_; lean_object* v___x_897_; lean_object* v___x_898_; 
v_sink_876_ = lean_ctor_get_uint64(v_s_874_, 0);
v_trace_877_ = lean_ctor_get_uint64(v_s_874_, 8);
v___x_878_ = ((lean_object*)(l_BalancedSqrt_output___closed__0));
v___x_879_ = lean_string_append(v___x_878_, v_mode_870_);
v___x_880_ = ((lean_object*)(l_BalancedSqrt_output___closed__1));
v___x_881_ = lean_string_append(v___x_879_, v___x_880_);
v___x_882_ = l_Nat_reprFast(v_width_871_);
v___x_883_ = lean_string_append(v___x_881_, v___x_882_);
lean_dec_ref(v___x_882_);
v___x_884_ = lean_string_append(v___x_883_, v___x_880_);
v___x_885_ = l_Nat_reprFast(v_blocks_872_);
v___x_886_ = lean_string_append(v___x_884_, v___x_885_);
lean_dec_ref(v___x_885_);
v___x_887_ = lean_string_append(v___x_886_, v___x_880_);
v___x_888_ = l_Nat_reprFast(v_nanos_873_);
v___x_889_ = lean_string_append(v___x_887_, v___x_888_);
lean_dec_ref(v___x_888_);
v___x_890_ = lean_string_append(v___x_889_, v___x_880_);
v___x_891_ = lean_uint64_to_nat(v_sink_876_);
v___x_892_ = l_Nat_reprFast(v___x_891_);
v___x_893_ = lean_string_append(v___x_890_, v___x_892_);
lean_dec_ref(v___x_892_);
v___x_894_ = lean_string_append(v___x_893_, v___x_880_);
v___x_895_ = lean_uint64_to_nat(v_trace_877_);
v___x_896_ = l_Nat_reprFast(v___x_895_);
v___x_897_ = lean_string_append(v___x_894_, v___x_896_);
lean_dec_ref(v___x_896_);
v___x_898_ = lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(v___x_897_);
return v___x_898_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_output___boxed(lean_object* v_mode_899_, lean_object* v_width_900_, lean_object* v_blocks_901_, lean_object* v_nanos_902_, lean_object* v_s_903_, lean_object* v_a_904_){
_start:
{
lean_object* v_res_905_; 
v_res_905_ = l_BalancedSqrt_output(v_mode_899_, v_width_900_, v_blocks_901_, v_nanos_902_, v_s_903_);
lean_dec_ref(v_s_903_);
lean_dec_ref(v_mode_899_);
return v_res_905_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_execute(lean_object* v_mode_911_, lean_object* v_width_912_, lean_object* v_blocks_913_, lean_object* v_run_914_, lean_object* v_dump_915_){
_start:
{
lean_object* v___x_917_; lean_object* v___x_918_; lean_object* v___x_919_; uint8_t v___x_920_; 
v___x_917_ = ((lean_object*)(l_BalancedSqrt_execute___closed__0));
v___x_918_ = lean_st_mk_ref(v___x_917_);
v___x_919_ = ((lean_object*)(l_BalancedSqrt_execute___closed__1));
v___x_920_ = lean_string_dec_eq(v_mode_911_, v___x_919_);
if (v___x_920_ == 0)
{
lean_object* v___x_921_; lean_object* v___x_922_; lean_object* v___x_923_; lean_object* v___x_924_; uint64_t v_sink_925_; uint64_t v_trace_926_; lean_object* v___x_927_; lean_object* v___x_928_; lean_object* v___x_929_; lean_object* v___x_930_; lean_object* v___x_931_; lean_object* v___x_932_; lean_object* v___x_933_; lean_object* v___x_934_; lean_object* v___x_935_; lean_object* v___x_936_; lean_object* v___x_937_; lean_object* v___x_938_; lean_object* v___x_939_; lean_object* v___x_940_; 
lean_dec_ref(v_dump_915_);
v___x_921_ = lean_unsigned_to_nat(1u);
lean_inc_ref(v_run_914_);
v___x_922_ = lean_apply_2(v_run_914_, v___x_921_, v___x_917_);
v___x_923_ = lean_st_ref_set(v___x_918_, v___x_922_);
v___x_924_ = lean_st_ref_get(v___x_918_);
v_sink_925_ = lean_ctor_get_uint64(v___x_924_, 0);
v_trace_926_ = lean_ctor_get_uint64(v___x_924_, 8);
lean_dec(v___x_924_);
v___x_927_ = ((lean_object*)(l_BalancedSqrt_execute___closed__2));
lean_inc(v_width_912_);
v___x_928_ = l_Nat_reprFast(v_width_912_);
v___x_929_ = lean_string_append(v___x_927_, v___x_928_);
lean_dec_ref(v___x_928_);
v___x_930_ = ((lean_object*)(l_BalancedSqrt_execute___closed__3));
v___x_931_ = lean_string_append(v___x_929_, v___x_930_);
v___x_932_ = lean_uint64_to_nat(v_sink_925_);
v___x_933_ = l_Nat_reprFast(v___x_932_);
v___x_934_ = lean_string_append(v___x_931_, v___x_933_);
lean_dec_ref(v___x_933_);
v___x_935_ = ((lean_object*)(l_BalancedSqrt_output___closed__1));
v___x_936_ = lean_string_append(v___x_934_, v___x_935_);
v___x_937_ = lean_uint64_to_nat(v_trace_926_);
v___x_938_ = l_Nat_reprFast(v___x_937_);
v___x_939_ = lean_string_append(v___x_936_, v___x_938_);
lean_dec_ref(v___x_938_);
v___x_940_ = lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(v___x_939_);
if (lean_obj_tag(v___x_940_) == 0)
{
lean_object* v___x_941_; lean_object* v___x_942_; lean_object* v___x_943_; lean_object* v___x_944_; lean_object* v___x_945_; lean_object* v___x_946_; lean_object* v___x_947_; 
lean_dec_ref_known(v___x_940_, 1);
v___x_941_ = lean_io_mono_nanos_now();
lean_inc(v_blocks_913_);
v___x_942_ = lean_apply_2(v_run_914_, v_blocks_913_, v___x_917_);
v___x_943_ = lean_st_ref_set(v___x_918_, v___x_942_);
v___x_944_ = lean_io_mono_nanos_now();
v___x_945_ = lean_st_ref_get(v___x_918_);
lean_dec(v___x_918_);
v___x_946_ = lean_nat_sub(v___x_944_, v___x_941_);
lean_dec(v___x_941_);
lean_dec(v___x_944_);
v___x_947_ = l_BalancedSqrt_output(v_mode_911_, v_width_912_, v_blocks_913_, v___x_946_, v___x_945_);
lean_dec(v___x_945_);
return v___x_947_;
}
else
{
lean_dec(v___x_918_);
lean_dec_ref(v_run_914_);
lean_dec(v_blocks_913_);
lean_dec(v_width_912_);
return v___x_940_;
}
}
else
{
lean_object* v___x_948_; 
v___x_948_ = lean_apply_1(v_dump_915_, lean_box(0));
if (lean_obj_tag(v___x_948_) == 0)
{
lean_object* v___x_949_; lean_object* v___x_950_; lean_object* v___x_951_; lean_object* v___x_952_; lean_object* v___x_953_; 
lean_dec_ref_known(v___x_948_, 1);
lean_inc(v_blocks_913_);
v___x_949_ = lean_apply_2(v_run_914_, v_blocks_913_, v___x_917_);
v___x_950_ = lean_st_ref_set(v___x_918_, v___x_949_);
v___x_951_ = lean_st_ref_get(v___x_918_);
lean_dec(v___x_918_);
v___x_952_ = lean_unsigned_to_nat(0u);
v___x_953_ = l_BalancedSqrt_output(v_mode_911_, v_width_912_, v_blocks_913_, v___x_952_, v___x_951_);
lean_dec(v___x_951_);
return v___x_953_;
}
else
{
lean_dec(v___x_918_);
lean_dec_ref(v_run_914_);
lean_dec(v_blocks_913_);
lean_dec(v_width_912_);
return v___x_948_;
}
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_execute___boxed(lean_object* v_mode_954_, lean_object* v_width_955_, lean_object* v_blocks_956_, lean_object* v_run_957_, lean_object* v_dump_958_, lean_object* v_a_959_){
_start:
{
lean_object* v_res_960_; 
v_res_960_ = l_BalancedSqrt_execute(v_mode_954_, v_width_955_, v_blocks_956_, v_run_957_, v_dump_958_);
lean_dec_ref(v_mode_954_);
return v_res_960_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0(size_t v_sz_961_, size_t v_i_962_, lean_object* v_bs_963_){
_start:
{
uint8_t v___x_964_; 
v___x_964_ = lean_usize_dec_lt(v_i_962_, v_sz_961_);
if (v___x_964_ == 0)
{
return v_bs_963_;
}
else
{
lean_object* v___x_965_; lean_object* v_v_966_; lean_object* v___x_967_; lean_object* v_bs_x27_968_; lean_object* v___x_969_; size_t v___x_970_; size_t v___x_971_; lean_object* v___x_972_; 
v___x_965_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1___closed__0));
v_v_966_ = lean_array_uget(v_bs_963_, v_i_962_);
v___x_967_ = lean_unsigned_to_nat(0u);
v_bs_x27_968_ = lean_array_uset(v_bs_963_, v_i_962_, v___x_967_);
v___x_969_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Model_roundRatQ(v___x_965_, v_v_966_);
v___x_970_ = ((size_t)1ULL);
v___x_971_ = lean_usize_add(v_i_962_, v___x_970_);
v___x_972_ = lean_array_uset(v_bs_x27_968_, v_i_962_, v___x_969_);
v_i_962_ = v___x_971_;
v_bs_963_ = v___x_972_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0___boxed(lean_object* v_sz_974_, lean_object* v_i_975_, lean_object* v_bs_976_){
_start:
{
size_t v_sz_boxed_977_; size_t v_i_boxed_978_; lean_object* v_res_979_; 
v_sz_boxed_977_ = lean_unbox_usize(v_sz_974_);
lean_dec(v_sz_974_);
v_i_boxed_978_ = lean_unbox_usize(v_i_975_);
lean_dec(v_i_975_);
v_res_979_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0(v_sz_boxed_977_, v_i_boxed_978_, v_bs_976_);
return v_res_979_;
}
}
static size_t _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0(void){
_start:
{
lean_object* v___x_980_; size_t v_sz_981_; 
v___x_980_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Support_ExactWorkload_sqrtXs;
v_sz_981_ = lean_array_size(v___x_980_);
return v_sz_981_;
}
}
static lean_object* _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__1(void){
_start:
{
lean_object* v___x_982_; size_t v___x_983_; size_t v_sz_984_; lean_object* v___x_985_; 
v___x_982_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Support_ExactWorkload_sqrtXs;
v___x_983_ = ((size_t)0ULL);
v_sz_984_ = lean_usize_once(&l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0, &l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0_once, _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0);
v___x_985_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0_spec__0(v_sz_984_, v___x_983_, v___x_982_);
return v___x_985_;
}
}
static lean_object* _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0(void){
_start:
{
lean_object* v___x_986_; 
v___x_986_ = lean_obj_once(&l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__1, &l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__1_once, _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__1);
return v___x_986_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg(lean_object* v_range_989_, lean_object* v_b_990_, lean_object* v_i_991_){
_start:
{
lean_object* v_stop_993_; lean_object* v_step_994_; uint8_t v___x_995_; 
v_stop_993_ = lean_ctor_get(v_range_989_, 1);
v_step_994_ = lean_ctor_get(v_range_989_, 2);
v___x_995_ = lean_nat_dec_lt(v_i_991_, v_stop_993_);
if (v___x_995_ == 0)
{
lean_object* v___x_996_; 
lean_dec(v_i_991_);
v___x_996_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_996_, 0, v_b_990_);
return v___x_996_;
}
else
{
lean_object* v___x_997_; lean_object* v___y_999_; lean_object* v___y_1011_; lean_object* v___x_1013_; lean_object* v_xs_1014_; lean_object* v___x_1015_; uint8_t v___x_1016_; 
v___x_997_ = lean_box(0);
v___x_1013_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__4, &l_BalancedSqrt_block1024___closed__4_once, _init_l_BalancedSqrt_block1024___closed__4);
v_xs_1014_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0;
v___x_1015_ = lean_array_get_borrowed(v___x_1013_, v_xs_1014_, v_i_991_);
v___x_1016_ = lean_uint8_once(&l_BalancedSqrt_block1024___closed__5, &l_BalancedSqrt_block1024___closed__5_once, _init_l_BalancedSqrt_block1024___closed__5);
if (v___x_1016_ == 0)
{
lean_object* v___x_1017_; lean_object* v_run_1018_; lean_object* v___x_1019_; 
v___x_1017_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__8, &l_BalancedSqrt_block1024___closed__8_once, _init_l_BalancedSqrt_block1024___closed__8);
v_run_1018_ = lean_ctor_get(v___x_1017_, 1);
lean_inc(v_run_1018_);
lean_inc(v___x_1015_);
v___x_1019_ = lean_apply_1(v_run_1018_, v___x_1015_);
v___y_999_ = v___x_1019_;
goto v___jp_998_;
}
else
{
lean_object* v___x_1020_; 
v___x_1020_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__9, &l_BalancedSqrt_block1024___closed__9_once, _init_l_BalancedSqrt_block1024___closed__9);
if (lean_obj_tag(v___x_1020_) == 1)
{
lean_object* v_val_1021_; uint8_t v___x_1022_; 
v_val_1021_ = lean_ctor_get(v___x_1020_, 0);
v___x_1022_ = lean_unbox(v_val_1021_);
if (v___x_1022_ == 2)
{
lean_object* v___x_1023_; 
lean_inc(v___x_1015_);
v___x_1023_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1(v___x_1015_);
v___y_999_ = v___x_1023_;
goto v___jp_998_;
}
else
{
lean_inc(v___x_1015_);
v___y_1011_ = v___x_1015_;
goto v___jp_1010_;
}
}
else
{
lean_inc(v___x_1015_);
v___y_1011_ = v___x_1015_;
goto v___jp_1010_;
}
}
v___jp_998_:
{
lean_object* v___x_1000_; lean_object* v___x_1001_; lean_object* v___x_1002_; lean_object* v___x_1003_; lean_object* v___x_1004_; lean_object* v___x_1005_; lean_object* v___x_1006_; lean_object* v___x_1007_; 
v___x_1000_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__0));
lean_inc(v_i_991_);
v___x_1001_ = l_Nat_reprFast(v_i_991_);
v___x_1002_ = lean_string_append(v___x_1000_, v___x_1001_);
lean_dec_ref(v___x_1001_);
v___x_1003_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1));
v___x_1004_ = lean_string_append(v___x_1002_, v___x_1003_);
v___x_1005_ = l_Nat_reprFast(v___y_999_);
v___x_1006_ = lean_string_append(v___x_1004_, v___x_1005_);
lean_dec_ref(v___x_1005_);
v___x_1007_ = lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(v___x_1006_);
if (lean_obj_tag(v___x_1007_) == 0)
{
lean_object* v___x_1008_; 
lean_dec_ref_known(v___x_1007_, 1);
v___x_1008_ = lean_nat_add(v_i_991_, v_step_994_);
lean_dec(v_i_991_);
v_b_990_ = v___x_997_;
v_i_991_ = v___x_1008_;
goto _start;
}
else
{
lean_dec(v_i_991_);
return v___x_1007_;
}
}
v___jp_1010_:
{
lean_object* v___x_1012_; 
v___x_1012_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1(v___y_1011_);
v___y_999_ = v___x_1012_;
goto v___jp_998_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___boxed(lean_object* v_range_1024_, lean_object* v_b_1025_, lean_object* v_i_1026_, lean_object* v___y_1027_){
_start:
{
lean_object* v_res_1028_; 
v_res_1028_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg(v_range_1024_, v_b_1025_, v_i_1026_);
lean_dec_ref(v_range_1024_);
return v_res_1028_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___redArg(lean_object* v_range_1029_, lean_object* v_b_1030_, lean_object* v_i_1031_){
_start:
{
lean_object* v_stop_1033_; lean_object* v_step_1034_; uint8_t v___x_1035_; 
v_stop_1033_ = lean_ctor_get(v_range_1029_, 1);
v_step_1034_ = lean_ctor_get(v_range_1029_, 2);
v___x_1035_ = lean_nat_dec_lt(v_i_1031_, v_stop_1033_);
if (v___x_1035_ == 0)
{
lean_object* v___x_1036_; 
lean_dec(v_i_1031_);
v___x_1036_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1036_, 0, v_b_1030_);
return v___x_1036_;
}
else
{
lean_object* v___x_1037_; lean_object* v___y_1039_; lean_object* v___y_1051_; lean_object* v___x_1053_; lean_object* v_xs_1054_; lean_object* v___x_1055_; uint8_t v___x_1056_; 
v___x_1037_ = lean_box(0);
v___x_1053_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__4, &l_BalancedSqrt_block1024___closed__4_once, _init_l_BalancedSqrt_block1024___closed__4);
v_xs_1054_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0;
v___x_1055_ = lean_array_get_borrowed(v___x_1053_, v_xs_1054_, v_i_1031_);
v___x_1056_ = lean_uint8_once(&l_BalancedSqrt_block1024___closed__5, &l_BalancedSqrt_block1024___closed__5_once, _init_l_BalancedSqrt_block1024___closed__5);
if (v___x_1056_ == 0)
{
lean_object* v___x_1057_; lean_object* v_run_1058_; lean_object* v___x_1059_; 
v___x_1057_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__8, &l_BalancedSqrt_block1024___closed__8_once, _init_l_BalancedSqrt_block1024___closed__8);
v_run_1058_ = lean_ctor_get(v___x_1057_, 1);
lean_inc(v_run_1058_);
lean_inc(v___x_1055_);
v___x_1059_ = lean_apply_1(v_run_1058_, v___x_1055_);
v___y_1039_ = v___x_1059_;
goto v___jp_1038_;
}
else
{
lean_object* v___x_1060_; 
v___x_1060_ = lean_obj_once(&l_BalancedSqrt_block1024___closed__9, &l_BalancedSqrt_block1024___closed__9_once, _init_l_BalancedSqrt_block1024___closed__9);
if (lean_obj_tag(v___x_1060_) == 1)
{
lean_object* v_val_1061_; uint8_t v___x_1062_; 
v_val_1061_ = lean_ctor_get(v___x_1060_, 0);
v___x_1062_ = lean_unbox(v_val_1061_);
if (v___x_1062_ == 2)
{
lean_object* v___x_1063_; 
lean_inc(v___x_1055_);
v___x_1063_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1(v___x_1055_);
v___y_1039_ = v___x_1063_;
goto v___jp_1038_;
}
else
{
lean_inc(v___x_1055_);
v___y_1051_ = v___x_1055_;
goto v___jp_1050_;
}
}
else
{
lean_inc(v___x_1055_);
v___y_1051_ = v___x_1055_;
goto v___jp_1050_;
}
}
v___jp_1038_:
{
lean_object* v___x_1040_; lean_object* v___x_1041_; lean_object* v___x_1042_; lean_object* v___x_1043_; lean_object* v___x_1044_; lean_object* v___x_1045_; lean_object* v___x_1046_; lean_object* v___x_1047_; 
v___x_1040_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__0));
lean_inc(v_i_1031_);
v___x_1041_ = l_Nat_reprFast(v_i_1031_);
v___x_1042_ = lean_string_append(v___x_1040_, v___x_1041_);
lean_dec_ref(v___x_1041_);
v___x_1043_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1));
v___x_1044_ = lean_string_append(v___x_1042_, v___x_1043_);
v___x_1045_ = l_Nat_reprFast(v___y_1039_);
v___x_1046_ = lean_string_append(v___x_1044_, v___x_1045_);
lean_dec_ref(v___x_1045_);
v___x_1047_ = lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(v___x_1046_);
if (lean_obj_tag(v___x_1047_) == 0)
{
lean_object* v___x_1048_; lean_object* v___x_1049_; 
lean_dec_ref_known(v___x_1047_, 1);
v___x_1048_ = lean_nat_add(v_i_1031_, v_step_1034_);
lean_dec(v_i_1031_);
v___x_1049_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg(v_range_1029_, v___x_1037_, v___x_1048_);
return v___x_1049_;
}
else
{
lean_dec(v_i_1031_);
return v___x_1047_;
}
}
v___jp_1050_:
{
lean_object* v___x_1052_; 
v___x_1052_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block1024_spec__1(v___y_1051_);
v___y_1039_ = v___x_1052_;
goto v___jp_1038_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___redArg___boxed(lean_object* v_range_1064_, lean_object* v_b_1065_, lean_object* v_i_1066_, lean_object* v___y_1067_){
_start:
{
lean_object* v_res_1068_; 
v_res_1068_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___redArg(v_range_1064_, v_b_1065_, v_i_1066_);
lean_dec_ref(v_range_1064_);
return v_res_1068_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run1024___lam__0(lean_object* v___x_1069_, lean_object* v___x_1070_, lean_object* v___x_1071_){
_start:
{
lean_object* v___x_1073_; 
v___x_1073_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___redArg(v___x_1069_, v___x_1070_, v___x_1071_);
if (lean_obj_tag(v___x_1073_) == 0)
{
lean_object* v___x_1075_; uint8_t v_isShared_1076_; uint8_t v_isSharedCheck_1080_; 
v_isSharedCheck_1080_ = !lean_is_exclusive(v___x_1073_);
if (v_isSharedCheck_1080_ == 0)
{
lean_object* v_unused_1081_; 
v_unused_1081_ = lean_ctor_get(v___x_1073_, 0);
lean_dec(v_unused_1081_);
v___x_1075_ = v___x_1073_;
v_isShared_1076_ = v_isSharedCheck_1080_;
goto v_resetjp_1074_;
}
else
{
lean_dec(v___x_1073_);
v___x_1075_ = lean_box(0);
v_isShared_1076_ = v_isSharedCheck_1080_;
goto v_resetjp_1074_;
}
v_resetjp_1074_:
{
lean_object* v___x_1078_; 
if (v_isShared_1076_ == 0)
{
lean_ctor_set(v___x_1075_, 0, v___x_1070_);
v___x_1078_ = v___x_1075_;
goto v_reusejp_1077_;
}
else
{
lean_object* v_reuseFailAlloc_1079_; 
v_reuseFailAlloc_1079_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1079_, 0, v___x_1070_);
v___x_1078_ = v_reuseFailAlloc_1079_;
goto v_reusejp_1077_;
}
v_reusejp_1077_:
{
return v___x_1078_;
}
}
}
else
{
return v___x_1073_;
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run1024___lam__0___boxed(lean_object* v___x_1082_, lean_object* v___x_1083_, lean_object* v___x_1084_, lean_object* v___y_1085_){
_start:
{
lean_object* v_res_1086_; 
v_res_1086_ = l_BalancedSqrt_run1024___lam__0(v___x_1082_, v___x_1083_, v___x_1084_);
lean_dec_ref(v___x_1082_);
return v_res_1086_;
}
}
static lean_object* _init_l_BalancedSqrt_run1024___closed__0(void){
_start:
{
lean_object* v_xs_1087_; lean_object* v___x_1088_; 
v_xs_1087_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0;
v___x_1088_ = lean_alloc_closure((void*)(l_BalancedSqrt_blocks1024___boxed), 3, 1);
lean_closure_set(v___x_1088_, 0, v_xs_1087_);
return v___x_1088_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run1024(lean_object* v_mode_1093_, lean_object* v_blocks_1094_){
_start:
{
lean_object* v___x_1096_; lean_object* v___x_1097_; lean_object* v___f_1098_; lean_object* v___x_1099_; 
v___x_1096_ = lean_unsigned_to_nat(1024u);
v___x_1097_ = lean_obj_once(&l_BalancedSqrt_run1024___closed__0, &l_BalancedSqrt_run1024___closed__0_once, _init_l_BalancedSqrt_run1024___closed__0);
v___f_1098_ = ((lean_object*)(l_BalancedSqrt_run1024___closed__1));
v___x_1099_ = l_BalancedSqrt_execute(v_mode_1093_, v___x_1096_, v_blocks_1094_, v___x_1097_, v___f_1098_);
return v___x_1099_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run1024___boxed(lean_object* v_mode_1100_, lean_object* v_blocks_1101_, lean_object* v_a_1102_){
_start:
{
lean_object* v_res_1103_; 
v_res_1103_ = l_BalancedSqrt_run1024(v_mode_1100_, v_blocks_1101_);
lean_dec_ref(v_mode_1100_);
return v_res_1103_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1(lean_object* v_range_1104_, lean_object* v_b_1105_, lean_object* v_i_1106_, lean_object* v_hs_1107_, lean_object* v_hl_1108_){
_start:
{
lean_object* v___x_1110_; 
v___x_1110_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___redArg(v_range_1104_, v_b_1105_, v_i_1106_);
return v___x_1110_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1___boxed(lean_object* v_range_1111_, lean_object* v_b_1112_, lean_object* v_i_1113_, lean_object* v_hs_1114_, lean_object* v_hl_1115_, lean_object* v___y_1116_){
_start:
{
lean_object* v_res_1117_; 
v_res_1117_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1(v_range_1111_, v_b_1112_, v_i_1113_, v_hs_1114_, v_hl_1115_);
lean_dec_ref(v_range_1111_);
return v_res_1117_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2(lean_object* v_range_1118_, lean_object* v_b_1119_, lean_object* v_i_1120_, lean_object* v_hs_1121_, lean_object* v_hl_1122_){
_start:
{
lean_object* v___x_1124_; 
v___x_1124_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg(v_range_1118_, v_b_1119_, v_i_1120_);
return v___x_1124_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___boxed(lean_object* v_range_1125_, lean_object* v_b_1126_, lean_object* v_i_1127_, lean_object* v_hs_1128_, lean_object* v_hl_1129_, lean_object* v___y_1130_){
_start:
{
lean_object* v_res_1131_; 
v_res_1131_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2(v_range_1125_, v_b_1126_, v_i_1127_, v_hs_1128_, v_hl_1129_);
lean_dec_ref(v_range_1125_);
return v_res_1131_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0_spec__0(size_t v_sz_1132_, size_t v_i_1133_, lean_object* v_bs_1134_){
_start:
{
uint8_t v___x_1135_; 
v___x_1135_ = lean_usize_dec_lt(v_i_1133_, v_sz_1132_);
if (v___x_1135_ == 0)
{
return v_bs_1134_;
}
else
{
lean_object* v___x_1136_; lean_object* v_v_1137_; lean_object* v___x_1138_; lean_object* v_bs_x27_1139_; lean_object* v___x_1140_; size_t v___x_1141_; size_t v___x_1142_; lean_object* v___x_1143_; 
v___x_1136_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0___closed__0));
v_v_1137_ = lean_array_uget(v_bs_1134_, v_i_1133_);
v___x_1138_ = lean_unsigned_to_nat(0u);
v_bs_x27_1139_ = lean_array_uset(v_bs_1134_, v_i_1133_, v___x_1138_);
v___x_1140_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Model_roundRatQ(v___x_1136_, v_v_1137_);
v___x_1141_ = ((size_t)1ULL);
v___x_1142_ = lean_usize_add(v_i_1133_, v___x_1141_);
v___x_1143_ = lean_array_uset(v_bs_x27_1139_, v_i_1133_, v___x_1140_);
v_i_1133_ = v___x_1142_;
v_bs_1134_ = v___x_1143_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0_spec__0___boxed(lean_object* v_sz_1145_, lean_object* v_i_1146_, lean_object* v_bs_1147_){
_start:
{
size_t v_sz_boxed_1148_; size_t v_i_boxed_1149_; lean_object* v_res_1150_; 
v_sz_boxed_1148_ = lean_unbox_usize(v_sz_1145_);
lean_dec(v_sz_1145_);
v_i_boxed_1149_ = lean_unbox_usize(v_i_1146_);
lean_dec(v_i_1146_);
v_res_1150_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0_spec__0(v_sz_boxed_1148_, v_i_boxed_1149_, v_bs_1147_);
return v_res_1150_;
}
}
static lean_object* _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0___closed__0(void){
_start:
{
lean_object* v___x_1151_; size_t v___x_1152_; size_t v_sz_1153_; lean_object* v___x_1154_; 
v___x_1151_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Support_ExactWorkload_sqrtXs;
v___x_1152_ = ((size_t)0ULL);
v_sz_1153_ = lean_usize_once(&l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0, &l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0_once, _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0);
v___x_1154_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0_spec__0(v_sz_1153_, v___x_1152_, v___x_1151_);
return v___x_1154_;
}
}
static lean_object* _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0(void){
_start:
{
lean_object* v___x_1155_; 
v___x_1155_ = lean_obj_once(&l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0___closed__0, &l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0___closed__0_once, _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0___closed__0);
return v___x_1155_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg(lean_object* v_range_1157_, lean_object* v_b_1158_, lean_object* v_i_1159_){
_start:
{
lean_object* v_stop_1161_; lean_object* v_step_1162_; uint8_t v___x_1163_; 
v_stop_1161_ = lean_ctor_get(v_range_1157_, 1);
v_step_1162_ = lean_ctor_get(v_range_1157_, 2);
v___x_1163_ = lean_nat_dec_lt(v_i_1159_, v_stop_1161_);
if (v___x_1163_ == 0)
{
lean_object* v___x_1164_; 
lean_dec(v_i_1159_);
v___x_1164_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1164_, 0, v_b_1158_);
return v___x_1164_;
}
else
{
lean_object* v___x_1165_; lean_object* v___y_1167_; lean_object* v___y_1179_; lean_object* v___x_1181_; lean_object* v_xs_1182_; lean_object* v___x_1183_; uint8_t v___x_1184_; 
v___x_1165_ = lean_box(0);
v___x_1181_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__4, &l_BalancedSqrt_block2048___closed__4_once, _init_l_BalancedSqrt_block2048___closed__4);
v_xs_1182_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0;
v___x_1183_ = lean_array_get_borrowed(v___x_1181_, v_xs_1182_, v_i_1159_);
v___x_1184_ = lean_uint8_once(&l_BalancedSqrt_block2048___closed__5, &l_BalancedSqrt_block2048___closed__5_once, _init_l_BalancedSqrt_block2048___closed__5);
if (v___x_1184_ == 0)
{
lean_object* v___x_1185_; lean_object* v_run_1186_; lean_object* v___x_1187_; 
v___x_1185_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__8, &l_BalancedSqrt_block2048___closed__8_once, _init_l_BalancedSqrt_block2048___closed__8);
v_run_1186_ = lean_ctor_get(v___x_1185_, 1);
lean_inc(v_run_1186_);
lean_inc(v___x_1183_);
v___x_1187_ = lean_apply_1(v_run_1186_, v___x_1183_);
v___y_1167_ = v___x_1187_;
goto v___jp_1166_;
}
else
{
lean_object* v___x_1188_; 
v___x_1188_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__9, &l_BalancedSqrt_block2048___closed__9_once, _init_l_BalancedSqrt_block2048___closed__9);
if (lean_obj_tag(v___x_1188_) == 1)
{
lean_object* v_val_1189_; uint8_t v___x_1190_; 
v_val_1189_ = lean_ctor_get(v___x_1188_, 0);
v___x_1190_ = lean_unbox(v_val_1189_);
if (v___x_1190_ == 2)
{
lean_object* v___x_1191_; 
lean_inc(v___x_1183_);
v___x_1191_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0(v___x_1183_);
v___y_1167_ = v___x_1191_;
goto v___jp_1166_;
}
else
{
lean_inc(v___x_1183_);
v___y_1179_ = v___x_1183_;
goto v___jp_1178_;
}
}
else
{
lean_inc(v___x_1183_);
v___y_1179_ = v___x_1183_;
goto v___jp_1178_;
}
}
v___jp_1166_:
{
lean_object* v___x_1168_; lean_object* v___x_1169_; lean_object* v___x_1170_; lean_object* v___x_1171_; lean_object* v___x_1172_; lean_object* v___x_1173_; lean_object* v___x_1174_; lean_object* v___x_1175_; 
v___x_1168_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg___closed__0));
lean_inc(v_i_1159_);
v___x_1169_ = l_Nat_reprFast(v_i_1159_);
v___x_1170_ = lean_string_append(v___x_1168_, v___x_1169_);
lean_dec_ref(v___x_1169_);
v___x_1171_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1));
v___x_1172_ = lean_string_append(v___x_1170_, v___x_1171_);
v___x_1173_ = l_Nat_reprFast(v___y_1167_);
v___x_1174_ = lean_string_append(v___x_1172_, v___x_1173_);
lean_dec_ref(v___x_1173_);
v___x_1175_ = lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(v___x_1174_);
if (lean_obj_tag(v___x_1175_) == 0)
{
lean_object* v___x_1176_; 
lean_dec_ref_known(v___x_1175_, 1);
v___x_1176_ = lean_nat_add(v_i_1159_, v_step_1162_);
lean_dec(v_i_1159_);
v_b_1158_ = v___x_1165_;
v_i_1159_ = v___x_1176_;
goto _start;
}
else
{
lean_dec(v_i_1159_);
return v___x_1175_;
}
}
v___jp_1178_:
{
lean_object* v___x_1180_; 
v___x_1180_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0(v___y_1179_);
v___y_1167_ = v___x_1180_;
goto v___jp_1166_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg___boxed(lean_object* v_range_1192_, lean_object* v_b_1193_, lean_object* v_i_1194_, lean_object* v___y_1195_){
_start:
{
lean_object* v_res_1196_; 
v_res_1196_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg(v_range_1192_, v_b_1193_, v_i_1194_);
lean_dec_ref(v_range_1192_);
return v_res_1196_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___redArg(lean_object* v_range_1197_, lean_object* v_b_1198_, lean_object* v_i_1199_){
_start:
{
lean_object* v_stop_1201_; lean_object* v_step_1202_; uint8_t v___x_1203_; 
v_stop_1201_ = lean_ctor_get(v_range_1197_, 1);
v_step_1202_ = lean_ctor_get(v_range_1197_, 2);
v___x_1203_ = lean_nat_dec_lt(v_i_1199_, v_stop_1201_);
if (v___x_1203_ == 0)
{
lean_object* v___x_1204_; 
lean_dec(v_i_1199_);
v___x_1204_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1204_, 0, v_b_1198_);
return v___x_1204_;
}
else
{
lean_object* v___x_1205_; lean_object* v___y_1207_; lean_object* v___y_1219_; lean_object* v___x_1221_; lean_object* v_xs_1222_; lean_object* v___x_1223_; uint8_t v___x_1224_; 
v___x_1205_ = lean_box(0);
v___x_1221_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__4, &l_BalancedSqrt_block2048___closed__4_once, _init_l_BalancedSqrt_block2048___closed__4);
v_xs_1222_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0;
v___x_1223_ = lean_array_get_borrowed(v___x_1221_, v_xs_1222_, v_i_1199_);
v___x_1224_ = lean_uint8_once(&l_BalancedSqrt_block2048___closed__5, &l_BalancedSqrt_block2048___closed__5_once, _init_l_BalancedSqrt_block2048___closed__5);
if (v___x_1224_ == 0)
{
lean_object* v___x_1225_; lean_object* v_run_1226_; lean_object* v___x_1227_; 
v___x_1225_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__8, &l_BalancedSqrt_block2048___closed__8_once, _init_l_BalancedSqrt_block2048___closed__8);
v_run_1226_ = lean_ctor_get(v___x_1225_, 1);
lean_inc(v_run_1226_);
lean_inc(v___x_1223_);
v___x_1227_ = lean_apply_1(v_run_1226_, v___x_1223_);
v___y_1207_ = v___x_1227_;
goto v___jp_1206_;
}
else
{
lean_object* v___x_1228_; 
v___x_1228_ = lean_obj_once(&l_BalancedSqrt_block2048___closed__9, &l_BalancedSqrt_block2048___closed__9_once, _init_l_BalancedSqrt_block2048___closed__9);
if (lean_obj_tag(v___x_1228_) == 1)
{
lean_object* v_val_1229_; uint8_t v___x_1230_; 
v_val_1229_ = lean_ctor_get(v___x_1228_, 0);
v___x_1230_ = lean_unbox(v_val_1229_);
if (v___x_1230_ == 2)
{
lean_object* v___x_1231_; 
lean_inc(v___x_1223_);
v___x_1231_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0(v___x_1223_);
v___y_1207_ = v___x_1231_;
goto v___jp_1206_;
}
else
{
lean_inc(v___x_1223_);
v___y_1219_ = v___x_1223_;
goto v___jp_1218_;
}
}
else
{
lean_inc(v___x_1223_);
v___y_1219_ = v___x_1223_;
goto v___jp_1218_;
}
}
v___jp_1206_:
{
lean_object* v___x_1208_; lean_object* v___x_1209_; lean_object* v___x_1210_; lean_object* v___x_1211_; lean_object* v___x_1212_; lean_object* v___x_1213_; lean_object* v___x_1214_; lean_object* v___x_1215_; 
v___x_1208_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg___closed__0));
lean_inc(v_i_1199_);
v___x_1209_ = l_Nat_reprFast(v_i_1199_);
v___x_1210_ = lean_string_append(v___x_1208_, v___x_1209_);
lean_dec_ref(v___x_1209_);
v___x_1211_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1));
v___x_1212_ = lean_string_append(v___x_1210_, v___x_1211_);
v___x_1213_ = l_Nat_reprFast(v___y_1207_);
v___x_1214_ = lean_string_append(v___x_1212_, v___x_1213_);
lean_dec_ref(v___x_1213_);
v___x_1215_ = lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(v___x_1214_);
if (lean_obj_tag(v___x_1215_) == 0)
{
lean_object* v___x_1216_; lean_object* v___x_1217_; 
lean_dec_ref_known(v___x_1215_, 1);
v___x_1216_ = lean_nat_add(v_i_1199_, v_step_1202_);
lean_dec(v_i_1199_);
v___x_1217_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg(v_range_1197_, v___x_1205_, v___x_1216_);
return v___x_1217_;
}
else
{
lean_dec(v_i_1199_);
return v___x_1215_;
}
}
v___jp_1218_:
{
lean_object* v___x_1220_; 
v___x_1220_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block2048_spec__0(v___y_1219_);
v___y_1207_ = v___x_1220_;
goto v___jp_1206_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___redArg___boxed(lean_object* v_range_1232_, lean_object* v_b_1233_, lean_object* v_i_1234_, lean_object* v___y_1235_){
_start:
{
lean_object* v_res_1236_; 
v_res_1236_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___redArg(v_range_1232_, v_b_1233_, v_i_1234_);
lean_dec_ref(v_range_1232_);
return v_res_1236_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run2048___lam__0(lean_object* v___x_1237_, lean_object* v___x_1238_, lean_object* v___x_1239_){
_start:
{
lean_object* v___x_1241_; 
v___x_1241_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___redArg(v___x_1237_, v___x_1238_, v___x_1239_);
if (lean_obj_tag(v___x_1241_) == 0)
{
lean_object* v___x_1243_; uint8_t v_isShared_1244_; uint8_t v_isSharedCheck_1248_; 
v_isSharedCheck_1248_ = !lean_is_exclusive(v___x_1241_);
if (v_isSharedCheck_1248_ == 0)
{
lean_object* v_unused_1249_; 
v_unused_1249_ = lean_ctor_get(v___x_1241_, 0);
lean_dec(v_unused_1249_);
v___x_1243_ = v___x_1241_;
v_isShared_1244_ = v_isSharedCheck_1248_;
goto v_resetjp_1242_;
}
else
{
lean_dec(v___x_1241_);
v___x_1243_ = lean_box(0);
v_isShared_1244_ = v_isSharedCheck_1248_;
goto v_resetjp_1242_;
}
v_resetjp_1242_:
{
lean_object* v___x_1246_; 
if (v_isShared_1244_ == 0)
{
lean_ctor_set(v___x_1243_, 0, v___x_1238_);
v___x_1246_ = v___x_1243_;
goto v_reusejp_1245_;
}
else
{
lean_object* v_reuseFailAlloc_1247_; 
v_reuseFailAlloc_1247_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1247_, 0, v___x_1238_);
v___x_1246_ = v_reuseFailAlloc_1247_;
goto v_reusejp_1245_;
}
v_reusejp_1245_:
{
return v___x_1246_;
}
}
}
else
{
return v___x_1241_;
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run2048___lam__0___boxed(lean_object* v___x_1250_, lean_object* v___x_1251_, lean_object* v___x_1252_, lean_object* v___y_1253_){
_start:
{
lean_object* v_res_1254_; 
v_res_1254_ = l_BalancedSqrt_run2048___lam__0(v___x_1250_, v___x_1251_, v___x_1252_);
lean_dec_ref(v___x_1250_);
return v_res_1254_;
}
}
static lean_object* _init_l_BalancedSqrt_run2048___closed__0(void){
_start:
{
lean_object* v_xs_1255_; lean_object* v___x_1256_; 
v_xs_1255_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0;
v___x_1256_ = lean_alloc_closure((void*)(l_BalancedSqrt_blocks2048___boxed), 3, 1);
lean_closure_set(v___x_1256_, 0, v_xs_1255_);
return v___x_1256_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run2048(lean_object* v_mode_1261_, lean_object* v_blocks_1262_){
_start:
{
lean_object* v___x_1264_; lean_object* v___x_1265_; lean_object* v___f_1266_; lean_object* v___x_1267_; 
v___x_1264_ = lean_unsigned_to_nat(2048u);
v___x_1265_ = lean_obj_once(&l_BalancedSqrt_run2048___closed__0, &l_BalancedSqrt_run2048___closed__0_once, _init_l_BalancedSqrt_run2048___closed__0);
v___f_1266_ = ((lean_object*)(l_BalancedSqrt_run2048___closed__1));
v___x_1267_ = l_BalancedSqrt_execute(v_mode_1261_, v___x_1264_, v_blocks_1262_, v___x_1265_, v___f_1266_);
return v___x_1267_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run2048___boxed(lean_object* v_mode_1268_, lean_object* v_blocks_1269_, lean_object* v_a_1270_){
_start:
{
lean_object* v_res_1271_; 
v_res_1271_ = l_BalancedSqrt_run2048(v_mode_1268_, v_blocks_1269_);
lean_dec_ref(v_mode_1268_);
return v_res_1271_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1(lean_object* v_range_1272_, lean_object* v_b_1273_, lean_object* v_i_1274_, lean_object* v_hs_1275_, lean_object* v_hl_1276_){
_start:
{
lean_object* v___x_1278_; 
v___x_1278_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___redArg(v_range_1272_, v_b_1273_, v_i_1274_);
return v___x_1278_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1___boxed(lean_object* v_range_1279_, lean_object* v_b_1280_, lean_object* v_i_1281_, lean_object* v_hs_1282_, lean_object* v_hl_1283_, lean_object* v___y_1284_){
_start:
{
lean_object* v_res_1285_; 
v_res_1285_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1(v_range_1279_, v_b_1280_, v_i_1281_, v_hs_1282_, v_hl_1283_);
lean_dec_ref(v_range_1279_);
return v_res_1285_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2(lean_object* v_range_1286_, lean_object* v_b_1287_, lean_object* v_i_1288_, lean_object* v_hs_1289_, lean_object* v_hl_1290_){
_start:
{
lean_object* v___x_1292_; 
v___x_1292_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___redArg(v_range_1286_, v_b_1287_, v_i_1288_);
return v___x_1292_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2___boxed(lean_object* v_range_1293_, lean_object* v_b_1294_, lean_object* v_i_1295_, lean_object* v_hs_1296_, lean_object* v_hl_1297_, lean_object* v___y_1298_){
_start:
{
lean_object* v_res_1299_; 
v_res_1299_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run2048_spec__1_spec__2(v_range_1293_, v_b_1294_, v_i_1295_, v_hs_1296_, v_hl_1297_);
lean_dec_ref(v_range_1293_);
return v_res_1299_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0_spec__0(size_t v_sz_1300_, size_t v_i_1301_, lean_object* v_bs_1302_){
_start:
{
uint8_t v___x_1303_; 
v___x_1303_ = lean_usize_dec_lt(v_i_1301_, v_sz_1300_);
if (v___x_1303_ == 0)
{
return v_bs_1302_;
}
else
{
lean_object* v___x_1304_; lean_object* v_v_1305_; lean_object* v___x_1306_; lean_object* v_bs_x27_1307_; lean_object* v___x_1308_; size_t v___x_1309_; size_t v___x_1310_; lean_object* v___x_1311_; 
v___x_1304_ = ((lean_object*)(l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0___closed__0));
v_v_1305_ = lean_array_uget(v_bs_1302_, v_i_1301_);
v___x_1306_ = lean_unsigned_to_nat(0u);
v_bs_x27_1307_ = lean_array_uset(v_bs_1302_, v_i_1301_, v___x_1306_);
v___x_1308_ = lp_floatlib_FloatLib_Floats_Formats_BinaryInterchange_Model_roundRatQ(v___x_1304_, v_v_1305_);
v___x_1309_ = ((size_t)1ULL);
v___x_1310_ = lean_usize_add(v_i_1301_, v___x_1309_);
v___x_1311_ = lean_array_uset(v_bs_x27_1307_, v_i_1301_, v___x_1308_);
v_i_1301_ = v___x_1310_;
v_bs_1302_ = v___x_1311_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0_spec__0___boxed(lean_object* v_sz_1313_, lean_object* v_i_1314_, lean_object* v_bs_1315_){
_start:
{
size_t v_sz_boxed_1316_; size_t v_i_boxed_1317_; lean_object* v_res_1318_; 
v_sz_boxed_1316_ = lean_unbox_usize(v_sz_1313_);
lean_dec(v_sz_1313_);
v_i_boxed_1317_ = lean_unbox_usize(v_i_1314_);
lean_dec(v_i_1314_);
v_res_1318_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0_spec__0(v_sz_boxed_1316_, v_i_boxed_1317_, v_bs_1315_);
return v_res_1318_;
}
}
static lean_object* _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0___closed__0(void){
_start:
{
lean_object* v___x_1319_; size_t v___x_1320_; size_t v_sz_1321_; lean_object* v___x_1322_; 
v___x_1319_ = lp_floatlibBenchmarks_FloatLibBenchmarks_Support_ExactWorkload_sqrtXs;
v___x_1320_ = ((size_t)0ULL);
v_sz_1321_ = lean_usize_once(&l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0, &l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0_once, _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0___closed__0);
v___x_1322_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0_spec__0(v_sz_1321_, v___x_1320_, v___x_1319_);
return v___x_1322_;
}
}
static lean_object* _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0(void){
_start:
{
lean_object* v___x_1323_; 
v___x_1323_ = lean_obj_once(&l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0___closed__0, &l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0___closed__0_once, _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0___closed__0);
return v___x_1323_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg(lean_object* v_range_1325_, lean_object* v_b_1326_, lean_object* v_i_1327_){
_start:
{
lean_object* v_stop_1329_; lean_object* v_step_1330_; uint8_t v___x_1331_; 
v_stop_1329_ = lean_ctor_get(v_range_1325_, 1);
v_step_1330_ = lean_ctor_get(v_range_1325_, 2);
v___x_1331_ = lean_nat_dec_lt(v_i_1327_, v_stop_1329_);
if (v___x_1331_ == 0)
{
lean_object* v___x_1332_; 
lean_dec(v_i_1327_);
v___x_1332_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1332_, 0, v_b_1326_);
return v___x_1332_;
}
else
{
lean_object* v___x_1333_; lean_object* v___y_1335_; lean_object* v___y_1347_; lean_object* v___x_1349_; lean_object* v_xs_1350_; lean_object* v___x_1351_; uint8_t v___x_1352_; 
v___x_1333_ = lean_box(0);
v___x_1349_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__4, &l_BalancedSqrt_block4096___closed__4_once, _init_l_BalancedSqrt_block4096___closed__4);
v_xs_1350_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0;
v___x_1351_ = lean_array_get_borrowed(v___x_1349_, v_xs_1350_, v_i_1327_);
v___x_1352_ = lean_uint8_once(&l_BalancedSqrt_block4096___closed__5, &l_BalancedSqrt_block4096___closed__5_once, _init_l_BalancedSqrt_block4096___closed__5);
if (v___x_1352_ == 0)
{
lean_object* v___x_1353_; lean_object* v_run_1354_; lean_object* v___x_1355_; 
v___x_1353_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__8, &l_BalancedSqrt_block4096___closed__8_once, _init_l_BalancedSqrt_block4096___closed__8);
v_run_1354_ = lean_ctor_get(v___x_1353_, 1);
lean_inc(v_run_1354_);
lean_inc(v___x_1351_);
v___x_1355_ = lean_apply_1(v_run_1354_, v___x_1351_);
v___y_1335_ = v___x_1355_;
goto v___jp_1334_;
}
else
{
lean_object* v___x_1356_; 
v___x_1356_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__9, &l_BalancedSqrt_block4096___closed__9_once, _init_l_BalancedSqrt_block4096___closed__9);
if (lean_obj_tag(v___x_1356_) == 1)
{
lean_object* v_val_1357_; uint8_t v___x_1358_; 
v_val_1357_ = lean_ctor_get(v___x_1356_, 0);
v___x_1358_ = lean_unbox(v_val_1357_);
if (v___x_1358_ == 2)
{
lean_object* v___x_1359_; 
lean_inc(v___x_1351_);
v___x_1359_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0(v___x_1351_);
v___y_1335_ = v___x_1359_;
goto v___jp_1334_;
}
else
{
lean_inc(v___x_1351_);
v___y_1347_ = v___x_1351_;
goto v___jp_1346_;
}
}
else
{
lean_inc(v___x_1351_);
v___y_1347_ = v___x_1351_;
goto v___jp_1346_;
}
}
v___jp_1334_:
{
lean_object* v___x_1336_; lean_object* v___x_1337_; lean_object* v___x_1338_; lean_object* v___x_1339_; lean_object* v___x_1340_; lean_object* v___x_1341_; lean_object* v___x_1342_; lean_object* v___x_1343_; 
v___x_1336_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg___closed__0));
lean_inc(v_i_1327_);
v___x_1337_ = l_Nat_reprFast(v_i_1327_);
v___x_1338_ = lean_string_append(v___x_1336_, v___x_1337_);
lean_dec_ref(v___x_1337_);
v___x_1339_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1));
v___x_1340_ = lean_string_append(v___x_1338_, v___x_1339_);
v___x_1341_ = l_Nat_reprFast(v___y_1335_);
v___x_1342_ = lean_string_append(v___x_1340_, v___x_1341_);
lean_dec_ref(v___x_1341_);
v___x_1343_ = lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(v___x_1342_);
if (lean_obj_tag(v___x_1343_) == 0)
{
lean_object* v___x_1344_; 
lean_dec_ref_known(v___x_1343_, 1);
v___x_1344_ = lean_nat_add(v_i_1327_, v_step_1330_);
lean_dec(v_i_1327_);
v_b_1326_ = v___x_1333_;
v_i_1327_ = v___x_1344_;
goto _start;
}
else
{
lean_dec(v_i_1327_);
return v___x_1343_;
}
}
v___jp_1346_:
{
lean_object* v___x_1348_; 
v___x_1348_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0(v___y_1347_);
v___y_1335_ = v___x_1348_;
goto v___jp_1334_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg___boxed(lean_object* v_range_1360_, lean_object* v_b_1361_, lean_object* v_i_1362_, lean_object* v___y_1363_){
_start:
{
lean_object* v_res_1364_; 
v_res_1364_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg(v_range_1360_, v_b_1361_, v_i_1362_);
lean_dec_ref(v_range_1360_);
return v_res_1364_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___redArg(lean_object* v_range_1365_, lean_object* v_b_1366_, lean_object* v_i_1367_){
_start:
{
lean_object* v_stop_1369_; lean_object* v_step_1370_; uint8_t v___x_1371_; 
v_stop_1369_ = lean_ctor_get(v_range_1365_, 1);
v_step_1370_ = lean_ctor_get(v_range_1365_, 2);
v___x_1371_ = lean_nat_dec_lt(v_i_1367_, v_stop_1369_);
if (v___x_1371_ == 0)
{
lean_object* v___x_1372_; 
lean_dec(v_i_1367_);
v___x_1372_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1372_, 0, v_b_1366_);
return v___x_1372_;
}
else
{
lean_object* v___x_1373_; lean_object* v___y_1375_; lean_object* v___y_1387_; lean_object* v___x_1389_; lean_object* v_xs_1390_; lean_object* v___x_1391_; uint8_t v___x_1392_; 
v___x_1373_ = lean_box(0);
v___x_1389_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__4, &l_BalancedSqrt_block4096___closed__4_once, _init_l_BalancedSqrt_block4096___closed__4);
v_xs_1390_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0;
v___x_1391_ = lean_array_get_borrowed(v___x_1389_, v_xs_1390_, v_i_1367_);
v___x_1392_ = lean_uint8_once(&l_BalancedSqrt_block4096___closed__5, &l_BalancedSqrt_block4096___closed__5_once, _init_l_BalancedSqrt_block4096___closed__5);
if (v___x_1392_ == 0)
{
lean_object* v___x_1393_; lean_object* v_run_1394_; lean_object* v___x_1395_; 
v___x_1393_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__8, &l_BalancedSqrt_block4096___closed__8_once, _init_l_BalancedSqrt_block4096___closed__8);
v_run_1394_ = lean_ctor_get(v___x_1393_, 1);
lean_inc(v_run_1394_);
lean_inc(v___x_1391_);
v___x_1395_ = lean_apply_1(v_run_1394_, v___x_1391_);
v___y_1375_ = v___x_1395_;
goto v___jp_1374_;
}
else
{
lean_object* v___x_1396_; 
v___x_1396_ = lean_obj_once(&l_BalancedSqrt_block4096___closed__9, &l_BalancedSqrt_block4096___closed__9_once, _init_l_BalancedSqrt_block4096___closed__9);
if (lean_obj_tag(v___x_1396_) == 1)
{
lean_object* v_val_1397_; uint8_t v___x_1398_; 
v_val_1397_ = lean_ctor_get(v___x_1396_, 0);
v___x_1398_ = lean_unbox(v_val_1397_);
if (v___x_1398_ == 2)
{
lean_object* v___x_1399_; 
lean_inc(v___x_1391_);
v___x_1399_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0(v___x_1391_);
v___y_1375_ = v___x_1399_;
goto v___jp_1374_;
}
else
{
lean_inc(v___x_1391_);
v___y_1387_ = v___x_1391_;
goto v___jp_1386_;
}
}
else
{
lean_inc(v___x_1391_);
v___y_1387_ = v___x_1391_;
goto v___jp_1386_;
}
}
v___jp_1374_:
{
lean_object* v___x_1376_; lean_object* v___x_1377_; lean_object* v___x_1378_; lean_object* v___x_1379_; lean_object* v___x_1380_; lean_object* v___x_1381_; lean_object* v___x_1382_; lean_object* v___x_1383_; 
v___x_1376_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg___closed__0));
lean_inc(v_i_1367_);
v___x_1377_ = l_Nat_reprFast(v_i_1367_);
v___x_1378_ = lean_string_append(v___x_1376_, v___x_1377_);
lean_dec_ref(v___x_1377_);
v___x_1379_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run1024_spec__1_spec__2___redArg___closed__1));
v___x_1380_ = lean_string_append(v___x_1378_, v___x_1379_);
v___x_1381_ = l_Nat_reprFast(v___y_1375_);
v___x_1382_ = lean_string_append(v___x_1380_, v___x_1381_);
lean_dec_ref(v___x_1381_);
v___x_1383_ = lp_floatlibBenchmarks_IO_println___at___00FloatLibBenchmarks_Public_Sweep_printHeader_spec__0(v___x_1382_);
if (lean_obj_tag(v___x_1383_) == 0)
{
lean_object* v___x_1384_; lean_object* v___x_1385_; 
lean_dec_ref_known(v___x_1383_, 1);
v___x_1384_ = lean_nat_add(v_i_1367_, v_step_1370_);
lean_dec(v_i_1367_);
v___x_1385_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg(v_range_1365_, v___x_1373_, v___x_1384_);
return v___x_1385_;
}
else
{
lean_dec(v_i_1367_);
return v___x_1383_;
}
}
v___jp_1386_:
{
lean_object* v___x_1388_; 
v___x_1388_ = l_FloatLib_Floats_Formats_BinaryInterchange_Model_SqrtBackend_word___at___00BalancedSqrt_block4096_spec__0(v___y_1387_);
v___y_1375_ = v___x_1388_;
goto v___jp_1374_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___redArg___boxed(lean_object* v_range_1400_, lean_object* v_b_1401_, lean_object* v_i_1402_, lean_object* v___y_1403_){
_start:
{
lean_object* v_res_1404_; 
v_res_1404_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___redArg(v_range_1400_, v_b_1401_, v_i_1402_);
lean_dec_ref(v_range_1400_);
return v_res_1404_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run4096___lam__0(lean_object* v___x_1405_, lean_object* v___x_1406_, lean_object* v___x_1407_){
_start:
{
lean_object* v___x_1409_; 
v___x_1409_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___redArg(v___x_1405_, v___x_1406_, v___x_1407_);
if (lean_obj_tag(v___x_1409_) == 0)
{
lean_object* v___x_1411_; uint8_t v_isShared_1412_; uint8_t v_isSharedCheck_1416_; 
v_isSharedCheck_1416_ = !lean_is_exclusive(v___x_1409_);
if (v_isSharedCheck_1416_ == 0)
{
lean_object* v_unused_1417_; 
v_unused_1417_ = lean_ctor_get(v___x_1409_, 0);
lean_dec(v_unused_1417_);
v___x_1411_ = v___x_1409_;
v_isShared_1412_ = v_isSharedCheck_1416_;
goto v_resetjp_1410_;
}
else
{
lean_dec(v___x_1409_);
v___x_1411_ = lean_box(0);
v_isShared_1412_ = v_isSharedCheck_1416_;
goto v_resetjp_1410_;
}
v_resetjp_1410_:
{
lean_object* v___x_1414_; 
if (v_isShared_1412_ == 0)
{
lean_ctor_set(v___x_1411_, 0, v___x_1406_);
v___x_1414_ = v___x_1411_;
goto v_reusejp_1413_;
}
else
{
lean_object* v_reuseFailAlloc_1415_; 
v_reuseFailAlloc_1415_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1415_, 0, v___x_1406_);
v___x_1414_ = v_reuseFailAlloc_1415_;
goto v_reusejp_1413_;
}
v_reusejp_1413_:
{
return v___x_1414_;
}
}
}
else
{
return v___x_1409_;
}
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run4096___lam__0___boxed(lean_object* v___x_1418_, lean_object* v___x_1419_, lean_object* v___x_1420_, lean_object* v___y_1421_){
_start:
{
lean_object* v_res_1422_; 
v_res_1422_ = l_BalancedSqrt_run4096___lam__0(v___x_1418_, v___x_1419_, v___x_1420_);
lean_dec_ref(v___x_1418_);
return v_res_1422_;
}
}
static lean_object* _init_l_BalancedSqrt_run4096___closed__0(void){
_start:
{
lean_object* v_xs_1423_; lean_object* v___x_1424_; 
v_xs_1423_ = l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0;
v___x_1424_ = lean_alloc_closure((void*)(l_BalancedSqrt_blocks4096___boxed), 3, 1);
lean_closure_set(v___x_1424_, 0, v_xs_1423_);
return v___x_1424_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run4096(lean_object* v_mode_1429_, lean_object* v_blocks_1430_){
_start:
{
lean_object* v___x_1432_; lean_object* v___x_1433_; lean_object* v___f_1434_; lean_object* v___x_1435_; 
v___x_1432_ = lean_unsigned_to_nat(4096u);
v___x_1433_ = lean_obj_once(&l_BalancedSqrt_run4096___closed__0, &l_BalancedSqrt_run4096___closed__0_once, _init_l_BalancedSqrt_run4096___closed__0);
v___f_1434_ = ((lean_object*)(l_BalancedSqrt_run4096___closed__1));
v___x_1435_ = l_BalancedSqrt_execute(v_mode_1429_, v___x_1432_, v_blocks_1430_, v___x_1433_, v___f_1434_);
return v___x_1435_;
}
}
LEAN_EXPORT lean_object* l_BalancedSqrt_run4096___boxed(lean_object* v_mode_1436_, lean_object* v_blocks_1437_, lean_object* v_a_1438_){
_start:
{
lean_object* v_res_1439_; 
v_res_1439_ = l_BalancedSqrt_run4096(v_mode_1436_, v_blocks_1437_);
lean_dec_ref(v_mode_1436_);
return v_res_1439_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1(lean_object* v_range_1440_, lean_object* v_b_1441_, lean_object* v_i_1442_, lean_object* v_hs_1443_, lean_object* v_hl_1444_){
_start:
{
lean_object* v___x_1446_; 
v___x_1446_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___redArg(v_range_1440_, v_b_1441_, v_i_1442_);
return v___x_1446_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1___boxed(lean_object* v_range_1447_, lean_object* v_b_1448_, lean_object* v_i_1449_, lean_object* v_hs_1450_, lean_object* v_hl_1451_, lean_object* v___y_1452_){
_start:
{
lean_object* v_res_1453_; 
v_res_1453_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1(v_range_1447_, v_b_1448_, v_i_1449_, v_hs_1450_, v_hl_1451_);
lean_dec_ref(v_range_1447_);
return v_res_1453_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2(lean_object* v_range_1454_, lean_object* v_b_1455_, lean_object* v_i_1456_, lean_object* v_hs_1457_, lean_object* v_hl_1458_){
_start:
{
lean_object* v___x_1460_; 
v___x_1460_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___redArg(v_range_1454_, v_b_1455_, v_i_1456_);
return v___x_1460_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2___boxed(lean_object* v_range_1461_, lean_object* v_b_1462_, lean_object* v_i_1463_, lean_object* v_hs_1464_, lean_object* v_hl_1465_, lean_object* v___y_1466_){
_start:
{
lean_object* v_res_1467_; 
v_res_1467_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00BalancedSqrt_run4096_spec__1_spec__2(v_range_1461_, v_b_1462_, v_i_1463_, v_hs_1464_, v_hl_1465_);
lean_dec_ref(v_range_1461_);
return v_res_1467_;
}
}
static lean_object* _init_l_main___boxed__const__1(void){
_start:
{
uint32_t v___x_1487_; lean_object* v___x_1488_; 
v___x_1487_ = 0;
v___x_1488_ = lean_box_uint32(v___x_1487_);
return v___x_1488_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_1489_){
_start:
{
if (lean_obj_tag(v_args_1489_) == 1)
{
lean_object* v_tail_1497_; 
v_tail_1497_ = lean_ctor_get(v_args_1489_, 1);
lean_inc(v_tail_1497_);
if (lean_obj_tag(v_tail_1497_) == 1)
{
lean_object* v_tail_1498_; 
v_tail_1498_ = lean_ctor_get(v_tail_1497_, 1);
lean_inc(v_tail_1498_);
if (lean_obj_tag(v_tail_1498_) == 1)
{
lean_object* v_head_1499_; lean_object* v_head_1500_; lean_object* v_head_1501_; lean_object* v_tail_1502_; uint8_t v___y_1504_; 
v_head_1499_ = lean_ctor_get(v_args_1489_, 0);
lean_inc(v_head_1499_);
lean_dec_ref_known(v_args_1489_, 2);
v_head_1500_ = lean_ctor_get(v_tail_1497_, 0);
lean_inc(v_head_1500_);
lean_dec_ref_known(v_tail_1497_, 2);
v_head_1501_ = lean_ctor_get(v_tail_1498_, 0);
lean_inc(v_head_1501_);
v_tail_1502_ = lean_ctor_get(v_tail_1498_, 1);
lean_inc(v_tail_1502_);
lean_dec_ref_known(v_tail_1498_, 2);
if (lean_obj_tag(v_tail_1502_) == 0)
{
lean_object* v___x_1560_; uint8_t v___x_1561_; 
v___x_1560_ = ((lean_object*)(l_BalancedSqrt_execute___closed__1));
v___x_1561_ = lean_string_dec_eq(v_head_1499_, v___x_1560_);
if (v___x_1561_ == 0)
{
lean_object* v___x_1562_; uint8_t v___x_1563_; 
v___x_1562_ = ((lean_object*)(l_main___closed__13));
v___x_1563_ = lean_string_dec_eq(v_head_1499_, v___x_1562_);
v___y_1504_ = v___x_1563_;
goto v___jp_1503_;
}
else
{
v___y_1504_ = v___x_1561_;
goto v___jp_1503_;
}
}
else
{
lean_dec(v_tail_1502_);
lean_dec(v_head_1501_);
lean_dec(v_head_1500_);
lean_dec(v_head_1499_);
goto v___jp_1494_;
}
v___jp_1503_:
{
if (v___y_1504_ == 0)
{
lean_object* v___x_1505_; lean_object* v___x_1506_; 
lean_dec(v_head_1501_);
lean_dec(v_head_1500_);
lean_dec(v_head_1499_);
v___x_1505_ = ((lean_object*)(l_main___closed__3));
v___x_1506_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1506_, 0, v___x_1505_);
return v___x_1506_;
}
else
{
lean_object* v___x_1507_; lean_object* v___x_1508_; lean_object* v___x_1509_; lean_object* v___x_1510_; 
v___x_1507_ = lean_unsigned_to_nat(0u);
v___x_1508_ = lean_string_utf8_byte_size(v_head_1501_);
v___x_1509_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1509_, 0, v_head_1501_);
lean_ctor_set(v___x_1509_, 1, v___x_1507_);
lean_ctor_set(v___x_1509_, 2, v___x_1508_);
v___x_1510_ = l_String_Slice_toNat_x3f(v___x_1509_);
lean_dec_ref_known(v___x_1509_, 3);
if (lean_obj_tag(v___x_1510_) == 1)
{
lean_object* v_val_1511_; lean_object* v___x_1513_; uint8_t v_isShared_1514_; uint8_t v_isSharedCheck_1557_; 
v_val_1511_ = lean_ctor_get(v___x_1510_, 0);
v_isSharedCheck_1557_ = !lean_is_exclusive(v___x_1510_);
if (v_isSharedCheck_1557_ == 0)
{
v___x_1513_ = v___x_1510_;
v_isShared_1514_ = v_isSharedCheck_1557_;
goto v_resetjp_1512_;
}
else
{
lean_inc(v_val_1511_);
lean_dec(v___x_1510_);
v___x_1513_ = lean_box(0);
v_isShared_1514_ = v_isSharedCheck_1557_;
goto v_resetjp_1512_;
}
v_resetjp_1512_:
{
uint8_t v___x_1515_; 
v___x_1515_ = lean_nat_dec_lt(v___x_1507_, v_val_1511_);
if (v___x_1515_ == 0)
{
lean_object* v___x_1516_; lean_object* v___x_1518_; 
lean_dec(v_val_1511_);
lean_dec(v_head_1500_);
lean_dec(v_head_1499_);
v___x_1516_ = ((lean_object*)(l_main___closed__5));
if (v_isShared_1514_ == 0)
{
lean_ctor_set(v___x_1513_, 0, v___x_1516_);
v___x_1518_ = v___x_1513_;
goto v_reusejp_1517_;
}
else
{
lean_object* v_reuseFailAlloc_1519_; 
v_reuseFailAlloc_1519_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1519_, 0, v___x_1516_);
v___x_1518_ = v_reuseFailAlloc_1519_;
goto v_reusejp_1517_;
}
v_reusejp_1517_:
{
return v___x_1518_;
}
}
else
{
lean_object* v___x_1520_; uint8_t v___x_1521_; 
v___x_1520_ = ((lean_object*)(l_main___closed__6));
v___x_1521_ = lean_string_dec_eq(v_head_1500_, v___x_1520_);
if (v___x_1521_ == 0)
{
lean_object* v___x_1522_; uint8_t v___x_1523_; 
v___x_1522_ = ((lean_object*)(l_main___closed__7));
v___x_1523_ = lean_string_dec_eq(v_head_1500_, v___x_1522_);
if (v___x_1523_ == 0)
{
lean_object* v___x_1524_; uint8_t v___x_1525_; 
v___x_1524_ = ((lean_object*)(l_main___closed__8));
v___x_1525_ = lean_string_dec_eq(v_head_1500_, v___x_1524_);
lean_dec(v_head_1500_);
if (v___x_1525_ == 0)
{
lean_object* v___x_1526_; lean_object* v___x_1528_; 
lean_dec(v_val_1511_);
lean_dec(v_head_1499_);
v___x_1526_ = ((lean_object*)(l_main___closed__10));
if (v_isShared_1514_ == 0)
{
lean_ctor_set(v___x_1513_, 0, v___x_1526_);
v___x_1528_ = v___x_1513_;
goto v_reusejp_1527_;
}
else
{
lean_object* v_reuseFailAlloc_1529_; 
v_reuseFailAlloc_1529_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1529_, 0, v___x_1526_);
v___x_1528_ = v_reuseFailAlloc_1529_;
goto v_reusejp_1527_;
}
v_reusejp_1527_:
{
return v___x_1528_;
}
}
else
{
lean_object* v___x_1530_; 
lean_del_object(v___x_1513_);
v___x_1530_ = l_BalancedSqrt_run4096(v_head_1499_, v_val_1511_);
lean_dec(v_head_1499_);
if (lean_obj_tag(v___x_1530_) == 0)
{
lean_dec_ref_known(v___x_1530_, 1);
goto v___jp_1491_;
}
else
{
lean_object* v_a_1531_; lean_object* v___x_1533_; uint8_t v_isShared_1534_; uint8_t v_isSharedCheck_1538_; 
v_a_1531_ = lean_ctor_get(v___x_1530_, 0);
v_isSharedCheck_1538_ = !lean_is_exclusive(v___x_1530_);
if (v_isSharedCheck_1538_ == 0)
{
v___x_1533_ = v___x_1530_;
v_isShared_1534_ = v_isSharedCheck_1538_;
goto v_resetjp_1532_;
}
else
{
lean_inc(v_a_1531_);
lean_dec(v___x_1530_);
v___x_1533_ = lean_box(0);
v_isShared_1534_ = v_isSharedCheck_1538_;
goto v_resetjp_1532_;
}
v_resetjp_1532_:
{
lean_object* v___x_1536_; 
if (v_isShared_1534_ == 0)
{
v___x_1536_ = v___x_1533_;
goto v_reusejp_1535_;
}
else
{
lean_object* v_reuseFailAlloc_1537_; 
v_reuseFailAlloc_1537_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1537_, 0, v_a_1531_);
v___x_1536_ = v_reuseFailAlloc_1537_;
goto v_reusejp_1535_;
}
v_reusejp_1535_:
{
return v___x_1536_;
}
}
}
}
}
else
{
lean_object* v___x_1539_; 
lean_del_object(v___x_1513_);
lean_dec(v_head_1500_);
v___x_1539_ = l_BalancedSqrt_run2048(v_head_1499_, v_val_1511_);
lean_dec(v_head_1499_);
if (lean_obj_tag(v___x_1539_) == 0)
{
lean_dec_ref_known(v___x_1539_, 1);
goto v___jp_1491_;
}
else
{
lean_object* v_a_1540_; lean_object* v___x_1542_; uint8_t v_isShared_1543_; uint8_t v_isSharedCheck_1547_; 
v_a_1540_ = lean_ctor_get(v___x_1539_, 0);
v_isSharedCheck_1547_ = !lean_is_exclusive(v___x_1539_);
if (v_isSharedCheck_1547_ == 0)
{
v___x_1542_ = v___x_1539_;
v_isShared_1543_ = v_isSharedCheck_1547_;
goto v_resetjp_1541_;
}
else
{
lean_inc(v_a_1540_);
lean_dec(v___x_1539_);
v___x_1542_ = lean_box(0);
v_isShared_1543_ = v_isSharedCheck_1547_;
goto v_resetjp_1541_;
}
v_resetjp_1541_:
{
lean_object* v___x_1545_; 
if (v_isShared_1543_ == 0)
{
v___x_1545_ = v___x_1542_;
goto v_reusejp_1544_;
}
else
{
lean_object* v_reuseFailAlloc_1546_; 
v_reuseFailAlloc_1546_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1546_, 0, v_a_1540_);
v___x_1545_ = v_reuseFailAlloc_1546_;
goto v_reusejp_1544_;
}
v_reusejp_1544_:
{
return v___x_1545_;
}
}
}
}
}
else
{
lean_object* v___x_1548_; 
lean_del_object(v___x_1513_);
lean_dec(v_head_1500_);
v___x_1548_ = l_BalancedSqrt_run1024(v_head_1499_, v_val_1511_);
lean_dec(v_head_1499_);
if (lean_obj_tag(v___x_1548_) == 0)
{
lean_dec_ref_known(v___x_1548_, 1);
goto v___jp_1491_;
}
else
{
lean_object* v_a_1549_; lean_object* v___x_1551_; uint8_t v_isShared_1552_; uint8_t v_isSharedCheck_1556_; 
v_a_1549_ = lean_ctor_get(v___x_1548_, 0);
v_isSharedCheck_1556_ = !lean_is_exclusive(v___x_1548_);
if (v_isSharedCheck_1556_ == 0)
{
v___x_1551_ = v___x_1548_;
v_isShared_1552_ = v_isSharedCheck_1556_;
goto v_resetjp_1550_;
}
else
{
lean_inc(v_a_1549_);
lean_dec(v___x_1548_);
v___x_1551_ = lean_box(0);
v_isShared_1552_ = v_isSharedCheck_1556_;
goto v_resetjp_1550_;
}
v_resetjp_1550_:
{
lean_object* v___x_1554_; 
if (v_isShared_1552_ == 0)
{
v___x_1554_ = v___x_1551_;
goto v_reusejp_1553_;
}
else
{
lean_object* v_reuseFailAlloc_1555_; 
v_reuseFailAlloc_1555_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1555_, 0, v_a_1549_);
v___x_1554_ = v_reuseFailAlloc_1555_;
goto v_reusejp_1553_;
}
v_reusejp_1553_:
{
return v___x_1554_;
}
}
}
}
}
}
}
else
{
lean_object* v___x_1558_; lean_object* v___x_1559_; 
lean_dec(v___x_1510_);
lean_dec(v_head_1500_);
lean_dec(v_head_1499_);
v___x_1558_ = ((lean_object*)(l_main___closed__12));
v___x_1559_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1559_, 0, v___x_1558_);
return v___x_1559_;
}
}
}
}
else
{
lean_dec_ref_known(v_tail_1497_, 2);
lean_dec(v_tail_1498_);
lean_dec_ref_known(v_args_1489_, 2);
goto v___jp_1494_;
}
}
else
{
lean_dec(v_tail_1497_);
lean_dec_ref_known(v_args_1489_, 2);
goto v___jp_1494_;
}
}
else
{
lean_dec(v_args_1489_);
goto v___jp_1494_;
}
v___jp_1491_:
{
lean_object* v___x_1492_; lean_object* v___x_1493_; 
v___x_1492_ = l_main___boxed__const__1;
v___x_1493_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1493_, 0, v___x_1492_);
return v___x_1493_;
}
v___jp_1494_:
{
lean_object* v___x_1495_; lean_object* v___x_1496_; 
v___x_1495_ = ((lean_object*)(l_main___closed__1));
v___x_1496_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1496_, 0, v___x_1495_);
return v___x_1496_;
}
}
}
LEAN_EXPORT lean_object* l_main___boxed(lean_object* v_args_1564_, lean_object* v_a_1565_){
_start:
{
lean_object* v_res_1566_; 
v_res_1566_ = _lean_main(v_args_1564_);
return v_res_1566_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_BalancedSqrt(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_floatlibBenchmarks_FloatLibBenchmarks_Public_Sweep(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0 = _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0();
lean_mark_persistent(l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run1024_spec__0);
l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0 = _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0();
lean_mark_persistent(l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run2048_spec__0);
l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0 = _init_l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0();
lean_mark_persistent(l_FloatLibBenchmarks_Public_Sweep_inputsSqrt___at___00BalancedSqrt_run4096_spec__0);
l_main___boxed__const__1 = _init_l_main___boxed__const__1();
lean_mark_persistent(l_main___boxed__const__1);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_BalancedSqrt(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = lean_unbox_uint32(lean_io_result_get_value(res));
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
