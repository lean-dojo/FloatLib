#!/usr/bin/env python3
"""Compile only scratch drivers, pinned to CPU41; never calibrate or time."""
from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess

HERE = Path(__file__).resolve().parent
BASE = HERE.parents[1]
REPO = BASE / "FloatLib"
CACHE = BASE / "integration-build"
BUILD = HERE.parent / "build"
AUDIT = HERE.parent / "audit"
TOOLCHAIN = Path("/home/ec2-user/.elan/toolchains/leanprover--lean4---v4.34.0")
IMAGE = "leanfloat-flocq-bench:4.2.2"
IMAGE_ID = "sha256:80d13ef0e8c4dbcab28b3812192071b8c0c1644b074d58ae2f03a9d9e1aea7b6"


def sha(path):
    return hashlib.file_digest(path.open("rb"), "sha256").hexdigest()


def main():
    os.sched_setaffinity(0, {41})
    (HERE / "tmp").mkdir(exist_ok=True)
    (HERE / "logs").mkdir(exist_ok=True)
    environment = dict(os.environ, TMPDIR=str(HERE / "tmp"),
                       LEAN_PATH=(AUDIT / "lean-path.txt").read_text().strip())
    commands = []

    def run(name, args):
        command = ["taskset", "-c", "41", *map(str, args)]
        commands.append({"name": name, "argv": command})
        (HERE / "compile-commands.json").write_text(json.dumps(commands, indent=2) + "\n")
        print("compile:", name, flush=True)
        with (HERE / "logs" / (name + ".log")).open("w") as log:
            subprocess.run(command, cwd=HERE, env=environment,
                           stdout=log, stderr=subprocess.STDOUT, check=True)

    actual_image = subprocess.check_output(
        ["docker", "image", "inspect", "--format", "{{.Id}}", IMAGE], text=True).strip()
    if actual_image != IMAGE_ID:
        raise RuntimeError("pinned Flocq image changed")
    extraction = json.loads((AUDIT / "extraction-manifest.json").read_text())
    for name, digest in extraction.items():
        if sha(BUILD / name) != digest:
            raise RuntimeError("retained extracted artifact changed: " + name)

    adapter = (REPO / "benchmarks/rocq/flocq_format_bench.ml").read_text()
    prefix, separator, _ = adapter.partition("let run_binary ")
    assert separator and "let result_bits precision" in prefix
    (HERE / "balanced_flocq.ml").write_text(
        prefix + (HERE / "balanced_flocq_suffix.ml").read_text())

    run("lean", [TOOLCHAIN / "bin/lean", "-c", HERE / "BalancedSqrt.c",
                 "-o", HERE / "BalancedSqrt.olean", HERE / "BalancedSqrt.lean"])
    compile_trace = json.loads(
        (CACHE / "ir/FloatLibBenchmarks/Public/FormatComparison.c.o.export.trace").read_text())
    original = shlex.split(compile_trace["log"][0]["message"].removeprefix(".> "))
    compile_args = [str(HERE / "BalancedSqrt.c") if a.endswith("/FormatComparison.c")
                    else str(HERE / "BalancedSqrt.o") if a.endswith("/FormatComparison.c.o.export")
                    else a for a in original]
    run("lean-c", compile_args)
    response = shlex.split((CACHE / "bin/execFloatFormatComparison.rsp").read_text())
    old_object = str(CACHE / "ir/FloatLibBenchmarks/Public/FormatComparison.c.o.export")
    assert response.count(old_object) == 1
    response = [str(HERE / "BalancedSqrt.o") if a == old_object else a for a in response]
    (HERE / "balanced-floatlib.rsp").write_text("\n".join(shlex.quote(a) for a in response) + "\n")
    run("lean-link", [TOOLCHAIN / "bin/clang", "-o", HERE / "balanced-floatlib",
                      "@" + str(HERE / "balanced-floatlib.rsp")])
    run("mpfr", ["gcc", "-O3", "-DNDEBUG", "-fno-lto", HERE / "balanced_mpfr.c",
                 "-lmpfr", "-lgmp", "-o", HERE / "balanced-mpfr"])
    run("ocaml", ["docker", "run", "--rm", "--network", "none", "--cpuset-cpus", "41",
                  "--mount", f"type=bind,src={BUILD},dst=/kernel,readonly",
                  "--mount", f"type=bind,src={HERE},dst=/scratch",
                  "--workdir", "/scratch", "--env", "TMPDIR=/scratch/tmp", IMAGE_ID,
                  "ocamlfind", "ocamlopt", "-O3", "-package", "zarith", "-linkpkg",
                  "-I", "/kernel", "/kernel/flocq_kernel.cmx", "/kernel/monotonic_clock.o",
                  "balanced_flocq.ml", "-cclib", "-lrt", "-o", "balanced-flocq"])
    source_paths = [
        REPO / "benchmarks/lean/FloatLibBenchmarks/Public/FormatComparison.lean",
        REPO / "benchmarks/lean/FloatLibBenchmarks/Public/Sweep.lean",
        REPO / "benchmarks/lean/FloatLibBenchmarks/Support/ExactWorkload.lean",
        REPO / "benchmarks/lean/FloatLibBenchmarks/Support/Sink.lean",
        REPO / "benchmarks/c/exact_format_mpfr.c",
        REPO / "benchmarks/c/benchmark_mpfr_protocol.h",
        REPO / "benchmarks/c/benchmark_protocol.h",
        REPO / "benchmarks/rocq/FlocqKernel.v",
        REPO / "benchmarks/rocq/flocq_format_bench.ml",
        REPO / "benchmarks/plots/format_comparison.py",
    ]
    artifact_paths = [
        CACHE / "bin/execFloatFormatComparison",
        CACHE / "bin/execFloatFormatComparison.rsp",
        HERE / "BalancedSqrt.c", HERE / "BalancedSqrt.o",
        HERE / "balanced-floatlib", HERE / "balanced-mpfr", HERE / "balanced-flocq",
        *[BUILD / name for name in extraction],
    ]
    manifest = {
        "status": "compiled; no timing or calibration",
        "compile_cpu": 41, "image_tag": IMAGE, "image_id": IMAGE_ID,
        "sources": {str(p): sha(p) for p in source_paths},
        "scratch_sources": {str(p): sha(p) for p in HERE.iterdir()
                            if p.suffix in {".lean", ".c", ".ml", ".py"}},
        "artifacts": {str(p): sha(p) for p in artifact_paths},
        "retained_full_value_audit": {
            str(AUDIT / name): sha(AUDIT / name)
            for name in ["agreement.json", "canonical-values.jsonl", "floatlib-values.txt",
                         "mpfr-values.txt", "flocq-values.txt", "extraction-manifest.json"]
        },
        "flocq_adapter_prefix_sha256": hashlib.sha256(prefix.encode()).hexdigest(),
        "cached_link": "Original response file; only root FormatComparison object replaced.",
    }
    (HERE / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print("Compiled all three drivers. No performance run.", flush=True)


if __name__ == "__main__":
    main()
