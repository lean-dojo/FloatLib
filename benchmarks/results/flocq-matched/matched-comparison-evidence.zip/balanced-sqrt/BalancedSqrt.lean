/- Scratch supplement; FloatLib's existing MIT license applies to reused code. -/
import FloatLibBenchmarks.Public.Sweep

open FloatLib.Floats FloatLib.Numerics
open FloatLib.Floats.Formats.BinaryInterchange
open FloatLibBenchmarks.Support
open scoped FloatLib.Floats.ExecFloat.Backend.PlanningThroughput

namespace BalancedSqrt

structure State where
  sink : UInt64 := Sink.initial
  trace : UInt64 := Sink.initial

/-- Choose from the remaining fixtures using the previous observed result.
The caller makes exactly sixteen choices before resetting `used`. -/
@[noinline] def nextUnused (used sink : UInt64) : Nat := Id.run do
  let mut index := Sink.dependentIndex sink
  for _ in [:16] do
    if used &&& (1 <<< UInt64.ofNat index) == 0 then
      return index
    index := (index + 1) % 16
  return index

@[inline] def advance (s : State) (index : Nat) (bits : UInt64) : State :=
  ⟨Sink.mix s.sink bits, Sink.mixNat s.trace index⟩

-- Only storage types differ. These loops call the same public sqrt capability
-- and exact input helper as the frozen FormatComparison executable.
@[noinline] def block1024 :
    Nat → UInt64 → Array (ExecFloat (ExecFloat.Binary.Family 19 1004)) → State → State
  | 0, _, _, s => s
  | n + 1, used, xs, s =>
    let index := nextUnused used s.sink
    let value := ExecFloat.sqrt xs[index]!
    block1024 n (used ||| (1 <<< UInt64.ofNat index)) xs
      (advance s index (FloatLibBenchmarks.Public.Sweep.resultBits value))

@[noinline] def block2048 :
    Nat → UInt64 → Array (ExecFloat (ExecFloat.Binary.Family 19 2028)) → State → State
  | 0, _, _, s => s
  | n + 1, used, xs, s =>
    let index := nextUnused used s.sink
    let value := ExecFloat.sqrt xs[index]!
    block2048 n (used ||| (1 <<< UInt64.ofNat index)) xs
      (advance s index (FloatLibBenchmarks.Public.Sweep.resultBits value))

@[noinline] def block4096 :
    Nat → UInt64 → Array (ExecFloat (ExecFloat.Binary.Family 19 4076)) → State → State
  | 0, _, _, s => s
  | n + 1, used, xs, s =>
    let index := nextUnused used s.sink
    let value := ExecFloat.sqrt xs[index]!
    block4096 n (used ||| (1 <<< UInt64.ofNat index)) xs
      (advance s index (FloatLibBenchmarks.Public.Sweep.resultBits value))

@[noinline] def blocks1024 (xs : Array (ExecFloat (ExecFloat.Binary.Family 19 1004))) :
    Nat → State → State
  | 0, s => s
  | n + 1, s => blocks1024 xs n (block1024 16 0 xs s)

@[noinline] def blocks2048 (xs : Array (ExecFloat (ExecFloat.Binary.Family 19 2028))) :
    Nat → State → State
  | 0, s => s
  | n + 1, s => blocks2048 xs n (block2048 16 0 xs s)

@[noinline] def blocks4096 (xs : Array (ExecFloat (ExecFloat.Binary.Family 19 4076))) :
    Nat → State → State
  | 0, s => s
  | n + 1, s => blocks4096 xs n (block4096 16 0 xs s)

def output (mode : String) (width blocks nanos : Nat) (s : State) : IO Unit :=
  IO.println s!"block|floatlib|{mode}|{width}|{blocks}|{nanos}|{s.sink}|{s.trace}"

/-- IO references keep warmup and the observed timed result on the intended
side of the monotonic clock calls. Parsing and fixture preparation precede this. -/
@[noinline] def execute (mode : String) (width blocks : Nat)
    (run : Nat → State → State) (dump : IO Unit) : IO Unit := do
  let result ← IO.mkRef ({} : State)
  if mode == "validate" then
    dump
    result.set (run blocks {})
    output mode width blocks 0 (← result.get)
  else
    result.set (run 1 {})
    let warmup ← result.get
    IO.println s!"warmup|floatlib|{width}|1|{warmup.sink}|{warmup.trace}"
    let start ← IO.monoNanosNow
    result.set (run blocks {})
    let stop ← IO.monoNanosNow
    let observed ← result.get
    output mode width blocks (stop - start) observed

def run1024 (mode : String) (blocks : Nat) : IO Unit := do
  let xs := FloatLibBenchmarks.Public.Sweep.inputsSqrt (ExecFloat.Binary.Family 19 1004)
  execute mode 1024 blocks (blocks1024 xs) do
    for index in [:16] do
      let value := ExecFloat.sqrt xs[index]!
      let raw := (BenchmarkCarrier.toModel (Format := FloatFormat) (Model := Model) value).toNatBits
      IO.println s!"value|1024|{index}|raw|{raw}"

def run2048 (mode : String) (blocks : Nat) : IO Unit := do
  let xs := FloatLibBenchmarks.Public.Sweep.inputsSqrt (ExecFloat.Binary.Family 19 2028)
  execute mode 2048 blocks (blocks2048 xs) do
    for index in [:16] do
      let value := ExecFloat.sqrt xs[index]!
      let raw := (BenchmarkCarrier.toModel (Format := FloatFormat) (Model := Model) value).toNatBits
      IO.println s!"value|2048|{index}|raw|{raw}"

def run4096 (mode : String) (blocks : Nat) : IO Unit := do
  let xs := FloatLibBenchmarks.Public.Sweep.inputsSqrt (ExecFloat.Binary.Family 19 4076)
  execute mode 4096 blocks (blocks4096 xs) do
    for index in [:16] do
      let value := ExecFloat.sqrt xs[index]!
      let raw := (BenchmarkCarrier.toModel (Format := FloatFormat) (Model := Model) value).toNatBits
      IO.println s!"value|4096|{index}|raw|{raw}"

end BalancedSqrt

def main (args : List String) : IO UInt32 := do
  match args with
  | [mode, width, blocks] =>
    unless mode == "validate" || mode == "time" do
      throw <| IO.userError "mode must be validate or time"
    let some count := blocks.toNat? | throw <| IO.userError "invalid block count"
    unless count > 0 do throw <| IO.userError "block count must be positive"
    match width with
    | "1024" => BalancedSqrt.run1024 mode count
    | "2048" => BalancedSqrt.run2048 mode count
    | "4096" => BalancedSqrt.run4096 mode count
    | _ => throw <| IO.userError "width must be 1024, 2048, or 4096"
    return 0
  | _ => throw <| IO.userError "usage: balanced-floatlib (validate|time) WIDTH BLOCKS"
