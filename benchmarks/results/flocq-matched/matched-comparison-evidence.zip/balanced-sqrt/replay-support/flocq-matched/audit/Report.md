Full-value Flocq agreement audit — 2026-09-18

**PASS: no value mismatches.** FloatLib's actual proved software paths, MPFR, and the newly extracted Flocq implementation agree on all **528 rounded inputs** and **1,056 arithmetic outputs**: 48 inputs and six operations × 16 outputs at each of 11 widths. This includes all sixteen 4096-bit square roots. Each lane supplied exactly 1,584 uniquely keyed records; missing, duplicate, unexpected, or malformed records were rejected.

The audit compared full arbitrary-precision dyadic values, retaining sign and every significand bit through 4096-bit storage. FloatLib supplied its complete raw encoding through `BenchmarkCarrier.toModel` and `Model.toNatBits`. MPFR supplied `mpfr_get_z_2exp`; Flocq supplied its full finite constructor. Comparison only removed powers of two from the significand and added them to the exponent. No 64-bit fingerprint was used to decide agreement.

| Storage bits | Exponent bits | Precision, including leading bit | Flocq `emax` | Inputs / outputs matched |
| ---: | ---: | ---: | ---: | ---: |
| 6 | 3 | 3 | 4 | 48 / 96 |
| 8 | 4 | 4 | 8 | 48 / 96 |
| 16 | 5 | 11 | 16 | 48 / 96 |
| 32 | 8 | 24 | 128 | 48 / 96 |
| 64 | 11 | 53 | 1024 | 48 / 96 |
| 128 | 15 | 113 | 16384 | 48 / 96 |
| 256 | 19 | 237 | 262144 | 48 / 96 |
| 512 | 19 | 493 | 262144 | 48 / 96 |
| 1024 | 19 | 1005 | 262144 | 48 / 96 |
| 2048 | 19 | 2029 | 262144 | 48 / 96 |
| 4096 | 19 | 4077 | 262144 | 48 / 96 |

The Lean, C, and OCaml source format tables were independently parsed and agreed at every supported width. Wide formats use precision `width − 19`, with 19 exponent bits; they are custom binary layouts. All eleven satisfy Flocq's required `0 < precision < emax`. The excluded layouts fail that precise requirement: width 4 has `(precision, emax) = (2, 2)`, width 5 has `(3, 2)`, and width 7 has `(4, 4)`. Their exclusion is correct for this certified Flocq interface.

The wrapper's proof arguments are appropriate. In the installed Flocq source, `Bdiv_correct_aux` quantifies positive integer significands and arbitrary integer exponents without requiring those operands to be representable in the destination format. The wrapper supplies numerator/exponent `numerator, 0`, denominator/exponent `denominator, 0`, numerator sign `sign`, denominator sign `false`, and nearest-even rounding. The fixture formula ensures a positive numerator and denominator. `proj1` supplies `valid_binary`; `SF2B` packages that result. Inspection of the extracted function confirms one `sFdiv_core_binary` followed by `binary_round_aux`, with no preliminary rounding of either integer operand. All six arithmetic wrappers also use nearest-even rounding.

Execution used the existing implementations:

- FloatLib: a scratch Lean driver imported cached `Public.Sweep`. Its actual input helpers use the same `ExactWorkload` vectors and `Model.roundRatQ` construction as `FormatComparison`. The driver called the explicit `Configured.Backend.word*` operations at 32/64 bits, and the public `ExecFloat` operations under `PlanningThroughput` elsewhere, matching the benchmark's dispatch choices. Results were obtained by Lean runtime evaluation; no reference arithmetic was substituted.
- MPFR: a scratch observer included the actual `exact_format_mpfr.c`, reusing its format-range selection, input initialization, and per-fixture arithmetic/gradual-underflow validation. The observer captured complete results before the original fingerprint computation.
- Flocq: the driver reused the OCaml benchmark's input functions and linked the existing extracted kernel object. It called the same six extracted operations, including fused `x[i] * y[i] + x[15-i]`. Build copies of the Rocq wrapper and OCaml benchmark matched the audited repository sources.

The environment was Lean 4.34.0, host MPFR 4.1.0/GCC 11.5.0, and Coq 8.20.1/OCaml 4.13.1 in `leanfloat-flocq-bench:4.2.2`. OCaml compilation and execution ran inside that existing image with networking disabled; the host GLIBC incompatibility did not affect the numerical audit. Parent-reported wrapper compilation was not repeated. No Lake build, full benchmark campaign, repository/EFS modification, or shared build lock was used by this audit.

Limits are explicit. These shared fixtures produced 1,174 positive finite values, 405 negative finite values, and five positive zeros per lane. The comparison preserves zero and infinity signs, but this dataset did **not** exercise negative zero, infinity, or NaN. Flocq's single-NaN interface cannot establish NaN payload/sign agreement. The result establishes complete agreement for the specified workload, not exhaustive format conformance or a timing result.

Evidence retained in this directory:

- `agreement.json`: counts, per-width outcomes, zero mismatches, and raw-data hashes.
- `floatlib-values.txt`, `mpfr-values.txt`, `flocq-values.txt`: complete original value dumps.
- `canonical-values.jsonl`: all three complete normalized values for every key.
- `format-domain.json`, `proof-evidence.json`: source-table checks and installed theorem/extraction excerpts.
- `source-manifest.json`, `extraction-manifest.json`, `run-manifest.json`, `environment.json`: source/artifact hashes, arithmetic provenance, and tool versions.
- Build/execution status and logs, plus `cleanup.json`.

Scratch driver sources, executables, compiler intermediates, and the full copied theorem source were deleted after their hashes and the audit evidence were captured. The parent's `flocq-matched/build` artifacts remain untouched.
