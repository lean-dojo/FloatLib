(*
  We time the OCaml code extracted from FlocqKernel.v, not the Rocq checker and
  not a hand-written replacement. Flocq is the external proved reference:
  https://flocq.gitlabpages.inria.fr/

  We construct the shared exact fixtures before timing and use the same
  result-dependent fixture chain as the other scalar lanes.
*)

module Zarith = Z

open Flocq_kernel

(* The extracted module also defines a type named [float]. Returning integer
   nanoseconds from the C clock keeps the timer independent of that generated
   name and avoids a conversion inside the measured interval. *)
external monotonic_nanos : unit -> int64 = "floatlib_monotonic_nanos"

(* Storage width, exponent-field width, and significand precision match the
   FloatLib and MPFR adapters. Flocq's certified IEEE interface requires
   precision < emax, excluding the 4-, 5-, and 7-bit custom layouts. *)
let formats =
  [|
    (6, 3, 3);
    (8, 4, 4);
    (16, 5, 11);
    (32, 8, 24);
    (64, 11, 53);
    (128, 15, 113);
    (256, 19, 237);
    (512, 19, 493);
    (1024, 19, 1005);
    (2048, 19, 2029);
    (4096, 19, 4077);
  |]
let operations = [| "add"; "sub"; "mul"; "div"; "sqrt"; "fma" |]

let z_of_int = Big_int_Z.big_int_of_int

let positive_env name default =
  match Sys.getenv_opt name with
  | None | Some "" -> default
  | Some text ->
      let value = int_of_string text in
      if value <= 0 then invalid_arg (name ^ " must be positive");
      value

let optional_width () =
  match Sys.getenv_opt "FORMAT_COMPARE_WIDTH" with
  | None | Some "" -> None
  | Some text ->
      let width = int_of_string text in
      if not (Array.exists (fun (candidate, _, _) -> candidate = width) formats)
      then invalid_arg ("unsupported FORMAT_COMPARE_WIDTH: " ^ text);
      Some width

let optional_operation () =
  match Sys.getenv_opt "FORMAT_COMPARE_OPERATION" with
  | None | Some "" -> None
  | Some operation ->
      if not (Array.exists (( = ) operation) operations)
      then invalid_arg ("unsupported FORMAT_COMPARE_OPERATION: " ^ operation);
      Some operation

let default_iterations width =
  if width <= 32 then 25_000
  else if width <= 64 then 10_000
  else if width <= 128 then 2_500
  else if width <= 256 then 500
  else if width <= 512 then 100
  else if width <= 1024 then 20
  else if width <= 2048 then 5
  else 1

let exact_input precision emax salt negative index =
  let numerator = ((index * salt + salt + 1) mod 113) + 7 in
  let denominator = ((index * 11 + salt) mod 29) + 32 in
  flocq_from_ratio
    (z_of_int precision)
    (z_of_int emax)
    negative
    (z_of_int numerator)
    (z_of_int denominator)

let inputs_x precision emax =
  Array.init 16 (fun index ->
      exact_input precision emax 37 (index mod 5 = 0) index)

let inputs_y precision emax =
  Array.init 16 (fun index ->
      exact_input precision emax 61 (index mod 3 = 0) index)

let inputs_sqrt precision emax =
  Array.init 16 (fun index -> exact_input precision emax 43 false index)

let mix_sink sink value =
  Int64.mul (Int64.logxor sink value) 1_099_511_628_211L

(* The unsigned FNV offset basis represented as an Int64 bit pattern. *)
let dependency_seed = Int64.of_string "-3750763034362895579"
let exponent_mix = Zarith.of_string "11400714819323198485"
let sign_mix = Zarith.of_string "9223372036854775808"
let zero_tag = Zarith.of_string "3257665815644502181"
let infinity_tag = Zarith.of_string "10067880064238660809"
let nan_tag = Zarith.of_string "5700357408180978091"
let two_to_64 = Zarith.shift_left Zarith.one 64

(* We use the preceding result to choose the next ordinary fixture. *)
let dependent_index sink =
  let folded =
    Int64.logxor sink (Int64.shift_right_logical sink 32)
  in
  let folded =
    Int64.logxor folded (Int64.shift_right_logical folded 16)
  in
  Int64.to_int (Int64.logand folded 15L)

let int64_of_uint64 value =
  let unsigned = Zarith.extract value 0 64 in
  let signed =
    if Zarith.testbit unsigned 63
    then Zarith.sub unsigned two_to_64
    else unsigned
  in
  Zarith.to_int64 signed

let special_fingerprint tag negative =
  int64_of_uint64 (if negative then Zarith.logxor tag sign_mix else tag)

let finite_fingerprint precision negative mantissa exponent =
  let used = Zarith.numbits mantissa in
  let normalized = Zarith.shift_left mantissa (precision - used) in
  if precision > 64 then
    int64_of_uint64 normalized
  else
    let normalized_exponent = Zarith.add exponent (Zarith.of_int used) in
    let mixed_exponent = Zarith.mul normalized_exponent exponent_mix in
    let fingerprint = Zarith.logxor normalized mixed_exponent in
    let fingerprint =
      if negative then Zarith.logxor fingerprint sign_mix else fingerprint
    in
    int64_of_uint64 fingerprint

(* Flocq stores finite values as mantissa × 2^exponent. We normalize that
   representation before hashing it, matching the token used by FloatLib,
   MPFR, native C, SoftFloat, and CPython. *)
let result_bits precision = function
  | B754_zero negative -> special_fingerprint zero_tag negative
  | B754_infinity negative -> special_fingerprint infinity_tag negative
  | B754_nan -> int64_of_uint64 nan_tag
  | B754_finite (negative, mantissa, exponent) ->
      finite_fingerprint precision negative mantissa exponent

(*
  Scratch supplement; prep.py prepends the exact current adapter definitions
  through result_bits. It links the retained extracted kernel unchanged.
*)
let[@inline never] next_unused used sink =
  let index = ref (dependent_index sink) in
  let fuel = ref 16 in
  while !fuel > 0 && used land (1 lsl !index) <> 0 do
    index := (!index + 1) land 15;
    decr fuel
  done;
  if !fuel = 0 then invalid_arg "full fixture mask";
  !index

let[@inline never] balanced_blocks operation precision blocks xs =
  let sink = ref dependency_seed in
  let trace = ref dependency_seed in
  for _block = 1 to blocks do
    let used = ref 0 in
    for _step = 1 to 16 do
      let index = next_unused !used !sink in
      used := !used lor (1 lsl index);
      let result = operation xs.(index) in
      sink := mix_sink !sink (result_bits precision result);
      trace := mix_sink !trace (Int64.of_int index)
    done
  done;
  (!sink, !trace)

let dump_value width index = function
  | B754_finite (negative, mantissa, exponent) ->
      Printf.printf "value|%d|%d|finite|%d|%s|%s\n%!"
        width index (if negative then 1 else 0)
        (Big_int_Z.string_of_big_int mantissa)
        (Big_int_Z.string_of_big_int exponent)
  | _ -> invalid_arg "positive sqrt fixture unexpectedly non-finite"

let () =
  if Array.length Sys.argv <> 4 then
    invalid_arg "usage: balanced-flocq (validate|time) WIDTH BLOCKS";
  let mode = Sys.argv.(1) in
  if mode <> "validate" && mode <> "time" then invalid_arg "invalid mode";
  let width = int_of_string Sys.argv.(2) in
  let blocks = int_of_string Sys.argv.(3) in
  if blocks <= 0 then invalid_arg "blocks must be positive";
  if width <> 1024 && width <> 2048 && width <> 4096
    then invalid_arg "unsupported width";
  let (_, exponent_bits, precision) =
    Array.find_opt (fun (w, _, _) -> w = width) formats |> Option.get in
  let emax = 1 lsl (exponent_bits - 1) in
  if precision <= 0 || precision >= emax then invalid_arg "Flocq format domain";
  let xs = inputs_sqrt precision emax in
  let operation = flocq_sqrt (z_of_int precision) (z_of_int emax) in
  let run = balanced_blocks operation precision in
  let ((sink, trace), nanos) =
    if mode = "validate" then begin
      Array.iteri (fun index value ->
        dump_value width index (operation value)) xs;
      (run blocks xs, 0L)
    end else begin
      let (warm_sink, warm_trace) = run 1 xs in
      Printf.printf "warmup|flocq|%d|1|%Lu|%Lu\n%!"
        width warm_sink warm_trace;
      let start = monotonic_nanos () in
      let result = run blocks xs in
      let stop = monotonic_nanos () in
      (result, Int64.sub stop start)
    end in
  Printf.printf "block|flocq|%s|%d|%d|%Ld|%Lu|%Lu\n%!"
    mode width blocks nanos sink trace
