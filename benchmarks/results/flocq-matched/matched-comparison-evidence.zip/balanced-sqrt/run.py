#!/usr/bin/env python3
"""Untimed validation now; `run` only after the parent releases CPU39."""
from pathlib import Path
import argparse
import ast
import csv
import hashlib
import json
import math
import os
import statistics
import subprocess
from datetime import datetime, timezone
from functools import lru_cache

HERE = Path(__file__).resolve().parent
BASE = HERE.parents[1]
AUDIT = HERE.parent / "audit"
WIDTHS = (1024, 2048, 4096)
LANES = ("floatlib", "mpfr", "flocq")
SERIES = {
    "floatlib": "ExecFloat binary proved software",
    "mpfr": "MPFR (binary) software reference",
    "flocq": "Flocq binary reference (precision model)",
}
SEED = 14695981039346656037
MASK = (1 << 64) - 1
FNV = 1099511628211
TARGET_NS = 200_000_000
MIN_NS = 50_000_000
DEFAULT_TRIALS = 1
METHOD = "result-dependent-complete-16-fixture-blocks"


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def verify_manifest():
    manifest = json.loads((HERE / "manifest.json").read_text())
    for group in ("sources", "scratch_sources", "artifacts", "retained_full_value_audit"):
        for name, digest in manifest[group].items():
            if sha(name) != digest:
                raise RuntimeError("changed source/evidence/artifact: " + name)
    actual_image = subprocess.check_output(
        ["docker", "image", "inspect", "--format", "{{.Id}}", manifest["image_tag"]],
        text=True).strip()
    if actual_image != manifest["image_id"]:
        raise RuntimeError("Flocq image changed")
    return manifest


def canonical(sign, mantissa, exponent):
    if mantissa <= 0:
        raise ValueError("expected a positive finite sqrt magnitude")
    trailing = (mantissa & -mantissa).bit_length() - 1
    return ["finite", sign, str(mantissa >> trailing), exponent + trailing]


def decode_raw(width, raw):
    if not 0 <= raw < (1 << width):
        raise ValueError("out-of-range encoding")
    fraction_bits = width - 20
    sign = raw >> (width - 1)
    exponent = (raw >> fraction_bits) & ((1 << 19) - 1)
    fraction = raw & ((1 << fraction_bits) - 1)
    if exponent in (0, (1 << 19) - 1):
        raise ValueError("these fixtures must produce positive normal values")
    return canonical(sign, (1 << fraction_bits) | fraction,
                     exponent - ((1 << 18) - 1) - fraction_bits)


@lru_cache(None)
def expected_values(width):
    rows = {}
    for line in (AUDIT / "canonical-values.jsonl").read_text().splitlines():
        row = json.loads(line)
        if row["width"] == width and row["group"] == "sqrt":
            values = row["values"]
            if not values["floatlib"] == values["mpfr"] == values["flocq"]:
                raise ValueError("retained audit disagrees")
            if row["index"] in rows:
                raise ValueError("duplicate retained fixture")
            rows[row["index"]] = values["floatlib"]
    if set(rows) != set(range(16)):
        raise ValueError("incomplete retained fixture vector")
    fingerprints = []
    seen = {}
    for index in range(16):
        value = rows[index]
        assert value[0:2] == ["finite", 0]
        mantissa = int(value[2])
        fingerprint = (mantissa << (width - 19 - mantissa.bit_length())) & MASK
        if fingerprint in seen and seen[fingerprint] != value:
            raise ValueError("unequal full values collide in timed observation")
        seen[fingerprint] = value
        fingerprints.append(fingerprint)
    return rows, tuple(fingerprints)


@lru_cache(None)
def expected_block(width, blocks):
    _, fingerprints = expected_values(width)
    sink = trace = SEED
    histogram = [0] * 16
    first_indices = []
    for block in range(blocks):
        used = 0
        for _ in range(16):
            folded = sink ^ (sink >> 32)
            index = (folded ^ (folded >> 16)) & 15
            for _fuel in range(16):
                if not used & (1 << index):
                    break
                index = (index + 1) & 15
            else:
                raise ValueError("mask exhausted early")
            used |= 1 << index
            sink = ((sink ^ fingerprints[index]) * FNV) & MASK
            trace = ((trace ^ index) * FNV) & MASK
            histogram[index] += 1
            if block == 0:
                first_indices.append(index)
        assert used == 65535
    assert histogram == [blocks] * 16
    return {"sink": sink, "trace": trace, "histogram": histogram,
            "first_block_indices": first_indices}


def command(lane, mode, width, blocks, cpu, image_id):
    arguments = [mode, str(width), str(blocks)]
    if lane != "flocq":
        return ["taskset", "-c", str(cpu), str(HERE / ("balanced-" + lane)), *arguments]
    return ["docker", "run", "--rm", "--network", "none", "--cpuset-cpus", str(cpu),
            "--mount", f"type=bind,src={HERE},dst=/scratch,readonly",
            "--mount", f"type=bind,src={HERE / 'tmp'},dst=/tmp",
            "--env", "TMPDIR=/tmp", image_id, "/scratch/balanced-flocq", *arguments]


def invoke(lane, mode, width, blocks, cpu, manifest, logdir, label):
    logdir.mkdir(parents=True, exist_ok=True)
    argv = command(lane, mode, width, blocks, cpu, manifest["image_id"])
    output = logdir / (label + ".txt")
    error = logdir / (label + ".stderr")
    write_json(logdir / (label + ".command.json"), argv)
    with output.open("w") as stdout, error.open("w") as stderr:
        subprocess.run(argv, env=dict(os.environ, TMPDIR=str(HERE / "tmp")),
                       stdout=stdout, stderr=stderr, check=True)
    values = {}
    records = []
    for line in output.read_text().splitlines():
        fields = line.split("|")
        if fields[0] == "value":
            if mode != "validate" or int(fields[1]) != width:
                raise ValueError("unexpected value record")
            index = int(fields[2])
            if index in values:
                raise ValueError("duplicate actual fixture")
            if fields[3] == "raw" and lane == "floatlib":
                value = decode_raw(width, int(fields[4]))
            elif fields[3] == "finite" and lane != "floatlib":
                value = canonical(int(fields[4]), int(fields[5]), int(fields[6]))
            else:
                raise ValueError("unexpected finite encoding")
            values[index] = value
        elif fields[0] == "warmup":
            if fields[1:4] != [lane, str(width), "1"]:
                raise ValueError("invalid warmup record")
            expected = expected_block(width, 1)
            if [int(x) & MASK for x in fields[4:6]] != [expected["sink"], expected["trace"]]:
                raise ValueError("warmup output/trace mismatch")
        elif fields[0] == "block":
            if fields[1:5] != [lane, mode, str(width), str(blocks)] or len(fields) != 8:
                raise ValueError("wrong block record")
            records.append({"lane": lane, "width": width, "blocks": blocks,
                            "iterations": blocks * 16, "totalNanos": int(fields[5]),
                            "sink": int(fields[6]) & MASK,
                            "fixtureTraceDigest": int(fields[7]) & MASK})
        else:
            raise ValueError("unexpected driver output: " + line[:160])
    if len(records) != 1:
        raise ValueError("missing or duplicate block result")
    result = records[0]
    expected = expected_block(width, blocks)
    if result["sink"] != expected["sink"] or result["fixtureTraceDigest"] != expected["trace"]:
        raise ValueError("complete-block output/trace disagrees with retained full values")
    if mode == "validate":
        if values != expected_values(width)[0] or result["totalNanos"] != 0:
            raise ValueError("full-value validation mismatch or unexpected timing")
    elif result["totalNanos"] <= 0:
        raise ValueError("timer returned nonpositive duration")
    result.update(log=str(output), log_sha256=sha(output))
    return result


def validate(manifest):
    receipts = []
    for width in WIDTHS:
        for lane in LANES:
            print(f"untimed CPU41 validation: {lane} width={width}", flush=True)
            receipt = invoke(lane, "validate", width, 1, 41, manifest,
                             HERE / "validation-logs", f"{lane}-{width}")
            receipt["full_values_checked"] = 16
            receipt["expected_block"] = expected_block(width, 1)
            receipts.append(receipt)
            write_json(HERE / "validation-progress.json", receipts)
    write_json(HERE / "validation.json", {
        "status": "PASS", "cpu": 41, "timed": False,
        "full_values_per_lane": 48, "full_value_checks": 144,
        "whole_block_checks": 9, "fixtures_per_block": 16,
        "manifest_sha256": sha(HERE / "manifest.json"),
        "retained_agreement_sha256": sha(AUDIT / "agreement.json"),
        "receipts": receipts,
        "limits": "Only the 48 original positive normal sqrt results are rechecked; "
                  "the retained broader audit binds other operations/widths. "
                  "Timed loops observe low 64 bits after full-value/collision validation.",
    })
    print("PASS: 144 complete values and nine block sink/trace checks; no timings.", flush=True)


def metadata(lane, width):
    source = HERE.parent / (lane + "-preflight.csv")
    rows = [r for r in csv.DictReader(source.open())
            if r["operation"] == "sqrt" and int(r["totalBits"]) == width
            and r["family"] != "posit"]
    assert len(rows) == 1
    keep = ("implementation", "family", "format", "totalBits",
            "operation", "executionClass", "backend")
    return {key: rows[0][key] for key in keep}


def summary_columns():
    path = BASE / "FloatLib/benchmarks/plots/format_comparison.py"
    tree = ast.parse(path.read_text())
    function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "write_summary")
    assignment = next(n for n in function.body if isinstance(n, ast.Assign)
                      and any(isinstance(t, ast.Name) and t.id == "fieldnames" for t in n.targets))
    return ast.literal_eval(assignment.value)


def percentile(values, probability):
    ordered = sorted(values)
    position = probability * (len(ordered) - 1)
    lower = math.floor(position)
    upper = math.ceil(position)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)


def summarize(directory):
    campaign = json.loads((directory / "campaign.json").read_text())
    if campaign["status"] != "PASS":
        raise ValueError("campaign incomplete")
    trials = campaign["trials_per_cell"]
    rows = campaign["trials"]
    summary = []
    for width in WIDTHS:
        for lane in LANES:
            group = [r for r in rows if r["width"] == width and r["lane"] == lane]
            assert len(group) == trials and {r["trial"] for r in group} == set(range(1, trials + 1))
            assert len({r["blocks"] for r in group}) == 1
            assert len({(r["sink"], r["fixtureTraceDigest"]) for r in group}) == 1
            assert all(r["totalNanos"] >= MIN_NS for r in group)
            values = [r["totalNanos"] / r["iterations"] for r in group]
            median = statistics.median(values)
            agreement = expected_block(width, 1)
            row = dict(metadata(lane, width), series=SERIES[lane], measurementMethod=METHOD,
                       trials=trials, iterations=group[0]["iterations"], sink=group[0]["sink"],
                       fixtureTraceDigest=group[0]["fixtureTraceDigest"], agreementIterations=16,
                       agreementSink=agreement["sink"], agreementFixtureTraceDigest=agreement["trace"])
            measures = {
                "minimumNanosPerOp": min(values), "p05NanosPerOp": percentile(values, .05),
                "q1NanosPerOp": percentile(values, .25), "medianNanosPerOp": median,
                "meanNanosPerOp": statistics.fmean(values), "q3NanosPerOp": percentile(values, .75),
                "p95NanosPerOp": percentile(values, .95), "maximumNanosPerOp": max(values),
                "standardDeviationNanosPerOp": statistics.stdev(values) if trials > 1 else 0.0,
                "medianAbsoluteDeviationNanosPerOp": statistics.median(abs(v - median) for v in values),
                "medianOperationsPerSecond": 1e9 / median,
            }
            row.update({k: f"{v:.9f}" for k, v in measures.items()})
            summary.append(row)
    with (directory / "summary.csv").open("w") as stream:
        writer = csv.DictWriter(stream, fieldnames=summary_columns(), lineterminator="\n")
        writer.writeheader()
        writer.writerows(summary)
    raw_columns = ["series", "trial", "blocks", "implementation", "family", "format",
                   "totalBits", "operation", "executionClass", "backend", "measurementMethod",
                   "iterations", "totalNanos", "sink", "fixtureTraceDigest",
                   "agreementIterations", "agreementSink", "agreementFixtureTraceDigest"]
    with (directory / "raw.csv").open("w") as stream:
        writer = csv.DictWriter(stream, fieldnames=raw_columns, lineterminator="\n")
        writer.writeheader()
        for sample in rows:
            lane, width = sample["lane"], sample["width"]
            agreement = expected_block(width, 1)
            raw = dict(metadata(lane, width), series=SERIES[lane], measurementMethod=METHOD,
                       agreementIterations=16, agreementSink=agreement["sink"],
                       agreementFixtureTraceDigest=agreement["trace"])
            raw.update({k: sample[k] for k in ("trial", "blocks", "iterations", "totalNanos",
                                             "sink", "fixtureTraceDigest")})
            writer.writerow(raw)
    print(f"Wrote nine summary cells and {len(rows)} raw trials to {directory}", flush=True)


def run_campaign(manifest, directory, cpu, trials=DEFAULT_TRIALS):
    if cpu != 39:
        raise ValueError("this supplemental campaign is reserved for CPU39")
    validation = json.loads((HERE / "validation.json").read_text())
    if validation["status"] != "PASS" or validation["manifest_sha256"] != sha(HERE / "manifest.json"):
        raise ValueError("validation no longer matches compiled artifacts")
    directory.mkdir(parents=True, exist_ok=False)
    state = {
        "status": "RUNNING", "started": datetime.now(timezone.utc).isoformat(),
        "cpu": cpu, "method": METHOD, "targetNanos": TARGET_NS, "minimumNanos": MIN_NS,
        "trials_per_cell": trials, "fixtures_per_block": 16, "warmup_blocks_per_process": 1,
        "manifest_sha256": sha(HERE / "manifest.json"),
        "validation_sha256": sha(HERE / "validation.json"),
        "calibration": [], "discarded_trials": [], "trials": [],
        "startup": "One process per calibration attempt/trial; initialization and warmup outside timer.",
    }

    def save():
        write_json(directory / "campaign.json", state)

    save()
    try:
        for width in WIDTHS:
            counts = {}
            for lane in LANES:
                blocks = 1
                for attempt in range(1, 13):
                    label = f"calibration-{lane}-{width}-{attempt}"
                    result = invoke(lane, "time", width, blocks, cpu, manifest,
                                    directory / "logs", label)
                    state["calibration"].append(result)
                    save()
                    if result["totalNanos"] >= TARGET_NS:
                        counts[lane] = blocks
                        break
                    blocks = max(blocks + 1, math.ceil(blocks * TARGET_NS / result["totalNanos"]))
                else:
                    raise RuntimeError(f"calibration did not converge for {lane}/{width}")
            # Rotate lane order; count remains fixed within each final cell.
            pending = {lane: [] for lane in LANES}
            attempts = {lane: 0 for lane in LANES}
            round_number = 0
            while any(len(pending[lane]) < trials for lane in LANES):
                shift = round_number % len(LANES)
                for lane in LANES[shift:] + LANES[:shift]:
                    if len(pending[lane]) == trials:
                        continue
                    attempts[lane] += 1
                    if attempts[lane] > 36:
                        raise RuntimeError("too many short-trial retries")
                    blocks = counts[lane]
                    label = f"trial-{lane}-{width}-attempt{attempts[lane]}"
                    print(f"CPU{cpu}: {lane} width={width} blocks={blocks} "
                          f"trial={len(pending[lane]) + 1}/{trials}", flush=True)
                    result = invoke(lane, "time", width, blocks, cpu, manifest,
                                    directory / "logs", label)
                    if result["totalNanos"] < MIN_NS:
                        # No selective removal: discard the entire partial cell and
                        # obtain a fresh cell at a larger whole-block count.
                        state["discarded_trials"].extend([*pending[lane], result])
                        pending[lane] = []
                        counts[lane] = max(blocks + 1, math.ceil(blocks * TARGET_NS / result["totalNanos"]))
                    else:
                        result["trial"] = len(pending[lane]) + 1
                        pending[lane].append(result)
                    state["in_progress_width"] = width
                    state["in_progress_trials"] = pending
                    save()
                round_number += 1
            state["trials"].extend(r for lane in LANES for r in pending[lane])
            state.pop("in_progress_trials", None)
            save()
        assert len(state["trials"]) == len(WIDTHS) * len(LANES) * trials
        state["status"] = "PASS"
        state["finished"] = datetime.now(timezone.utc).isoformat()
        save()
        summarize(directory)
    except BaseException as error:
        state["status"] = "FAILED"
        state["error"] = str(error)
        save()
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("validate", "run", "summarize"))
    parser.add_argument("--cpu", type=int, default=39)
    parser.add_argument("--trials", type=int, choices=(1, 9), default=DEFAULT_TRIALS)
    parser.add_argument("--output", type=Path, default=HERE / "results")
    args = parser.parse_args()
    os.sched_setaffinity(0, {41})
    if args.mode == "summarize":
        summarize(args.output.resolve())
        return
    manifest = verify_manifest()
    if args.mode == "validate":
        validate(manifest)
    else:
        run_campaign(manifest, args.output.resolve(), args.cpu, args.trials)


if __name__ == "__main__":
    main()
