(*
  Scratch supplement; prep.py prepends the exact current adapter definitions
  through result_bits. It links the retained extracted kernel unchanged.
*)
let[@inline never] next_unused used sink =
  let index = ref (dependent_index sink) in
  let fuel = ref 16 in
  while !fuel > 0 && used land (1 lsl !index) <> 0 do
    index := (!index + 1) land 15;
    decr fuel
  done;
  if !fuel = 0 then invalid_arg "full fixture mask";
  !index

let[@inline never] balanced_blocks operation precision blocks xs =
  let sink = ref dependency_seed in
  let trace = ref dependency_seed in
  for _block = 1 to blocks do
    let used = ref 0 in
    for _step = 1 to 16 do
      let index = next_unused !used !sink in
      used := !used lor (1 lsl index);
      let result = operation xs.(index) in
      sink := mix_sink !sink (result_bits precision result);
      trace := mix_sink !trace (Int64.of_int index)
    done
  done;
  (!sink, !trace)

let dump_value width index = function
  | B754_finite (negative, mantissa, exponent) ->
      Printf.printf "value|%d|%d|finite|%d|%s|%s\n%!"
        width index (if negative then 1 else 0)
        (Big_int_Z.string_of_big_int mantissa)
        (Big_int_Z.string_of_big_int exponent)
  | _ -> invalid_arg "positive sqrt fixture unexpectedly non-finite"

let () =
  if Array.length Sys.argv <> 4 then
    invalid_arg "usage: balanced-flocq (validate|time) WIDTH BLOCKS";
  let mode = Sys.argv.(1) in
  if mode <> "validate" && mode <> "time" then invalid_arg "invalid mode";
  let width = int_of_string Sys.argv.(2) in
  let blocks = int_of_string Sys.argv.(3) in
  if blocks <= 0 then invalid_arg "blocks must be positive";
  if width <> 1024 && width <> 2048 && width <> 4096
    then invalid_arg "unsupported width";
  let (_, exponent_bits, precision) =
    Array.find_opt (fun (w, _, _) -> w = width) formats |> Option.get in
  let emax = 1 lsl (exponent_bits - 1) in
  if precision <= 0 || precision >= emax then invalid_arg "Flocq format domain";
  let xs = inputs_sqrt precision emax in
  let operation = flocq_sqrt (z_of_int precision) (z_of_int emax) in
  let run = balanced_blocks operation precision in
  let ((sink, trace), nanos) =
    if mode = "validate" then begin
      Array.iteri (fun index value ->
        dump_value width index (operation value)) xs;
      (run blocks xs, 0L)
    end else begin
      let (warm_sink, warm_trace) = run 1 xs in
      Printf.printf "warmup|flocq|%d|1|%Lu|%Lu\n%!"
        width warm_sink warm_trace;
      let start = monotonic_nanos () in
      let result = run blocks xs in
      let stop = monotonic_nanos () in
      (result, Int64.sub stop start)
    end in
  Printf.printf "block|flocq|%s|%d|%d|%Ld|%Lu|%Lu\n%!"
    mode width blocks nanos sink trace
