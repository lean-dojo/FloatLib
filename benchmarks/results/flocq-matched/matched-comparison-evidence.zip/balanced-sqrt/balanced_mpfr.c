/* Scratch supplement. Reuses FloatLib's locally licensed benchmark adapter. */
#define main original_format_benchmark_main
#include "../../FloatLib/benchmarks/c/exact_format_mpfr.c"
#undef main

static NOINLINE size_t next_unused(uint64_t used, uint64_t sink) {
  size_t index = floatlib_benchmark_dependent_index(sink, 16);
  for (unsigned fuel = 0; fuel < 16; ++fuel) {
    if ((used & (UINT64_C(1) << index)) == 0) return index;
    index = (index + 1) & 15;
  }
  abort(); /* The block always has an unused fixture at this call. */
}

static NOINLINE struct floatlib_benchmark_result balanced_blocks(
    size_t blocks, mpfr_t xs[16], mpfr_t rounded) {
  struct floatlib_benchmark_result result = {
      FLOATLIB_BENCHMARK_DEPENDENCY_SEED, FLOATLIB_BENCHMARK_FIXTURE_TRACE_SEED};
  for (size_t block = 0; block < blocks; ++block) {
    uint64_t used = 0;
    for (unsigned step = 0; step < 16; ++step) {
      size_t index = next_unused(used, result.sink);
      used |= UINT64_C(1) << index;
      int ternary = mpfr_sqrt(rounded, xs[index], MPFR_RNDN);
      mpfr_subnormalize(rounded, ternary, MPFR_RNDN);
      result.sink = floatlib_benchmark_mix_sink(
          result.sink, floatlib_benchmark_mpfr_result_fingerprint(rounded));
      result.fixture_trace = floatlib_benchmark_mix_fixture_trace(
          result.fixture_trace, index);
    }
  }
  return result;
}

static void dump_value(unsigned width, unsigned index, mpfr_t value) {
  if (!mpfr_number_p(value) || mpfr_zero_p(value)) abort();
  mpz_t significand;
  mpz_init(significand);
  mpfr_exp_t exponent = mpfr_get_z_2exp(significand, value);
  int negative = mpz_sgn(significand) < 0;
  mpz_abs(significand, significand);
  printf("value|%u|%u|finite|%d|", width, index, negative);
  mpz_out_str(stdout, 10, significand);
  printf("|%ld\n", (long)exponent);
  mpz_clear(significand);
}

int main(int argc, char **argv) {
  if (argc != 4 ||
      (strcmp(argv[1], "validate") != 0 && strcmp(argv[1], "time") != 0)) {
    fputs("usage: balanced-mpfr (validate|time) WIDTH BLOCKS\n", stderr);
    return 2;
  }
  size_t width = positive_size_text("width", argv[2]);
  size_t blocks = positive_size_text("blocks", argv[3]);
  if (width != 1024 && width != 2048 && width != 4096) return 2;
  const struct format_case *format = NULL;
  for (size_t i = 0; i < sizeof(format_cases) / sizeof(format_cases[0]); ++i)
    if (format_cases[i].total_bits == width) format = &format_cases[i];
  if (format == NULL) return 2;
  select_format_range(format);
  mpfr_t xs[16], ys[16], sqrt_xs[16], rounded;
  init_inputs(format->precision, xs, ys, sqrt_xs);
  mpfr_init2(rounded, format->precision);
  struct floatlib_benchmark_result result;
  uint64_t nanos = 0;
  if (strcmp(argv[1], "validate") == 0) {
    for (unsigned index = 0; index < 16; ++index) {
      int ternary = mpfr_sqrt(rounded, sqrt_xs[index], MPFR_RNDN);
      mpfr_subnormalize(rounded, ternary, MPFR_RNDN);
      dump_value((unsigned)width, index, rounded);
    }
    result = balanced_blocks(blocks, sqrt_xs, rounded);
  } else {
    result = balanced_blocks(1, sqrt_xs, rounded);
    printf("warmup|mpfr|%zu|1|%" PRIu64 "|%" PRIu64 "\n",
           width, result.sink, result.fixture_trace);
    uint64_t start = monotonic_nanos();
    result = balanced_blocks(blocks, sqrt_xs, rounded);
    uint64_t stop = monotonic_nanos();
    nanos = stop - start;
  }
  printf("block|mpfr|%s|%zu|%zu|%" PRIu64 "|%" PRIu64 "|%" PRIu64 "\n",
         argv[1], width, blocks, nanos, result.sink, result.fixture_trace);
  mpfr_clear(rounded);
  clear_inputs(xs, ys, sqrt_xs);
  mpfr_free_cache();
  return 0;
}
