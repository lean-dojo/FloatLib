Completed: nine sqrt cells (1024/2048/4096 × FloatLib/MPFR/Flocq), one trial each, on CPU39. The timing process exited 0. No repository or slide files were edited.

Each complete block visits the same sixteen original fixtures exactly once. The evolving result checksum chooses an unused index by cyclic probing; the used mask resets at each block boundary while checksum and fixture trace carry forward. Every result contributes to both later selection and the observable sink. Generated C and native-object inspection retain the sqrt calls and both loop backedges (`codegen-audit.json` and `codegen/`).

Calibration targets 200ms with whole blocks; every accepted trial is at least 50ms. There is one complete untimed warmup block per process. Preparation and clocks' setup are outside measured work. Slow Flocq blocks stay whole even when they exceed the target. All three lanes use the same control algorithm.

Full-value checks matched all 144 current lane/fixture outputs against the retained 1,584-value audit; nine complete-block checksum/trace checks and three additional two-block checks at width1024 passed on CPU41. No numerical binaries changed when the Python runner was changed to one trial. Both manifest versions and the binding explanation are retained.

`results-one-trial/summary.csv` has the main plot's exact summary columns and requested series names; `raw.csv` contains all nine accepted trials. `campaign.json` and `logs/` preserve calibration and trial records. The raw method tag is `result-dependent-complete-16-fixture-blocks`; the frozen main raw parser accepts only its original tag. Merge the summary cells directly or have parent integration handle the new method explicitly.

One trial gives no variability estimate: p05, median and p95 equal the observation, and standard deviation is recorded as zero by convention. These positive normal fixtures establish the shared workload, not accuracy over every input class.

| Width | Implementation | Blocks | Operations | Measured ms | ns/op |
|---:|---|---:|---:|---:|---:|
| 1024 | ExecFloat binary proved software | 1137 | 18192 | 200.042 | 10996.175 |
| 1024 | MPFR (binary) software reference | 23289 | 372624 | 200.444 | 537.926 |
| 1024 | Flocq binary reference (precision model) | 1 | 16 | 754.996 | 47187232.312 |
| 2048 | ExecFloat binary proved software | 723 | 11568 | 200.337 | 17318.226 |
| 2048 | MPFR (binary) software reference | 13607 | 217712 | 200.909 | 922.821 |
| 2048 | Flocq binary reference (precision model) | 1 | 16 | 3846.457 | 240403586.438 |
| 4096 | ExecFloat binary proved software | 326 | 5216 | 198.356 | 38028.419 |
| 4096 | MPFR (binary) software reference | 6616 | 105856 | 199.543 | 1885.046 |
| 4096 | Flocq binary reference (precision model) | 1 | 16 | 21510.677 | 1344417297.938 |

The whole campaign took 115.0s including startup, calibration and warmup; its shortest accepted interval was 198.356ms.

See `Replay.md` for commands and cache prerequisites, `manifest.json` for exact SHA-256s, and `archive-files.json` for the parent archive inventory. Compiled outputs are retained pending the parent's hash/archive confirmation.
