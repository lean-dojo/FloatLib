# FloatLib, extracted Flocq, and MPFR: one-trial comparison

The plotted table contains 198 cells: three implementations, eleven binary
widths, and six operations. Each cell contains one timed trial.

189 cells come from main/trial-01.csv. The nine square-root cells at 1024,
2048, and 4096 bits come from balanced-sqrt/raw.csv. Each of these
supplemental trials visits every one of the sixteen fixtures equally often.
The source column in matched-benchmark-summary.csv records that selection.
The larger campaign was stopped at the user's request; later trials and
partial trials do not contribute to this figure. Its log and resource
record are retained as context, not as additional plotted samples.

All timed cells exceed 50 ms. Input preparation, startup, warmup, agreement
checks, and output are outside the timers. The times include allocation,
result observation, and loop/adapter costs. No variability estimate is
made from one trial.

source/FloatLib-source.tar.gz contains the measured library and corrected
main benchmark harness. Its manifest records every source hash. From that
source tree, after installing its pinned Lean/mathlib dependencies and the
documented MPFR/Docker prerequisites, the main command is:

    FORMAT_COMPARE_PROFILE=flocq FORMAT_COMPARE_DEVELOPMENT_ONLY=1 \
    FORMAT_COMPARE_CPU=39 bash benchmarks/scripts/format-comparison.sh 1 OUTPUT

Use an available logical CPU on the replay machine. The Flocq Docker image
and toolchain versions are recorded in numerical-audit/environment.json.
The harness can build its image from benchmarks/rocq/Dockerfile.

The square-root supplement is a separate benchmark driver. Its Lean, C,
and OCaml source, build commands, compiled artifact hashes, complete-value
checks, and generated-code excerpts are under balanced-sqrt/. The scripts
record their original local directory layout; adjust those paths to the
replay workspace. Build and validate the drivers before using run.py run
--cpu 39 --trials 1 --output OUTPUT. Keep its complete-block method when
comparing the wide square-root points.

numerical-audit/ contains full-value comparisons of 528 inputs and 1056
operation results across the three implementations. checks/ contains the
additional 256-step agreement checks for all 66 operation/width pairs.
These workloads contain finite values and positive zero; the checks do
not cover NaN payloads or exception flags.

The plot generator also uses the deck's public/fonts/lmroman10-regular.otf.
The corrected slide and its companion method note link this archive.
