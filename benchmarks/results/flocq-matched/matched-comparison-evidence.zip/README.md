# Matched FloatLib, Flocq, and MPFR comparison: evidence archive

This archive holds the nine-trial campaign of 2026-10-31 on FloatLib 2.0.0
(commit `8c88715`). `benchmarks/plots/flocq_matched.py` reads it directly.

- `main/` is the output of `benchmarks/scripts/format-comparison.sh` with the
  Flocq profile: nine trials of 198 cells (FloatLib, Flocq, and MPFR at eleven
  widths and six operations), calibration pilots, trial order, backend selection,
  process resources, the 256-operation agreement report, and `metadata.txt`.
  `main/MANIFEST.tsv` is the campaign's own manifest. Its `metadata.txt` entry
  hashes the bytes before redaction, which `publication-redactions.json` next to
  this archive records.
- `balanced-sqrt/` is the square-root supplement at 1,024, 2,048, and 4,096 bits.
  All three implementations visit every one of the sixteen inputs once per block,
  in a result-dependent order. `results-9trials/raw.csv` holds nine trials of the
  nine cells. `validation.json` and `two-block-validation.json` check the complete
  values, `codegen/` compares the driver's generated square-root code with the
  campaign executable's, and `run.py.diff-from-recorded` shows the path and CPU
  edits to the earlier driver.
- `numerical-audit/` compares the full significand, exponent, and sign of all 528
  prepared inputs and 1,056 results across the three implementations.
  `drivers/` holds the two value-dump drivers written for this run.
- `summary/` holds the nine-trial medians with 5th and 95th percentiles
  (`matched-ratios-median.csv`), the one-trial selection rule of the earlier
  campaign applied to this run (`matched-benchmark-summary-trial01.csv`), a
  cell-by-cell comparison with the earlier campaign (`rerun-vs-recorded.csv`), and
  headline counts (`headline.json`).
- `flocq-build/` holds the extracted Flocq sources and the hashes of the rebuilt
  benchmark, `scripts/` the wrappers and analysis scripts, and `logs/` the build
  logs and load samples.
- `matched-benchmark-summary.csv` is the website table: per cell, the median,
  minimum, and maximum time per operation over nine trials, with the complete-block
  square roots replacing the main chain at 1,024 bits and above.

The campaign ran pinned to logical CPU 92 of an Intel Xeon Platinum 8275CL that
other work shared, with load averages between 35 and 126. FloatLib was built with
Lean 4.35.0 and Mathlib `56a00585`. Flocq 4.2.2 was extracted with Coq 8.20.1 and
compiled with OCaml 4.13.1 and Zarith 1.14 in the pinned image `80d13ef0e8c4`.
MPFR 4.1.0 was used with GCC 11.5.0. The Flocq wrapper, its OCaml driver, the MPFR
adapter, and the exact workload are byte-identical to the earlier campaign's, and the
extracted OCaml is identical to the earlier extraction.

Local paths and the host name are replaced by `/workspace` and
`benchmark-host.example.invalid` placeholders. `SHA256.json` lists the published
bytes of every member.
