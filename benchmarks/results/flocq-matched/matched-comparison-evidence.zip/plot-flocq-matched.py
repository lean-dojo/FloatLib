"""Render all cells of the matched FloatLib, Flocq, and MPFR campaign."""

from pathlib import Path
import csv

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.ticker import FixedLocator, FuncFormatter, NullLocator

here = Path(__file__).resolve().parent
root = here.parent.parent
font_manager.fontManager.addfont(str(root / "public/fonts/lmroman10-regular.otf"))
plt.rcParams.update({
    "font.family": "Latin Modern Roman",
    "font.size": 12,
    "mathtext.fontset": "cm",
    "text.color": "#172333",
    "axes.labelcolor": "#172333",
    "xtick.color": "#586474",
    "ytick.color": "#586474",
    "svg.fonttype": "path",
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.edgecolor": "#b9c5d5",
})

with (here / "matched-benchmark-summary.csv").open() as source:
    rows = list(csv.DictReader(source))
widths = {6, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096}
series = [
    ("ExecFloat binary proved software", "FloatLib binary", "#2878df", "s", "-"),
    ("Flocq binary reference (precision model)", "Extracted Flocq", "#60656f", "D", "--"),
    ("MPFR (binary) software reference", "MPFR", "#fa6635", "^", ":"),
]
operations = [
    ("add", "Addition"), ("sub", "Subtraction"), ("mul", "Multiplication"),
    ("div", "Division"), ("sqrt", "Square root"), ("fma", "Fused multiply-add"),
]
expected = {
    (name, operation, width)
    for name, *_ in series
    for operation, _ in operations
    for width in widths
}
actual = {(row["series"], row["operation"], int(row["totalBits"])) for row in rows}
assert actual == expected and len(rows) == len(expected), "Incomplete or duplicate matrix"
assert all(int(row["trials"]) == 1 for row in rows), "Expected one trial per cell"

fig, axes = plt.subplots(2, 3, figsize=(11.8, 4.87), sharex=True, sharey=True)
handles = {}
for ax, (operation, title) in zip(axes.flat, operations):
    for name, label, color, marker, style in series:
        data = sorted(
            (row for row in rows if row["series"] == name and row["operation"] == operation),
            key=lambda row: int(row["totalBits"]),
        )
        xs = [int(row["totalBits"]) for row in data]
        times = [float(row["nanosPerOp"]) for row in data]
        assert all(0 < value < 3e9 for value in times)
        line, = ax.plot(
            xs, times, color=color, marker=marker, linestyle=style,
            linewidth=1.7, markersize=3.4, label=label,
        )
        handles[label] = line
    ax.set_title(title, fontsize=14, loc="left", pad=4)
    ax.set_xscale("log", base=2)
    ax.set_yscale("log")
    ax.set_xlim(4.8, 5500)
    ax.set_ylim(3, 3e9)
    ax.xaxis.set_major_locator(FixedLocator([8, 32, 256, 4096]))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{int(value):,}"))
    ax.xaxis.set_minor_locator(NullLocator())
    ax.yaxis.set_major_locator(FixedLocator([10, 1e3, 1e5, 1e7, 1e9]))
    ax.yaxis.set_major_formatter(FuncFormatter(
        lambda value, _: {10: "10 ns", 1e3: "1 µs", 1e5: "100 µs", 1e7: "10 ms", 1e9: "1 s"}[value]
    ))
    ax.yaxis.set_minor_locator(NullLocator())
    ax.tick_params(axis="both", labelsize=11, length=2.5, pad=3)
    ax.grid(alpha=.25, linewidth=.7)

fig.legend(
    [handles[label] for _, label, *_ in series],
    [label for _, label, *_ in series],
    loc="upper center", bbox_to_anchor=(.56, 1.015),
    ncol=3, frameon=False, fontsize=13, handlelength=2.1,
    columnspacing=2.8, handletextpad=.55,
)
fig.text(.008, .44, "Time / operation · lower is faster",
         rotation=90, ha="left", va="center", fontsize=12)
fig.text(.56, .012, "Encoded width (bits) · logarithmic axes",
         ha="center", va="bottom", fontsize=12)
fig.subplots_adjust(left=.087, right=.995, bottom=.11, top=.86,
                    wspace=.14, hspace=.39)
fig.savefig(root / "public/revision-floatlib/matched-flocq.svg")
print(f"Plotted all {len(rows)} matched cells across six operations.")
