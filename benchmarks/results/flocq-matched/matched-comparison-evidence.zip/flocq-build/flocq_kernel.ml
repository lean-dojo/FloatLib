
(** val xorb : bool -> bool -> bool **)

let xorb b1 b2 =
  if b1 then if b2 then false else true else b2

(** val negb : bool -> bool **)

let negb = function
| true -> false
| false -> true

(** val fst : ('a1 * 'a2) -> 'a1 **)

let fst = function
| (x, _) -> x

type comparison =
| Eq
| Lt
| Gt

(** val eqb : bool -> bool -> bool **)

let eqb b1 b2 =
  if b1 then b2 else if b2 then false else true

module Pos =
 struct
  type mask =
  | IsNul
  | IsPos of Big_int_Z.big_int
  | IsNeg
 end

module Coq_Pos =
 struct
  (** val succ : Big_int_Z.big_int -> Big_int_Z.big_int **)

  let rec succ = Big_int_Z.succ_big_int

  (** val add :
      Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int **)

  let rec add = Big_int_Z.add_big_int

  (** val add_carry :
      Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int **)

  and add_carry x y =
    (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
      (fun p ->
      (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
        (fun q ->
        (fun x -> Big_int_Z.succ_big_int (Big_int_Z.mult_int_big_int 2 x))
        (add_carry p q))
        (fun q -> Big_int_Z.mult_int_big_int 2 (add_carry p q))
        (fun _ ->
        (fun x -> Big_int_Z.succ_big_int (Big_int_Z.mult_int_big_int 2 x))
        (succ p))
        y)
      (fun p ->
      (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
        (fun q -> Big_int_Z.mult_int_big_int 2 (add_carry p q))
        (fun q ->
        (fun x -> Big_int_Z.succ_big_int (Big_int_Z.mult_int_big_int 2 x))
        (add p q))
        (fun _ -> Big_int_Z.mult_int_big_int 2 (succ p))
        y)
      (fun _ ->
      (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
        (fun q ->
        (fun x -> Big_int_Z.succ_big_int (Big_int_Z.mult_int_big_int 2 x))
        (succ q))
        (fun q -> Big_int_Z.mult_int_big_int 2 (succ q))
        (fun _ ->
        (fun x -> Big_int_Z.succ_big_int (Big_int_Z.mult_int_big_int 2 x))
        Big_int_Z.unit_big_int)
        y)
      x

  (** val pred_double : Big_int_Z.big_int -> Big_int_Z.big_int **)

  let rec pred_double x =
    (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
      (fun p ->
      (fun x -> Big_int_Z.succ_big_int (Big_int_Z.mult_int_big_int 2 x))
      (Big_int_Z.mult_int_big_int 2 p))
      (fun p ->
      (fun x -> Big_int_Z.succ_big_int (Big_int_Z.mult_int_big_int 2 x))
      (pred_double p))
      (fun _ -> Big_int_Z.unit_big_int)
      x

  type mask = Pos.mask =
  | IsNul
  | IsPos of Big_int_Z.big_int
  | IsNeg

  (** val succ_double_mask : mask -> mask **)

  let succ_double_mask = function
  | IsNul -> IsPos Big_int_Z.unit_big_int
  | IsPos p ->
    IsPos ((fun x -> Big_int_Z.succ_big_int (Big_int_Z.mult_int_big_int 2 x))
      p)
  | IsNeg -> IsNeg

  (** val double_mask : mask -> mask **)

  let double_mask = function
  | IsPos p -> IsPos (Big_int_Z.mult_int_big_int 2 p)
  | x0 -> x0

  (** val double_pred_mask : Big_int_Z.big_int -> mask **)

  let double_pred_mask x =
    (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
      (fun p -> IsPos (Big_int_Z.mult_int_big_int 2
      (Big_int_Z.mult_int_big_int 2 p)))
      (fun p -> IsPos (Big_int_Z.mult_int_big_int 2
      (pred_double p)))
      (fun _ -> IsNul)
      x

  (** val sub_mask : Big_int_Z.big_int -> Big_int_Z.big_int -> mask **)

  let rec sub_mask x y =
    (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
      (fun p ->
      (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
        (fun q -> double_mask (sub_mask p q))
        (fun q -> succ_double_mask (sub_mask p q))
        (fun _ -> IsPos (Big_int_Z.mult_int_big_int 2 p))
        y)
      (fun p ->
      (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
        (fun q -> succ_double_mask (sub_mask_carry p q))
        (fun q -> double_mask (sub_mask p q))
        (fun _ -> IsPos (pred_double p))
        y)
      (fun _ ->
      (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
        (fun _ -> IsNeg)
        (fun _ -> IsNeg)
        (fun _ -> IsNul)
        y)
      x

  (** val sub_mask_carry : Big_int_Z.big_int -> Big_int_Z.big_int -> mask **)

  and sub_mask_carry x y =
    (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
      (fun p ->
      (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
        (fun q -> succ_double_mask (sub_mask_carry p q))
        (fun q -> double_mask (sub_mask p q))
        (fun _ -> IsPos (pred_double p))
        y)
      (fun p ->
      (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
        (fun q -> double_mask (sub_mask_carry p q))
        (fun q -> succ_double_mask (sub_mask_carry p q))
        (fun _ -> double_pred_mask p)
        y)
      (fun _ -> IsNeg)
      x

  (** val mul :
      Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int **)

  let rec mul = Big_int_Z.mult_big_int

  (** val iter : ('a1 -> 'a1) -> 'a1 -> Big_int_Z.big_int -> 'a1 **)

  let rec iter f x n =
    (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
      (fun n' -> f (iter f (iter f x n') n'))
      (fun n' -> iter f (iter f x n') n')
      (fun _ -> f x)
      n

  (** val div2 : Big_int_Z.big_int -> Big_int_Z.big_int **)

  let div2 p =
    (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
      (fun p0 -> p0)
      (fun p0 -> p0)
      (fun _ -> Big_int_Z.unit_big_int)
      p

  (** val div2_up : Big_int_Z.big_int -> Big_int_Z.big_int **)

  let div2_up p =
    (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
      (fun p0 -> succ p0)
      (fun p0 -> p0)
      (fun _ -> Big_int_Z.unit_big_int)
      p

  (** val compare_cont :
      comparison -> Big_int_Z.big_int -> Big_int_Z.big_int -> comparison **)

  let rec compare_cont = (fun c x y -> let s = Big_int_Z.compare_big_int x y in
  if s = 0 then c else if s < 0 then Lt else Gt)

  (** val compare : Big_int_Z.big_int -> Big_int_Z.big_int -> comparison **)

  let compare = (fun x y -> let s = Big_int_Z.compare_big_int x y in
  if s = 0 then Eq else if s < 0 then Lt else Gt)

  (** val leb : Big_int_Z.big_int -> Big_int_Z.big_int -> bool **)

  let leb x y =
    match compare x y with
    | Gt -> false
    | _ -> true

  (** val sqrtrem_step :
      (Big_int_Z.big_int -> Big_int_Z.big_int) -> (Big_int_Z.big_int ->
      Big_int_Z.big_int) -> (Big_int_Z.big_int * mask) ->
      Big_int_Z.big_int * mask **)

  let sqrtrem_step f g = function
  | (s, y) ->
    (match y with
     | IsPos r ->
       let s' =
         (fun x -> Big_int_Z.succ_big_int (Big_int_Z.mult_int_big_int 2 x))
         (Big_int_Z.mult_int_big_int 2 s)
       in
       let r' = g (f r) in
       if leb s' r'
       then (((fun x -> Big_int_Z.succ_big_int (Big_int_Z.mult_int_big_int 2 x))
              s), (sub_mask r' s'))
       else ((Big_int_Z.mult_int_big_int 2 s), (IsPos r'))
     | _ ->
       ((Big_int_Z.mult_int_big_int 2 s),
         (sub_mask (g (f Big_int_Z.unit_big_int))
           (Big_int_Z.mult_int_big_int 2 (Big_int_Z.mult_int_big_int 2
           Big_int_Z.unit_big_int)))))

  (** val sqrtrem : Big_int_Z.big_int -> Big_int_Z.big_int * mask **)

  let rec sqrtrem p =
    (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
      (fun p0 ->
      (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
        (fun p1 ->
        sqrtrem_step (fun x ->
          (fun x -> Big_int_Z.succ_big_int (Big_int_Z.mult_int_big_int 2 x))
          x) (fun x ->
          (fun x -> Big_int_Z.succ_big_int (Big_int_Z.mult_int_big_int 2 x))
          x) (sqrtrem p1))
        (fun p1 ->
        sqrtrem_step (fun x -> Big_int_Z.mult_int_big_int 2 x) (fun x ->
          (fun x -> Big_int_Z.succ_big_int (Big_int_Z.mult_int_big_int 2 x))
          x) (sqrtrem p1))
        (fun _ -> (Big_int_Z.unit_big_int, (IsPos
        (Big_int_Z.mult_int_big_int 2 Big_int_Z.unit_big_int))))
        p0)
      (fun p0 ->
      (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
        (fun p1 ->
        sqrtrem_step (fun x ->
          (fun x -> Big_int_Z.succ_big_int (Big_int_Z.mult_int_big_int 2 x))
          x) (fun x -> Big_int_Z.mult_int_big_int 2 x) (sqrtrem p1))
        (fun p1 ->
        sqrtrem_step (fun x -> Big_int_Z.mult_int_big_int 2 x) (fun x ->
          Big_int_Z.mult_int_big_int 2 x) (sqrtrem p1))
        (fun _ -> (Big_int_Z.unit_big_int, (IsPos Big_int_Z.unit_big_int)))
        p0)
      (fun _ -> (Big_int_Z.unit_big_int, IsNul))
      p
 end

module Z =
 struct
  (** val double : Big_int_Z.big_int -> Big_int_Z.big_int **)

  let double x =
    (fun fO fp fn z -> let s = Big_int_Z.sign_big_int z in
  if s = 0 then fO () else if s > 0 then fp z
  else fn (Big_int_Z.minus_big_int z))
      (fun _ -> Big_int_Z.zero_big_int)
      (fun p -> (Big_int_Z.mult_int_big_int 2 p))
      (fun p -> Big_int_Z.minus_big_int (Big_int_Z.mult_int_big_int 2 p))
      x

  (** val succ_double : Big_int_Z.big_int -> Big_int_Z.big_int **)

  let succ_double x =
    (fun fO fp fn z -> let s = Big_int_Z.sign_big_int z in
  if s = 0 then fO () else if s > 0 then fp z
  else fn (Big_int_Z.minus_big_int z))
      (fun _ -> Big_int_Z.unit_big_int)
      (fun p ->
      ((fun x -> Big_int_Z.succ_big_int (Big_int_Z.mult_int_big_int 2 x))
      p))
      (fun p -> Big_int_Z.minus_big_int (Coq_Pos.pred_double p))
      x

  (** val pred_double : Big_int_Z.big_int -> Big_int_Z.big_int **)

  let pred_double x =
    (fun fO fp fn z -> let s = Big_int_Z.sign_big_int z in
  if s = 0 then fO () else if s > 0 then fp z
  else fn (Big_int_Z.minus_big_int z))
      (fun _ -> Big_int_Z.minus_big_int Big_int_Z.unit_big_int)
      (fun p -> (Coq_Pos.pred_double p))
      (fun p -> Big_int_Z.minus_big_int
      ((fun x -> Big_int_Z.succ_big_int (Big_int_Z.mult_int_big_int 2 x)) p))
      x

  (** val pos_sub :
      Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int **)

  let rec pos_sub x y =
    (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
      (fun p ->
      (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
        (fun q -> double (pos_sub p q))
        (fun q -> succ_double (pos_sub p q))
        (fun _ -> (Big_int_Z.mult_int_big_int 2 p))
        y)
      (fun p ->
      (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
        (fun q -> pred_double (pos_sub p q))
        (fun q -> double (pos_sub p q))
        (fun _ -> (Coq_Pos.pred_double p))
        y)
      (fun _ ->
      (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
        (fun q -> Big_int_Z.minus_big_int (Big_int_Z.mult_int_big_int 2
        q))
        (fun q -> Big_int_Z.minus_big_int (Coq_Pos.pred_double q))
        (fun _ -> Big_int_Z.zero_big_int)
        y)
      x

  (** val add :
      Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int **)

  let add = Big_int_Z.add_big_int

  (** val opp : Big_int_Z.big_int -> Big_int_Z.big_int **)

  let opp = Big_int_Z.minus_big_int

  (** val sub :
      Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int **)

  let sub = Big_int_Z.sub_big_int

  (** val mul :
      Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int **)

  let mul = Big_int_Z.mult_big_int

  (** val pow_pos :
      Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int **)

  let pow_pos z0 =
    Coq_Pos.iter (mul z0) Big_int_Z.unit_big_int

  (** val pow :
      Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int **)

  let pow x y =
    (fun fO fp fn z -> let s = Big_int_Z.sign_big_int z in
  if s = 0 then fO () else if s > 0 then fp z
  else fn (Big_int_Z.minus_big_int z))
      (fun _ -> Big_int_Z.unit_big_int)
      (fun p -> pow_pos x p)
      (fun _ -> Big_int_Z.zero_big_int)
      y

  (** val compare : Big_int_Z.big_int -> Big_int_Z.big_int -> comparison **)

  let compare = (fun x y -> let s = Big_int_Z.compare_big_int x y in
  if s = 0 then Eq else if s < 0 then Lt else Gt)

  (** val leb : Big_int_Z.big_int -> Big_int_Z.big_int -> bool **)

  let leb x y =
    match compare x y with
    | Gt -> false
    | _ -> true

  (** val ltb : Big_int_Z.big_int -> Big_int_Z.big_int -> bool **)

  let ltb x y =
    match compare x y with
    | Lt -> true
    | _ -> false

  (** val max :
      Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int **)

  let max = Big_int_Z.max_big_int

  (** val min :
      Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int **)

  let min = Big_int_Z.min_big_int

  (** val to_pos : Big_int_Z.big_int -> Big_int_Z.big_int **)

  let to_pos z0 =
    (fun fO fp fn z -> let s = Big_int_Z.sign_big_int z in
  if s = 0 then fO () else if s > 0 then fp z
  else fn (Big_int_Z.minus_big_int z))
      (fun _ -> Big_int_Z.unit_big_int)
      (fun p -> p)
      (fun _ -> Big_int_Z.unit_big_int)
      z0

  (** val pos_div_eucl :
      Big_int_Z.big_int -> Big_int_Z.big_int ->
      Big_int_Z.big_int * Big_int_Z.big_int **)

  let rec pos_div_eucl a b =
    (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
      (fun a' ->
      let (q, r) = pos_div_eucl a' b in
      let r' =
        add (mul (Big_int_Z.mult_int_big_int 2 Big_int_Z.unit_big_int) r)
          Big_int_Z.unit_big_int
      in
      if ltb r' b
      then ((mul (Big_int_Z.mult_int_big_int 2 Big_int_Z.unit_big_int) q), r')
      else ((add
              (mul (Big_int_Z.mult_int_big_int 2 Big_int_Z.unit_big_int) q)
              Big_int_Z.unit_big_int), (sub r' b)))
      (fun a' ->
      let (q, r) = pos_div_eucl a' b in
      let r' = mul (Big_int_Z.mult_int_big_int 2 Big_int_Z.unit_big_int) r in
      if ltb r' b
      then ((mul (Big_int_Z.mult_int_big_int 2 Big_int_Z.unit_big_int) q), r')
      else ((add
              (mul (Big_int_Z.mult_int_big_int 2 Big_int_Z.unit_big_int) q)
              Big_int_Z.unit_big_int), (sub r' b)))
      (fun _ ->
      if leb (Big_int_Z.mult_int_big_int 2 Big_int_Z.unit_big_int) b
      then (Big_int_Z.zero_big_int, Big_int_Z.unit_big_int)
      else (Big_int_Z.unit_big_int, Big_int_Z.zero_big_int))
      a

  (** val div_eucl :
      Big_int_Z.big_int -> Big_int_Z.big_int ->
      Big_int_Z.big_int * Big_int_Z.big_int **)

  let div_eucl = Big_int_Z.(fun x y ->
  match sign_big_int y with
  | 0 -> (zero_big_int, x)
  | 1 -> quomod_big_int x y
  | _ -> let (q, r) = quomod_big_int (add_int_big_int (-1) x) y in
          (add_int_big_int (-1) q, add_big_int (add_int_big_int 1 y) r))

  (** val even : Big_int_Z.big_int -> bool **)

  let even z0 =
    (fun fO fp fn z -> let s = Big_int_Z.sign_big_int z in
  if s = 0 then fO () else if s > 0 then fp z
  else fn (Big_int_Z.minus_big_int z))
      (fun _ -> true)
      (fun p ->
      (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
        (fun _ -> false)
        (fun _ -> true)
        (fun _ -> false)
        p)
      (fun p ->
      (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
        (fun _ -> false)
        (fun _ -> true)
        (fun _ -> false)
        p)
      z0

  (** val div2 : Big_int_Z.big_int -> Big_int_Z.big_int **)

  let div2 z0 =
    (fun fO fp fn z -> let s = Big_int_Z.sign_big_int z in
  if s = 0 then fO () else if s > 0 then fp z
  else fn (Big_int_Z.minus_big_int z))
      (fun _ -> Big_int_Z.zero_big_int)
      (fun p ->
      (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
        (fun _ -> (Coq_Pos.div2 p))
        (fun _ -> (Coq_Pos.div2 p))
        (fun _ -> Big_int_Z.zero_big_int)
        p)
      (fun p -> Big_int_Z.minus_big_int (Coq_Pos.div2_up p))
      z0

  (** val sqrtrem :
      Big_int_Z.big_int -> Big_int_Z.big_int * Big_int_Z.big_int **)

  let sqrtrem n =
    (fun fO fp fn z -> let s = Big_int_Z.sign_big_int z in
  if s = 0 then fO () else if s > 0 then fp z
  else fn (Big_int_Z.minus_big_int z))
      (fun _ -> (Big_int_Z.zero_big_int, Big_int_Z.zero_big_int))
      (fun p ->
      let (s, m) = Coq_Pos.sqrtrem p in
      (match m with
       | Coq_Pos.IsPos r -> (s, r)
       | _ -> (s, Big_int_Z.zero_big_int)))
      (fun _ -> (Big_int_Z.zero_big_int, Big_int_Z.zero_big_int))
      n

  (** val shiftl :
      Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int **)

  let shiftl = Big_int_Z.(fun x y ->
  let y = int_of_big_int y in
  if y < 0 then shift_right_big_int x (-y)
  else shift_left_big_int x y)
 end

(** val zeq_bool : Big_int_Z.big_int -> Big_int_Z.big_int -> bool **)

let zeq_bool x y =
  match Z.compare x y with
  | Eq -> true
  | _ -> false

(** val shift_pos :
    Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int **)

let shift_pos n z0 =
  Coq_Pos.iter (fun x -> Big_int_Z.mult_int_big_int 2 x) z0 n

type spec_float =
| S754_zero of bool
| S754_infinity of bool
| S754_nan
| S754_finite of bool * Big_int_Z.big_int * Big_int_Z.big_int

(** val emin : Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int **)

let emin prec emax =
  Z.sub
    (Z.sub
      ((fun x -> Big_int_Z.succ_big_int (Big_int_Z.mult_int_big_int 2 x))
      Big_int_Z.unit_big_int) emax) prec

(** val fexp :
    Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int ->
    Big_int_Z.big_int **)

let fexp prec emax e =
  Z.max (Z.sub e prec) (emin prec emax)

(** val digits2_pos : Big_int_Z.big_int -> Big_int_Z.big_int **)

let rec digits2_pos n =
  (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
    (fun p -> Coq_Pos.succ (digits2_pos p))
    (fun p -> Coq_Pos.succ (digits2_pos p))
    (fun _ -> Big_int_Z.unit_big_int)
    n

(** val zdigits2 : Big_int_Z.big_int -> Big_int_Z.big_int **)

let zdigits2 n =
  (fun fO fp fn z -> let s = Big_int_Z.sign_big_int z in
  if s = 0 then fO () else if s > 0 then fp z
  else fn (Big_int_Z.minus_big_int z))
    (fun _ -> n)
    (fun p -> (digits2_pos p))
    (fun p -> (digits2_pos p))
    n

(** val iter_pos : ('a1 -> 'a1) -> Big_int_Z.big_int -> 'a1 -> 'a1 **)

let rec iter_pos f n x =
  (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
    (fun n' -> iter_pos f n' (iter_pos f n' (f x)))
    (fun n' -> iter_pos f n' (iter_pos f n' x))
    (fun _ -> f x)
    n

type location =
| Loc_Exact
| Loc_Inexact of comparison

type shr_record = { shr_m : Big_int_Z.big_int; shr_r : bool; shr_s : bool }

(** val shr_1 : shr_record -> shr_record **)

let shr_1 mrs =
  let { shr_m = m; shr_r = r; shr_s = s } = mrs in
  let s0 = (||) r s in
  ((fun fO fp fn z -> let s = Big_int_Z.sign_big_int z in
  if s = 0 then fO () else if s > 0 then fp z
  else fn (Big_int_Z.minus_big_int z))
     (fun _ -> { shr_m = Big_int_Z.zero_big_int; shr_r = false; shr_s =
     s0 })
     (fun p0 ->
     (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
       (fun p -> { shr_m = p; shr_r = true; shr_s = s0 })
       (fun p -> { shr_m = p; shr_r = false; shr_s = s0 })
       (fun _ -> { shr_m = Big_int_Z.zero_big_int; shr_r = true; shr_s =
       s0 })
       p0)
     (fun p0 ->
     (fun f2p1 f2p f1 p ->
  if Big_int_Z.le_big_int p Big_int_Z.unit_big_int then f1 () else
  let (q,r) = Big_int_Z.quomod_big_int p (Big_int_Z.big_int_of_int 2) in
  if Big_int_Z.eq_big_int r Big_int_Z.zero_big_int then f2p q else f2p1 q)
       (fun p -> { shr_m = (Big_int_Z.minus_big_int p); shr_r = true; shr_s =
       s0 })
       (fun p -> { shr_m = (Big_int_Z.minus_big_int p); shr_r = false;
       shr_s = s0 })
       (fun _ -> { shr_m = Big_int_Z.zero_big_int; shr_r = true; shr_s =
       s0 })
       p0)
     m)

(** val loc_of_shr_record : shr_record -> location **)

let loc_of_shr_record mrs =
  let { shr_m = _; shr_r = shr_r0; shr_s = shr_s0 } = mrs in
  if shr_r0
  then if shr_s0 then Loc_Inexact Gt else Loc_Inexact Eq
  else if shr_s0 then Loc_Inexact Lt else Loc_Exact

(** val shr_record_of_loc : Big_int_Z.big_int -> location -> shr_record **)

let shr_record_of_loc m = function
| Loc_Exact -> { shr_m = m; shr_r = false; shr_s = false }
| Loc_Inexact c ->
  (match c with
   | Eq -> { shr_m = m; shr_r = true; shr_s = false }
   | Lt -> { shr_m = m; shr_r = false; shr_s = true }
   | Gt -> { shr_m = m; shr_r = true; shr_s = true })

(** val shr :
    shr_record -> Big_int_Z.big_int -> Big_int_Z.big_int ->
    shr_record * Big_int_Z.big_int **)

let shr mrs e n =
  (fun fO fp fn z -> let s = Big_int_Z.sign_big_int z in
  if s = 0 then fO () else if s > 0 then fp z
  else fn (Big_int_Z.minus_big_int z))
    (fun _ -> (mrs, e))
    (fun p -> ((iter_pos shr_1 p mrs), (Z.add e n)))
    (fun _ -> (mrs, e))
    n

(** val shr_fexp :
    Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int ->
    Big_int_Z.big_int -> location -> shr_record * Big_int_Z.big_int **)

let shr_fexp prec emax m e l =
  shr (shr_record_of_loc m l) e
    (Z.sub (fexp prec emax (Z.add (zdigits2 m) e)) e)

(** val shl_align :
    Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int ->
    Big_int_Z.big_int * Big_int_Z.big_int **)

let shl_align mx ex ex' =
  (fun fO fp fn z -> let s = Big_int_Z.sign_big_int z in
  if s = 0 then fO () else if s > 0 then fp z
  else fn (Big_int_Z.minus_big_int z))
    (fun _ -> (mx, ex))
    (fun _ -> (mx, ex))
    (fun d -> ((shift_pos d mx), ex'))
    (Z.sub ex' ex)

(** val cond_Zopp : bool -> Big_int_Z.big_int -> Big_int_Z.big_int **)

let cond_Zopp b m =
  if b then Z.opp m else m

(** val new_location_even :
    Big_int_Z.big_int -> Big_int_Z.big_int -> location **)

let new_location_even nb_steps k =
  if zeq_bool k Big_int_Z.zero_big_int
  then Loc_Exact
  else Loc_Inexact
         (Z.compare
           (Z.mul (Big_int_Z.mult_int_big_int 2 Big_int_Z.unit_big_int) k)
           nb_steps)

(** val new_location_odd :
    Big_int_Z.big_int -> Big_int_Z.big_int -> location **)

let new_location_odd nb_steps k =
  if zeq_bool k Big_int_Z.zero_big_int
  then Loc_Exact
  else Loc_Inexact
         (match Z.compare
                  (Z.add
                    (Z.mul (Big_int_Z.mult_int_big_int 2
                      Big_int_Z.unit_big_int) k) Big_int_Z.unit_big_int)
                  nb_steps with
          | Eq -> Lt
          | x -> x)

(** val new_location : Big_int_Z.big_int -> Big_int_Z.big_int -> location **)

let new_location nb_steps =
  if Z.even nb_steps
  then new_location_even nb_steps
  else new_location_odd nb_steps

(** val sFdiv_core_binary :
    Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int ->
    Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int ->
    (Big_int_Z.big_int * Big_int_Z.big_int) * location **)

let sFdiv_core_binary prec emax m1 e1 m2 e2 =
  let d1 = zdigits2 m1 in
  let d2 = zdigits2 m2 in
  let e' =
    Z.min (fexp prec emax (Z.sub (Z.add d1 e1) (Z.add d2 e2))) (Z.sub e1 e2)
  in
  let s = Z.sub (Z.sub e1 e2) e' in
  let m' =
    (fun fO fp fn z -> let s = Big_int_Z.sign_big_int z in
  if s = 0 then fO () else if s > 0 then fp z
  else fn (Big_int_Z.minus_big_int z))
      (fun _ -> m1)
      (fun _ -> Z.shiftl m1 s)
      (fun _ -> Big_int_Z.zero_big_int)
      s
  in
  let (q, r) = Z.div_eucl m' m2 in ((q, e'), (new_location m2 r))

(** val sFsqrt_core_binary :
    Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int ->
    Big_int_Z.big_int -> (Big_int_Z.big_int * Big_int_Z.big_int) * location **)

let sFsqrt_core_binary prec emax m e =
  let d = zdigits2 m in
  let e' =
    Z.min
      (fexp prec emax (Z.div2 (Z.add (Z.add d e) Big_int_Z.unit_big_int)))
      (Z.div2 e)
  in
  let s =
    Z.sub e (Z.mul (Big_int_Z.mult_int_big_int 2 Big_int_Z.unit_big_int) e')
  in
  let m' =
    (fun fO fp fn z -> let s = Big_int_Z.sign_big_int z in
  if s = 0 then fO () else if s > 0 then fp z
  else fn (Big_int_Z.minus_big_int z))
      (fun _ -> m)
      (fun _ -> Z.shiftl m s)
      (fun _ -> Big_int_Z.zero_big_int)
      s
  in
  let (q, r) = Z.sqrtrem m' in
  let l =
    if zeq_bool r Big_int_Z.zero_big_int
    then Loc_Exact
    else Loc_Inexact (if Z.leb r q then Lt else Gt)
  in
  ((q, e'), l)

type radix =
  Big_int_Z.big_int
  (* singleton inductive, whose constructor was Build_radix *)

(** val radix2 : radix **)

let radix2 =
  (Big_int_Z.mult_int_big_int 2 Big_int_Z.unit_big_int)

type float = { fnum : Big_int_Z.big_int; fexp0 : Big_int_Z.big_int }

(** val cond_incr : bool -> Big_int_Z.big_int -> Big_int_Z.big_int **)

let cond_incr b m =
  if b then Z.add m Big_int_Z.unit_big_int else m

(** val round_sign_DN : bool -> location -> bool **)

let round_sign_DN s = function
| Loc_Exact -> false
| Loc_Inexact _ -> s

(** val round_sign_UP : bool -> location -> bool **)

let round_sign_UP s = function
| Loc_Exact -> false
| Loc_Inexact _ -> negb s

(** val round_N : bool -> location -> bool **)

let round_N p = function
| Loc_Exact -> false
| Loc_Inexact c -> (match c with
                    | Eq -> p
                    | Lt -> false
                    | Gt -> true)

(** val falign :
    radix -> float -> float ->
    (Big_int_Z.big_int * Big_int_Z.big_int) * Big_int_Z.big_int **)

let falign beta f1 f2 =
  let { fnum = m1; fexp0 = e1 } = f1 in
  let { fnum = m2; fexp0 = e2 } = f2 in
  if Z.leb e1 e2
  then ((m1, (Z.mul m2 (Z.pow beta (Z.sub e2 e1)))), e1)
  else (((Z.mul m1 (Z.pow beta (Z.sub e1 e2))), m2), e2)

(** val fplus : radix -> float -> float -> float **)

let fplus beta f1 f2 =
  let (p, e) = falign beta f1 f2 in
  let (m1, m2) = p in { fnum = (Z.add m1 m2); fexp0 = e }

(** val fmult : radix -> float -> float -> float **)

let fmult _ f1 f2 =
  let { fnum = m1; fexp0 = e1 } = f1 in
  let { fnum = m2; fexp0 = e2 } = f2 in
  { fnum = (Z.mul m1 m2); fexp0 = (Z.add e1 e2) }

type binary_float =
| B754_zero of bool
| B754_infinity of bool
| B754_nan
| B754_finite of bool * Big_int_Z.big_int * Big_int_Z.big_int

(** val sF2B :
    Big_int_Z.big_int -> Big_int_Z.big_int -> spec_float -> binary_float **)

let sF2B _ _ = function
| S754_zero s -> B754_zero s
| S754_infinity s -> B754_infinity s
| S754_nan -> B754_nan
| S754_finite (s, m, e) -> B754_finite (s, m, e)

(** val bsign :
    Big_int_Z.big_int -> Big_int_Z.big_int -> binary_float -> bool **)

let bsign _ _ = function
| B754_zero s -> s
| B754_infinity s -> s
| B754_nan -> false
| B754_finite (s, _, _) -> s

type mode =
| Mode_NE
| Mode_ZR
| Mode_DN
| Mode_UP
| Mode_NA

(** val choice_mode :
    mode -> bool -> Big_int_Z.big_int -> location -> Big_int_Z.big_int **)

let choice_mode m sx mx lx =
  match m with
  | Mode_NE -> cond_incr (round_N (negb (Z.even mx)) lx) mx
  | Mode_ZR -> mx
  | Mode_DN -> cond_incr (round_sign_DN sx lx) mx
  | Mode_UP -> cond_incr (round_sign_UP sx lx) mx
  | Mode_NA -> cond_incr (round_N true lx) mx

(** val overflow_to_inf : mode -> bool -> bool **)

let overflow_to_inf m s =
  match m with
  | Mode_ZR -> false
  | Mode_DN -> s
  | Mode_UP -> negb s
  | _ -> true

(** val binary_overflow :
    Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> bool -> spec_float **)

let binary_overflow prec emax m s =
  if overflow_to_inf m s
  then S754_infinity s
  else S754_finite (s,
         (Z.to_pos
           (Z.sub
             (Z.pow (Big_int_Z.mult_int_big_int 2 Big_int_Z.unit_big_int)
               prec) Big_int_Z.unit_big_int)), (Z.sub emax prec))

(** val binary_fit_aux :
    Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> bool ->
    Big_int_Z.big_int -> Big_int_Z.big_int -> spec_float **)

let binary_fit_aux prec emax mode0 sx mx ex =
  if Z.leb ex (Z.sub emax prec)
  then S754_finite (sx, mx, ex)
  else binary_overflow prec emax mode0 sx

(** val binary_round_aux :
    Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> bool ->
    Big_int_Z.big_int -> Big_int_Z.big_int -> location -> spec_float **)

let binary_round_aux prec emax mode0 sx mx ex lx =
  let (mrs', e') = shr_fexp prec emax mx ex lx in
  let (mrs'', e'') =
    shr_fexp prec emax
      (choice_mode mode0 sx mrs'.shr_m (loc_of_shr_record mrs')) e' Loc_Exact
  in
  ((fun fO fp fn z -> let s = Big_int_Z.sign_big_int z in
  if s = 0 then fO () else if s > 0 then fp z
  else fn (Big_int_Z.minus_big_int z))
     (fun _ -> S754_zero sx)
     (fun m -> binary_fit_aux prec emax mode0 sx m e'')
     (fun _ -> S754_nan)
     mrs''.shr_m)

(** val bmult :
    Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> binary_float ->
    binary_float -> binary_float **)

let bmult prec emax m x y =
  match x with
  | B754_zero sx ->
    (match y with
     | B754_zero sy -> B754_zero (xorb sx sy)
     | B754_finite (sy, _, _) -> B754_zero (xorb sx sy)
     | _ -> B754_nan)
  | B754_infinity sx ->
    (match y with
     | B754_infinity sy -> B754_infinity (xorb sx sy)
     | B754_finite (sy, _, _) -> B754_infinity (xorb sx sy)
     | _ -> B754_nan)
  | B754_nan -> B754_nan
  | B754_finite (sx, mx, ex) ->
    (match y with
     | B754_zero sy -> B754_zero (xorb sx sy)
     | B754_infinity sy -> B754_infinity (xorb sx sy)
     | B754_nan -> B754_nan
     | B754_finite (sy, my, ey) ->
       sF2B prec emax
         (binary_round_aux prec emax m (xorb sx sy) (Coq_Pos.mul mx my)
           (Z.add ex ey) Loc_Exact))

(** val shl_align_fexp :
    Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int ->
    Big_int_Z.big_int -> Big_int_Z.big_int * Big_int_Z.big_int **)

let shl_align_fexp prec emax mx ex =
  shl_align mx ex (fexp prec emax (Z.add (digits2_pos mx) ex))

(** val binary_round :
    Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> bool ->
    Big_int_Z.big_int -> Big_int_Z.big_int -> spec_float **)

let binary_round prec emax m sx mx ex =
  let (mz, ez) = shl_align_fexp prec emax mx ex in
  binary_round_aux prec emax m sx mz ez Loc_Exact

(** val binary_normalize :
    Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> Big_int_Z.big_int ->
    Big_int_Z.big_int -> bool -> binary_float **)

let binary_normalize prec emax mode0 m e szero =
  (fun fO fp fn z -> let s = Big_int_Z.sign_big_int z in
  if s = 0 then fO () else if s > 0 then fp z
  else fn (Big_int_Z.minus_big_int z))
    (fun _ -> B754_zero szero)
    (fun m0 ->
    sF2B prec emax (binary_round prec emax mode0 false m0 e))
    (fun m0 -> sF2B prec emax (binary_round prec emax mode0 true m0 e))
    m

(** val fplus_naive :
    bool -> Big_int_Z.big_int -> Big_int_Z.big_int -> bool ->
    Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int ->
    Big_int_Z.big_int **)

let fplus_naive sx mx ex sy my ey ez =
  Z.add (cond_Zopp sx (fst (shl_align mx ex ez)))
    (cond_Zopp sy (fst (shl_align my ey ez)))

(** val bplus :
    Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> binary_float ->
    binary_float -> binary_float **)

let bplus prec emax m x y =
  match x with
  | B754_zero sx ->
    (match y with
     | B754_zero sy ->
       if eqb sx sy
       then x
       else (match m with
             | Mode_DN -> B754_zero true
             | _ -> B754_zero false)
     | B754_nan -> B754_nan
     | _ -> y)
  | B754_infinity sx ->
    (match y with
     | B754_infinity sy -> if eqb sx sy then x else B754_nan
     | B754_nan -> B754_nan
     | _ -> x)
  | B754_nan -> B754_nan
  | B754_finite (sx, mx, ex) ->
    (match y with
     | B754_zero _ -> x
     | B754_infinity _ -> y
     | B754_nan -> B754_nan
     | B754_finite (sy, my, ey) ->
       let ez = Z.min ex ey in
       binary_normalize prec emax m (fplus_naive sx mx ex sy my ey ez) ez
         (match m with
          | Mode_DN -> true
          | _ -> false))

(** val bminus :
    Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> binary_float ->
    binary_float -> binary_float **)

let bminus prec emax m x y =
  match x with
  | B754_zero sx ->
    (match y with
     | B754_zero sy ->
       if eqb sx (negb sy)
       then x
       else (match m with
             | Mode_DN -> B754_zero true
             | _ -> B754_zero false)
     | B754_infinity sy -> B754_infinity (negb sy)
     | B754_nan -> B754_nan
     | B754_finite (sy, my, ey) -> B754_finite ((negb sy), my, ey))
  | B754_infinity sx ->
    (match y with
     | B754_infinity sy -> if eqb sx (negb sy) then x else B754_nan
     | B754_nan -> B754_nan
     | _ -> x)
  | B754_nan -> B754_nan
  | B754_finite (sx, mx, ex) ->
    (match y with
     | B754_zero _ -> x
     | B754_infinity sy -> B754_infinity (negb sy)
     | B754_nan -> B754_nan
     | B754_finite (sy, my, ey) ->
       let ez = Z.min ex ey in
       binary_normalize prec emax m (fplus_naive sx mx ex (negb sy) my ey ez)
         ez (match m with
             | Mode_DN -> true
             | _ -> false))

(** val bfma_szero :
    Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> binary_float ->
    binary_float -> binary_float -> bool **)

let bfma_szero prec emax m x y z0 =
  let s_xy = xorb (bsign prec emax x) (bsign prec emax y) in
  if eqb s_xy (bsign prec emax z0)
  then s_xy
  else (match m with
        | Mode_DN -> true
        | _ -> false)

(** val bfma :
    Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> binary_float ->
    binary_float -> binary_float -> binary_float **)

let bfma prec emax m x y z0 =
  match x with
  | B754_zero _ ->
    (match y with
     | B754_zero _ ->
       (match z0 with
        | B754_zero _ -> B754_zero (bfma_szero prec emax m x y z0)
        | B754_nan -> B754_nan
        | _ -> z0)
     | B754_finite (_, _, _) ->
       (match z0 with
        | B754_zero _ -> B754_zero (bfma_szero prec emax m x y z0)
        | B754_nan -> B754_nan
        | _ -> z0)
     | _ -> B754_nan)
  | B754_infinity sx ->
    (match y with
     | B754_infinity sy ->
       let s = xorb sx sy in
       (match z0 with
        | B754_infinity sz -> if eqb s sz then z0 else B754_nan
        | B754_nan -> B754_nan
        | _ -> B754_infinity s)
     | B754_finite (sy, _, _) ->
       let s = xorb sx sy in
       (match z0 with
        | B754_infinity sz -> if eqb s sz then z0 else B754_nan
        | B754_nan -> B754_nan
        | _ -> B754_infinity s)
     | _ -> B754_nan)
  | B754_nan -> B754_nan
  | B754_finite (sx, mx, ex) ->
    (match y with
     | B754_zero _ ->
       (match z0 with
        | B754_zero _ -> B754_zero (bfma_szero prec emax m x y z0)
        | B754_nan -> B754_nan
        | _ -> z0)
     | B754_infinity sy ->
       let s = xorb sx sy in
       (match z0 with
        | B754_infinity sz -> if eqb s sz then z0 else B754_nan
        | B754_nan -> B754_nan
        | _ -> B754_infinity s)
     | B754_nan -> B754_nan
     | B754_finite (sy, my, ey) ->
       (match z0 with
        | B754_zero _ ->
          let x0 = { fnum = (cond_Zopp sx mx); fexp0 = ex } in
          let y0 = { fnum = (cond_Zopp sy my); fexp0 = ey } in
          let { fnum = mr; fexp0 = er } = fmult radix2 x0 y0 in
          binary_normalize prec emax m mr er (bfma_szero prec emax m x y z0)
        | B754_infinity _ -> z0
        | B754_nan -> B754_nan
        | B754_finite (sz, mz, ez) ->
          let x0 = { fnum = (cond_Zopp sx mx); fexp0 = ex } in
          let y0 = { fnum = (cond_Zopp sy my); fexp0 = ey } in
          let z1 = { fnum = (cond_Zopp sz mz); fexp0 = ez } in
          let { fnum = mr; fexp0 = er } = fplus radix2 (fmult radix2 x0 y0) z1
          in
          binary_normalize prec emax m mr er (bfma_szero prec emax m x y z0)))

(** val bdiv :
    Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> binary_float ->
    binary_float -> binary_float **)

let bdiv prec emax m x y =
  match x with
  | B754_zero sx ->
    (match y with
     | B754_infinity sy -> B754_zero (xorb sx sy)
     | B754_finite (sy, _, _) -> B754_zero (xorb sx sy)
     | _ -> B754_nan)
  | B754_infinity sx ->
    (match y with
     | B754_zero sy -> B754_infinity (xorb sx sy)
     | B754_finite (sy, _, _) -> B754_infinity (xorb sx sy)
     | _ -> B754_nan)
  | B754_nan -> B754_nan
  | B754_finite (sx, mx, ex) ->
    (match y with
     | B754_zero sy -> B754_infinity (xorb sx sy)
     | B754_infinity sy -> B754_zero (xorb sx sy)
     | B754_nan -> B754_nan
     | B754_finite (sy, my, ey) ->
       sF2B prec emax
         (let (p, lz) = sFdiv_core_binary prec emax mx ex my ey in
          let (mz, ez) = p in
          binary_round_aux prec emax m (xorb sx sy) mz ez lz))

(** val bsqrt :
    Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> binary_float ->
    binary_float **)

let bsqrt prec emax m x = match x with
| B754_zero _ -> x
| B754_infinity s -> if s then B754_nan else x
| B754_nan -> B754_nan
| B754_finite (sx, mx, ex) ->
  if sx
  then B754_nan
  else sF2B prec emax
         (let (p, lz) = sFsqrt_core_binary prec emax mx ex in
          let (mz, ez) = p in binary_round_aux prec emax m false mz ez lz)

(** val flocq_make :
    Big_int_Z.big_int -> Big_int_Z.big_int -> bool -> Big_int_Z.big_int ->
    Big_int_Z.big_int -> binary_float **)

let flocq_make prec emax sign mantissa exponent =
  binary_normalize prec emax Mode_NE
    (if sign then Z.opp mantissa else mantissa) exponent sign

(** val flocq_add :
    Big_int_Z.big_int -> Big_int_Z.big_int -> binary_float -> binary_float ->
    binary_float **)

let flocq_add prec emax x y =
  bplus prec emax Mode_NE x y

(** val flocq_sub :
    Big_int_Z.big_int -> Big_int_Z.big_int -> binary_float -> binary_float ->
    binary_float **)

let flocq_sub prec emax x y =
  bminus prec emax Mode_NE x y

(** val flocq_mul :
    Big_int_Z.big_int -> Big_int_Z.big_int -> binary_float -> binary_float ->
    binary_float **)

let flocq_mul prec emax x y =
  bmult prec emax Mode_NE x y

(** val flocq_div :
    Big_int_Z.big_int -> Big_int_Z.big_int -> binary_float -> binary_float ->
    binary_float **)

let flocq_div prec emax x y =
  bdiv prec emax Mode_NE x y

(** val flocq_from_ratio :
    Big_int_Z.big_int -> Big_int_Z.big_int -> bool -> Big_int_Z.big_int ->
    Big_int_Z.big_int -> binary_float **)

let flocq_from_ratio prec emax sign numerator denominator =
  sF2B prec emax
    (let (p, lz) =
       sFdiv_core_binary prec emax numerator Big_int_Z.zero_big_int
         denominator Big_int_Z.zero_big_int
     in
     let (mz, ez) = p in
     binary_round_aux prec emax Mode_NE (xorb sign false) mz ez lz)

(** val flocq_sqrt :
    Big_int_Z.big_int -> Big_int_Z.big_int -> binary_float -> binary_float **)

let flocq_sqrt prec emax x =
  bsqrt prec emax Mode_NE x

(** val flocq_fma :
    Big_int_Z.big_int -> Big_int_Z.big_int -> binary_float -> binary_float ->
    binary_float -> binary_float **)

let flocq_fma prec emax x y z0 =
  bfma prec emax Mode_NE x y z0
