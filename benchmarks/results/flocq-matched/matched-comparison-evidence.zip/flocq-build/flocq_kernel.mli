
val xorb : bool -> bool -> bool

val negb : bool -> bool

val fst : ('a1 * 'a2) -> 'a1

type comparison =
| Eq
| Lt
| Gt

val eqb : bool -> bool -> bool

module Pos :
 sig
  type mask =
  | IsNul
  | IsPos of Big_int_Z.big_int
  | IsNeg
 end

module Coq_Pos :
 sig
  val succ : Big_int_Z.big_int -> Big_int_Z.big_int

  val add : Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int

  val add_carry : Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int

  val pred_double : Big_int_Z.big_int -> Big_int_Z.big_int

  type mask = Pos.mask =
  | IsNul
  | IsPos of Big_int_Z.big_int
  | IsNeg

  val succ_double_mask : mask -> mask

  val double_mask : mask -> mask

  val double_pred_mask : Big_int_Z.big_int -> mask

  val sub_mask : Big_int_Z.big_int -> Big_int_Z.big_int -> mask

  val sub_mask_carry : Big_int_Z.big_int -> Big_int_Z.big_int -> mask

  val mul : Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int

  val iter : ('a1 -> 'a1) -> 'a1 -> Big_int_Z.big_int -> 'a1

  val div2 : Big_int_Z.big_int -> Big_int_Z.big_int

  val div2_up : Big_int_Z.big_int -> Big_int_Z.big_int

  val compare_cont :
    comparison -> Big_int_Z.big_int -> Big_int_Z.big_int -> comparison

  val compare : Big_int_Z.big_int -> Big_int_Z.big_int -> comparison

  val leb : Big_int_Z.big_int -> Big_int_Z.big_int -> bool

  val sqrtrem_step :
    (Big_int_Z.big_int -> Big_int_Z.big_int) -> (Big_int_Z.big_int ->
    Big_int_Z.big_int) -> (Big_int_Z.big_int * mask) ->
    Big_int_Z.big_int * mask

  val sqrtrem : Big_int_Z.big_int -> Big_int_Z.big_int * mask
 end

module Z :
 sig
  val double : Big_int_Z.big_int -> Big_int_Z.big_int

  val succ_double : Big_int_Z.big_int -> Big_int_Z.big_int

  val pred_double : Big_int_Z.big_int -> Big_int_Z.big_int

  val pos_sub : Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int

  val add : Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int

  val opp : Big_int_Z.big_int -> Big_int_Z.big_int

  val sub : Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int

  val mul : Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int

  val pow_pos : Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int

  val pow : Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int

  val compare : Big_int_Z.big_int -> Big_int_Z.big_int -> comparison

  val leb : Big_int_Z.big_int -> Big_int_Z.big_int -> bool

  val ltb : Big_int_Z.big_int -> Big_int_Z.big_int -> bool

  val max : Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int

  val min : Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int

  val to_pos : Big_int_Z.big_int -> Big_int_Z.big_int

  val pos_div_eucl :
    Big_int_Z.big_int -> Big_int_Z.big_int ->
    Big_int_Z.big_int * Big_int_Z.big_int

  val div_eucl :
    Big_int_Z.big_int -> Big_int_Z.big_int ->
    Big_int_Z.big_int * Big_int_Z.big_int

  val even : Big_int_Z.big_int -> bool

  val div2 : Big_int_Z.big_int -> Big_int_Z.big_int

  val sqrtrem : Big_int_Z.big_int -> Big_int_Z.big_int * Big_int_Z.big_int

  val shiftl : Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int
 end

val zeq_bool : Big_int_Z.big_int -> Big_int_Z.big_int -> bool

val shift_pos : Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int

type spec_float =
| S754_zero of bool
| S754_infinity of bool
| S754_nan
| S754_finite of bool * Big_int_Z.big_int * Big_int_Z.big_int

val emin : Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int

val fexp :
  Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int ->
  Big_int_Z.big_int

val digits2_pos : Big_int_Z.big_int -> Big_int_Z.big_int

val zdigits2 : Big_int_Z.big_int -> Big_int_Z.big_int

val iter_pos : ('a1 -> 'a1) -> Big_int_Z.big_int -> 'a1 -> 'a1

type location =
| Loc_Exact
| Loc_Inexact of comparison

type shr_record = { shr_m : Big_int_Z.big_int; shr_r : bool; shr_s : bool }

val shr_1 : shr_record -> shr_record

val loc_of_shr_record : shr_record -> location

val shr_record_of_loc : Big_int_Z.big_int -> location -> shr_record

val shr :
  shr_record -> Big_int_Z.big_int -> Big_int_Z.big_int ->
  shr_record * Big_int_Z.big_int

val shr_fexp :
  Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int ->
  Big_int_Z.big_int -> location -> shr_record * Big_int_Z.big_int

val shl_align :
  Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int ->
  Big_int_Z.big_int * Big_int_Z.big_int

val cond_Zopp : bool -> Big_int_Z.big_int -> Big_int_Z.big_int

val new_location_even : Big_int_Z.big_int -> Big_int_Z.big_int -> location

val new_location_odd : Big_int_Z.big_int -> Big_int_Z.big_int -> location

val new_location : Big_int_Z.big_int -> Big_int_Z.big_int -> location

val sFdiv_core_binary :
  Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int ->
  Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int ->
  (Big_int_Z.big_int * Big_int_Z.big_int) * location

val sFsqrt_core_binary :
  Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int ->
  Big_int_Z.big_int -> (Big_int_Z.big_int * Big_int_Z.big_int) * location

type radix =
  Big_int_Z.big_int
  (* singleton inductive, whose constructor was Build_radix *)

val radix2 : radix

type float = { fnum : Big_int_Z.big_int; fexp0 : Big_int_Z.big_int }

val cond_incr : bool -> Big_int_Z.big_int -> Big_int_Z.big_int

val round_sign_DN : bool -> location -> bool

val round_sign_UP : bool -> location -> bool

val round_N : bool -> location -> bool

val falign :
  radix -> float -> float ->
  (Big_int_Z.big_int * Big_int_Z.big_int) * Big_int_Z.big_int

val fplus : radix -> float -> float -> float

val fmult : radix -> float -> float -> float

type binary_float =
| B754_zero of bool
| B754_infinity of bool
| B754_nan
| B754_finite of bool * Big_int_Z.big_int * Big_int_Z.big_int

val sF2B :
  Big_int_Z.big_int -> Big_int_Z.big_int -> spec_float -> binary_float

val bsign : Big_int_Z.big_int -> Big_int_Z.big_int -> binary_float -> bool

type mode =
| Mode_NE
| Mode_ZR
| Mode_DN
| Mode_UP
| Mode_NA

val choice_mode :
  mode -> bool -> Big_int_Z.big_int -> location -> Big_int_Z.big_int

val overflow_to_inf : mode -> bool -> bool

val binary_overflow :
  Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> bool -> spec_float

val binary_fit_aux :
  Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> bool -> Big_int_Z.big_int
  -> Big_int_Z.big_int -> spec_float

val binary_round_aux :
  Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> bool -> Big_int_Z.big_int
  -> Big_int_Z.big_int -> location -> spec_float

val bmult :
  Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> binary_float ->
  binary_float -> binary_float

val shl_align_fexp :
  Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int ->
  Big_int_Z.big_int -> Big_int_Z.big_int * Big_int_Z.big_int

val binary_round :
  Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> bool -> Big_int_Z.big_int
  -> Big_int_Z.big_int -> spec_float

val binary_normalize :
  Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> Big_int_Z.big_int ->
  Big_int_Z.big_int -> bool -> binary_float

val fplus_naive :
  bool -> Big_int_Z.big_int -> Big_int_Z.big_int -> bool -> Big_int_Z.big_int
  -> Big_int_Z.big_int -> Big_int_Z.big_int -> Big_int_Z.big_int

val bplus :
  Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> binary_float ->
  binary_float -> binary_float

val bminus :
  Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> binary_float ->
  binary_float -> binary_float

val bfma_szero :
  Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> binary_float ->
  binary_float -> binary_float -> bool

val bfma :
  Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> binary_float ->
  binary_float -> binary_float -> binary_float

val bdiv :
  Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> binary_float ->
  binary_float -> binary_float

val bsqrt :
  Big_int_Z.big_int -> Big_int_Z.big_int -> mode -> binary_float ->
  binary_float

val flocq_make :
  Big_int_Z.big_int -> Big_int_Z.big_int -> bool -> Big_int_Z.big_int ->
  Big_int_Z.big_int -> binary_float

val flocq_add :
  Big_int_Z.big_int -> Big_int_Z.big_int -> binary_float -> binary_float ->
  binary_float

val flocq_sub :
  Big_int_Z.big_int -> Big_int_Z.big_int -> binary_float -> binary_float ->
  binary_float

val flocq_mul :
  Big_int_Z.big_int -> Big_int_Z.big_int -> binary_float -> binary_float ->
  binary_float

val flocq_div :
  Big_int_Z.big_int -> Big_int_Z.big_int -> binary_float -> binary_float ->
  binary_float

val flocq_from_ratio :
  Big_int_Z.big_int -> Big_int_Z.big_int -> bool -> Big_int_Z.big_int ->
  Big_int_Z.big_int -> binary_float

val flocq_sqrt :
  Big_int_Z.big_int -> Big_int_Z.big_int -> binary_float -> binary_float

val flocq_fma :
  Big_int_Z.big_int -> Big_int_Z.big_int -> binary_float -> binary_float ->
  binary_float -> binary_float
