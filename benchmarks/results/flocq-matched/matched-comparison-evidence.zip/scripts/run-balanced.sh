#!/usr/bin/env bash
# Nine-trial balanced-sqrt supplement on CPU 92 (driver on CPU 93), after the main campaign.
set -euo pipefail
source /workspace/evidence/flocq-matched/scripts/env.sh
cd "$EV/balanced-sqrt"
# Metadata (format and backend labels) from this rerun's calibration pilots.
mkdir -p metadata
python3 -I - "$EV/campaign/calibration" metadata <<'PY'
import csv, sys
from pathlib import Path
cal, out = Path(sys.argv[1]), Path(sys.argv[2])
lanes = {"floatlib": "binary-software", "mpfr": "mpfr-reference", "flocq": "flocq-reference"}
for name, lane in lanes.items():
    rows = []
    for width in (1024, 2048, 4096):
        rows += list(csv.DictReader(open(cal / f"pilot-{lane}-{width}-sqrt.csv")))
    with open(out / f"{name}-preflight.csv", "w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)
PY
log="$EV/logs/balanced-load.txt"
{ echo "start-utc $(date -u +%FT%TZ)"; echo "uptime-before $(uptime)"; } > "$log"
status=0
python3 -I run.py run --cpu 92 --trials 9 --output results-9trials > "$EV/logs/balanced-run.log" 2>&1 || status=$?
{ echo "finish-utc $(date -u +%FT%TZ)"; echo "uptime-after $(uptime)"; echo "exit-status $status"; } >> "$log"
exit "$status"
