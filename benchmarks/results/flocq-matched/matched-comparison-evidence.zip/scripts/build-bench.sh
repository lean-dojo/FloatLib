#!/usr/bin/env bash
# Build the benchmark executables this job needs into the shared build directory.
set -euo pipefail
source /workspace/evidence/flocq-matched/scripts/env.sh
cd "$REPO"
echo "start $(date -u +%FT%TZ) load: $(cat /proc/loadavg)"
export LEAN_NUM_THREADS=4
taskset -c "$MY_CPUS" bash -c 'source tests/lib/lake.sh; floatlib_benchmark_lake build execFloatFormatComparison execFloatSelectionMatrix execFloatP3109Comparison execFloatTensorLibComparison'
echo "done $(date -u +%FT%TZ) load: $(cat /proc/loadavg)"
