#!/usr/bin/env python3
"""Assemble the rerun's matched Flocq tables and compare them with the recorded release data.

Inputs (all read-only): the nine-trial format-comparison campaign, the balanced-sqrt rerun,
and the recorded matched-benchmark-summary.csv. Outputs go to evidence/flocq-matched/summary.
"""
import csv
import json
import statistics
import sys
from pathlib import Path

EV = Path("/workspace/evidence/flocq-matched")
REPO = Path("/workspace/repo")
RECORDED = REPO / "benchmarks/results/flocq-matched/matched-benchmark-summary.csv"
OUT = EV / "summary"
WIDTHS = (6, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096)
OPS = ("add", "sub", "mul", "div", "sqrt", "fma")
IMPLS = ("ExecFloat", "Flocq", "MPFR")
SERIES = {"ExecFloat": "ExecFloat binary proved software",
          "MPFR": "MPFR (binary) software reference",
          "Flocq": "Flocq binary reference (precision model)"}
WIDE_SQRT = {(impl, w, "sqrt") for impl in IMPLS for w in (1024, 2048, 4096)}
RAW_FIELDS = ["implementation", "family", "format", "totalBits", "operation", "executionClass",
              "backend", "measurementMethod", "iterations", "totalNanos", "sink",
              "fixtureTraceDigest", "agreementIterations", "agreementSink",
              "agreementFixtureTraceDigest"]
SUMMARY_FIELDS = ["series", *RAW_FIELDS, "trials", "blocks", "nanosPerOp", "source"]


def key(row):
    return row["implementation"], int(row["totalBits"]), row["operation"]


def read(path):
    with open(path, newline="") as stream:
        return list(csv.DictReader(stream))


def main_trials(campaign):
    trials = {}
    for path in sorted((campaign / "raw").glob("trial-*.csv")):
        number = int(path.stem.split("-")[1])
        rows = read(path)
        cells = {key(r): r for r in rows}
        assert len(cells) == len(rows) == 198, (path, len(rows))
        trials[number] = cells
    return trials


def balanced_trials(directory):
    rows = read(directory / "raw.csv")
    out = {}
    for r in rows:
        out.setdefault(int(r["trial"]), {})[key(r)] = r
    return out


def summary_row(raw, trials, blocks, source, nanos_per_op=None):
    row = {"series": SERIES[raw["implementation"]], **{f: raw[f] for f in RAW_FIELDS},
           "trials": str(trials), "blocks": blocks, "source": source}
    if nanos_per_op is None:
        nanos_per_op = int(raw["totalNanos"]) / int(raw["iterations"])
    row["nanosPerOp"] = f"{nanos_per_op:.9f}"
    return row


def write(path, rows, fields):
    with open(path, "w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def headline(times):
    """times[(impl, width, op)] -> ns/op. Ratios are other/FloatLib (above 1 favours FloatLib)."""
    result = {}
    for other in ("Flocq", "MPFR"):
        ratios = sorted(
            (times[(other, w, op)] / times[("ExecFloat", w, op)], w, op)
            for w in WIDTHS for op in OPS)
        wins = [r for r in ratios if r[0] > 1]
        result[other] = {
            "cells": len(ratios),
            "floatlibFaster": len(wins),
            "medianRatioOtherOverFloatLib": statistics.median(r[0] for r in ratios),
            "minRatio": {"ratio": ratios[0][0], "width": ratios[0][1], "op": ratios[0][2]},
            "maxRatio": {"ratio": ratios[-1][0], "width": ratios[-1][1], "op": ratios[-1][2]},
            "floatlibLosses": [
                {"width": w, "op": op, "ratio": r,
                 "floatlibNs": times[("ExecFloat", w, op)], "otherNs": times[(other, w, op)]}
                for r, w, op in ratios if r <= 1],
        }
    result["binary64Mul"] = {impl: times[(impl, 64, "mul")] for impl in IMPLS}
    result["e4m3Fma8"] = {impl: times[(impl, 8, "fma")] for impl in IMPLS}
    result["e3m2Fma6"] = {impl: times[(impl, 6, "fma")] for impl in IMPLS}
    return result


def main():
    campaign = Path(sys.argv[1]) if len(sys.argv) > 1 else EV / "campaign"
    balanced = Path(sys.argv[2]) if len(sys.argv) > 2 else EV / "balanced-sqrt/results-9trials"
    OUT.mkdir(exist_ok=True)
    trials = main_trials(campaign)
    btrials = balanced_trials(balanced)
    n_main, n_bal = len(trials), len(btrials)

    # 1. One-trial selection, by the recorded rule: main trial 1, balanced trial 1 for wide sqrt.
    one = []
    for cell, raw in sorted(trials[1].items(), key=lambda kv: (IMPLS.index(kv[0][0]), kv[0][1], OPS.index(kv[0][2]))):
        if cell in WIDE_SQRT:
            b = btrials[1][cell]
            r = {f: b[f] for f in RAW_FIELDS}
            one.append(summary_row(r, 1, b["blocks"], "balanced-sqrt/raw.csv"))
        else:
            one.append(summary_row(raw, 1, "", "main/trial-01.csv"))
    write(OUT / "matched-benchmark-summary-trial01.csv", one, SUMMARY_FIELDS)
    t_one = {key(r): float(r["nanosPerOp"]) for r in one}

    # 2. Medians over all trials (main: 9 trials; balanced: its trials), same replacement rule.
    med_fields = ["series", "implementation", "format", "totalBits", "operation", "backend",
                  "measurementMethod", "trials", "medianNanosPerOp", "minNanosPerOp",
                  "maxNanosPerOp", "relativeSpread", "source"]
    med_rows, t_med = [], {}
    for cell in sorted(trials[1], key=lambda c: (IMPLS.index(c[0]), c[1], OPS.index(c[2]))):
        if cell in WIDE_SQRT:
            samples = [btrials[t][cell] for t in sorted(btrials)]
            source = "balanced-sqrt/raw.csv"
        else:
            samples = [trials[t][cell] for t in sorted(trials)]
            source = "main/raw/trial-*.csv"
        values = [int(s["totalNanos"]) / int(s["iterations"]) for s in samples]
        assert len({s["backend"] for s in samples}) == 1
        median = statistics.median(values)
        t_med[cell] = median
        med_rows.append({
            "series": SERIES[cell[0]], "implementation": cell[0], "format": samples[0]["format"],
            "totalBits": cell[1], "operation": cell[2], "backend": samples[0]["backend"],
            "measurementMethod": samples[0]["measurementMethod"], "trials": len(values),
            "medianNanosPerOp": f"{median:.3f}", "minNanosPerOp": f"{min(values):.3f}",
            "maxNanosPerOp": f"{max(values):.3f}",
            "relativeSpread": f"{(max(values) - min(values)) / median:.4f}", "source": source})
    write(OUT / "matched-benchmark-summary-median.csv", med_rows, med_fields)

    # 3. Recorded release numbers and the cell-by-cell comparison.
    recorded = read(RECORDED)
    t_rec = {key(r): float(r["nanosPerOp"]) for r in recorded}
    b_rec = {key(r): r["backend"] for r in recorded}
    b_new = {key(r): r["backend"] for r in one}
    cmp_rows = []
    for cell in sorted(t_rec, key=lambda c: (IMPLS.index(c[0]), c[1], OPS.index(c[2]))):
        cmp_rows.append({
            "implementation": cell[0], "totalBits": cell[1], "operation": cell[2],
            "recordedNanosPerOp": f"{t_rec[cell]:.3f}", "rerunTrial01NanosPerOp": f"{t_one[cell]:.3f}",
            "rerunMedianNanosPerOp": f"{t_med[cell]:.3f}",
            "medianOverRecorded": f"{t_med[cell] / t_rec[cell]:.4f}",
            "recordedBackend": b_rec[cell], "rerunBackend": b_new[cell],
            "backendChanged": str(b_rec[cell] != b_new[cell]).lower()})
    write(OUT / "rerun-vs-recorded.csv", cmp_rows, list(cmp_rows[0]))

    report = {
        "mainTrials": n_main, "balancedTrials": n_bal,
        "recorded": headline(t_rec),
        "rerunTrial01": headline(t_one),
        "rerunMedian": headline(t_med),
        "controlDrift": {
            impl: {
                "medianOverRecorded": statistics.median(
                    t_med[c] / t_rec[c] for c in t_rec if c[0] == impl),
                "min": min(t_med[c] / t_rec[c] for c in t_rec if c[0] == impl),
                "max": max(t_med[c] / t_rec[c] for c in t_rec if c[0] == impl)}
            for impl in IMPLS},
        "backendChanges": [
            {"width": c[1], "op": c[2], "recorded": b_rec[c], "rerun": b_new[c]}
            for c in sorted(t_rec) if c[0] == "ExecFloat" and b_rec[c] != b_new[c]],
    }
    (OUT / "headline.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: report[k] for k in ("mainTrials", "balancedTrials", "controlDrift")}, indent=2))
    for label in ("recorded", "rerunTrial01", "rerunMedian"):
        f = report[label]["Flocq"]
        print(label, "Flocq: FloatLib faster", f["floatlibFaster"], "/", f["cells"],
              "median", round(f["medianRatioOtherOverFloatLib"], 2),
              "losses", [(l["width"], l["op"], round(l["floatlibNs"], 1), round(l["otherNs"], 1))
                         for l in f["floatlibLosses"]],
              "b64 mul", {k: round(v, 1) for k, v in report[label]["binary64Mul"].items()})


if __name__ == "__main__":
    main()
