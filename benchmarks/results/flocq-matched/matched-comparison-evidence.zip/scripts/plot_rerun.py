#!/usr/bin/env python3
"""Draw the website-style matched Flocq figure from the rerun, with the repository's own plotting
function (benchmarks/plots/flocq_matched.py, imported read-only, no bytecode written).

1. One-trial selection (the recorded rule): overview PNG plus the per-operation SVGs.
2. Nine-trial medians: overview PNG only (the per-operation SVG notes say "one trial").
"""
import csv
import os
import sys
from pathlib import Path

sys.dont_write_bytecode = True
REPO = Path("/workspace/repo")
EV = Path("/workspace/evidence/flocq-matched")
sys.path.insert(0, str(REPO / "benchmarks/plots"))
os.environ.setdefault("MPLCONFIGDIR", str(EV / "tmp/matplotlib"))
import flocq_matched  # noqa: E402
import format_comparison  # noqa: E402


def main():
    rows = list(csv.DictReader(open(EV / "summary/matched-benchmark-summary-trial01.csv")))
    assert len(rows) == 198
    out = EV / "summary/figure-trial01/floatlib-flocq-matched-rerun-trial01.png"
    flocq_matched.plot(rows, out)
    print("wrote", out)

    med = list(csv.DictReader(open(EV / "summary/matched-benchmark-summary-median.csv")))
    assert len(med) == 198
    for r in med:
        r["nanosPerOp"] = r["medianNanosPerOp"]
    for name in ("save_operation_svg", "write_operation_series"):
        setattr(format_comparison, name, lambda *args, **kwargs: None)
    out = EV / "summary/figure-median/floatlib-flocq-matched-rerun-median9.png"
    flocq_matched.plot(med, out)
    print("wrote", out)


if __name__ == "__main__":
    main()
