#!/usr/bin/env python3
"""Compare rerun FLoPS and TensorLib results.json files with the recorded release files."""
import json
import statistics
import sys
from pathlib import Path

REPO = Path("/workspace/repo/benchmarks/results")
EV = Path("/workspace/evidence/flocq-matched")


def medians(result, keyname):
    return {(s["implementation"], s["format"], s[keyname]): s for s in result["summary"]}


def flops(new_path, old_path):
    new, old = json.loads(new_path.read_text()), json.loads(old_path.read_text())
    out = {"preflightCases": sum(r["cases"] for r in new["preflight"]),
           "preflightMismatches": sum(r["mismatches"] for r in new["preflight"]),
           "fixtureCases": 16 * len(new["fixtures"]),
           "fixtureDisagreements": sum(not r["agree"] for r in new["fixtures"]),
           "recordedPreflightCases": sum(r["cases"] for r in old["preflight"]),
           "recordedPreflightMismatches": sum(r["mismatches"] for r in old["preflight"]),
           "sameOutputHashesAsRecorded": all(
               a["output_sha256"] == b["output_sha256"]
               for a, b in zip(new["preflight"], old["preflight"])),
           "cells": []}
    nm, om = medians(new, "operation"), medians(old, "operation")
    wins = 0
    for fmt in ("Binary4p2sf", "Binary8p4se", "Binary8p3se"):
        for op in ("add", "mul", "div", "fma"):
            f_new, x_new = nm[("FloatLib", fmt, op)], nm[("FLoPS", fmt, op)]
            f_old, x_old = om[("FloatLib", fmt, op)], om[("FLoPS", fmt, op)]
            wins += f_new["median_ns"] < x_new["median_ns"]
            out["cells"].append({
                "format": fmt, "operation": op,
                "FloatLib_ns": round(f_new["median_ns"], 1), "FLoPS_ns": round(x_new["median_ns"], 1),
                "FLoPS_over_FloatLib": round(x_new["median_ns"] / f_new["median_ns"], 3),
                "recorded_FloatLib_ns": round(f_old["median_ns"], 1),
                "recorded_FLoPS_ns": round(x_old["median_ns"], 1),
                "recorded_FLoPS_over_FloatLib": round(x_old["median_ns"] / f_old["median_ns"], 3),
                "FloatLib_p05_p95": [round(f_new["p05_ns"], 1), round(f_new["p95_ns"], 1)],
                "FLoPS_p05_p95": [round(x_new["p05_ns"], 1), round(x_new["p95_ns"], 1)]})
    out["floatlibLowerMedian"] = wins
    out["recordedFloatlibLowerMedian"] = sum(
        om[("FloatLib", c["format"], c["operation"])]["median_ns"]
        < om[("FLoPS", c["format"], c["operation"])]["median_ns"] for c in out["cells"])
    busy = [t["host_busy_percent"] for t in new["trials"]]
    out["hostBusyPercent"] = {"median": statistics.median(busy), "max": max(busy)}
    return out


def tensorlib(new_path, old_path):
    new, old = json.loads(new_path.read_text()), json.loads(old_path.read_text())
    def counts(r):
        return {"cases": sum(x["cases"] for x in r["preflight"]),
                "valueChecksPerLibrary": sum(x["cases"] for x in r["preflight"]),
                "oracleFailures": {n: sum(x["oracle_failures"][n] for x in r["preflight"])
                                   for n in ("FloatLib", "TensorLib")},
                "semanticDifferences": sum(x["semantic_differences"] for x in r["preflight"]),
                "nanEncodingDifferences": sum(x["nan_encoding_differences"] for x in r["preflight"])}
    out = {"rerun": counts(new), "recorded": counts(old),
           "sameOutputHashesAsRecorded": {
               f'{a["format"]}/{a["direction"]}': a["output_sha256"] == b["output_sha256"]
               for a, b in zip(new["preflight"], old["preflight"])},
           "cells": []}
    nm, om = medians(new, "direction"), medians(old, "direction")
    ratios = []
    for fmt in ("binary16", "bfloat16", "e4m3fn", "e5m2"):
        for d in ("decode", "encode"):
            f, t = nm[("FloatLib", fmt, d)], nm[("TensorLib", fmt, d)]
            fo, to = om[("FloatLib", fmt, d)], om[("TensorLib", fmt, d)]
            ratios.append(f["median_ns"] / t["median_ns"])
            out["cells"].append({
                "format": fmt, "direction": d,
                "FloatLib_ns": round(f["median_ns"], 1), "TensorLib_ns": round(t["median_ns"], 1),
                "FloatLib_over_TensorLib": round(f["median_ns"] / t["median_ns"], 2),
                "recorded_FloatLib_ns": round(fo["median_ns"], 1),
                "recorded_TensorLib_ns": round(to["median_ns"], 1),
                "recorded_FloatLib_over_TensorLib": round(fo["median_ns"] / to["median_ns"], 2)})
    out["FloatLibOverTensorLibRange"] = [round(min(ratios), 2), round(max(ratios), 2)]
    rec = [c["recorded_FloatLib_over_TensorLib"] for c in out["cells"]]
    out["recordedFloatLibOverTensorLibRange"] = [min(rec), max(rec)]
    busy = [t["host_busy_percent"] for t in new["trials"]]
    out["hostBusyPercent"] = {"median": statistics.median(busy), "max": max(busy)}
    return out


def main():
    which = sys.argv[1]
    if which == "flops":
        report = flops(EV / "flops/output/results.json", REPO / "p3109-flops/results.json")
        target = EV / "flops/comparison-with-recorded.json"
    else:
        report = tensorlib(EV / "tensorlib/output/results.json", REPO / "tensorlib/results.json")
        target = EV / "tensorlib/comparison-with-recorded.json"
    target.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
