#!/usr/bin/env bash
# Every 60 s: load average, and processes (pcpu > 1) last seen on my CPUs 92-95 or on 92's sibling 44.
out="${1:?output file}"
while true; do
  printf '%s load=%s | ' "$(date -u +%FT%TZ)" "$(cut -d' ' -f1-3 /proc/loadavg)"
  ps -eo psr=,pcpu=,comm= | awk '($1==92||$1==44||$1==93||$1==94||$1==95) && $2>1 {printf "cpu%s:%s:%s ", $1, $3, $2} END {print ""}'
  sleep 60
done >> "$out" 2>&1
