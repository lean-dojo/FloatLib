#!/usr/bin/env bash
# Pre-build the FLoPS side exactly as compare-p3109-flops.py does without
# --skip-build (adapter copy, lakefile target, cache get, build), so the
# script can later run its checks and timings with --skip-build.
set -euo pipefail
source /workspace/evidence/flocq-matched/scripts/env.sh
work="$EV/flops/work"; flops="$work/FLoPS"
python3 -I - "$REPO" "$flops" <<'PY'
import shutil, sys
from pathlib import Path
root, flops = Path(sys.argv[1]), Path(sys.argv[2])
shutil.copyfile(root / "benchmarks/lean/FloatLibBenchmarks/Support/P3109Protocol.lean", flops / "P3109Protocol.lean")
shutil.copyfile(root / "benchmarks/external/flops/Main.lean", flops / "ComparisonMain.lean")
lakefile = flops / "lakefile.lean"
target = ("\nlean_lib P3109Protocol\n"
          "\nlean_exe p3109Comparison where\n  root := `ComparisonMain\n")
if target not in lakefile.read_text():
    lakefile.write_text(lakefile.read_text() + target)
PY
cd "$flops"
echo "cache get start $(date -u +%FT%TZ)"
taskset -c 95 lake exe cache get > "$work/flops-cache.log" 2>&1
echo "build start $(date -u +%FT%TZ)"
LEAN_NUM_THREADS=1 taskset -c 95 lake build p3109Comparison > "$work/flops-build.log" 2>&1
echo "done $(date -u +%FT%TZ)"
ls -la .lake/build/bin/p3109Comparison
