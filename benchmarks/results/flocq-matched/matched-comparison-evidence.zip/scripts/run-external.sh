#!/usr/bin/env bash
# Run the documented FLoPS or TensorLib comparison (checks + paired timings) on CPU 92.
# Builds were done beforehand with the scripts' own build commands, so --skip-build is used.
set -euo pipefail
source /workspace/evidence/flocq-matched/scripts/env.sh
which="${1:?flops or tensorlib}"
case "$which" in
  flops) script=compare-p3109-flops.py ;;
  tensorlib) script=compare-tensorlib.py ;;
  *) exit 2 ;;
esac
cd "$REPO"
log="$EV/logs/$which-load.txt"
{ echo "start-utc $(date -u +%FT%TZ)"; echo "uptime-before $(uptime)"; } > "$log"
status=0
taskset -c 92,93 python3 -I "benchmarks/scripts/$script" \
  --work-dir "$EV/$which/work" --build-dir "$FLOATLIB_BUILD_DIR" \
  --output "$EV/$which/output" --cpu 92 --skip-build > "$EV/logs/$which-run.log" 2>&1 || status=$?
{ echo "finish-utc $(date -u +%FT%TZ)"; echo "uptime-after $(uptime)"; echo "exit-status $status"; } >> "$log"
exit "$status"
