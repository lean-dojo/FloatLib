#!/usr/bin/env bash
# Nine-trial matched Flocq campaign with the documented flocq profile, pinned to
# logical CPU 92, using the pinned Flocq image the recorded run used.
set -euo pipefail
source /workspace/evidence/flocq-matched/scripts/env.sh
cd "$REPO"
out="$EV/campaign"
log="$EV/logs/campaign-load.txt"
{
  echo "start-utc $(date -u +%FT%TZ)"
  echo "uptime-before $(uptime)"
  echo "loadavg-before $(cat /proc/loadavg)"
} > "$log"
# Light load sampler on CPU 95: load average and anything running on CPU 92 or its sibling 44.
(
  while true; do
    printf '%s %s | ' "$(date -u +%FT%TZ)" "$(cut -d' ' -f1-3 /proc/loadavg)"
    ps -eo psr=,pcpu=,comm= | awk '$1==92||$1==44 {printf "cpu%s:%s:%s ", $1, $3, $2} END {print ""}'
    sleep 60
  done
) > "$EV/logs/campaign-load-samples.txt" 2>&1 &
sampler=$!
taskset -pc 95 "$sampler" >/dev/null
trap 'kill "$sampler" 2>/dev/null || true' EXIT
status=0
FORMAT_COMPARE_PROFILE=flocq \
FORMAT_COMPARE_DEVELOPMENT_ONLY=0 \
FORMAT_COMPARE_CPU=92 \
FLOCQ_BENCH_IMAGE=leanfloat-flocq-bench:4.2.2 \
  bash benchmarks/scripts/format-comparison.sh 9 "$out" || status=$?
{
  echo "finish-utc $(date -u +%FT%TZ)"
  echo "uptime-after $(uptime)"
  echo "loadavg-after $(cat /proc/loadavg)"
  echo "exit-status $status"
} >> "$log"
exit "$status"
