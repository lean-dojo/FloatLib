#!/usr/bin/env python3
"""Compare the generated C of the wide sqrt specializations in FormatComparison.c and
BalancedSqrt.c after normalizing the call-site part of the specialization names."""
import hashlib
import json
import re
import sys
from pathlib import Path

FC = Path("/workspace/build/ir/FloatLibBenchmarks/Public/FormatComparison.c")
BS = Path("/workspace/evidence/flocq-matched/balanced-sqrt/BalancedSqrt.c")
OUT = Path("/workspace/evidence/flocq-matched/balanced-sqrt/codegen")
CTX = {
    "fc": r"__private_FloatLibBenchmarks_Public_FormatComparison_0__FloatLibBenchmarks_Public_FormatComparison_binary{w}SoftwareSqrt_spec",
    "bs": r"BalancedSqrt_block{w}_spec",
}
PREFIX = "FloatLib_Floats_Formats_BinaryInterchange_Model_"


def functions(text, pattern):
    """Map name -> body for top-level function definitions whose name matches pattern."""
    out = {}
    for m in re.finditer(r"^(?:LEAN_EXPORT |static )?[A-Za-z_][A-Za-z0-9_\* ]*?\b((?:lp_floatlibBenchmarks_|l_)[A-Za-z0-9_]+)\(([^;{]*)\)\s*\{", text, re.M):
        name = m.group(1)
        if not re.search(pattern, name):
            continue
        depth, i = 0, m.end() - 1
        while True:
            c = text[i]
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    break
            i += 1
        out[name] = text[m.start():i + 1]
    return out


def normalize(body, ctx):
    body = body.replace("lp_floatlibBenchmarks_", "l_")
    body = re.sub(ctx, "CTX_spec", body)
    body = body.replace("l_" + PREFIX, "l_")
    names = {}
    def renumber(m):
        return names.setdefault(m.group(0), f"v{len(names)}")
    return re.sub(r"\bv_[A-Za-z0-9_]*?_[0-9]+_\b", renumber, body)


def main():
    fc_text, bs_text = FC.read_text(), BS.read_text()
    report = {}
    for w in (1024, 2048, 4096):
        fc_ctx, bs_ctx = CTX["fc"].format(w=w), CTX["bs"].format(w=w)
        a = {normalize(n, fc_ctx): normalize(b, fc_ctx) for n, b in functions(fc_text, fc_ctx).items()}
        b = {normalize(n, bs_ctx): normalize(v, bs_ctx) for n, v in functions(bs_text, bs_ctx).items()}
        common = sorted(set(a) & set(b))
        same = [n for n in common if a[n] == b[n]]
        report[w] = {"formatComparisonFunctions": len(a), "balancedFunctions": len(b),
                     "common": len(common), "identicalAfterNormalization": len(same),
                     "onlyFormatComparison": sorted(set(a) - set(b))[:10],
                     "onlyBalanced": sorted(set(b) - set(a))[:10],
                     "differing": [n for n in common if a[n] != b[n]][:10]}
        (OUT / f"sqrt{w}-formatcomparison.c.txt").write_text("\n\n".join(a[n] for n in sorted(a)))
        (OUT / f"sqrt{w}-balanced.c.txt").write_text("\n\n".join(b[n] for n in sorted(b)))
    (OUT / "codegen-compare.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
