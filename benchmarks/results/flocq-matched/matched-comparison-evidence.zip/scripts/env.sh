# Shared environment for the flocq-matched rerun (sourced by wrapper scripts).
export EV=/workspace/evidence/flocq-matched
export REPO=/workspace/repo
export FLOATLIB_BUILD_DIR=/workspace/build
export TMPDIR=$EV/tmp
export MY_CPUS=92-95
