#!/usr/bin/env python3
"""Link a scratch Lean driver object with the exact object list and flags Lake used
for execFloatFormatComparison, replacing only the root FormatComparison object."""
import json, shlex, subprocess, sys
from pathlib import Path

BUILD = Path("/workspace/build")
CLANG = "/workspace/user/.elan/toolchains/leanprover--lean4---v4.35.0/bin/clang"


def main():
    obj, exe, cpu = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve(), sys.argv[3]
    rsp = BUILD / "bin/execFloatFormatComparison.rsp"
    trace = json.loads((BUILD / "bin/execFloatFormatComparison.trace").read_text())
    command = shlex.split(trace["log"][0]["message"].removeprefix(".> "))
    assert command[0] == CLANG and command[-1] == "@" + str(rsp), command
    args = shlex.split(rsp.read_text())
    old = str(BUILD / "ir/FloatLibBenchmarks/Public/FormatComparison.c.o.export")
    assert args.count(old) == 1
    args = [str(obj) if a == old else a for a in args]
    new_rsp = exe.with_suffix(".rsp")
    new_rsp.write_text("\n".join(shlex.quote(a) for a in args) + "\n")
    argv = ["taskset", "-c", cpu, CLANG, "-o", str(exe), "@" + str(new_rsp)]
    exe.with_suffix(".link.json").write_text(json.dumps(argv, indent=2) + "\n")
    subprocess.run(argv, check=True)


if __name__ == "__main__":
    main()
