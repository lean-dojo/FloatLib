#!/usr/bin/env bash
# Compile a scratch Lean-generated C file with the exact flags Lake used for
# FloatLibBenchmarks.Public.Sweep (read from its trace), pinned to one CPU.
set -euo pipefail
src="${1:?C source}"; obj="${2:?object}"; cpu="${3:?cpu}"
trace=/workspace/build/ir/FloatLibBenchmarks/Public/Sweep.c.o.export.trace
python3 -I - "$trace" "$src" "$obj" > "$obj.cmd.json" <<'PY'
import json, shlex, sys
trace, src, obj = sys.argv[1:]
message = json.load(open(trace))["log"][0]["message"].removeprefix(".> ")
args = shlex.split(message)
out = []
for a in args:
    if a.endswith("/Sweep.c"):
        out.append(src)
    elif a.endswith("/Sweep.c.o.export"):
        out.append(obj)
    else:
        out.append(a)
assert src in out and obj in out
print(json.dumps(out))
PY
mapfile -t argv < <(python3 -I -c 'import json,sys; print("\n".join(json.load(open(sys.argv[1]))))' "$obj.cmd.json")
exec taskset -c "$cpu" "${argv[@]}"
