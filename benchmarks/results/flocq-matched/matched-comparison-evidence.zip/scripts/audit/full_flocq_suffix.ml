(* Full-value dump for the matched Flocq comparison rerun. The prefix of this
   file is the current flocq_format_bench.ml up to [run_binary], unchanged, so
   the formats, exact inputs and extracted operations are the benchmark's own. *)
let dump_value width group index = function
  | B754_finite (negative, mantissa, exponent) ->
      Printf.printf "%d|%s|%d|finite|%d|%s|%s\n" width group index
        (if negative then 1 else 0)
        (Big_int_Z.string_of_big_int mantissa)
        (Big_int_Z.string_of_big_int exponent)
  | B754_zero negative ->
      Printf.printf "%d|%s|%d|zero|%d|0|0\n" width group index
        (if negative then 1 else 0)
  | B754_infinity _ | B754_nan ->
      invalid_arg "benchmark fixture produced a non-finite value"

let () =
  Array.iter
    (fun (width, exponent_bits, precision) ->
      let emax = 1 lsl (exponent_bits - 1) in
      if precision <= 0 || precision >= emax then
        invalid_arg "Flocq requires 0 < precision < emax";
      let p = z_of_int precision and e = z_of_int emax in
      let xs = inputs_x precision emax in
      let ys = inputs_y precision emax in
      let sqrt_xs = inputs_sqrt precision emax in
      Array.iteri (fun i v -> dump_value width "input-x" i v) xs;
      Array.iteri (fun i v -> dump_value width "input-y" i v) ys;
      Array.iteri (fun i v -> dump_value width "input-sqrt" i v) sqrt_xs;
      List.iter
        (fun (name, operation) ->
          Array.iteri
            (fun i x -> dump_value width name i (operation p e x ys.(i)))
            xs)
        [ ("add", flocq_add); ("sub", flocq_sub); ("mul", flocq_mul);
          ("div", flocq_div) ];
      Array.iteri (fun i x -> dump_value width "sqrt" i (flocq_sqrt p e x)) sqrt_xs;
      Array.iteri
        (fun i x -> dump_value width "fma" i (flocq_fma p e x ys.(i) xs.(15 - i)))
        xs;
      flush stdout)
    formats
