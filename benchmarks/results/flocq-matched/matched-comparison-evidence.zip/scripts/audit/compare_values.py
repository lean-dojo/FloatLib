#!/usr/bin/env python3
"""Three-way complete-value comparison of the rerun dumps (FloatLib, MPFR, Flocq).

Normalization is the one in benchmarks/plots/flocq_matched.py: decode FloatLib's packed
encoding, keep sign and the entire significand, and move only powers of two into the exponent.
Also compares each new dump byte for byte with the recorded audit dump."""
import hashlib
import json
import sys
from pathlib import Path

EV = Path("/workspace/evidence/flocq-matched")
NEW = EV / "numerical-audit"
OLD = EV / "recorded-zip/numerical-audit"
EXPONENT_BITS = {6: 3, 8: 4, 16: 5, 32: 8, 64: 11, 128: 15,
                 256: 19, 512: 19, 1024: 19, 2048: 19, 4096: 19}
GROUPS = ("add", "sub", "mul", "div", "sqrt", "fma", "input-x", "input-y", "input-sqrt")


def normalize(sign, significand, exponent):
    assert sign in (0, 1) and significand >= 0
    if significand == 0:
        return ("zero", sign, 0, 0)
    shift = (significand & -significand).bit_length() - 1
    return ("finite", sign, significand >> shift, exponent + shift)


def parse(path, packed):
    values = {}
    for line in path.read_text().splitlines():
        f = line.split("|")
        width, group, index = int(f[0]), f[1], int(f[2])
        if packed:
            assert len(f) == 4
            bits = int(f[3])
            assert 0 <= bits < 1 << width
            frac_bits = width - EXPONENT_BITS[width] - 1
            sign = bits >> (width - 1)
            exp = (bits >> frac_bits) & ((1 << EXPONENT_BITS[width]) - 1)
            frac = bits & ((1 << frac_bits) - 1)
            assert exp != (1 << EXPONENT_BITS[width]) - 1, "non-finite"
            bias = (1 << (EXPONENT_BITS[width] - 1)) - 1
            sig = frac if exp == 0 else (1 << frac_bits) + frac
            value = normalize(sign, sig, max(1, exp) - bias - frac_bits)
        else:
            assert len(f) == 7 and f[3] in ("finite", "zero")
            if f[3] == "zero":
                assert f[5:] == ["0", "0"]
                value = normalize(int(f[4]), 0, 0)
            else:
                assert int(f[5]) > 0
                value = normalize(int(f[4]), int(f[5]), int(f[6]))
        k = (width, group, index)
        assert k not in values, k
        values[k] = value
    expected = {(w, g, i) for w in EXPONENT_BITS for g in GROUPS for i in range(16)}
    assert set(values) == expected, "incomplete matrix"
    return values


def main():
    lanes = {"floatlib": True, "mpfr": False, "flocq": False}
    values = {lane: parse(NEW / f"{lane}-values.txt", packed) for lane, packed in lanes.items()}
    keys = sorted(values["floatlib"])
    mismatches = [k for k in keys if not values["floatlib"][k] == values["mpfr"][k] == values["flocq"][k]]
    classes = {}
    for k in keys:
        v = values["floatlib"][k]
        c = f"{v[0]}/{'negative' if v[1] else 'positive'}"
        classes[c] = classes.get(c, 0) + 1
    per_width = []
    for w in EXPONENT_BITS:
        ks = [k for k in keys if k[0] == w]
        per_width.append({"width": w, "inputs": sum(k[1].startswith("input") for k in ks),
                          "outputs": sum(not k[1].startswith("input") for k in ks),
                          "mismatches": sum(k in mismatches for k in ks)})
    identical = {lane: (NEW / f"{lane}-values.txt").read_bytes() == (OLD / f"{lane}-values.txt").read_bytes()
                 for lane in lanes}
    report = {
        "status": "PASS" if not mismatches and all(identical.values()) else "FAIL",
        "rows_per_lane": len(keys),
        "input_rows_per_lane": sum(k[1].startswith("input") for k in keys),
        "result_rows_per_lane": sum(not k[1].startswith("input") for k in keys),
        "three_way_mismatches": [list(k) for k in mismatches],
        "classes": classes,
        "per_width": per_width,
        "byte_identical_to_recorded_dump": identical,
        "data_sha256": {lane: hashlib.sha256((NEW / f"{lane}-values.txt").read_bytes()).hexdigest()
                        for lane in lanes},
        "comparison": "entire significand and exponent, normalized only by removing powers of two; "
                      "sign and zero sign retained",
    }
    (NEW / "agreement.json").write_text(json.dumps(report, indent=2) + "\n")
    with (NEW / "canonical-values.jsonl").open("w") as out:
        for k in keys:
            out.write(json.dumps({"width": k[0], "group": k[1], "index": k[2], "values": {
                lane: [values[lane][k][0], values[lane][k][1], str(values[lane][k][2]), values[lane][k][3]]
                for lane in lanes}}) + "\n")
    print(json.dumps({k: report[k] for k in ("status", "rows_per_lane", "classes",
                                             "byte_identical_to_recorded_dump")}, indent=2))
    if report["status"] != "PASS":
        sys.exit(1)


if __name__ == "__main__":
    main()
