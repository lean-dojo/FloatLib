/* Full-value observer for the matched Flocq comparison rerun.
 * It includes FloatLib's unmodified MPFR benchmark adapter and reuses its
 * format table, exponent-range selection, and exact input construction, then
 * prints every prepared input and every fixture result in full
 * (mpfr_get_z_2exp), in the format of the recorded numerical audit. */
#define main original_format_benchmark_main
#include "/workspace/repo/benchmarks/c/exact_format_mpfr.c"
#undef main

static const unsigned widths[] = {6, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096};

static void dump_value(unsigned width, const char *group, unsigned index, mpfr_t value) {
  if (mpfr_nan_p(value) || mpfr_inf_p(value)) {
    fprintf(stderr, "non-finite value at %u %s %u\n", width, group, index);
    exit(EXIT_FAILURE);
  }
  if (mpfr_zero_p(value)) {
    printf("%u|%s|%u|zero|%d|0|0\n", width, group, index, mpfr_signbit(value) ? 1 : 0);
    return;
  }
  mpz_t significand;
  mpz_init(significand);
  mpfr_exp_t exponent = mpfr_get_z_2exp(significand, value);
  int negative = mpz_sgn(significand) < 0;
  mpz_abs(significand, significand);
  printf("%u|%s|%u|finite|%d|", width, group, index, negative);
  mpz_out_str(stdout, 10, significand);
  printf("|%ld\n", (long)exponent);
  mpz_clear(significand);
}

int main(void) {
  for (size_t w = 0; w < sizeof(widths) / sizeof(widths[0]); ++w) {
    const struct format_case *format = NULL;
    for (size_t i = 0; i < sizeof(format_cases) / sizeof(format_cases[0]); ++i) {
      if (format_cases[i].total_bits == widths[w]) format = &format_cases[i];
    }
    if (format == NULL) return EXIT_FAILURE;
    select_format_range(format);
    mpfr_t xs[ARRAY_SIZE], ys[ARRAY_SIZE], sqrt_xs[ARRAY_SIZE], rounded;
    init_inputs(format->precision, xs, ys, sqrt_xs);
    mpfr_init2(rounded, format->precision);
    for (unsigned i = 0; i < ARRAY_SIZE; ++i) dump_value(widths[w], "input-x", i, xs[i]);
    for (unsigned i = 0; i < ARRAY_SIZE; ++i) dump_value(widths[w], "input-y", i, ys[i]);
    for (unsigned i = 0; i < ARRAY_SIZE; ++i) dump_value(widths[w], "input-sqrt", i, sqrt_xs[i]);
    for (size_t op = 0; op < sizeof(operations) / sizeof(operations[0]); ++op) {
      /* Validate the adapter's fingerprint collision rule exactly as the timed adapter does. */
      validate_fixture_fingerprints(format, operations[op], xs, ys, sqrt_xs);
      for (unsigned i = 0; i < ARRAY_SIZE; ++i) {
        int ternary;
        const char *name = operations[op];
        if (strcmp(name, "add") == 0) ternary = mpfr_add(rounded, xs[i], ys[i], MPFR_RNDN);
        else if (strcmp(name, "sub") == 0) ternary = mpfr_sub(rounded, xs[i], ys[i], MPFR_RNDN);
        else if (strcmp(name, "mul") == 0) ternary = mpfr_mul(rounded, xs[i], ys[i], MPFR_RNDN);
        else if (strcmp(name, "div") == 0) ternary = mpfr_div(rounded, xs[i], ys[i], MPFR_RNDN);
        else if (strcmp(name, "sqrt") == 0) ternary = mpfr_sqrt(rounded, sqrt_xs[i], MPFR_RNDN);
        else if (strcmp(name, "fma") == 0)
          ternary = mpfr_fma(rounded, xs[i], ys[i], xs[ARRAY_SIZE - 1 - i], MPFR_RNDN);
        else abort();
        mpfr_subnormalize(rounded, ternary, MPFR_RNDN);
        dump_value(widths[w], name, i, rounded);
      }
    }
    mpfr_clear(rounded);
    clear_inputs(xs, ys, sqrt_xs);
  }
  mpfr_free_cache();
  return EXIT_SUCCESS;
}
