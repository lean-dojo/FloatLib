#!/usr/bin/env bash
# Rebuild the extracted Flocq kernel and benchmark with the exact commands of
# format-comparison.sh (plus --network none), in the pinned image, to compare
# artifact hashes with the recorded extraction manifest.
set -euo pipefail
source /workspace/evidence/flocq-matched/scripts/env.sh
out="$EV/flocq-build-repeat"
mkdir -p "$out"
image=leanfloat-flocq-bench:4.2.2
docker image inspect --format '{{.Id}}' "$image" > "$out/image-id.txt"
taskset -c 93 docker run --rm --network none \
  --cpuset-cpus 93 \
  --user "$(id -u):$(id -g)" \
  --env HOME=/home/coq \
  --volume "$REPO/benchmarks/rocq:/src:ro" \
  --volume "$out:/build" \
  --workdir /build \
  "$image" \
  sh -lc '
    cp /src/FlocqKernel.v .
    cp /src/flocq_format_bench.ml .
    cp /src/monotonic_clock.c .
    opam exec -- coqc FlocqKernel.v
    opam exec -- ocamlfind ocamlopt \
      -O3 -linkpkg -package zarith,unix \
      monotonic_clock.c flocq_kernel.mli flocq_kernel.ml \
      flocq_format_bench.ml -cclib -lrt \
      -o flocq_format_bench
    coqc --version; ocamlfind ocamlopt -version; opam list --installed coq-flocq zarith coq ocaml 2>/dev/null
  '
(cd "$out" && sha256sum FlocqKernel.v flocq_kernel.ml flocq_kernel.mli flocq_kernel.cmx flocq_kernel.o monotonic_clock.o flocq_format_bench > SHA256SUMS)
cat "$out/SHA256SUMS"
