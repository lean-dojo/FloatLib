#!/usr/bin/env bash
# Pre-build the TensorLib side exactly as compare-tensorlib.py does without
# --skip-build (adapter copy, lakefile target, cache get, build).
set -euo pipefail
source /workspace/evidence/flocq-matched/scripts/env.sh
work="$EV/tensorlib/work"; tensorlib="$work/TensorLib"
cpu="${1:-94}"
python3 -I - "$REPO" "$tensorlib" <<'PY'
import shutil, sys
from pathlib import Path
root, tensorlib = Path(sys.argv[1]), Path(sys.argv[2])
shutil.copyfile(root / "benchmarks/lean/FloatLibBenchmarks/Support/ConversionProtocol.lean", tensorlib / "ConversionProtocol.lean")
shutil.copyfile(root / "benchmarks/external/tensorlib/Main.lean", tensorlib / "ComparisonMain.lean")
lakefile = tensorlib / "lakefile.lean"
target = ("\nlean_lib ConversionProtocol\n\nlean_exe conversionComparison where\n"
          "  root := `ComparisonMain\n")
if target not in lakefile.read_text():
    lakefile.write_text(lakefile.read_text() + target)
PY
cd "$tensorlib"
echo "cache get start $(date -u +%FT%TZ)"
taskset -c "$cpu" lake exe cache get TensorLib/Float.lean > "$work/tensorlib-cache.log" 2>&1
echo "build start $(date -u +%FT%TZ)"
LEAN_NUM_THREADS=1 taskset -c "$cpu" lake build conversionComparison > "$work/tensorlib-build.log" 2>&1
echo "done $(date -u +%FT%TZ)"
ls -la .lake/build/bin/conversionComparison
