"""Assemble the requested one-trial slide from checked measurements."""

from pathlib import Path
import csv
import hashlib
import json
import math
import sys

root = Path(__file__).resolve().parent
supplement = Path(sys.argv[1])
output = root / "one-trial"
output.mkdir(exist_ok=True)
widths = {6, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096}
operations = {"add", "sub", "mul", "div", "sqrt", "fma"}
implementations = {"ExecFloat", "Flocq", "MPFR"}
series = {
    "ExecFloat": "ExecFloat binary proved software",
    "Flocq": "Flocq binary reference (precision model)",
    "MPFR": "MPFR (binary) software reference",
}
expected = {(i, w, o) for i in implementations for w in widths for o in operations}
replacement_keys = {(i, w, "sqrt") for i in implementations for w in (1024, 2048, 4096)}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def key(row):
    return row["implementation"], int(row["totalBits"]), row["operation"]


def agreement(row):
    return tuple(int(row[column]) % (1 << 64) for column in (
        "agreementIterations", "agreementSink", "agreementFixtureTraceDigest"
    ))


original_path = root / "campaign/raw/trial-01.csv"
original = read_csv(original_path)
by_key = {key(row): row for row in original}
assert len(original) == 198 and set(by_key) == expected
assert all(int(r["totalNanos"]) >= 50_000_000 and int(r["iterations"]) > 0 for r in original)
for width in widths:
    for operation in operations:
        prefixes = {agreement(by_key[(i, width, operation)]) for i in implementations}
        assert len(prefixes) == 1 and next(iter(prefixes))[0] == 256

campaign = json.loads((supplement / "campaign.json").read_text())
assert campaign["status"] == "PASS" and campaign["trials_per_cell"] == 1
assert campaign["cpu"] == 39 and campaign["fixtures_per_block"] == 16
replacement_path = supplement / "raw.csv"
replacement = read_csv(replacement_path)
replacement_by_key = {key(row): row for row in replacement}
assert len(replacement) == 9 and set(replacement_by_key) == replacement_keys
for row in replacement:
    assert int(row["trial"]) == 1
    assert int(row["iterations"]) == 16 * int(row["blocks"])
    assert int(row["totalNanos"]) >= 50_000_000
for width in (1024, 2048, 4096):
    prefixes = {agreement(replacement_by_key[(i, width, "sqrt")]) for i in implementations}
    assert len(prefixes) == 1 and next(iter(prefixes))[0] == 16

source_hashes = json.loads((root / "campaign-launch-sources.json").read_text())
for path, digest in source_hashes.items():
    assert sha(root.parent / "FloatLib" / path) == digest, path

rows = []
for cell in sorted(expected):
    balanced = cell in replacement_keys
    source = replacement_by_key[cell] if balanced else by_key[cell]
    row = dict(source)
    row["series"] = series[cell[0]]
    row["trials"] = 1
    row["nanosPerOp"] = f'{int(row["totalNanos"]) / int(row["iterations"]):.9f}'
    row["source"] = "balanced-sqrt/raw.csv" if balanced else "main/trial-01.csv"
    row["blocks"] = row.get("blocks", "")
    row.pop("trial", None)
    rows.append(row)

columns = [
    "series", *original[0].keys(), "trials", "blocks", "nanosPerOp", "source"
]
summary = output / "matched-benchmark-summary.csv"
with summary.open("w") as stream:
    writer = csv.DictWriter(stream, fieldnames=columns, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
reloaded = read_csv(summary)
assert len(reloaded) == 198
for row in reloaded:
    assert math.isclose(
        float(row["nanosPerOp"]), int(row["totalNanos"]) / int(row["iterations"]),
        rel_tol=1e-10, abs_tol=1e-6,
    )

receipt = {
    "status": "PASS",
    "scope": "One trial per plotted cell; variability is not estimated.",
    "summaryCells": 198,
    "trialsPerCell": 1,
    "mainTrialCellsUsed": 189,
    "balancedSqrtCellsUsed": 9,
    "mainThreeWay256StepChecks": 66,
    "balancedThreeWay16OperandChecks": 3,
    "minimumMeasuredNanoseconds": min(int(row["totalNanos"]) for row in rows),
    "allTimePerOperationValuesRecomputed": True,
    "launchSourceHashesUnchanged": True,
    "sources": {
        "main/trial-01.csv": sha(original_path),
        "balanced-sqrt/raw.csv": sha(replacement_path),
        "balanced-sqrt/campaign.json": sha(supplement / "campaign.json"),
    },
    "summarySha256": sha(summary),
}
(output / "review.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
