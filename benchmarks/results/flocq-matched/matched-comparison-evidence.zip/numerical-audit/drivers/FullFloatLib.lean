/- Scratch full-value dump for the matched Flocq comparison rerun; not part of FloatLib.
FloatLib's MIT license applies to the reused benchmark code. -/
import FloatLibBenchmarks.Public.Sweep

open FloatLib.Floats FloatLib.Numerics
open FloatLib.Floats.Formats.BinaryInterchange
open FloatLibBenchmarks.Support
open scoped FloatLib.Floats.ExecFloat.Backend.PlanningThroughput

set_option maxHeartbeats 0

namespace FullValues

/-- Complete raw encoding, as in the recorded audit (`BenchmarkCarrier.toModel` then `toNatBits`). -/
def raw {F : Type} [EncodedFormat F] [BenchmarkCarrier F FloatFormat Model]
    (value : ExecFloat F) : Nat :=
  (BenchmarkCarrier.toModel (Format := FloatFormat) (Model := Model) value).toNatBits

structure Ops (F : Type) [EncodedFormat F] where
  add : ExecFloat F → ExecFloat F → ExecFloat F
  sub : ExecFloat F → ExecFloat F → ExecFloat F
  mul : ExecFloat F → ExecFloat F → ExecFloat F
  div : ExecFloat F → ExecFloat F → ExecFloat F
  sqrt : ExecFloat F → ExecFloat F
  fma : ExecFloat F → ExecFloat F → ExecFloat F → ExecFloat F

/-- One line per (index, group), in the recorded audit's order. -/
def dump {F : Type} [EncodedFormat F] [BenchmarkCarrier F FloatFormat Model]
    (width : Nat) (ops : Ops F) (tag : String := "") : IO Unit := do
  let xs := FloatLibBenchmarks.Public.Sweep.inputsX F
  let ys := FloatLibBenchmarks.Public.Sweep.inputsY F
  let ss := FloatLibBenchmarks.Public.Sweep.inputsSqrt F
  for i in [:16] do
    let x := xs[i]!
    let y := ys[i]!
    let s := ss[i]!
    if tag.isEmpty then
      IO.println s!"{width}|input-x|{i}|{raw x}"
      IO.println s!"{width}|input-y|{i}|{raw y}"
      IO.println s!"{width}|input-sqrt|{i}|{raw s}"
    IO.println s!"{width}|{tag}add|{i}|{raw (ops.add x y)}"
    IO.println s!"{width}|{tag}sub|{i}|{raw (ops.sub x y)}"
    IO.println s!"{width}|{tag}mul|{i}|{raw (ops.mul x y)}"
    IO.println s!"{width}|{tag}div|{i}|{raw (ops.div x y)}"
    IO.println s!"{width}|{tag}sqrt|{i}|{raw (ops.sqrt s)}"
    IO.println s!"{width}|{tag}fma|{i}|{raw (ops.fma x y xs[15 - i]!)}"

/-- Public operations under `PlanningThroughput`, as in `FormatComparison`. -/
macro "public_ops" e:num f:num : term =>
  `(({ add := fun a b => ExecFloat.add a b, sub := fun a b => ExecFloat.sub a b,
       mul := fun a b => ExecFloat.mul a b, div := fun a b => ExecFloat.div a b,
       sqrt := fun a => ExecFloat.sqrt a, fma := fun a b c => ExecFloat.fma a b c } :
      Ops (ExecFloat.Binary.Family $e $f)))

/-- The pinned proved word kernels that `FormatComparison` uses at binary32 and binary64. -/
macro "word_ops" e:num f:num : term =>
  `(({ add := fun a b => Configured.Backend.wordAdd a b,
       sub := fun a b => Configured.Backend.wordSub a b,
       mul := fun a b => Configured.Backend.wordMul a b,
       div := fun a b => Configured.Backend.wordDiv a b,
       sqrt := fun a => Configured.Backend.wordSqrt a,
       fma := fun a b c => Configured.Backend.wordFma a b c } :
      Ops (ExecFloat.Binary.Family $e $f)))

@[noinline] def values6 : IO Unit := dump 6 (public_ops 3 2)
@[noinline] def values8 : IO Unit := dump 8 (public_ops 4 3)
@[noinline] def values16 : IO Unit := dump 16 (public_ops 5 10)
@[noinline] def values32 : IO Unit := dump 32 (word_ops 8 23)
@[noinline] def values64 : IO Unit := dump 64 (word_ops 11 52)
@[noinline] def values128 : IO Unit := dump 128 (public_ops 15 112)
@[noinline] def values256 : IO Unit := dump 256 (public_ops 19 236)
@[noinline] def values512 : IO Unit := dump 512 (public_ops 19 492)
@[noinline] def values1024 : IO Unit := dump 1024 (public_ops 19 1004)
@[noinline] def values2048 : IO Unit := dump 2048 (public_ops 19 2028)
@[noinline] def values4096 : IO Unit := dump 4096 (public_ops 19 4076)
@[noinline] def public32 : IO Unit := dump 32 (public_ops 8 23) "public-"
@[noinline] def public64 : IO Unit := dump 64 (public_ops 11 52) "public-"

def values : IO Unit := do
  values6
  values8
  values16
  values32
  values64
  values128
  values256
  values512
  values1024
  values2048
  values4096

/-- Public dispatch at binary32 and binary64, to compare with the pinned word kernels. -/
def publicWord : IO Unit := do
  public32
  public64

end FullValues

def main (args : List String) : IO UInt32 := do
  match args with
  | ["values"] => FullValues.values; return 0
  | ["public-word"] => FullValues.publicWord; return 0
  | _ => IO.eprintln "usage: full-floatlib (values|public-word)"; return 2
